#Filename test2.py 

def Add(a, b): 
	print "a="
	print a
	print "b="
	print b
    print "a+b=", a+b


def Hello(s): 
    print "Hello, world!";
    print s;
