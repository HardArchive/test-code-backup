#pragma once

class CRegister
{
public:
	CRegister(void);
	~CRegister(void);

public:
	void GetMachine(char* pszMachine);

private:
	void GetMacAddress(char* pszMacBuf);
	void GetDiskSerialNum(char* pszDiskSerialBuf);
	void GetCPUSerialNum(char* pszCPUSerialBuf);
};
