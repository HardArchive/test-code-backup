#include "StdAfx.h"
#include "Register.h"
#include <Nb30.h>
#pragma comment (lib,"netapi32.lib")

struct ADAPTER_INFO
{	
	ADAPTER_STATUS nStatus;
	NAME_BUFFER    nBuffer;
};

CRegister::CRegister(void)
{
}

CRegister::~CRegister(void)
{
}

void CRegister::GetMacAddress(char* pszMacBuf)
{
	char szMacAddr[6] = {0};
	NCB nInfo;
	memset(&nInfo,0,sizeof(NCB));
	nInfo.ncb_command  = NCBRESET;
	nInfo.ncb_lana_num = 0;
	Netbios(&nInfo);
	ADAPTER_INFO AdaINfo;
	//��ʼ��NetBIOS
	memset(&nInfo,0,sizeof(NCB));
	nInfo.ncb_command  = NCBASTAT;
	nInfo.ncb_lana_num = 0;
	nInfo.ncb_buffer   = (unsigned char*)&AdaINfo;
	nInfo.ncb_length   = sizeof(ADAPTER_INFO);
	strncpy((char*)nInfo.ncb_callname,"*",NCBNAMSZ);
	Netbios(&nInfo);	
	//CString MacAddr;
	sprintf(szMacAddr, "%02X%02X%02X%02X%02X%02X",
		AdaINfo.nStatus.adapter_address[0],
		AdaINfo.nStatus.adapter_address[1],
		AdaINfo.nStatus.adapter_address[2],
		AdaINfo.nStatus.adapter_address[3],
		AdaINfo.nStatus.adapter_address[4],
		AdaINfo.nStatus.adapter_address[5]
	);
	//MacAddr.Format("%02X%02X%02X%02X%02X%02X",
	//	AdaINfo.nStatus.adapter_address[0],
	//	AdaINfo.nStatus.adapter_address[1],
	//	AdaINfo.nStatus.adapter_address[2],
	//	AdaINfo.nStatus.adapter_address[3],
	//	AdaINfo.nStatus.adapter_address[4],
	//	AdaINfo.nStatus.adapter_address[5]
	//);
	//return MacAddr.Mid(4,4);
	strncpy(pszMacBuf, szMacAddr+4, 4);

}

void CRegister::GetDiskSerialNum(char* pszDiskSerialBuf)
{
	char szSerial[8] = {0};
	DWORD ser = 0;
	char namebuf[128];
	char filebuf[128];
	//��ȡC�̵����к�
	::GetVolumeInformation("c:\\",namebuf,128,&ser,0,0,filebuf,128);
	//CString DiskID;
	sprintf(szSerial, "%08X", ser);
	//DiskID.Format("%08X",ser);
	//return DiskID.Mid(3,3);
	strncpy(pszDiskSerialBuf, szSerial+3, 3);

}

void CRegister::GetCPUSerialNum(char* pszCPUSerialBuf)
{
	//char szCpuSerial[MAX_PATH] = {0};
	//��ȡCPU���к�
	unsigned long s1,s2; //4���ֽ�    
	char sel;   
	sel='1';   
	char szCPUID[32] = {0}, szCPUID1[16] = {0}, szCPUID2[16] = {0};
	//CString CpuID,CPUID1,CPUID2;   
	__asm{   
		mov eax,01h   
			xor edx,edx   
			cpuid   
			mov s1,edx   
			mov s2,eax   
	}   
	sprintf(szCPUID1, "%08X%08X",s1,s2);
	//CPUID1.Format("%08X%08X",s1,s2);   
	__asm{   
		mov eax,03h   
			xor ecx,ecx   
			xor edx,edx   
			cpuid   
			mov s1,edx   
			mov s2,ecx   
	}   
	//CPUID2.Format("%08X%08X",s1,s2);
	sprintf(szCPUID2, "%08X%08X",s1,s2);
	//CpuID=CPUID1+CPUID2;
	sprintf(szCPUID, "%s%s", szCPUID1, szCPUID2);  //ȡ��CPUID�ַ���
	//return CpuID.Mid(5,3);
	strncpy(pszCPUSerialBuf, szCPUID+5, 3);
	//sprintf(pszCPUSerialBuf, "%s", szCPUID)

}

void CRegister::GetMachine(char* pszMachine)
{
	int iNum = 0;
	char szMachine[MAX_PATH] = {0};
	char szCPUSerialNum[4] = {0};
	char szDiskSerialNum[3] = {0};
	char szMacAddress[5] = {0};
	//����һ����Կ����
	char code[16][3]={"ah","tm","ib","nw","rt","vx","zc","gf",
		"pn","xq","fc","oj","wm","eq","np","qw"};

	//��ȡCPU���к�+Ӳ�����к�+����MAC��ַ
	GetCPUSerialNum(szCPUSerialNum);
	GetDiskSerialNum(szDiskSerialNum);
	GetMacAddress(szMacAddress);
	
	sprintf(szMachine, "%s%s%s", szCPUSerialNum, szDiskSerialNum, szMacAddress);


	//����ʮ���������ִ���Կ������ѡ���ַ���
	for(int i=0; i<10; i++)
	{
		char p = szMachine[i];
		// A - Z
		if (p >= 65 && p <= 90)
		{
			p -= 32; 
		}

		if(p>='a'&&p<='f')
			iNum = p - 'a' + 10;
		else
			iNum = p - '0';
		//CString tmp = code[num];
		//reg += tmp;
		pszMachine[i] = code[iNum];
	}
	//reg.MakeUpper();
	//GetDlgItem(IDC_EDIT2)->SetWindowText(reg.Mid(0,5));
	//GetDlgItem(IDC_EDIT3)->SetWindowText(reg.Mid(5,5));
	//GetDlgItem(IDC_EDIT4)->SetWindowText(reg.Mid(10,5));
	//GetDlgItem(IDC_EDIT5)->SetWindowText(reg.Mid(15,5));

}