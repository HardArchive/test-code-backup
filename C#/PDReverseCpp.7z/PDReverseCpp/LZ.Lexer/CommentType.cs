namespace LZ.Lexer
{
    using System;

    public enum CommentType
    {
        Block,
        SingleLine,
        Documentation
    }
}
