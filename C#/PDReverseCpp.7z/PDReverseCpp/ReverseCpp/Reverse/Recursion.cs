﻿namespace LZ.Reverse
{
    using System;

    public enum Recursion
    {
        NONE,
        LIMITED,
        FULL
    }
}

