// First_ATL.cpp : Implementation of CFirst_ATL
#include "stdafx.h"
#include "Simple_ATL.h"
#include "First_ATL.h"

/////////////////////////////////////////////////////////////////////////////
// CFirst_ATL


STDMETHODIMP CFirst_ATL::AddNumbers(long Num1, long Num2, long *ReturnVal)
{
	// TODO: Add your implementation code here
	*ReturnVal = Num1 + Num2;

	return S_OK;
}
