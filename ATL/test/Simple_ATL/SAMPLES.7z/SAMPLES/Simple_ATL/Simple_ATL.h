

/* this ALWAYS GENERATED file contains the definitions for the interfaces */


 /* File created by MIDL compiler version 7.00.0555 */
/* at Fri Aug 16 17:42:47 2013
 */
/* Compiler settings for .\Simple_ATL.idl:
    Oicf, W1, Zp8, env=Win32 (32b run), target_arch=X86 7.00.0555 
    protocol : dce , ms_ext, c_ext, robust
    error checks: allocation ref bounds_check enum stub_data 
    VC __declspec() decoration level: 
         __declspec(uuid()), __declspec(selectany), __declspec(novtable)
         DECLSPEC_UUID(), MIDL_INTERFACE()
*/
/* @@MIDL_FILE_HEADING(  ) */

#pragma warning( disable: 4049 )  /* more than 64k source lines */


/* verify that the <rpcndr.h> version is high enough to compile this file*/
#ifndef __REQUIRED_RPCNDR_H_VERSION__
#define __REQUIRED_RPCNDR_H_VERSION__ 475
#endif

#include "rpc.h"
#include "rpcndr.h"

#ifndef __RPCNDR_H_VERSION__
#error this stub requires an updated version of <rpcndr.h>
#endif // __RPCNDR_H_VERSION__

#ifndef COM_NO_WINDOWS_H
#include "windows.h"
#include "ole2.h"
#endif /*COM_NO_WINDOWS_H*/

#ifndef __Simple_ATL_h__
#define __Simple_ATL_h__

#if defined(_MSC_VER) && (_MSC_VER >= 1020)
#pragma once
#endif

/* Forward Declarations */ 

#ifndef __IFirst_ATL_FWD_DEFINED__
#define __IFirst_ATL_FWD_DEFINED__
typedef interface IFirst_ATL IFirst_ATL;
#endif 	/* __IFirst_ATL_FWD_DEFINED__ */


#ifndef __First_ATL_FWD_DEFINED__
#define __First_ATL_FWD_DEFINED__

#ifdef __cplusplus
typedef class First_ATL First_ATL;
#else
typedef struct First_ATL First_ATL;
#endif /* __cplusplus */

#endif 	/* __First_ATL_FWD_DEFINED__ */


/* header files for imported files */
#include "oaidl.h"
#include "ocidl.h"

#ifdef __cplusplus
extern "C"{
#endif 


#ifndef __IFirst_ATL_INTERFACE_DEFINED__
#define __IFirst_ATL_INTERFACE_DEFINED__

/* interface IFirst_ATL */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_IFirst_ATL;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("C399F5EF-3D23-4DF4-BEA8-FDEAE3C29776")
    IFirst_ATL : public IDispatch
    {
    public:
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE AddNumbers( 
            /* [in] */ long Num1,
            /* [in] */ long Num2,
            /* [out] */ long *ReturnVal) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IFirst_ATLVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            IFirst_ATL * This,
            /* [in] */ REFIID riid,
            /* [annotation][iid_is][out] */ 
            __RPC__deref_out  void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            IFirst_ATL * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            IFirst_ATL * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            IFirst_ATL * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            IFirst_ATL * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            IFirst_ATL * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [range][in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            IFirst_ATL * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS *pDispParams,
            /* [out] */ VARIANT *pVarResult,
            /* [out] */ EXCEPINFO *pExcepInfo,
            /* [out] */ UINT *puArgErr);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *AddNumbers )( 
            IFirst_ATL * This,
            /* [in] */ long Num1,
            /* [in] */ long Num2,
            /* [out] */ long *ReturnVal);
        
        END_INTERFACE
    } IFirst_ATLVtbl;

    interface IFirst_ATL
    {
        CONST_VTBL struct IFirst_ATLVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IFirst_ATL_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 

#define IFirst_ATL_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 

#define IFirst_ATL_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 


#define IFirst_ATL_GetTypeInfoCount(This,pctinfo)	\
    ( (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo) ) 

#define IFirst_ATL_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    ( (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo) ) 

#define IFirst_ATL_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    ( (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId) ) 

#define IFirst_ATL_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    ( (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr) ) 


#define IFirst_ATL_AddNumbers(This,Num1,Num2,ReturnVal)	\
    ( (This)->lpVtbl -> AddNumbers(This,Num1,Num2,ReturnVal) ) 

#endif /* COBJMACROS */


#endif 	/* C style interface */




#endif 	/* __IFirst_ATL_INTERFACE_DEFINED__ */



#ifndef __SIMPLE_ATLLib_LIBRARY_DEFINED__
#define __SIMPLE_ATLLib_LIBRARY_DEFINED__

/* library SIMPLE_ATLLib */
/* [helpstring][version][uuid] */ 


EXTERN_C const IID LIBID_SIMPLE_ATLLib;

EXTERN_C const CLSID CLSID_First_ATL;

#ifdef __cplusplus

class DECLSPEC_UUID("153FC33C-8D26-4620-ACBA-3371AAC67A23")
First_ATL;
#endif
#endif /* __SIMPLE_ATLLib_LIBRARY_DEFINED__ */

/* Additional Prototypes for ALL interfaces */

/* end of Additional Prototypes */

#ifdef __cplusplus
}
#endif

#endif


