// First_ATL.h : Declaration of the CFirst_ATL

#ifndef __FIRST_ATL_H_
#define __FIRST_ATL_H_

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// CFirst_ATL
class ATL_NO_VTABLE CFirst_ATL : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CFirst_ATL, &CLSID_First_ATL>,
	public IDispatchImpl<IFirst_ATL, &IID_IFirst_ATL, &LIBID_SIMPLE_ATLLib>
{
public:
	CFirst_ATL()
	{
	}

DECLARE_REGISTRY_RESOURCEID(IDR_FIRST_ATL)
DECLARE_NOT_AGGREGATABLE(CFirst_ATL)

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CFirst_ATL)
	COM_INTERFACE_ENTRY(IFirst_ATL)
	COM_INTERFACE_ENTRY(IDispatch)
END_COM_MAP()

// IFirst_ATL
public:
	STDMETHOD(AddNumbers)(/*[in]*/ long Num1, /*[in]*/ long Num2, /*[out]*/ long *ReturnVal);
};

#endif //__FIRST_ATL_H_
