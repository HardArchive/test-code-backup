//////////////////////////////////////////////////////////////////////
//
// GUID definitions for the SimpleMsgBox interface and coclass
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_SIMPLEMSGBOXCOMDEF_H__E66A448E_57A8_448B_B78D_E86E8A66F098__INCLUDED_)
#define AFX_SIMPLEMSGBOXCOMDEF_H__E66A448E_57A8_448B_B78D_E86E8A66F098__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

struct __declspec(uuid("{7D51904D-1645-4a8c-BDE0-0F4A44FC38C4}")) ISimpleMsgBox;
class  __declspec(uuid("{7D51904E-1645-4a8c-BDE0-0F4A44FC38C4}")) CSimpleMsgBoxImpl;

#endif  // defined (AFX_SIMPLEMSGBOXCOMDEF_H__E66A448E_57A8_448B_B78D_E86E8A66F098__INCLUDED_)
