//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by OpenedFiles.rc
//
#define IDS_PROJNAME                    100
#define IDS_INFO                        101
#define IDR_INTERFACECLS                102
#define IDD_DIALOG1                     201
#define IDC_LIST1                       201
#define IDR_MENU1                       202
#define IDC_PROGRESS1                   202
#define IDD_DIALOG2                     203
#define IDI_ICON1                       204
#define IDD_PROGRESS_DLG                205
#define IDC_COMBO2                      207
#define IDR_XPDRIVER                    208
#define IDR_TOOLBAR1                    218
#define IDR_TOOLBAR2                    221
#define IDI_ICON2                       233
#define IDI_ICON4                       238
#define IDI_ICON5                       239
#define IDI_ICON3                       241
#define IDI_ICON6                       242
#define IDR_VISTA_DRIVER                245
#define ID_MAIN_TERMINATE               32768
#define ID_MAIN_TERMINATEALLPROCESS     32769
#define ID_BUTTONREFRESH                32770
#define ID_BUTTON32773                  32773
#define ID_MAIN_COPYFILENAME            32774
#define ID_MAIN_FINDTARGET              32775
#define ID_MAIN_CLOSEHANDLE             32776
#define ID_MAIN_CLOSEALLHANDLES         32777
#define ID_MAIN_SHOWLOADEDMODULESONLY   32778
#define ID_MAIN_SHOWLOADEDFILESONLY     32779

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        246
#define _APS_NEXT_COMMAND_VALUE         32780
#define _APS_NEXT_CONTROL_VALUE         208
#define _APS_NEXT_SYMED_VALUE           103
#endif
#endif
