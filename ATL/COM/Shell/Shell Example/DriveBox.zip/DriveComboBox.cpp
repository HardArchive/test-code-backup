// DriveComboBox.cpp : implementation file
//

#include "stdafx.h"
#include "DriveComboBox.h"

#define ICONSTARTX  3	// the output x position of the icon in the item.
#define SPACE	5		// the space between the icon and the text.

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDriveComboBox

CDriveComboBox::CDriveComboBox()
{
}

CDriveComboBox::~CDriveComboBox()
{
}


BEGIN_MESSAGE_MAP(CDriveComboBox, CComboBox)
	//{{AFX_MSG_MAP(CDriveComboBox)
	ON_CONTROL_REFLECT(CBN_SELCHANGE, OnSelchange)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDriveComboBox message handlers

void CDriveComboBox::DrawItem(LPDRAWITEMSTRUCT lpDrawItemStruct) 
{
	// TODO: Add your code to draw the specified item
	if(lpDrawItemStruct->CtlType!=ODT_COMBOBOX)
		return;
	if(lpDrawItemStruct->itemID <0)
		return;
	CImageList	*imagelist;
	HIMAGELIST	himSmall;
	SHFILEINFO	stFileInfo;

	COLORREF	textColor=::GetSysColor( COLOR_WINDOWTEXT );//text color
	COLORREF	backColor=::GetSysColor(COLOR_WINDOW);//the item's back color
	
	CString itemString;// The item's string
	CString	itemPath;// The item string's path
	// get item string
	GetLBText(lpDrawItemStruct->itemID, itemString );
	CRect	itemRect=lpDrawItemStruct->rcItem;

	CDC* pDC = CDC::FromHandle(lpDrawItemStruct->hDC);
	// First,let's draw the item's background.
	if( lpDrawItemStruct->itemState & ODS_FOCUS )
	{
		//Invert the text color
		backColor=::GetSysColor(COLOR_HIGHLIGHT);
		textColor=0x00FFFFFF & ~textColor;
	}
	pDC->FillRect (&itemRect,&CBrush(backColor));
	// if the item has foucs,we should draw a focus rect.
	if( lpDrawItemStruct->itemState & ODS_FOCUS )
	{
		pDC->DrawFocusRect( &itemRect);
	}
	pDC->SetBkMode(TRANSPARENT);
	pDC->SetTextColor (textColor);
	// We should get the itemString's path.
	// Get the drive label
	itemPath=itemString.Mid(2,1)+CString(":\\");
	itemString=itemPath;
	// Draw the icon and text.
	// Get the file's small icon.
	// Use SHGetFileInfo(),you can get a lot of infomation about files,
	//    directory,drives such as icon,stasus,etc.
	himSmall=(HIMAGELIST):: SHGetFileInfo(_T(itemPath),0,
			&stFileInfo,sizeof(stFileInfo),SHGFI_SYSICONINDEX | SHGFI_SMALLICON);
	imagelist=CImageList::FromHandle(himSmall);
	//Draw the icon.
	imagelist->Draw (pDC,stFileInfo.iIcon ,CPoint(itemRect.left+ICONSTARTX,itemRect.top+1),ILD_TRANSPARENT);
	//last we'll draw the string.
	itemRect.OffsetRect (ICONSTARTX+SPACE+16,0);
	DrawText(lpDrawItemStruct->hDC, itemString, -1, &itemRect,
				DT_LEFT | DT_VCENTER | DT_SINGLELINE);
}

void CDriveComboBox::MeasureItem(LPMEASUREITEMSTRUCT lpMeasureItemStruct) 
{
	// TODO: Add your code to determine the size of specified item
}

CString CDriveComboBox::GetCurDrive()
{
	CString itemString,itemPath;// The item's string and its path.
	GetLBText(GetCurSel(), itemString );
	itemPath=itemString.Mid(2,1)+CString(":\\");
	return itemPath;
}

BOOL CDriveComboBox::InitBox(UINT res, CWnd *parent,UINT msg)
{
	m_cwndParent=parent;
	m_nMsg=msg;
	if(SubclassDlgItem(res, parent)==FALSE)
		return FALSE;
	this->Dir(0x4000,"c:\\");
	this->SetCurSel (1);
	return TRUE;
}

void CDriveComboBox::OnSelchange() 
// use the message defined in parent 
// window,we can notify our parent
// that our drive has changed.
// If you don't need this,you 
//can deal it with it's parent directly.
{
	// TODO: Add your control notification handler code here
	m_cwndParent->PostMessage(m_nMsg, DRIVES, 0);
}
