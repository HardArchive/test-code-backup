#include <windows.h>
#include <stdio.h>
#include <tchar.h>
#include "CH364PGMDLL.h"
#include "resource.h"

#pragma comment(lib,"CH364PGMDLL")

typedef	struct	_CH366_IO_REG {	   // CH364оƬ�����üĴ���
	UCHAR CH366CfgDout;                // 00H ����Ĵ���
	UCHAR CH366CfgCtrl;                // 01H ���ƼĴ���
	UCHAR CH366CfgDin;                 // 02H ����Ĵ���
	UCHAR CH366CfgSet;                 // 03H ���üĴ���
	ULONG rev[61];
	UCHAR CH366CfgAux;				   // F8H �����Ĵ���
} mCH366_IO_REG, *mPCH366_IO_REG;


#define         APP_NAME                _T("IsoWin")


HINSTANCE       ghInstance;
HWND            ghDialog;
BOOL            m_open;
HANDLE          Drv_Handle;

mPCH366_IO_REG  CfgRegBaseAdd;
UCHAR           gMyWndName[ 64 ];

void MyShowErr( void )
{
	ULONG le;
	TCHAR msg[128], buf[256];

    le = GetLastError();
    FormatMessage( FORMAT_MESSAGE_FROM_SYSTEM, 0, le,
        MAKELANGID( LANG_NEUTRAL, SUBLANG_DEFAULT ), msg, sizeof(msg), 0);
    _stprintf( buf, _T("�������:0x%x,%s"), le, msg );
    MessageBox( ghDialog, buf, gMyWndName, MB_ICONWARNING | MB_OK );
}

BOOL RunOneOnly( void )
{
	ULONG i;
	TCHAR buf[MAX_PATH];
 
    _tcsncpy( buf, _T(APP_NAME"_RunOneEvent"), sizeof(buf) );
    buf[ sizeof(buf) - 1 ] = 0;
	CreateEvent( NULL, TRUE, TRUE, buf );
	i = GetLastError( );
	if( i == ERROR_ALREADY_EXISTS )
        return FALSE;
	return TRUE;
}

BOOL IsAdmin( void )
{
	HANDLE			hAccessToken;
	TCHAR			InfoBuffer[1024];
	PTOKEN_GROUPS	ptgGroups;
	ULONG			dwInfoBufferSize;
	PSID			psidAdministrators;
	ULONG           i;
	BOOL			bRet;
	SID_IDENTIFIER_AUTHORITY siaNtAuthority = SECURITY_NT_AUTHORITY;


	bRet = FALSE;
    if(!OpenProcessToken(GetCurrentProcess(),TOKEN_QUERY,&hAccessToken))
		goto cleanup;

    bRet = GetTokenInformation( hAccessToken, TokenGroups,InfoBuffer,
		1024, &dwInfoBufferSize);

    CloseHandle(hAccessToken);

    if(!bRet)
       goto cleanup;

    if( !AllocateAndInitializeSid( &siaNtAuthority, 2, SECURITY_BUILTIN_DOMAIN_RID,
		DOMAIN_ALIAS_RID_ADMINS, 0, 0, 0, 0, 0, 0, &psidAdministrators) )
       goto cleanup;

    bRet = FALSE;
    ptgGroups = (PTOKEN_GROUPS)InfoBuffer;
    for(i = 0; i < ptgGroups->GroupCount; i++)
    {
        if(EqualSid(psidAdministrators,ptgGroups->Groups[i].Sid))
        {
            bRet = TRUE;
            break;
        }
    }

    FreeSid(psidAdministrators);

cleanup:
    return bRet;
}

void InitCH366( void )
{
	ULONG  CH366ID=0;
	ULONG  ISCH366=0;

    if( !SearchPath( NULL,"CH364PGM", ".sys", 0, NULL, NULL ) )
        MessageBox( ghDialog, _T("�ڵ�ǰĿ¼��û�з���CH364PGM.sys�ļ�"), gMyWndName, MB_ICONSTOP | MB_OK );

    Drv_Handle=InitCH364IODrv( ghDialog );
    if(Drv_Handle==INVALID_HANDLE_VALUE ){
        MessageBox( ghDialog, _T("װ��CH364IO.sys�ļ�ʧ��"), gMyWndName, MB_ICONSTOP | MB_OK );
		MyShowErr();
	}

    m_open=0x00;
    if( FindCH366(Drv_Handle,&CH366ID,&ISCH366,&CfgRegBaseAdd) ){
		if( ISCH366 ){
			SetDlgItemText(ghDialog,IDC_EDIT_DEVICE,TEXT("��"));
			m_open=0x01;
		}else{
			m_open=0x00;
			SetDlgItemText(ghDialog,IDC_EDIT_DEVICE,TEXT("��"));
			MessageBox( ghDialog, "û���ҵ�CH364��", gMyWndName, MB_ICONSTOP | MB_OK );
			
		}
	}
	else MyShowErr();
}

void InitGUI( void )
{
	UCHAR   s;
	//USHORT  dw;
	//TCHAR buf[256];


    
    if( m_open )
    {
        if( CH364mReadIoByte(Drv_Handle,&CfgRegBaseAdd->CH366CfgCtrl,&s) )
        {
			
            if((s&0x2)==0)
                CheckRadioButton(ghDialog,IDC_RADIO_NEI,IDC_RADIO_WAI,IDC_RADIO_NEI);
            else
                CheckRadioButton(ghDialog,IDC_RADIO_NEI,IDC_RADIO_WAI,IDC_RADIO_WAI);
        }
		/*
		if( !CH364mReadIoByte(Drv_Handle,&CfgRegBaseAdd->CH366CfgDout,&s) )
        {
            MessageBox(ghDialog, _T("��CH364IO����!"), gMyWndName, MB_OK|MB_ICONINFORMATION);
            return;
        }
		
		s = s & 0x0DF;
		if( !CH364mWriteIoByte(Drv_Handle,&CfgRegBaseAdd->CH366CfgDout,s) )
        {
            MessageBox(ghDialog, _T("дCH364IO����!"), gMyWndName, MB_OK|MB_ICONINFORMATION);
            return;
        }
		
		if( CH364mReadIoByte(Drv_Handle,&CfgRegBaseAdd->rev[0x39],&s) )
        {
			_stprintf( buf, _T("IO%04X:%02X "), (ULONG)(&CfgRegBaseAdd->rev[0x39]),s );
			MessageBox( ghDialog, buf, gMyWndName, MB_ICONWARNING | MB_OK );
        }
		if( CH364mReadIoWord(Drv_Handle,&CfgRegBaseAdd->rev[0x18],&dw) )
        {
			_stprintf( buf, _T("IO%04X:%04X "), (ULONG)(&CfgRegBaseAdd->rev[0x18]), dw );
			MessageBox( ghDialog, buf, gMyWndName, MB_ICONWARNING | MB_OK );
        }
		*/
		
    }

	CheckRadioButton(ghDialog,IDC_RADIO_REBOOT,IDC_RADIO_HIBERNATE,IDC_RADIO_REBOOT);
	CheckRadioButton(ghDialog,IDC_RADIO_TRUE,IDC_RADIO_FALSE,IDC_RADIO_TRUE);
}



BOOL Reboot( VOID )
{
	HANDLE hToken;
	TOKEN_PRIVILEGES tkp;

    if (!OpenProcessToken( GetCurrentProcess(), TOKEN_ADJUST_PRIVILEGES | TOKEN_QUERY, &hToken) )
    {
        MyShowErr( );
        return FALSE;
    }

    LookupPrivilegeValue( NULL, SE_SHUTDOWN_NAME, &tkp.Privileges[0].Luid );
    tkp.PrivilegeCount = 1;
    tkp.Privileges[0].Attributes = SE_PRIVILEGE_ENABLED;
    AdjustTokenPrivileges( hToken, FALSE, &tkp, 0,(PTOKEN_PRIVILEGES)NULL, 0 );
    if( GetLastError() != ERROR_SUCCESS )
    {
        MyShowErr( );
        return FALSE;
    }

    if( !ExitWindowsEx( EWX_REBOOT, 0 ) )
    {
        MyShowErr( );
        return FALSE;
    }
    return TRUE;
}
//����
BOOL Hibernate()
{

	HANDLE hProcess,hToken;
	TOKEN_PRIVILEGES Privileges;
	LUID luid;
	hProcess=GetCurrentProcess();
	if ( ! OpenProcessToken(hProcess,TOKEN_ADJUST_PRIVILEGES,&hToken) ) {
		return FALSE;
	}
	Privileges.PrivilegeCount=1;
	if ( ! LookupPrivilegeValue(NULL,SE_SHUTDOWN_NAME,&luid) ) {
		CloseHandle(hToken);
		return FALSE;
	}
	Privileges.Privileges[0].Luid=luid;
	Privileges.Privileges[0].Attributes=SE_PRIVILEGE_ENABLED;
	if ( ! AdjustTokenPrivileges(hToken,FALSE,&Privileges,NULL,NULL,NULL) ){
		CloseHandle(hToken);
		return FALSE;
	}
	CloseHandle(hToken);
	
	
	if (!SetSystemPowerState(FALSE,TRUE)){
		return FALSE;
	}
	SetThreadExecutionState(ES_DISPLAY_REQUIRED);
	Sleep(1000);
	CloseCH364IODrv(Drv_Handle);
	InitCH366();
    InitGUI( );
	
	return TRUE;
}


// bNetBit    Ϊ1ʱ���л�������;�����л���������
// bReboot    Ϊ1ʱ��������������������߼��������������ߵĻ�����������Զ�����
// bInterFace Ϊ1ʱ������ʱ����ѡ����棬���򲻳�ѡ����档
void ChangeNet( BOOL bNetBit , BOOL bReboot , BOOL bInterFace)
{
	UCHAR       ch;
	//TCHAR buf[256];
	HINSTANCE   hInsQHuan=0;

    if(m_open)
    {
        if( !CH364mReadIoByte(Drv_Handle,&CfgRegBaseAdd->CH366CfgCtrl,&ch) )
        {
            MessageBox(ghDialog, _T("��CH364IO����!"), gMyWndName, MB_OK|MB_ICONINFORMATION);
            return;
        }

        if( IDOK == MessageBox( ghDialog, _T("�Ƿ�Ҫ�л���ǰ���绷��? \n(�л�ǰ�����������������߼����!)\n"), 
            gMyWndName, MB_OKCANCEL | MB_ICONQUESTION ) )
        { 
			ch = ch | 0x80;
            if( bNetBit == 1 )
                ch = ch | 0x08;		//λ3��1��ϵͳ�ػ���̵�����ѡ���л�������
            else
                ch = ch & 0x0F7;    //λ3��0��ϵͳ�ػ���̵�����ѡ���л�������
			if(bInterFace)
			{
				ch = ch & 0x0CF;	//λ4��λ5��ͬʱ������ѡ����棬����ȫ����Ϊ0
			}
			else{
				if( bNetBit == 1 )	//λ5��λ3��ͬ,λ4��λ3�෴ʱ����ѡ�����
					ch = ch | 0x20;
				else
					ch = ch | 0x10;
			}
			

            if( !CH364mWriteIoByte( Drv_Handle,&CfgRegBaseAdd->CH366CfgCtrl,(UCHAR)ch) )
            {
                MessageBox(ghDialog, _T("дCH364IO����!"), gMyWndName, MB_OK|MB_ICONINFORMATION);
                return;
            }
			if(!bReboot) {	

				if( !CH364mReadIoByte( Drv_Handle,&CfgRegBaseAdd->CH366CfgAux,&ch) )
				{
					//_stprintf( buf, _T("Write before CH366CfgAux:%02X "), ch );
					//MessageBox( ghDialog, buf, gMyWndName, MB_ICONWARNING | MB_OK );
					MessageBox(ghDialog, _T("��CH364IO����!"), gMyWndName, MB_OK|MB_ICONINFORMATION);
					return;
				}
				
				ch = ch & 0x0FE ;
				if( !CH364mWriteIoByte( Drv_Handle,&CfgRegBaseAdd->CH366CfgAux,(UCHAR)ch) )
				{
					MessageBox(ghDialog, _T("дCH364IO����!"), gMyWndName, MB_OK|MB_ICONINFORMATION);
					return;
				}
				/*
				if( CH364mReadIoByte( Drv_Handle,&CfgRegBaseAdd->CH366CfgAux,&ch) )
				{
					_stprintf( buf, _T("Write after CH366CfgAux:%02X "), ch );
					MessageBox( ghDialog, buf, gMyWndName, MB_ICONWARNING | MB_OK );
				}
				*/

			}
            Sleep(500);
			if( bReboot )
				Reboot();
			else{
				Hibernate();
			}
        }
        else
        {
            ShowWindow( ghDialog, SW_HIDE );
        }
    }
    else
    {
        MessageBox( ghDialog, _T("���뿨�豸û�ҵ�!"), gMyWndName, MB_OK|MB_ICONERROR);
    }
}



LRESULT CALLBACK mDialogMain( HWND hDialog, UINT uMessage, WPARAM wParam, LPARAM lParam )
{
	UINT uNetState,uRebootState,uInterfaceState;
    switch( uMessage )
    {
        case WM_INITDIALOG:
        {
			
            ghDialog = hDialog;
            InitCH366( );
            InitGUI( );
			
            return (TRUE);
        }
        case WM_COMMAND:
        {
            if (HIWORD(wParam) == BN_CLICKED) 
            { 
                switch (LOWORD(wParam)) 
                { 
				case IDC_RADIO_NEI:
					CheckRadioButton(ghDialog,IDC_RADIO_NEI,IDC_RADIO_WAI,IDC_RADIO_NEI);
					break;
				case IDC_RADIO_WAI:
					CheckRadioButton(ghDialog,IDC_RADIO_NEI,IDC_RADIO_WAI,IDC_RADIO_WAI);
					break;
				case IDC_RADIO_REBOOT:
					CheckRadioButton(ghDialog,IDC_RADIO_REBOOT,IDC_RADIO_HIBERNATE,IDC_RADIO_REBOOT);
					break;
				case IDC_RADIO_HIBERNATE:
					CheckRadioButton(ghDialog,IDC_RADIO_REBOOT,IDC_RADIO_HIBERNATE,IDC_RADIO_HIBERNATE);
					break;
				case IDC_RADIO_TRUE:
					CheckRadioButton(ghDialog,IDC_RADIO_TRUE,IDC_RADIO_FALSE,IDC_RADIO_TRUE);
					break;
				case IDC_RADIO_FALSE:
					CheckRadioButton(ghDialog,IDC_RADIO_TRUE,IDC_RADIO_FALSE,IDC_RADIO_FALSE);
					break;
				case IDC_BUTTON_CHANGE:
					if (m_open)
					{
						uNetState = IsDlgButtonChecked(ghDialog,IDC_RADIO_WAI);
						uRebootState = IsDlgButtonChecked(ghDialog,IDC_RADIO_REBOOT);
						uInterfaceState = IsDlgButtonChecked(ghDialog,IDC_RADIO_TRUE);
						ChangeNet(uNetState,uRebootState,uInterfaceState);
					}
					break;
				}
			}

            return (TRUE);
        }

       

        case WM_CLOSE:
        {
            
            if (m_open)
                CloseCH364IODrv(Drv_Handle);
            
            EndDialog( hDialog, 0 );
            return (TRUE);
        }
    }
    return (FALSE);
}

int	APIENTRY WinMain( HINSTANCE hInstance, HINSTANCE hPrevInst, LPSTR lpCmdLine, int nShowCmd )
{
    if( !IsAdmin( ) )
    {
        MessageBox( NULL, _T("��ʹ�ù���ԱȨ�����б�����"), gMyWndName, MB_OK|MB_ICONWARNING);
        return 0;    
    }
	
    if( !RunOneOnly( ) )
    {
        MessageBox( NULL, _T("���뿨����������"), gMyWndName, MB_OK|MB_ICONINFORMATION);
        return 0;
    }
	
    ghInstance = hInstance;
    return DialogBox( hInstance, (LPCSTR)IDD_DIALOG_PCIEISL, NULL,(DLGPROC)mDialogMain );
}

