#include "PreCompile.h"
#include "[!output PROJECT_NAME]App.h"
#include "[!output PROJECT_NAME]Frame.h"

bool [!output PROJECT_NAME]App::OnInit()
{
    [!output PROJECT_NAME]Frame* myFrame = new [!output PROJECT_NAME]Frame(wxT("wxWindowApp"));
    myFrame->Show(true);
    return true;
}

IMPLEMENT_APP([!output PROJECT_NAME]App);