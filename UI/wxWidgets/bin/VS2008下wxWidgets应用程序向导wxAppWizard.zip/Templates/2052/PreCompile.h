#ifndef PreCompile_h__
#define PreCompile_h__

#include <wx/wx.h>
#include <wx/wxprec.h>
#include <wx/stockitem.h>
#include <wx/dialog.h>

#include <iostream>
#include <cstdlib>
#include <cstdio>

#endif // PreCompile_h__
