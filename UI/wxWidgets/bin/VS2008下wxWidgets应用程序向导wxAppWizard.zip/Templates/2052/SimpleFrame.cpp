#include "PreCompile.h"
#include "[!output PROJECT_NAME]Frame.h"

[!output PROJECT_NAME]Frame::[!output PROJECT_NAME]Frame(const wxString title):wxFrame(NULL,wxID_ANY,title)
{
	Center();
}

