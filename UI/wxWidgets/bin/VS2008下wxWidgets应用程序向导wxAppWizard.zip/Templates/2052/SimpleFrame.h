#ifndef [!output PROJECT_NAME]Frame_h__
#define [!output PROJECT_NAME]Frame_h__


class [!output PROJECT_NAME]Frame : public wxFrame
{
public:
	[!output PROJECT_NAME]Frame(const wxString title);
};

#endif // [!output PROJECT_NAME]Frame_h__