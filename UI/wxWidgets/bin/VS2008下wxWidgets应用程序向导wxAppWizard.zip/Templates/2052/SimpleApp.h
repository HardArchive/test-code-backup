#ifndef [!output PROJECT_NAME]App_h__
#define [!output PROJECT_NAME]App_h__


class [!output PROJECT_NAME]App : public wxApp
{
public:
    virtual bool OnInit();
};

DECLARE_APP([!output PROJECT_NAME]App);

#endif // [!output PROJECT_NAME]App_h__
