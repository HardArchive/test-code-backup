﻿中文名字: 金山卫士系统优化独立版
英文缩写: ksystemoptimization
完整英文: kingsoft system optimization

 
