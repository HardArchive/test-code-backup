/************************************************************************/
/* ��ȡϵͳ��һЩ��Ϣ                                                                    */
/************************************************************************/

#include "StdAfx.h"
#include "GetGlobalState.h"
#include <ShlObj.h>

#pragma comment(lib,"ShFolder.Lib")

//����ģʽ���Ҹú���������ĳ�Ա����
// GetGlobalState.functionName() ��ֱ��ʹ������ĺ���
CGetGlobalState* GetGlobalState()
{
	static CGetGlobalState	state;
	return &state;
}

// ���캯���������̵Ļ�ַ��Ϊ����
CGetGlobalState::CGetGlobalState(void)
{
	InitModule( (HMODULE)&__ImageBase );
}

CGetGlobalState::~CGetGlobalState(void)
{
}

// ��ʼ����ģ��
VOID CGetGlobalState::InitModule( HMODULE hMod )
{
	m_hMod = hMod;

	// ��ȡϵͳ�汾
	OSVERSIONINFO	osver = {0};
	osver.dwOSVersionInfoSize = sizeof(OSVERSIONINFO);
	GetVersionEx(&osver);
	m_dwMajorVer = osver.dwMajorVersion;
	m_dwMinVer	 = osver.dwMinorVersion;

	m_bIsWOW64 = GetIsWOW64();

	// ��ȡ����ϵͳ��Ϣ
	GetModulePath();
	GetModuleDir();
	GetProgramDir();
	GetSystem32Dir();
	GetWindowsDir();
	GetProgramDir();
	GetCommonAppDataDir();
	GetAppDataDir();
}

// ��ȡ��ǰ�����·����
LPCTSTR CGetGlobalState::GetModulePath()
{
	static	TCHAR	szPath[MAX_PATH] = {0};
	if ( szPath[0] == 0 )
	{
		GetModuleFileName(m_hMod,szPath, MAX_PATH);
	}
	return szPath;
}

// ��ȡ��ǰ�������ڵ�Ŀ¼
LPCTSTR CGetGlobalState::GetModuleDir()
{
	static	TCHAR	szPath[MAX_PATH] = {0};
	if ( szPath[0] == 0 )
	{
		GetModuleFileName(m_hMod,szPath, MAX_PATH);
		// PathRemoveFileSpec-ϵͳapi
		PathRemoveFileSpec(szPath);
	}
	return szPath;
}

// ��ȡwindows��װĿ¼
LPCTSTR CGetGlobalState::GetWindowsDir()
{
	static	TCHAR	szPath[MAX_PATH] = {0};
	if ( szPath[0] == 0 )
	{
		GetSystemWindowsDirectory(szPath, MAX_PATH);
	//	GetWindowsDirectory(szPath, MAX_PATH);
	}
	return szPath;
}

// ��ȡsystem32Ŀ¼
LPCTSTR CGetGlobalState::GetSystem32Dir()
{
	static	TCHAR	szPath[MAX_PATH] = {0};
	if ( szPath[0] == 0 )
	{
		GetSystemDirectory(szPath, MAX_PATH);
	}
	return szPath;
}

// ��ȡProgramFilesĿ¼
LPCTSTR CGetGlobalState::GetProgramDir()
{
	static TCHAR szDir[MAX_PATH] = {0};

	if ( szDir[0] == 0 )
	{
		DWORD dwType = REG_SZ;
		DWORD dwSize = sizeof(szDir);
		// ��ע�����
		if( ERROR_SUCCESS == SHGetValue( HKEY_LOCAL_MACHINE, _T("SOFTWARE\\Microsoft\\Windows\\CurrentVersion"), 
			_T("ProgramFilesDir"), &dwType, szDir, &dwSize ) && dwSize > 1 )
		{
			// ȥ��·�������'\\'
			FixPathLastSpec(szDir);
			return szDir ;
		}

		// ע������ȡʧ�����ȡ��������
		if( 0 != GetEnvironmentVariable( _T("ProgramFiles"), szDir, dwSize ) )
		{
			FixPathLastSpec(szDir);
			return szDir ;
		}	
	}
	return szDir;
}

// ȥ��·�������'\\'
BOOL CGetGlobalState::FixPathLastSpec( LPTSTR lpPath )
{
	if ( lpPath == NULL )
		return FALSE;

	size_t	nLen = _tcslen(lpPath);
	if ( nLen > 1 )
	{
		// ��������'\\'��ȥ��
		if ( lpPath[nLen-1] == _T('\\') )
			lpPath[nLen-1] = 0;

		return TRUE;
	}
	return FALSE;
}

// ��ȡ��ʱ�ļ�Ŀ¼
LPCTSTR CGetGlobalState::GetTempDir()
{
	static	TCHAR	szPath[MAX_PATH] = {0};
	if ( szPath[0] == 0 )
	{
		GetTempPath(MAX_PATH,szPath);
		FixPathLastSpec(szPath);
	}
	return szPath;
}

// ��ȡͨ��appdataĿ¼
LPCTSTR CGetGlobalState::GetCommonAppDataDir()
{
	static	TCHAR	szPath[MAX_PATH] = {0};
	if ( szPath[0] == 0 )
	{
		SHGetSpecialFolderPath( NULL, szPath, CSIDL_COMMON_APPDATA, FALSE );
		FixPathLastSpec(szPath);
	}
	return szPath;
}

// ��ȡappdataĿ¼
LPCTSTR CGetGlobalState::GetAppDataDir()
{
	static	TCHAR	szPath[MAX_PATH] = {0};
	if ( szPath[0] == 0 )
	{
		SHGetSpecialFolderPath( NULL, szPath, CSIDL_APPDATA, FALSE );
		FixPathLastSpec(szPath);
	}
	return szPath;
}

// ��ȡrundll32.exe��·����
LPCTSTR CGetGlobalState::GetRundll32Path()
{
	static	TCHAR	szPath[MAX_PATH] = {0};
	if ( szPath[0] == 0 )
	{
		// ��ȡsystem32Ŀ¼��������"rundll32.exe"
		LPCTSTR	lpWinPath = GetSystem32Dir();
		_sntprintf_s( szPath, MAX_PATH, _T("%s\\Rundll32.exe"), lpWinPath);
	}
	return szPath;
}


// ��ȡregsvr32.exe��·����
LPCTSTR CGetGlobalState::GetRegSrvPath()
{
	static	TCHAR	szPath[MAX_PATH] = {0};
	if ( szPath[0] == 0 )
	{
		LPCTSTR	lpWinPath = GetSystem32Dir();
		_sntprintf_s( szPath, MAX_PATH, _T("%s\\regsvr32.exe"), lpWinPath);
	}
	return szPath;
}
							 
//�ǲ���64λϵͳ����
BOOL CGetGlobalState::GetIsWOW64()
{
	HMODULE hLib;
	BOOL bNeedFree = FALSE;
	BOOL bRet = FALSE;

	hLib = GetModuleHandle(_T("shlwapi.dll"));
	if(hLib == NULL)
	{
		hLib = LoadLibrary(_T("shlwapi.dll"));
		bNeedFree = TRUE;
	}

	if(hLib)
	{
		BOOL (__stdcall* pfnIsOS)(DWORD dwVer);

		(FARPROC&)pfnIsOS = GetProcAddress(hLib, MAKEINTRESOURCEA(437) );
		if(pfnIsOS)
		{
			bRet = pfnIsOS(30);
		}

		if(bNeedFree)
			FreeLibrary(hLib);

		SetLastError(ERROR_SUCCESS);
	}
	else
	{
		SetLastError(ERROR_OLD_WIN_VERSION);
	}

	return bRet;
}

// ��ȡwindowsĿ¼��explorer.exe��·����
LPCTSTR CGetGlobalState::GetExplorerPath()
{
	static	TCHAR	szPath[MAX_PATH] = {0};
	if ( szPath[0] == 0 )
	{
		LPCTSTR	lpWinPath = GetWindowsDir();
		_sntprintf_s( szPath, MAX_PATH, _T("%s\\explorer.exe"), lpWinPath);
	}
	return szPath;
}

// ��ȡsystem32Ŀ¼��explorer.exe��·����
LPCTSTR CGetGlobalState::GetSysExplorerPath()
{
	static	TCHAR	szPath[MAX_PATH] = {0};
	if ( szPath[0] == 0 )
	{
		LPCTSTR	lpWinPath = GetSystem32Dir();
		_sntprintf_s( szPath, MAX_PATH, _T("%s\\explorer.exe"), lpWinPath);
	}
	return szPath;
}

// ��ȡ�û���ʼ�˵���Ŀ¼
LPCTSTR CGetGlobalState::GetUserStartMenuProgDir()
{
	static	TCHAR	szPath[MAX_PATH] = {0};
	if ( szPath[0] == 0 )
	{
		SHGetSpecialFolderPath( NULL, szPath, CSIDL_PROGRAMS, FALSE );
		FixPathLastSpec(szPath);
	}
	return szPath;
}

// ��ȡ�����û�ͨ�ÿ�ʼ�˵���Ŀ¼
LPCTSTR CGetGlobalState::GetCommonStartMenuProgDir()
{
	static	TCHAR	szPath[MAX_PATH] = {0};
	if ( szPath[0] == 0 )
	{
		SHGetSpecialFolderPath( NULL, szPath, CSIDL_COMMON_PROGRAMS, FALSE );
		FixPathLastSpec(szPath);
	}
	return szPath;
}

LPCTSTR CGetGlobalState::GetUserDesktopDir()
{
	static	TCHAR	szPath[MAX_PATH] = {0};
	if ( szPath[0] == 0 )
	{
		SHGetSpecialFolderPath( NULL, szPath, CSIDL_DESKTOPDIRECTORY, FALSE );
		FixPathLastSpec(szPath);
	}
	return szPath;
}

// ��ȡͨ������Ŀ¼
LPCTSTR CGetGlobalState::GetCommonDesktopDir()
{
	static	TCHAR	szPath[MAX_PATH] = {0};
	if ( szPath[0] == 0 )
	{
		SHGetSpecialFolderPath( NULL, szPath, CSIDL_COMMON_DESKTOPDIRECTORY, FALSE );
		FixPathLastSpec(szPath);
	}
	return szPath;
}

// ��ȡQuick Launch��Ŀ¼
LPCTSTR CGetGlobalState::GetQuickLanchDir()
{
	static	TCHAR	szPath[MAX_PATH] = {0};
	if ( szPath[0] == 0 )
	{
		LPCTSTR	lpAppData = GetAppDataDir();
		if (lpAppData[0]!=0)
		{
			_sntprintf_s( szPath, MAX_PATH, _T("%s\\Microsoft\\Internet Explorer\\Quick Launch"), lpAppData);
		}
	}
	return szPath;
}

// ��ȡ�û���ʼ�˵��ĸ�Ŀ¼
LPCTSTR CGetGlobalState::GetUserStartMenuRootDir()
{
	static	TCHAR	szPath[MAX_PATH] = {0};
	if ( szPath[0] == 0 )
	{
		SHGetSpecialFolderPath( NULL, szPath, CSIDL_STARTMENU, FALSE );
		FixPathLastSpec(szPath);
	}
	return szPath;
}

// ��ȡͨ�ÿ�ʼ�˵��ĸ�Ŀ¼
LPCTSTR CGetGlobalState::GetCommonStartMenuRootDir()
{
	static	TCHAR	szPath[MAX_PATH] = {0};
	if ( szPath[0] == 0 )
	{
		SHGetSpecialFolderPath( NULL, szPath, CSIDL_COMMON_STARTMENU, FALSE );
		FixPathLastSpec(szPath);
	}
	return szPath;
}

// ��ȡ��ǰ�û�������Ŀ¼
LPCTSTR CGetGlobalState::GetUserStartRunDir()
{
	static	TCHAR	szPath[MAX_PATH] = {0};
	if ( szPath[0] == 0 )
	{
		SHGetSpecialFolderPath( NULL, szPath, CSIDL_STARTUP, FALSE );
		FixPathLastSpec(szPath);
	}
	return szPath;
}

// ��ȡͨ��������Ŀ¼
LPCTSTR CGetGlobalState::GetCommonStartRunDir()
{
	static	TCHAR	szPath[MAX_PATH] = {0};
	if ( szPath[0] == 0 )
	{
		SHGetSpecialFolderPath( NULL, szPath, CSIDL_COMMON_STARTUP, FALSE );
		FixPathLastSpec(szPath);
	}
	return szPath;
}

// ��ȡ�û�FavoriteĿ¼
LPCTSTR CGetGlobalState::GetUserFavoriteDir()
{
	static	TCHAR	szPath[MAX_PATH] = {0};
	if ( szPath[0] == 0 )
	{
		SHGetSpecialFolderPath( NULL, szPath, CSIDL_FAVORITES, FALSE );
		FixPathLastSpec(szPath);
	}
	return szPath;
}

// ��ȡͨ��FavoriteĿ¼
LPCTSTR CGetGlobalState::GetCommonFavoriteDir()
{
	static	TCHAR	szPath[MAX_PATH] = {0};
	if ( szPath[0] == 0 )
	{
		SHGetSpecialFolderPath( NULL, szPath, CSIDL_COMMON_FAVORITES, FALSE );
		FixPathLastSpec(szPath);
	}
	return szPath;
}

// �����ļ������õ�·����
VOID CGetGlobalState::GetLongPath( LPCTSTR lpFile, CString& strLongFile )
{
	DWORD	nSize = ::GetLongPathName(lpFile, NULL, 0);
	// ��ȡ��С��ͬʱҲ�ж��Ƿ��ܻ�ȡ��
	if ( nSize > 0 )
	{
		TCHAR*	pBuffer = new TCHAR[nSize+1];
		::GetLongPathName(lpFile, pBuffer, nSize+1);
		strLongFile = pBuffer;
		delete pBuffer;
	}
	else
		strLongFile = lpFile;
}

// ��ȡie��·����
LPCTSTR CGetGlobalState::GetIExplorerPath()
{
	static	TCHAR	szPath[MAX_PATH] = {0};
	if ( szPath[0] == 0 )
	{
		LPCTSTR	lpProgDir = GetProgramDir();
		if (lpProgDir[0]!=0)
		{
			_sntprintf_s( szPath, MAX_PATH, _T("%s\\Internet Explorer\\iexplore.exe"), lpProgDir);
		}
	}
	return szPath;
}

// ��ȡuserinit.exe��·����
LPCTSTR CGetGlobalState::GetUserinitPath()
{
	static	TCHAR	szPath[MAX_PATH] = {0};
	if ( szPath[0] == 0 )
	{
		LPCTSTR	lpSysDir = GetSystem32Dir();
		if (lpSysDir[0]!=0)
		{
			_sntprintf_s( szPath, MAX_PATH, _T("%s\\Userinit.exe"), lpSysDir);
		}
	}
	return szPath;
}

// ��ȡwinlogin.exe��·����
LPCTSTR CGetGlobalState::GetWinlogonPath()
{
	static	TCHAR	szPath[MAX_PATH] = {0};
	if ( szPath[0] == 0 )
	{
		LPCTSTR	lpSysDir = GetSystem32Dir();
		if (lpSysDir[0]!=0)
		{
			_sntprintf_s( szPath, MAX_PATH, _T("%s\\winlogon.exe"), lpSysDir);
		}
	}
	return szPath;
}