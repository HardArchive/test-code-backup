/************************************************************************/
/* .lnk�ļ�����                                                                     */
/************************************************************************/

#pragma once

#include <shlobj.h>

class CLnkDecode
{
public:

	//�ж��ļ��ǲ���.lnk�ļ�
	static BOOL IsLnkPostFile(LPCTSTR lpFileName)
	{
		//��ȡ�ļ���׺
		LPCTSTR		lpPostFix = GetFilePostFix(lpFileName);

		if (lpPostFix==NULL)
			return FALSE;

		return (_tcsicmp(lpPostFix,_T("lnk"))==0);
	}

	// ����Lnk�ļ�
	static BOOL QueryLnk(LPCTSTR lpLinkPath,CString &strExePath,CString &strExeParam)
	{
		IShellLink*	pShellLink;

		// ��IShellLink�ӿ�������lnk�ļ�
		// 
		// �õ��̷߳�ʽ����COM����
		BOOL bReturn = (::CoInitialize(NULL) == S_OK);
		if(TRUE || bReturn)
		{
			bReturn = ::CoCreateInstance (CLSID_ShellLink, NULL, CLSCTX_INPROC_SERVER,
				IID_IShellLink, (void **)&pShellLink) >= 0;
			// ��CLSID_ShellLink��ʶ����������lnk������COM����
			if(bReturn)
			{
				//������鿴MSDN
				IPersistFile *ppf;
				bReturn = pShellLink->QueryInterface(IID_IPersistFile, (void **)&ppf) >= 0;
				if(bReturn)
				{
					bReturn = ppf->Load(lpLinkPath, TRUE) >= 0;
					if(bReturn)
					{
						CString		strIePath;
						CString		strParam;
						pShellLink->GetPath( strIePath.GetBuffer(MAX_PATH+1), MAX_PATH, NULL, SLGP_UNCPRIORITY );
						pShellLink->GetArguments( strParam.GetBuffer(MAX_PATH + 1),MAX_PATH);
						strIePath.ReleaseBuffer();
						strParam.ReleaseBuffer();
						
						if (!strIePath.IsEmpty())
						{
							strExePath = (LPCTSTR)strIePath;
							
							if (!strParam.IsEmpty())
								strExeParam = strParam;

							bReturn = TRUE;
						}
						else
							bReturn = FALSE;
					}
					ppf->Release();
				}
				pShellLink->Release();
			}
			::CoUninitialize();
		}

		return bReturn;
	}

protected:
	//��ȡ�ļ���׺
	static LPCTSTR GetFilePostFix(LPCTSTR lpFile)
	{
		LPCTSTR lpPostFix = _tcsrchr(lpFile, _T('.'));
		if ( lpPostFix != NULL )
			lpPostFix++;
		return lpPostFix;
	}
};