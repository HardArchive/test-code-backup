#include "stdafx.h"
#include "more_bkwin2.h"

LRESULT CBkSafeMoreDlg::OnInitDialog(HWND hWnd, LPARAM lParam)
{

    return TRUE;
}

void CBkSafeMoreDlg::OnBtnClose()
{
    EndDialog(IDOK);
}

