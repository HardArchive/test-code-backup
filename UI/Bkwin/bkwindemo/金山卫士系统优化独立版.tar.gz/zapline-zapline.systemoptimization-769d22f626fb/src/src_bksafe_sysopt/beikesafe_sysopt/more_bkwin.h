#pragma once

#include <wtlhelper/whwindow.h>
#include <bkres/bkres.h>

#define MB_BK_CUSTOM_BUTTON         0x80000000
extern BOOL	g_bkMsgBox;

class CBkSafeMore
    : public CBkDialogImpl<CBkSafeMore>
    , public CWHRoundRectFrameHelper<CBkSafeMore>
{
public:
    CBkSafeMore()
        : CBkDialogImpl<CBkSafeMore>(IDR_BK_MORE_BKWIN)
    {
    }

    enum
    {
        ID_CLOSE        = 1001,
        ID_OPEN_DLG     = 1002,
        ID_COMBO_BOX    = 1003,
        ID_EDIT_USER    = 1004,
        ID_EDIT_PASS    = 1005,
        ID_BTN_RESET    = 1006,
        ID_BTN_LOGIN    = 1007,
    };

protected:
    void OnBtnClose();
    void OnBtnOpenDlg();
    void OnBtnLogin();
    void OnBtnReset();

    LRESULT OnInitDialog(HWND hWnd, LPARAM lParam);

    BK_NOTIFY_MAP(IDC_RICHVIEW_WIN)
        BK_NOTIFY_ID_COMMAND(ID_CLOSE, OnBtnClose)
        BK_NOTIFY_ID_COMMAND(ID_OPEN_DLG, OnBtnOpenDlg)
        BK_NOTIFY_ID_COMMAND(ID_BTN_LOGIN, OnBtnLogin)
        BK_NOTIFY_ID_COMMAND(ID_BTN_RESET, OnBtnReset)
    BK_NOTIFY_MAP_END()

    BEGIN_MSG_MAP_EX(CBkSafeMore)
        MSG_BK_NOTIFY(IDC_RICHVIEW_WIN)
        CHAIN_MSG_MAP(CBkDialogImpl<CBkSafeMore>)
        CHAIN_MSG_MAP(CWHRoundRectFrameHelper<CBkSafeMore>)
        MSG_WM_INITDIALOG(OnInitDialog)
        REFLECT_NOTIFICATIONS_EX()
    END_MSG_MAP()
};