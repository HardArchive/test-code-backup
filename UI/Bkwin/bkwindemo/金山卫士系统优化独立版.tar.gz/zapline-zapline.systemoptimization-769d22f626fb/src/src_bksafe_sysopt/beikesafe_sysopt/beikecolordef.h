
#pragma once

#define COL_DEFAULT_WHITE_BG	RGB(0xfb,0xfc,0xfd)
#define COL_DEFAULT_LINK		RGB(55,106,169)

