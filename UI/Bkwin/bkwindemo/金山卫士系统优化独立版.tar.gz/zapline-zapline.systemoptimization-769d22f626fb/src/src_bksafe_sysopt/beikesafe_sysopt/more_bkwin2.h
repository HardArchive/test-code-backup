#pragma once

#include <wtlhelper/whwindow.h>

#define MB_BK_CUSTOM_BUTTON         0x80000000
extern BOOL	g_bkMsgBox;

class CBkSafeMoreDlg
    : public CBkDialogImpl<CBkSafeMoreDlg>
{
public:
    CBkSafeMoreDlg()
        : CBkDialogImpl<CBkSafeMoreDlg>()
    {
    }

    enum
    {
        ID_CLOSE        = 1001,
    };

protected:
    void OnBtnClose();

    LRESULT OnInitDialog(HWND hWnd, LPARAM lParam);

    BK_NOTIFY_MAP(IDC_RICHVIEW_WIN)
        BK_NOTIFY_ID_COMMAND(ID_CLOSE, OnBtnClose)
    BK_NOTIFY_MAP_END()

    BEGIN_MSG_MAP_EX(CBkSafeMoreDlg)
        MSG_BK_NOTIFY(IDC_RICHVIEW_WIN)
        CHAIN_MSG_MAP(CBkDialogImpl<CBkSafeMoreDlg>)
        MSG_WM_INITDIALOG(OnInitDialog)
    END_MSG_MAP()
};