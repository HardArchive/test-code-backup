#include "stdafx.h"
#include "more_bkwin.h"
#include "more_bkwin2.h"
#include <fstream>
#include <string>
#include "globalstate\GetGlobalState.h"

LRESULT CBkSafeMore::OnInitDialog(HWND hWnd, LPARAM lParam)
{
    CbkCombo* p = (CbkCombo*)BkWnds::GetWindow((UINT)ID_COMBO_BOX);
    p->SetType(enum_TYPE_EDIT | enum_TYPE_READONLY | enum_TYPE_LEFTLINE);
    p->AddString(_T("34344"));
    p->AddString(_T("444"));
    p->SetCurSel(0);
    return TRUE;
}

void CBkSafeMore::OnBtnClose()
{
    EndDialog(IDOK);
}

void CBkSafeMore::OnBtnOpenDlg()
{
    CString strPath;
    CGetGlobalState *pGetGlobalState = GetGlobalState();
    strPath = pGetGlobalState->GetModuleDir();
    strPath += L"\\heihei.txt";

    std::ifstream in(strPath); 
    std::istreambuf_iterator<char> beg(in), end; 
    std::string sData(beg, end); 

    CBkSafeMoreDlg dlg;
    dlg.SetXml(sData.c_str());
    dlg.DoModal();
}

void CBkSafeMore::OnBtnLogin()
{
    CString strTemp;
    strTemp = GetItemText(ID_EDIT_USER);
    strTemp += GetItemText(ID_EDIT_PASS);
    ::MessageBox(0, strTemp, L"", 0);
}

void CBkSafeMore::OnBtnReset()
{
    SetItemText(ID_EDIT_USER, L"username");
    SetItemText(ID_EDIT_PASS, L"pass");
}
