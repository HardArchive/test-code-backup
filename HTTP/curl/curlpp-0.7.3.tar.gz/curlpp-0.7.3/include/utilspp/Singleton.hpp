#include "ThreadingSingle.hpp"
#include "singleton/SingletonHolder.hpp"
#include "singleton/LifetimeLibrary.hpp"
