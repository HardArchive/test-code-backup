#include <stdio.h>
#include <windows.h>
#include <time.h>
#include <memory.h>

#include "RWLock.h"

#define NUM_OF_THREADS 150
#define NUM_OF_LOOPS   56



#define LOG(str,var1) Logger(str,var1)


RWLOCK g_MainLock;
RWLOCK threads_locker;
RWLOCK Logger_Lock;


FILE* LogFile;
void Logger(char* str,int var1){
	RWLock_StartWrite(&Logger_Lock);
	fprintf(LogFile,str,var1);
	//printf(str,var1);
	RWLock_EndWrite(&Logger_Lock);
}


DWORD random(int x){
	int res = rand() % x;
	if(res<0)res = -res;
	if(res>=x)res=x-1;
	return (DWORD)res;
}


char g_SomeData[10000];
int  g_data2=0;

void Do_Read(){
	LOG("---- READ ------\r\n",0);
	for(int i=0;i<1000;i++)g_data2+=g_SomeData[random(10000)];
}
void Do_Write(){
	LOG("==== WRITE =====\r\n",0);
	for(int i=0;i<10000;i++)g_SomeData[i]=(char)random(256);
}



DWORD WINAPI ThreadProc(void* data){
	int ThreadID = (int)data;
	int i;
	printf("Started thread %d\n",ThreadID);
	Sleep(10+random(80));

	for(i=0;i<NUM_OF_LOOPS;i++){
		Sleep(random(30));
		if(0==(random(50))){
			//----[ read then write ]-------------[
			LOG("ReadToWrite:Read:Start %d\r\n",ThreadID);
			RWLock_StartRead(&g_MainLock);
			LOG("ReadToWrite:Read:Working %d\r\n",ThreadID);
			
			Do_Read(); //Sleep(READ_TIME); // it's bad to Sleep
			
			LOG("****ReadToWrite:Upgrading %d\r\n",ThreadID);
			RWLock_UpgradeToWriter(&g_MainLock);
			LOG("****ReadToWrite:Upgraded %d\r\n",ThreadID);
			
			Do_Write();

			LOG("****ReadToWrite:Write:Stopping %d\r\n",ThreadID);
			RWLock_EndAccess(&g_MainLock);
			LOG("****ReadToWrite:Done %d\r\n",ThreadID);
			//------------------------------------/
		}else if(random(5)){
			//--------[ read ]---------------------[
			LOG("Read:Start %d\r\n",ThreadID);
			RWLock_StartRead(&g_MainLock);
			LOG("Read:Working %d\r\n",ThreadID);

			Do_Read();//Sleep(READ_TIME);
			
			LOG("Read:Stopping %d\r\n",ThreadID);
			RWLock_EndRead(&g_MainLock);
			LOG("Read:Done%d\r\n",ThreadID);
			//-------------------------------------/
		}else{
			//----------[ write ]------------------[
			LOG("**Write:Start %d\r\n",ThreadID);
			RWLock_StartWrite(&g_MainLock);
			LOG("**Write:Working %d\r\n",ThreadID);

			Do_Write(); //Sleep(WRITE_TIME);
			
			LOG("**Write:Stopping %d\r\n",ThreadID);
			RWLock_EndWrite(&g_MainLock);
			LOG("**Write:Done%d\r\n",ThreadID);
			//-------------------------------------/
		}
	}

	printf("Ended thread %d\n",ThreadID);
	RWLock_EndRead(&threads_locker);
	return 1;
}


void main(){
	int i;
	DWORD tid;

	LogFile=fopen("logfile.txt","wb");
	printf("Starting to write to logfile.txt\n");

	RWLock_Init(&g_MainLock);
	RWLock_Init(&threads_locker);
	RWLock_Init(&Logger_Lock);

	//-----[ example of using MultiStartWrite ]------------------------[
	RWLock_MultiStartWrite(3,&g_MainLock,&threads_locker,&Logger_Lock);
	RWLock_MultiEndWrite(3,&g_MainLock,&threads_locker,&Logger_Lock);

	// second way
	RWLOCK* Array1[3];
	Array1[0]=&g_MainLock;
	Array1[1]=&threads_locker;
	Array1[2]=&Logger_Lock;
	RWLock_MultiStartWrite(-3,Array1);
	RWLock_MultiEndWrite(-3,Array1);
	//-----------------------------------------------------------------/

	srand( (unsigned) time(NULL) );

	LOG("*****Global RWLocks are ready******\r\n",0);
	
	for(i=0;i<NUM_OF_THREADS;i++){
		LOG("======= creating thread =======\r\n",0);
		Sleep(50);
		RWLock_StartRead(&threads_locker);
		if(!CreateThread(0,0,ThreadProc,(void*)i,0,&tid)){
			RWLock_EndRead(&threads_locker);
		}
	}
	LOG("*****Killing global RWLocks********\r\n",0);
	RWLock_Free(&threads_locker);	LOG("killed1\r\n",0);
	RWLock_Free(&g_MainLock);		LOG("killed2\r\n",0);
	RWLock_Free(&Logger_Lock);		printf("killed3\r\n");
	printf("*****Killed global RWLocks*********\r\n");
	fclose(LogFile);
}
