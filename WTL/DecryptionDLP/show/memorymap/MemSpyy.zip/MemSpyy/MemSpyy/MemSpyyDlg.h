// MemSpyyDlg.h : header file
//

#pragma once
#include "afxwin.h"
#include "OpenGLControl.h"


// CMemSpyyDlg dialog
class CMemSpyyDlg : public CDialog
{
// Construction
public:
	CMemSpyyDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	enum { IDD = IDD_MemSpyy_DIALOG };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support


// Implementation
protected:
	HICON m_hIcon;
	COpenGLControl m_OpenGLControl;

	// Generated message map functions
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnTimer(UINT nIDEvent);

private:
	CString				GetEXENameByPID( DWORD inPID );

	CStatic				m_LargestCtl;
	UINT_PTR			m_nTimer;

	DWORD				m_hLibModule;	// base adress of loaded module (==HMODULE);
public:
	afx_msg void OnEnUpdatePid();
private:
	long m_PID;
	CStatic m_TotalFreeCtl;


	HANDLE		m_Thread;
	void*		m_pLibRemote;	// the address (in the remote process) where szLibPath will be copied to;
	char		m_szLibPath [_MAX_PATH];

public:
	CStatic		m_StatusCtl;
	CStatic		m_TotalDllCtl;
	CEdit		m_PIDCtl;
	CStatic		m_PIDNameCtl;

	void		UpdateStatus ( PVOID inBaseAddress );

	void		SetLargestFree( unsigned long inLargestFree );
	void		SetTotalFree( unsigned long inTotalFree );
	void		SetTotalDLL( unsigned long inTotalDLL );
};
