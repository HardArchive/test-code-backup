#pragma once


// COpenGLControl
#include "OpenGLDevice.h"
#include <GL\gl.h>
#include <GL\glu.h>
#include <map>

class COpenGLControl : public CWnd
{
	DECLARE_DYNAMIC(COpenGLControl)

public:
	COpenGLControl();
	virtual ~COpenGLControl();

protected:
	DECLARE_MESSAGE_MAP()

protected:
	void InitGL();
	void DrawGLScene( bool inSelect = false );
	OpenGLDevice openGLDevice;
	CClientDC* dc;
public:
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnPaint();
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);

	BOOL RegisterWindowClass();
	void SetPID( unsigned long inPID ) { m_PID = inPID; DrawGLScene();}
	void ForceDraw();

private:
	void DrawMemory( SIZE_T blockSizeBytes );
	void CheckInit();


	GLfloat m_CurrentStartX;
	GLfloat m_CurrentStartY;

	int m_Width;
	int m_Height;

	int m_OriginX;
	int m_OriginY;

	int m_PrevY;
	int m_PrevX;
	int m_PrevLDownY;
	int m_PrevLDownX;
	int m_PrevRDownY;
	int m_PrevRDownX;

	GLfloat m_Red;
	GLfloat m_Blue;

	int m_DefaultWidth;
	int m_DefaultHeight;

	bool m_OpenGLInitialized;

	unsigned long m_CurrentlySelected;

	unsigned long m_PID;

	std::map<unsigned long, PVOID> m_MemoryBlocks;

public:
	afx_msg BOOL OnMouseWheel(UINT nFlags, short zDelta, CPoint pt);
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnRButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnRButtonDblClk(UINT nFlags, CPoint point);
};


