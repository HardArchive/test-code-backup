
#ifndef __TESTCLASS2_H__
#define __TESTCLASS2_H__

//The class don`t use memory pool !
class CTestClass2
{
private:
	char m_chBuf[1000];
};

#endif //__TESTCLASS2_H__