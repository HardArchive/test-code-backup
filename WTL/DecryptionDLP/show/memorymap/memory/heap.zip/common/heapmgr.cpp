/**
 * Heap manager class
 *
 * This source code is free and anyone can copy, pirate or distribute
 * the code without prior written or vocal permission.
 *
 * This software is provided "AS IS" and without any express or implied
 * warranties, including, but not limited to, the implied warranties of
 * merchantability and fitness for a particular purpose are disclaimed.
 *
 * Written By: Pradeep Chulliyan (chulliyan@hotmail.com)
 * Dated: June 07 2006
 */
#include "heapmgr.h"

// Memory alignment unit
//
const int MEM_ALIGN_SIZE = sizeof(double);

// Create a heap from a memory block and initialize trees
//
CHeapManager :: CHeapManager (CMemory* mem, CLock* lck, bool init)
              : m_mem (mem), m_lck (lck) 
{
    m_hdr = (HEAP_HEADER*)m_mem->GetPtr();

    // Lock the memory block to complete the initialization process before
    // the first access
    //
    CLocker l (m_lck);

    if (init)
    {
        memset (m_hdr, 0, sizeof (HEAP_HEADER));
        m_hdr->free = GetMaximumSize();

        // Insert the first memory block in the trees
        //
        HEAP_BLOCK* blk = (HEAP_BLOCK*)&m_hdr[1];
        
        blk->ptr.key = mem->ToOffset (blk);
        blk->len.key = (DWORD)m_hdr->free;

        InsertLenNode (&m_hdr->len, &blk->len);
        InsertNode (&m_hdr->ptr, &blk->ptr);
    }
}

// Print out debug information
//
CHeapManager :: ~CHeapManager()
{
#ifdef _DEBUG
    TCHAR sz[200];
    DBG_OUT (GetStatus (sz));
#endif
}

// Allocate 'len' number of bytes from the heap
//
void* CHeapManager :: Alloc (int len)
{
    if (len <= 0)
        return 0;

    // Align the block size to 'MEM_ALIGN_SIZE'
    //
    len = (len + MEM_ALIGN_SIZE) & ~(MEM_ALIGN_SIZE - 1);

    // Check for memory availability
    //
    CLocker lock (m_lck);
	if (len > (int)(m_hdr->free - sizeof (HEAP_BLOCK)))
		return 0;

    // Splay the 'length' tree to obtain the best match
    //
    TREE_NODE* node  = TO_NPTR (Splay (&m_hdr->len, (DWORD)len));
    bool       splay = true;

    if (node && node->key < (DWORD)len)
    {
        splay = false;
        if ((node = TO_NPTR (node->right)))
        {
            while (node->left)
                node = TO_NPTR (node->left);
        }
    }

    // If we cannot retrieve any tree node, return '0' to indicate error.
    //
    if (!node)
        return 0;

    // 'len' node is the first attribute of the HEAP_BLOCK, therefore every
    // 'len' node is also a HEAP_BLOCK.
    //
    HEAP_BLOCK* blk = (HEAP_BLOCK*)node;
    int         tln = len + sizeof (HEAP_BLOCK);
    int         rem = (int)node->key - tln;
    BYTE*       ptr = (BYTE*)&blk[1];

    // Remove current block from the trees
    //
    DeleteLenNode (&m_hdr->len, node, splay);
    DeleteNode (&m_hdr->ptr, &blk->ptr, false);

    // If the block is larger than the requested size, split the block and 
    // insert the second block into the trees
    //
    if (rem >= MEM_ALIGN_SIZE)
    {
        HEAP_BLOCK* sec = (HEAP_BLOCK*)&ptr[len];

        // Commit memory if necessary
        //
        m_mem->Commit (sec, sizeof (HEAP_BLOCK));

        blk->len.key = (DWORD)len;
        sec->len.key = (DWORD)rem;
        sec->ptr.key = m_mem->ToOffset (sec);

        // Insert the second block into the trees
        //
        InsertLenNode (&m_hdr->len, &sec->len);
        InsertNode (&m_hdr->ptr, &sec->ptr);
    }
    else
    {
        tln = (int)node->key;
        m_mem->Commit (ptr, tln);
    }

    // Adjust the allocation size
    //
    m_hdr->free  -= tln;
    m_hdr->alloc += tln;

    // Clear attributes and return the pointer
    //
    blk->len.right = blk->ptr.right = 0;
    blk->len.left  = blk->ptr.left  = 0;
    blk->next      = blk->prev      = 0;

    // Clear trailing 'pad'.
    //
    ptr[len - 1] = 0;
	return ptr;
}

// Release a memory pointer by pushing the HEAP_BLOCK's nodes back into the
// trees. Also, check to see if we can merge the block with an exising node
// in the trees.
//
void CHeapManager :: Free (void* ptr)
{
    if (!ptr || m_mem->IsPtr (ptr) == false)
        return;

    HEAP_BLOCK* blk  = (HEAP_BLOCK*)((BYTE*)ptr - sizeof (HEAP_BLOCK));
    HEAP_BLOCK* next = (HEAP_BLOCK*)((BYTE*)&blk[1] + blk->len.key);

    // Check for memory corruption
    //
#ifdef _DEBUG
    BYTE* tpad = ((BYTE*)ptr + blk->len.key - 1);
    if (*tpad)
        DBG_OUT (_T ("Heap corruption detected"));
#endif

    CLocker  lck (m_lck);

    // Check if the pointer has already been freed or not
    //
#ifdef _DEBUG
    NODE_PTR tmp = Splay (&m_hdr->ptr, blk->ptr.key);
    if (tmp && TO_NPTR (tmp)->key == blk->ptr.key)
    {
        DBG_ERROR (_T ("Freeing an already freed memory"));
        return;
    }
#endif

    // Adjust the free bytes
    //
    m_hdr->free  += blk->len.key;
    m_hdr->alloc -= blk->len.key;

    TREE_NODE* node = 0;
    NODE_PTR   pred = 0;
    if (m_mem->IsPtr (next))
        node = TO_NPTR (Splay (&m_hdr->ptr, next->ptr.key));

    if (node)
    {
		// Find a predecessor
        //
        if (node->key < next->ptr.key)
        {
            pred = TO_NOFF (node);
        }
        else if ((pred = node->left) > 0)
        {
            while (TO_NPTR (pred)->right)
                pred = TO_NPTR (pred)->right;
        }

        // See if the block can be merged with the sucessor
        //
        if (node->key == next->ptr.key)
        {
            // Remove the successor from both trees
            //
            DeleteLenNode (&m_hdr->len, &next->len, false);
            DeleteNode (&m_hdr->ptr, &next->ptr, true); 

            // Adjust the size
            //
            blk->len.key += (next->len.key + sizeof (HEAP_BLOCK));
            m_hdr->free  += sizeof (HEAP_BLOCK);
        }

        // See if the block can be merged with the predecessor
        //
        if (pred)
        {
            HEAP_BLOCK* b = (HEAP_BLOCK*)m_mem->ToPtr (TO_NPTR (pred)->key);
            HEAP_BLOCK* t = (HEAP_BLOCK*)((BYTE*)&b[1] + b->len.key);

            // Merge with the predecessor
            //
            if (t->ptr.key == blk->ptr.key)
            {
                // Remove the predecessor from the 'len' tree
                //
                DeleteLenNode (&m_hdr->len, &b->len, false);

                // Adjust the size
                //
                b->len.key   += (blk->len.key + sizeof (HEAP_BLOCK));
                m_hdr->free  += (int)sizeof (HEAP_BLOCK);
                m_hdr->alloc -= (int)sizeof (HEAP_BLOCK);

                // Re-insert the node in 'len' tree
                //
                InsertLenNode (&m_hdr->len, &b->len);
                
                blk = 0; // We don't have to insert the node
            }
        }
    }

    // Insert the node
    //
    if (blk)
    {
        InsertLenNode (&m_hdr->len, &blk->len);
        InsertNode (&m_hdr->ptr, &blk->ptr);
    }
}

// Adjust the tree (splay the heap) to get the best matching node
// at the top of the heap.
//
NODE_PTR CHeapManager :: Splay (NODE_PTR* root, DWORD key)
{
    TREE_NODE* t = TO_NPTR (*root);
	if (t == 0)
        return 0;

    TREE_NODE  n = {0};
    TREE_NODE* l = &n;
    TREE_NODE* r = l;
    TREE_NODE* y = 0;

    for (;;)
    {
        if (key < t->key)
        {
            if (t->left == 0)
                break;

            // Rotate right
            //
            if (key < TO_NPTR (t->left)->key)
            {
                y        = TO_NPTR (t->left);
                t->left  = y->right;
                y->right = TO_NOFF (t);
                t        = y;

                if (t->left == 0)
                    break;
            }

            // Link right
            //
            r->left = TO_NOFF (t);
            r       = t;
            t       = TO_NPTR (t->left);
        }
        else if (key > t->key)
        {
            if (t->right == 0) 
                break;

            // Rotate left
            //
            if (key > TO_NPTR (t->right)->key)
            {
                y        = TO_NPTR (t->right);
                t->right = y->left;
                y->left  = TO_NOFF (t);
                t        = y;

                if (t->right == 0)
                    break;
            }
                              
            // Link left
            //
            l->right = TO_NOFF (t);
            l        = t;
            t        = TO_NPTR (t->right);
        }
        else
            break;
    }

    // Re-create the node
    //
    l->right = r->left = 0;
    l->right = t->left;
    r->left  = t->right;
    t->left  = n.right;
    t->right = n.left;

    return (*root = TO_NOFF (t));
}

// Delete a node from the tree. If 'splay' is true, then the tree
// is assumed to be splayed with the correct key.
//
void CHeapManager :: DeleteNode (NODE_PTR* r, TREE_NODE* t, bool splay)
{
    NODE_PTR x = *r;

    if (splay)
        x = TO_NOFF (t);
    else
        x = Splay (&x, t->key);

    if (TO_NPTR (x)->key == t->key)
    {
        if (t->left == 0)
        {
            x = t->right;
        }
        else
        {
            x = Splay (&t->left, t->key);
            TO_NPTR (x)->right = t->right;
        }
    }
    *r = x;
}

// Insert a node into the tree
//
void CHeapManager :: InsertNode (NODE_PTR* r, TREE_NODE* n)
{
    InsertNode (r, n, TO_NPTR (Splay (r, n->key)));
}

// Insert a node into the tree
//
void CHeapManager :: InsertNode (NODE_PTR* r, TREE_NODE* n, TREE_NODE* t)
{
    if (t == 0)
    {
        n->left = n->right = 0;
    }
    else if (n->key < t->key)
    {
        n->left  = t->left;
        n->right = TO_NOFF (t);
        t->left  = 0;
    }
    else
    {
        n->right = t->right;
        n->left  = TO_NOFF (t);
        t->right = 0;
    }

    *r = TO_NOFF (n);
}

// There can be more than one length node with the same key (or memory
// blocks with the same length). This method will look for the matching node
// in the tree and later walk the linked list to delete the correct node.
//
void CHeapManager :: DeleteLenNode (NODE_PTR* r, TREE_NODE* n, bool splay)
{
    HEAP_BLOCK* p = (HEAP_BLOCK*)n;

    // If the node 'n' is not the first node in the linked list,
    // simply de-link 'n' from the linked list.
    //
    if (p->prev)
    {
        TO_BPTR (p->prev)->next = p->next;
        if (p->next)
            TO_BPTR (p->next)->prev = p->prev;
    }
    else
    {
        // If the node 'n' is the first node of the linked list, then
        // remove it from the tree and add the next node from the linked
        // list to the tree.
        //
        if (p->next)
        {
            HEAP_BLOCK* t = TO_BPTR (p->next);
            NODE_PTR    x = *r;
            
            if (splay)
                x = TO_NOFF (n);
            else
                x = Splay (&x, n->key);

            if (x && TO_NPTR (x)->key == n->key)
            {
                t->len.left  = TO_NPTR (x)->left;
                t->len.right = TO_NPTR (x)->right;
                t->prev      = 0;
                *r           = (NODE_PTR)p->next;
            }
        }
        else
            DeleteNode (r, n, false);
    }
}

// There can be many 'len' nodes with the same key. Therefore, we have to 
// build a linked list of 'len' nodes if a node already exists in the tree.
//
void CHeapManager :: InsertLenNode (NODE_PTR* r, TREE_NODE* n)
{
    // 'len' TREE_NODE is the first entry in the 'HEAP_BLOCK'. Therefore,
    // we can safely typecast TREE_NODE to a HEAP_BLOCK.
    //
    HEAP_BLOCK* t = TO_BPTR (Splay (r, n->key));
    HEAP_BLOCK* p = (HEAP_BLOCK*)n;

    if (!t || t->len.key != n->key)
    {
        // Insert into the tree
        //
        p->prev = p->next = 0;
        InsertNode (r, n, (TREE_NODE*)t);
    }
    else
    {
        // Link to the existing tree node
        //
        p->next = t->next;
        p->prev = TO_BOFF (t);
        t->next = TO_BOFF (p);
        
        if (p->next)
            TO_BPTR (p->next)->prev = TO_BOFF (p);
    }
}

///////////////////////////// Debug functions ////////////////////////////
//
// Avoid recursion as much as possible while walking the trees as it may
// cause stack overflow if there are large number of tree nodes.
//
int CHeapManager :: CountLeftNodes (TREE_NODE* n) const
{
    int c = 0;
    while (n)
    {
        c++;
        c += CountRightNodes (TO_NPTR (n->right));
        n  = TO_NPTR (n->left);
    }
    return c;
}

int CHeapManager :: CountRightNodes (TREE_NODE* n) const
{
    int c = 0;
    while (n)
    {
        c++;
        c += CountLeftNodes (TO_NPTR (n->left));
        n  = TO_NPTR (n->right);
    }
    return c;
}

int CHeapManager :: VerifyPtrTree (TREE_NODE* n) const
{
    int c = 0;
    if (n)
    {
        c++;
        if (n->left)
            c += CountLeftNodes (TO_NPTR (n->left));

        if (n->right)
            c += CountRightNodes (TO_NPTR (n->right));
    }
    return c;
}

int CHeapManager :: VerifyLenTree (NODE_PTR r, int& cnt) const
{
    int         c = 0;
    HEAP_BLOCK* b = (HEAP_BLOCK*)TO_NPTR (r);

    if (b)
    {
        c++;
        cnt += (int)b->len.key + sizeof (HEAP_BLOCK);
        
        HEAP_BLOCK* n = TO_BPTR (b->next);
        while (n)
        {
            cnt += (int)n->len.key  + sizeof (HEAP_BLOCK);
            n    = TO_BPTR (n->next);
            c++;
        }

        if (b->len.left)
            c += VerifyLenTree (b->len.left, cnt);
        if (b->len.right)
            c += VerifyLenTree (b->len.right, cnt);
    }
    return c;
}

// Verify the integrity of the heap trees and return the status as a string
//
TCHAR* CHeapManager :: GetStatus (TCHAR* buf) const
{
    CLocker lk (m_lck);
    int     ln = 0;
    int     c1 = VerifyPtrTree (TO_NPTR (m_hdr->ptr));
    int     c2 = VerifyLenTree (m_hdr->len, ln);

    // Total memory
    //
    ::_tstrcpy (buf, _T ("T="));
    ::_titoa ((long)GetMaximumSize(), &buf[::_tstrcnt (buf)], 10);

    // Free memory
    //
    ::_tstrcat (buf, _T (",F="));
    ::_titoa ((long)m_hdr->free, &buf[::_tstrcnt (buf)], 10);

    // Len tree
    //
    ::_tstrcat (buf, _T (",L="));
    ::_titoa ((long)c2, &buf[::_tstrcnt (buf)], 10);

    // Ptr tree
    //
    ::_tstrcat (buf, _T (",P="));
    ::_titoa ((long)c1, &buf[::_tstrcnt (buf)], 10);
    return buf;
}

