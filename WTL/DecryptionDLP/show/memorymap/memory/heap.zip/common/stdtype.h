/**
 * Type declaration
 *
 * This source code is free and anyone can copy, pirate or distribute
 * the code without prior written or vocal permission.
 *
 * This software is provided "AS IS" and without any express or implied
 * warranties, including, but not limited to, the implied warranties of
 * merchantability and fitness for a particular purpose are disclaimed.
 *
 * Written By: Pradeep Chulliyan (chulliyan@hotmail.com)
 * Dated: June 07 2006
 */
#ifndef __CMNTYPE_H__
#define __CMNTYPE_H__

#ifdef _UNICODE
#define _tstrcnt        wcslen
#define _tstrcpy        wcscpy
#define _tstrncpy       wcsncpy
#define _tstrcat        wcscat
#define _tstrlen        wcslen
#define _tstrcmp        wcscmp
#define _tstrcmpi       _wcsicmp
#define _tstrncmp       wcsncmp
#define _tstrncmpi      _wcsnicmp
#define _tstrchr        wcschr
#define _tstrrchr       wcsrchr
#define _tstrstr        wcsstr
#define _tstrlwr        _wcslwr
#define _tstrupr        _wcsupr
#define _tstrpbrk       wcspbrk
#define _tstrrev        _wcsrev
#define _tsscanf        swscanf
#define _titoa          _itow
#define _tatoi          _wtoi

#ifdef _UNIX
#define _tmain          main
#define _T(x)           Lx
#endif
#else // NON-UNICODE

#define _tstrcnt        strlen
#define _tstrlen        strlen
#define _tstrcpy        strcpy
#define _tstrncpy       strncpy
#define _tstrcat        strcat
#define _tstrcmp        strcmp
#ifndef _WIN32
#define _tstrcmpi       strcasecmp
#define _tstrncmpi      strncasecmp
#else
#define _tstrcmpi       strcmpi
#define _tstrncmpi      strncmpi
#endif
#define _tstrncmp       strncmp
#define _tstrstr        strstr
#define _tstrstrni      strstrni
#define _tstrchr        strchr
#define _tstrrchr       strrchr
#define _tstrrev        strrev
#define _tstrupr        strupr
#define _tstrlwr        strlwr
#define _tstrtod        strtod
#define _tsscanf        sscanf
#define _tmain          main
#define _tprintf        printf
#define _titoa          itoa
#define _tatoi          atoi

#ifdef _UNIX
#define Sleep(x)        sleep((x+999)/1000)
#define _T(x)           x
#endif

#endif


#ifndef _WIN32
typedef const char*             LPCSTR;
typedef const char*             LPCTSTR;
typedef char                    TCHAR;
typedef uint64_t                ULONG64;
typedef unsigned long           DWORD;
typedef unsigned char           BYTE;
typedef int                     HANDLE;
typedef pthread_t               THREAD_HANDLE;
typedef pthread_t               THREAD_ID;
typedef void*                   THREAD_RET;

typedef clock_t                 TICK_T;
#define INVALID_HANDLE_VALUE    ~(0)
#define CRITICAL_SECTION        pthread_mutex_t
#define EnterCriticalSection    pthread_mutex_lock
#define LeaveCriticalSection    pthread_mutex_unlock
#define DeleteCriticalSection   pthread_mutex_destroy
#define GetCurrentProcessId     getpid
#define GetCurrentThreadId      pthread_self
#define CloseHandle             close
#define GetTickCount            clock
#define wsprintf                sprintf

//
#define itoa(x,y,z)             sprintf((y),_T("%d"),(int)(x))
#else
typedef HANDLE                  THREAD_HANDLE;
typedef DWORD                   THREAD_ID;
typedef DWORD                   THREAD_RET;
typedef DWORD                   TICK_T;
#endif

#define UB8_UB4(x)              ((DWORD)((x) & 0x00000000ffffffff))
#define _TLEN(x)                ((::_tstrlen (x) + 1) * sizeof (TCHAR))

#endif // __CMNTYPE_H__

