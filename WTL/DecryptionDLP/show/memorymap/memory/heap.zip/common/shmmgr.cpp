/**
 * Virtual and shared memory manager classes
 *
 * This source code is free and anyone can copy, pirate or distribute
 * the code without prior written or vocal permission.
 *
 * This software is provided "AS IS" and without any express or implied
 * warranties, including, but not limited to, the implied warranties of
 * merchantability and fitness for a particular purpose are disclaimed.
 *
 * Written By: Pradeep Chulliyan (chulliyan@hotmail.com)
 * Dated: June 07 2006
 */
#include "shmmgr.h"

//////////////////////////////// CVirtualMemory //////////////////////////
//
DWORD CVirtualMemory::g_page = 0;

// Construct and get the default page size from the system
//
CVirtualMemory :: CVirtualMemory (bool reserve) : CMemory(), m_max (0),
                  m_reserve (reserve), m_local (true)
{
    // Initialize page size
    //
    if (g_page == 0)
    {
#ifdef _WIN32
        SYSTEM_INFO sys = {0};
        ::GetSystemInfo (&sys);
        g_page = sys.dwPageSize;
#elif __linux
        g_page = (DWORD)getpagesize();
#elif _SC_PAGESIZE // Solaris
        g_page = (DWORD)sysconf (_SC_PAGESIZE);
#elif _SC_PAGE_SIZE	// HP
        g_page = sysconf (_SC_PAGE_SIZE);
#endif
    }
}

// Set maximum size
//
void CVirtualMemory :: SetMaximumSize()
{
    m_max = this->m_ptr;
    if (m_max)
    {
        if (m_reserve)
            Commit (m_max, 0);
        else
            m_max = &m_max[this->m_len];
    }
}

// Return the minimum commit size
//
DWORD CVirtualMemory :: GetCommitSize (DWORD len)
{
    if (len <= GetPageSize())
    {
        len = (DWORD)(this->m_len / 12);
        if (len < GetPageSize())
            len = GetPageSize();
    }
    return len;
}

//////////////////////////////// CSharedMemory //////////////////////////
//
// Construct and set 'm_local' to false
//
CSharedMemory :: CSharedMemory (bool reserve) : CVirtualMemory (reserve)
{
    m_local = false;
    m_first = false;
}

// Allocate a shared memory block
//
bool CSharedMemory :: Alloc (int pages, LPCTSTR name)
{
    if (pages <= 0)
        pages = 1;

    this->m_len = pages * GetPageSize();
    
    // Invoke the platform specific allocation method
    //
    if (Alloc (name))
    {
        SetMaximumSize();
        return true;
    }
    return false;
}

