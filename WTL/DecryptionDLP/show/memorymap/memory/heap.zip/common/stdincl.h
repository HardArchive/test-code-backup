/**
 * Common include file
 *
 * This source code is free and anyone can copy, pirate or distribute
 * the code without prior written or vocal permission.
 *
 * This software is provided "AS IS" and without any express or implied
 * warranties, including, but not limited to, the implied warranties of
 * merchantability and fitness for a particular purpose are disclaimed.
 *
 * Written By: Pradeep Chulliyan
 * Dated: June 07 2006
 */
#ifndef __STDINCL_H__
#define __STDINCL_H__

#ifdef _WIN32
#pragma warning (disable: 4100) // Disable unreferenced argument warning
#pragma warning (disable: 4706) // Disable assignement within condition
#pragma warning (disable: 4516) // Access declaration over-ride
#pragma warning (disable: 4127) // Conditional expression is constant
#pragma warning (disable: 4512) // Assignment operator could not be generated
#pragma warning (disable: 383)  // Value copied to temporary
#pragma warning (disable: 981)  // Disable evaluation order check
#pragma warning (disable: 174)  // Expression has no effect (Intel compiler)
#pragma warning (disable: 869)  // Unreferenced parameters (intel)
#endif

// UNICODE directives
//
#if defined (_UNICODE) && !defined (UNICODE)
#define UNICODE
#endif

#if defined (UNICODE) && !defined (_UNICODE)
#define _UNICODE
#endif

// Windows include files
//
#ifdef _WIN32
#define VC_EXTRALEAN
#define WIN32_LEAN_AND_MEAN
#undef  _WIN32_WINNT
#define _WIN32_WINNT 0x0500
#include <windows.h>
#include <winternl.h>
#include <tchar.h>
#include <winsock.h>
#include <objbase.h>
#define _WINSOCK2API_
#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <io.h>
#include <process.h>
#include <fcntl.h>
#include <sys/stat.h>

#if defined (_M_X64) && !defined (_X64)
#define _X64
#endif

// UNIX include files
//
#else
#define __stdcall
#define __cdecl
#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <fcntl.h>
#include <dirent.h>
#include <unistd.h>
#include <utime.h>
#include <errno.h>
#include <signal.h>
#include <ctype.h>
#include <time.h>
#include <pthread.h>
#include <dlfcn.h>
#include <stdint.h>
#include <netdb.h>
#include <sys/time.h>
#include <sys/stat.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <sys/shm.h>
#include <sys/ipc.h>
#include <sys/mman.h>
#include <sys/file.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <locale.h>
#include <wchar.h>

#define _UNIX
#endif

#include "stdtype.h"
#include "stdtmpl.h"

#ifdef _DEBUG
#ifdef _WIN32
#define DBG_OUT(x)  {::OutputDebugString (x); ::OutputDebugString (_T ("\r\n"));}

#ifdef _CONSOLE
#define PRINT_C(x,y)  {::_tprintf (_T ("%s: %s\n"), (x), (y));}
#else
#define PRINT_C(x,y)  {::MessageBox (0, (y), (x), MB_ICONSTOP);}
#endif

// Critical debug message
//
#define DBG_ERROR(x) \
    if (IsDebuggerPresent()) \
        {::OutputDebugString (x); ::OutputDebugString (_T ("\r\n"));} \
    else \
        {PRINT_C((x), _T ("Critical Error"));}
#else
#define DBG_OUT(x)   {::_tprintf (_T ("%s\n"), (x));}
#define DBG_ERROR(x) {::_tprintf (_T ("Errod: %s\n"), (x));}
#endif
#else
#define DBG_OUT(x)
#endif
#endif // __STDINCL_H__

