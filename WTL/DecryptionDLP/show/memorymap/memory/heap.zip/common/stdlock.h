/**
 * Critical section lock encapsulation classes
 *
 * This source code is free and anyone can copy, pirate or distribute
 * the code without prior written or vocal permission.
 *
 * This software is provided "AS IS" and without any express or implied
 * warranties, including, but not limited to, the implied warranties of
 * merchantability and fitness for a particular purpose are disclaimed.
 *
 * Written By: Pradeep Chulliyan (chulliyan@hotmail.com)
 * Dated: June 07 2006
 */
#ifndef __STDLOCK_H__
#define __STDLOCK_H__

// Wait return values (for UNIX)
//
#ifndef _WIN32
#define WAIT_OBJECT_0  0L
#define WAIT_TIMEOUT   258L
#endif

// Base class of all Lock classes
//
class CLock
{
public:
    CLock() : m_tid (0), m_ref (0) {}
    virtual ~CLock() {}

    // Lock the critical section code
    //
    void Lock()
    {
        THREAD_ID t = ::GetCurrentThreadId();
        if (m_tid != t)
        {
            DoLock(); 
            m_tid = t;
            m_ref = 0;
        }
        m_ref++;
    }

    // Unlock critical section code
    //
    void Unlock()
    {
        if (m_tid == ::GetCurrentThreadId())
        {
            if (--m_ref == 0)
            {
                m_tid = 0;
                DoUnlock();
            }
        }
    }

    // Derived classes must implement the actual locking code
    //
protected:
    virtual void DoLock()   = 0;
    virtual void DoUnlock() = 0;

private:
    THREAD_ID m_tid; // Thread id of the owner thread
    DWORD     m_ref; // Reference counter
};

// Inter-thread lock class
//
class CThreadLock : public CLock
{
    // Platform specific implementations
    //
public:
    void Initialize (CRITICAL_SECTION* sec);
    void Destroy (CRITICAL_SECTION* sec);
    void SetSpinCount (CRITICAL_SECTION* sec, DWORD cnt);

    // Constructor and destructor
    //
public:
    CThreadLock() {CThreadLock::Initialize (&m_sec);}
    ~CThreadLock() {CThreadLock::Destroy (&m_sec);}

protected:
    virtual void DoLock()   {::EnterCriticalSection (&m_sec);}
    virtual void DoUnlock() {::LeaveCriticalSection (&m_sec);}

private:
    CRITICAL_SECTION  m_sec;
};

// Inter-process lock class
//
class CProcessLock : public CLock
{
public:
    CProcessLock (LPCTSTR name);

    // Check if this is the first instance of the lock
    //
    bool IsFirst() {return m_first;}

protected:
    virtual void DoLock();
    virtual void DoUnlock();

private:
    CHandle m_mutex;
    bool    m_first;
};

// Helper class
//
class CLocker
{
public:
    CLocker (CLock* lck) : m_lock (lck) {if (lck) lck->Lock();}
    virtual ~CLocker () {if (m_lock) m_lock->Unlock();}

private:
    CLock* m_lock;
};

#endif // __STDLOCK_H__

