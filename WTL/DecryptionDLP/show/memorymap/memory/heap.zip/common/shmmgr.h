/**
 * Virtual and shared memory manager classes
 *
 * This source code is free and anyone can copy, pirate or distribute
 * the code without prior written or vocal permission.
 *
 * This software is provided "AS IS" and without any express or implied
 * warranties, including, but not limited to, the implied warranties of
 * merchantability and fitness for a particular purpose are disclaimed.
 *
 * Written By: Pradeep Chulliyan (chulliyan@hotmail.com)
 * Dated: June 07 2006
 */
#ifndef __SHMMGR_H__
#define __SHMMGR_H__
#include "stdincl.h"

// Virtual memory manager class. Virtual memory can be committed on
// demand, where as regular memory block is pre-committed.
//
class CVirtualMemory : public CMemory
{
public:
    CVirtualMemory (bool reserve);
    ~CVirtualMemory() {Free();}

    // Allocate the memory
    //
    bool Alloc (int pages);

    // Free the allocated block of memory
    //
    virtual void Free();

    // Commit a region of memory
    //
    bool Commit (void* ptr, int len);

    // Return the maximum committed memory size
    //
    DWORD GetCommitSize() {return (DWORD)(m_max - this->m_ptr);}

    // Return the size of the system's memory page
    //
    DWORD GetPageSize() {return g_page;}

protected:
    BYTE* m_max;     // Maximum size
    bool  m_reserve; // Reserve but not commit
    bool  m_local;   // Local memory

    // Shared helper methods
    //
protected:
    void  SetMaximumSize();
    DWORD GetCommitSize (DWORD len);

private:
    static DWORD g_page;
};

// Shared memory is protected by a MUTEX object. In order to Lock/Unlock the
// shared memory during modification, use 'Lock and Unlock' methods of this
// class.
//
class CSharedMemory : public CVirtualMemory
{
public:
    CSharedMemory (bool reserve);
    ~CSharedMemory() {Free();}
    
public:
    // Allocate shared memory segment
    //
    bool Alloc (int pages, LPCTSTR name);

    // Free shared memory segment and handles
    //
    void Free();

    // Check if the shared memory is valid.
    //
    bool IsValid() {return m_mem.IsValid();}

    // Check if this is the first instance of shared memory
    //
    bool IsFirst() {return m_first;}

private:
    CHandle m_mem;     // Handle of the file mapping
    bool    m_first;   // 

private:
    bool  Alloc (LPCTSTR name);
};

#endif // __SHMMGR_H__

