/**
 * Windows 'CRITICAL_SECTION', MUTEX and EVENT encapsulation classes
 *
 * This source code is free and anyone can copy, pirate or distribute
 * the code without prior written or vocal permission.
 *
 * This software is provided "AS IS" and without any express or implied
 * warranties, including, but not limited to, the implied warranties of
 * merchantability and fitness for a particular purpose are disclaimed.
 *
 * Written By: Pradeep Chulliyan (chulliyan@hotmail.com)
 * Dated: June 07 2006
 */
#include "stdincl.h"
#include "stdlock.h"

// Initialize critical section
//
void CThreadLock :: Initialize (CRITICAL_SECTION* sec)
{
    ::InitializeCriticalSection (sec);
}

// Delete critical section
//
void CThreadLock :: Destroy (CRITICAL_SECTION* sec)
{
    ::DeleteCriticalSection (sec);
}

// Set spin count
//
void CThreadLock :: SetSpinCount (CRITICAL_SECTION* sec, DWORD cnt)
{
#ifndef _WIN32_WCE
    ::SetCriticalSectionSpinCount (sec, cnt);
#endif
}

//////////////////////////////// CProcessLock ////////////////////////////
//
// Create a MUTEX
//
CProcessLock :: CProcessLock (LPCTSTR name)
{
    m_mutex = ::CreateMutex (0, FALSE, name);
    m_first = (::GetLastError() != ERROR_ALREADY_EXISTS);
}

// Lock 
//
void CProcessLock :: DoLock()
{
    ::WaitForSingleObject (m_mutex, INFINITE);
}

// Unlock 
//
void CProcessLock :: DoUnlock()
{
    ::ReleaseMutex (m_mutex);
}

