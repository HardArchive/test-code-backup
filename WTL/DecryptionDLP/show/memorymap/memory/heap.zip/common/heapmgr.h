/**
 * Heap manager class
 *
 * This source code is free and anyone can copy, pirate or distribute
 * the code without prior written or vocal permission.
 *
 * This software is provided "AS IS" and without any express or implied
 * warranties, including, but not limited to, the implied warranties of
 * merchantability and fitness for a particular purpose are disclaimed.
 *
 * Written By: Pradeep Chulliyan (chulliyan@hotmail.com)
 * Dated: June 07 2006
 */
#ifndef __HEAPMGR_H__
#define __HEAPMGR_H__
#include "stdincl.h"
#include "stdlock.h"

// Operating system does not guarantee to map the shared memory in 
// the same address location in all the processes. Therefore, enable
// __SHARED compilation flag to make use OFFSETs instead of the real
// pointers in the heap data structures.
//
#define __SHARED

#ifdef __SHARED
#define NODE_PTR    DWORD
#define BLOCK_PTR   DWORD
#define TO_NPTR(x)  ((TREE_NODE*)ToPtr(x))
#define TO_NOFF(x)  ToOffset(x)
#define TO_BPTR(x)  ((HEAP_BLOCK*)ToPtr(x))
#define TO_BOFF(x)  ToOffset(x)
#else
#define NODE_PTR    TREE_NODE*
#define BLOCK_PTR   HEAP_BLOCK*
#define TO_NPTR(x)  x
#define TO_NOFF(x)  x
#define TO_BPTR(x)  ((HEAP_BLOCK*)x)
#define TO_BOFF(x)  x
#endif

///////////////////////// Heap structures ////////////////////////////////
//
// Tree node
//
typedef struct TREE_NODE
{
    DWORD    key;   // Node key
    NODE_PTR right; // Right node
    NODE_PTR left;  // Left node
}TREE_NODE;

// HEAP header
//
typedef struct HEAP_HEADER
{
    NODE_PTR len;     // 'Length' tree
    NODE_PTR ptr;     // 'Pointer' tree
    int      free;    // Free bytes
    int      alloc;   // Allocated bytes
    DWORD    meta[4]; // Shared meta data
}HEAP_HEADER;

// Heap memory block consists of a 'len' tree node, a pointer tree node
// and a pair of linked list nodes for maintaining multiple 'len' nodes
// in a tree.
//
typedef struct HEAP_BLOCK
{
    TREE_NODE len;  // Length node
    TREE_NODE ptr;  // Pointer node
    BLOCK_PTR next; // Used by 'len' tree
    BLOCK_PTR prev; // Used by 'len' tree
}HEAP_BLOCK;

// Heap manager class for allocating and freeing blocks of memory from
// a pre-existing block of memory.
//
class CHeapManager
{
public:
    CHeapManager (CMemory* mem, CLock* lck, bool init);
    ~CHeapManager();

    // Public methods
    //
public:
    // Allocate a block of memory
    //
    void* Alloc (int len);

    // Free previously allocated memory block.
    //
    void Free (void* ptr);

    // Return the 'free size' in BYTES
    //
    int GetFreeSize() const {return m_hdr->free;}

    // Return the 'allocated size' in BYTES
    //
    int GetAllocatedSize() const {return m_hdr->alloc;}

    // Return the maxium size in BYTES
    //
    int GetMaximumSize() const 
    {
        return (m_mem->GetSize() - (int)(sizeof (HEAP_BLOCK) 
                + sizeof (HEAP_HEADER)));
    }

    // Set a DWORD in the shared meta data segment
    //
    void SetMetaData (int idx, DWORD dat)
    {
        if (idx >= 0 && idx < 4)
            m_hdr->meta[idx] = dat;
    }

    // Get a previously stored meta data
    //
    DWORD GetMetaData (int idx)
    {
        if (idx >= 0 && idx < 4)
            return m_hdr->meta[idx];
        return 0;
    }

    // Convert pointer offset to pointer.
    //
    void* ToPtr (DWORD off) const
    {
        return (off >= sizeof (HEAP_HEADER) ? m_mem->ToPtr (off) : 0);
    }

    // Check if the pointer is a valid pointer within the heap
    //
    bool IsPtr (const void* ptr) const {return m_mem->IsPtr (ptr);}

    // Convert offset to a 'TCHAR*'
    //
    TCHAR* CharPtr (DWORD off) const {return (TCHAR*)ToPtr (off);}

    // Convert pointer to offset.
    //
    DWORD ToOffset (const void* ptr) const {return m_mem->ToOffset (ptr);}

    // Verify the integrity of the heap trees and return the status as a
    // string.
    //
    TCHAR* GetStatus (TCHAR* buf) const;

private:
    CMemory*     m_mem; // Heap memory block
    CLock*       m_lck; // Lock object
    HEAP_HEADER* m_hdr; // Heap header

    // Helper methods
    //
private:
    NODE_PTR Splay (NODE_PTR* r, DWORD key);

    // Insert a node into the tree
    //
    void InsertNode (NODE_PTR* r, TREE_NODE* n);

    // Helper method to insert a node
    //
    void InsertNode (NODE_PTR* r, TREE_NODE* n, TREE_NODE* t);

    // Delete a node from the tree
    //
    void DeleteNode (NODE_PTR* r, TREE_NODE* t, bool splay);

    // Insert a node into the 'length' tree
    //
    void InsertLenNode (NODE_PTR* r, TREE_NODE* n);

    // Delete a node from the 'length' tree
    //
    void DeleteLenNode (NODE_PTR* r, TREE_NODE* n, bool splay);

    // Debug methods
    //
    int VerifyPtrTree (TREE_NODE* n) const;
    int VerifyLenTree (NODE_PTR n, int& cnt) const;
    int CountLeftNodes (TREE_NODE* n) const;
    int CountRightNodes (TREE_NODE* n) const;
};

#endif // __HEAPMGR_H__


