// heapdlg.h : header file
//

#pragma once
#include "heaptst.h"

#define SHM_MAX_INST 4

// CHeapDlg dialog
//
class CHeapDlg : public CDialog
{
// Construction
public:
	CHeapDlg(CWnd* pParent = NULL);	// standard constructor
	~CHeapDlg();

// Dialog Data
	enum { IDD = IDD_HEAP_DIALOG };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support

public:
    void DisplayProgress (bool end);

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg void OnTimer (UINT_PTR id);
    afx_msg void OnBnClickedOk();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()

private:
    CHeapManager*  m_heap;
    CHeapTest      m_test;
    int            m_idx;
    CProcessLock*  m_lock[SHM_MAX_INST];
    TCHAR          m_str[300];

private:
    void    Test();
    CStack* GetStack (int idx);
};
