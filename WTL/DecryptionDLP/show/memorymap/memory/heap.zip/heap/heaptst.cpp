/**
 * Heap tester classes
 *
 * This source code is free and anyone can copy, pirate or distribute
 * the code without prior written or vocal permission.
 *
 * This software is provided "AS IS" and without any express or implied
 * warranties, including, but not limited to, the implied warranties of
 * merchantability and fitness for a particular purpose are disclaimed.
 *
 * Written By: Pradeep Chulliyan (chulliyan@hotmail.com)
 * Dated: June 07 2006
 */
#include "heaptst.h"

// Used by 'new' and 'delete' allocate C++ objects in the
// shared heap
//
static CHeapManager* g_heap = 0;

//
CHeapTest :: CHeapTest() : m_heap (0), m_lck (0), m_mem (0), m_alloc (0)
{
    ::srand ((unsigned int)::GetCurrentProcessId());
    memset (m_arr, 0, sizeof (m_arr));
}

// Create heap manager
//
CHeapManager* CHeapTest :: Create (int t, bool test)
{
    bool init  = true;
    bool res   = false;
    int  pages = (test ? 10000 : 3000);

    switch (t)
    {
    case 0:
        m_mem = new CVirtualMemory (res);
        ((CVirtualMemory*)m_mem)->Alloc (pages);
        break;
    case 1:
        m_lck = new CThreadLock();
        m_mem = new CVirtualMemory (res);
        ((CVirtualMemory*)m_mem)->Alloc (pages);
        break;
    default:
        m_lck = new CProcessLock (_T ("heap_test_lock"));
        m_mem = new CSharedMemory (res);
        ((CSharedMemory*)m_mem)->Alloc (pages, _T ("heap_test_shm"));
        init = ((CSharedMemory*)m_mem)->IsFirst();
        break;
    }
    if (m_mem->GetPtr())
        m_heap = new CHeapManager (m_mem, m_lck, init);
    return (g_heap = m_heap);
}

//
void CHeapTest :: Close()
{
    if (m_heap)
    {
        Free (m_heap);
        delete m_heap;
        delete m_mem;
        delete m_lck;

        m_heap = 0;
    }
}

// Test performance
//
int CHeapTest :: Test (TEST_CALLBACK fn, void* ctx, DWORD& m, DWORD& h)
{
    int i = 0;

    for (; i < 32; i++)
    {
        (*fn) (ctx, false);

        m += Test (0);
        h += Test (m_heap);

        (*fn) (ctx, true);
    }
    return i;
}

// Allocate and free memory blocks and measure time
//
DWORD CHeapTest :: Test (CHeapManager* heap)
{
    TICK_T t = ::GetTickCount();
    
    // Allocate and free memory for 50000 times
    //
    for (int i = 0; i < 50000; i++)
        Alloc (heap);

    // Free the allocated memory
    //
    Free (heap);

    return (DWORD)(::GetTickCount() - t);
}

// Allocate memory using either the 'CHeapManager' or 'malloc'.
//
void CHeapTest :: Alloc (CHeapManager* heap)
{
    int d = ::rand() % (sizeof (m_arr) / sizeof (m_arr[0]));
    int l = d + 1;

    // Free the previous memory
    //
    if (m_arr[d])
    {
        if (heap)
            heap->Free (m_arr[d]);
        else
            ::free (m_arr[d]);
        m_alloc -= l;
    }

    if (heap)
        m_arr[d] =  m_heap->Alloc (l);
    else
        m_arr[d] = ::malloc (l);

    if (m_arr[d])
        m_alloc += l;
    else
        ::_tprintf (_T ("Failed %d\n"), l);
}

// Free memory using either the 'CHeapManager' or 'free'
//
void CHeapTest :: Free (CHeapManager* heap)
{
    for (int i = 0; i < (int)(sizeof (m_arr) / sizeof (m_arr[0])); i++)
    {
        if (m_arr[i])
        {
            if (heap)
                heap->Free (m_arr[i]);
            else
                ::free (m_arr[i]);

            m_alloc -= (i + 1);
            m_arr[i] = 0;
        }
    }
}

//
void CHeapTest :: GetStatus (TCHAR* str)
{
    ::wsprintf (str, _T ("PID (%d) = %d"), ::GetCurrentProcessId(), m_alloc);
}

#ifdef _CONSOLE
//
static void TestCallback (void* ctx, bool end)
{
    ::_tprintf (_T ("."));
    ::fflush (stdout);
}

int _tmain (int argc, TCHAR* argv[])
{
    // Test with thread lock
    //
    int type = 0;
    if (argc > 1 && ::_tstrcmpi (argv[1], _T ("/tc")) == 0)
    {
        type = 1;
    }
    else if (argc > 1 && ::_tstrcmpi (argv[1], _T ("/tm")) == 0)
    {
        type = 2;
    }

    CHeapTest     test;
    CHeapManager* heap = test.Create (type, true);
    
    if (heap)
    {
        DWORD m = 0;
        DWORD h = 0;
        int   c = test.Test (TestCallback, 0, m, h);

        ::_tprintf (_T ("\n\nmalloc = %d, heap = %d\n"), (int)(m/c), (int)(h/c));

        TCHAR sz[300];
        ::_tprintf (_T ("%s\n"), heap->GetStatus (sz));
    }
}
#endif

// Allocate memory using memory manager.
//
void* CHeapObject :: operator new (size_t len)
{
    return g_heap->Alloc ((int)len);
}

// 
void CHeapObject :: operator delete (void* ptr, size_t len)
{
    g_heap->Free (ptr);
}

// Delete 'CInfo' objects
//
CStack :: ~CStack()
{
    for (int i = 0; i < m_idx; i++)
    {
        CInfo* o = (CInfo*)g_heap->ToPtr (m_arr[i]);
        delete o;
    }
}

// Pop an object from the stack
//
CInfo* CStack :: Pop()
{
    if (m_idx > 0)
        return (CInfo*)g_heap->ToPtr (m_arr[--m_idx]);
    return 0;
}

// Push an 'CInfo' object into stack
//
void CStack :: Push (CInfo* o)
{
    if (o != 0)
    {
        if (m_idx < (int)(sizeof (m_arr) / sizeof (m_arr[0])))
            m_arr[m_idx++] = g_heap->ToOffset (o);
        else
            delete o;
    }
}

//
CInfo :: CInfo (DWORD pid)
{
    int val = ::rand();
    int len = 100 + (val % 5000);

    m_str = (TCHAR*)g_heap->Alloc (len);
    if (m_str)
        ::wsprintf (m_str, _T ("pid=%d, rand=%d, len=%d"), (int)pid, val, len);
}

CInfo :: ~CInfo()
{
    g_heap->Free (m_str);
}
