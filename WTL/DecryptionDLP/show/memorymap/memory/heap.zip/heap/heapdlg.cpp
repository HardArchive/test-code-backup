// heapdlg.cpp : implementation file
//

#include "stdafx.h"
#include "heap.h"
#include "heapdlg.h"
#include "shellapi.h"

// CAboutDlg dialog used for App About
//
class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	enum { IDD = IDD_ABOUTBOX };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

// Implementation
protected:
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
END_MESSAGE_MAP()


// CHeapDlg dialog
//
CHeapDlg::CHeapDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CHeapDlg::IDD, pParent)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);

    m_heap = 0;
    m_idx  = 0;
    memset (m_lock, 0, sizeof (m_lock));
}

//
CHeapDlg :: ~CHeapDlg()
{
    if (m_lock[0])
    {
        if (m_idx == 0)
        {
            // Delete stacks
            //
            for (int i = 0; i < SHM_MAX_INST; i++)
            {
                delete GetStack (i);
                delete m_lock[i];
            }
        }
        else 
        {
            CStack* st = GetStack (m_idx);
            if (st)
                st->SetPID (0);
        }
    }
    m_test.Close();
}

void CHeapDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CHeapDlg, CDialog)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_TIMER()
	ON_WM_QUERYDRAGICON()
	//}}AFX_MSG_MAP
    ON_BN_CLICKED(IDOK, &CHeapDlg::OnBnClickedOk)
END_MESSAGE_MAP()

// CHeapDlg message handlers

BOOL CHeapDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu (FALSE);
	if (pSysMenu != NULL)
	{
        pSysMenu->RemoveMenu (1, MF_BYPOSITION);

        CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon

    // Check if we are running in 'test mode'
    //
    bool    test = true;
    int     type = 2;
    int     argc = 0;
    LPWSTR* argv = CommandLineToArgvW (::GetCommandLine(), &argc);
    LPCTSTR psz  = (argc > 1 ? argv[1] : _T (""));

    // Test with thread lock
    //
    if (::_tstrcmpi (psz, _T ("/t")) == 0)
        type = 0;
    else if (::_tstrcmpi (psz, _T ("/tc")) == 0)
        type = 1;
    else if (::_tstrcmpi (psz, _T ("/tm")))
        test = false;
    ::LocalFree (argv);

    if ((m_heap = m_test.Create (type, test)) != 0)
    {
        // Get a meta data index
        //
        if (test == false)
        {
            CStack* st = 0;

            m_test.Lock();
            for (m_idx = 0; m_idx < SHM_MAX_INST; m_idx++)
            {
                st = GetStack (m_idx);
                if (st == 0 || st->GetPID() == 0)
                {
                    // Set instance id as windows caption
                    //
                    ::wsprintf (m_str, _T ("Heap: Instance# %d"), m_idx);
                    SetWindowText (m_str);

                    if (st)
                        st->SetPID (::GetCurrentProcessId());
                    
                    // Create locks
                    //
                    for (int i = 0; i < SHM_MAX_INST; i++)
                    {
                        ::wsprintf (m_str, _T ("heal_l_%d"), i);
                        m_lock[i] = new CProcessLock (m_str);
                    }
                    break;
                }
            }

            // Create stacks and launch addtional instances
            //
            if (m_idx == 0)
            {
                ::GetModuleFileName (0, m_str, 250);

                for (int i = 0; i < SHM_MAX_INST; i++)
                {
                    st = new CStack();

                    // Set owner PID
                    //
                    if (i == 0)
                        st->SetPID (::GetCurrentProcessId());
                    
                    m_heap->SetMetaData (i, m_heap->ToOffset (st));

                    // Launch instance
                    //
                    PROCESS_INFORMATION pi = {0};
                    STARTUPINFO         si = {0};
                    si.cb          = sizeof (STARTUPINFO);
                    si.dwFlags     = STARTF_USESHOWWINDOW;
                    si.wShowWindow = SW_HIDE;

                    if (::CreateProcess (m_str, 0, 0, 0, FALSE, 0, 0, 0, &si, &pi))
                    {
                        ::CloseHandle (pi.hThread);
                        ::CloseHandle (pi.hProcess);
                    }
                }
            }
            m_test.Unlock();

            if (m_idx == SHM_MAX_INST)
                PostMessage (WM_CLOSE);
            else
                SetTimer (1000, 100, 0);
        }
        else
            SetTimer (1001, 100, 0);
    }
    else
    {
        AfxMessageBox (_T ("Failed to allocate shared memory"), MB_ICONSTOP);
        PostMessage (WM_CLOSE);
    }
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CHeapDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CHeapDlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this function to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CHeapDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}

//
void CHeapDlg::OnBnClickedOk()
{
    KillTimer (1002);
    OnOK();
}

//  
void CHeapDlg :: OnTimer (UINT_PTR id)
{
    // Kill the timer and randomize the next timer
    //
    KillTimer (id);

    if (id == 1000)
    {
        // Adjust the window location
        //
        RECT rc;
        ::GetWindowRect (m_hWnd, &rc);

        int x = rc.top;
        int y = rc.left;

        if (m_idx == 1)
        {
            x += (rc.bottom - x);
        }
        else if (m_idx == 2)
        {
            y += (rc.right - y);
        }
        else if (m_idx == 3)
        {
            x += (rc.bottom - x);
            y += (rc.right - y);
        }
        x -= 120;
        y -= 220;

        int h = rc.bottom - rc.top;
        int w = rc.right - rc.left;
        MoveWindow (y, x, w, h, TRUE);
        ShowWindow (SW_SHOW);
        SetTimer (1002, 200, 0);
    }
    else if (id == 1001)
    {
        // Run performance test
        //
        Test();
    }
    else
    {
        UINT    lbl = IDC_DATA1;
        CStack* st  = 0;

        // Push data into the stack and retrieve data from the 
        // other's stack.
        //
        for (int i = 0; i < SHM_MAX_INST; i++)
        {
            if ((st = GetStack (i)) == 0)
                continue;

            // Push data into the stack
            //
            m_lock[i]->Lock();
            if (i == m_idx)
            {
                if (st->IsFull() == false)
                {
                    st->Push (new CInfo (st->GetPID()));
                    st->Push (new CInfo (st->GetPID()));
                    st->Push (new CInfo (st->GetPID()));
                }
            }
            else if (st->IsEmpty() == false)
            {
                // Get data from other's stack
                //
                CInfo* s = st->Pop();
                SetDlgItemText (lbl, *s);
                delete s;
                
                if (lbl == IDC_DATA1)
                    lbl = IDC_DATA2;
                else if (lbl == IDC_DATA2)
                    lbl = IDC_DATA3;
            }
            m_lock[i]->Unlock();
        }

        // Print statistics
        //
        SetDlgItemText (IDC_STATUS, m_heap->GetStatus (m_str));
        ::_titoa (m_heap->GetFreeSize(), m_str, 10);
        SetDlgItemText (IDC_FREE, m_str);
        SetTimer (1002, (100 + (::rand() % 500)), 0);

        // Check if we need to enable/disable exit button
        //
        if (m_idx == 0)
        {
            BOOL b = TRUE;
            for (int i = 1; i < SHM_MAX_INST; i++)
            {
                st = GetStack (i);
                if (!st || st->GetPID() == 0)
                    continue;

                HANDLE h = ::OpenProcess (SYNCHRONIZE, FALSE, st->GetPID());
                if (h)
                {
                    ::CloseHandle (h);
                    b = FALSE;
                    break;
                }
                else
                    st->SetPID (0);
            }
            GetDlgItem (IDOK)->EnableWindow (b);
        }
    }
}

// Display progress
//
void CHeapDlg :: DisplayProgress (bool end)
{
    TCHAR sz[40];
    if (end == false)
    {
        ::_tstrcat (m_str, _T (".."));
        SetDlgItemText (IDC_FREE, m_str);
        ::_titoa (m_heap->GetFreeSize(), sz, 10);
        SetDlgItemText (IDC_FREE, sz);
        SetDlgItemText (IDC_DATA1, m_str);
        SetDlgItemText (IDC_DATA2, m_str);
        SetDlgItemText (IDC_DATA3, m_str);
    }
    else
    {
        MSG msg;
        while (::PeekMessage (&msg, 0, 0, 0, FALSE))
            ::AfxPumpMessage();
    }
}

//
static void TestCallback (void* ctx, bool end)
{
    ((CHeapDlg*)ctx)->DisplayProgress (end);
}

// Test performance
//
void CHeapDlg :: Test()
{
    DWORD m = 0;
    DWORD h = 0;

    GetDlgItem (IDOK)->EnableWindow (FALSE);
    m_str[0] = 0;

    int c = m_test.Test (TestCallback, this, m, h);

    ::wsprintf (m_str, _T ("malloc = %d, heap = %d\n"), m / c, h / c);
    MessageBox (m_str, _T ("Time taken"), MB_ICONINFORMATION);
    GetDlgItem (IDOK)->EnableWindow (TRUE);
}

// Retrieve the stack structure
//
CStack* CHeapDlg :: GetStack (int idx)
{
    return (CStack*)m_heap->ToPtr (m_heap->GetMetaData (idx));
}
