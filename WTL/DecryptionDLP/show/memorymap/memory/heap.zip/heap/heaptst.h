/**
 * Heap test classes
 *
 * This source code is free and anyone can copy, pirate or distribute
 * the code without prior written or vocal permission.
 *
 * This software is provided "AS IS" and without any express or implied
 * warranties, including, but not limited to, the implied warranties of
 * merchantability and fitness for a particular purpose are disclaimed.
 *
 * Written By: Pradeep Chulliyan (chulliyan@hotmail.com)
 * Dated: June 07 2006
 */
#ifndef __HEAPTST_H__
#define __HEAPTST_H__
#include "../common/heapmgr.h"
#include "../common/shmmgr.h"

typedef void (*TEST_CALLBACK) (void* ctx, bool end);

// CHeapTest
//
class CHeapTest
{
public:
	CHeapTest();

public:
    CHeapManager* Create (int t, bool test);
    
    // 
    void Close();

    void Alloc (CHeapManager* heap);
    void Free (CHeapManager* heap);
    
    //
    void GetStatus (TCHAR* str);

    // Lock the heap
    //
    void Lock()   {if (m_lck) m_lck->Lock();}
    void Unlock() {if (m_lck) m_lck->Unlock();}

    //
    int   Test (TEST_CALLBACK fn, void* ctx, DWORD& m, DWORD& h);
    DWORD Test (CHeapManager* heap);

private:
    CHeapManager*  m_heap;
    CLock*         m_lck;
    CMemory*       m_mem;
    int            m_alloc;
    void*          m_arr[8192];
};

// Parent class of all the classes allocated from the heap
//
class CHeapObject
{
public:
    CHeapObject() {}
    virtual ~CHeapObject() {}

    // Override 'new' and 'delete' to allocate memmory using
    // the heap manager
    //
    void* operator new (size_t len);
    void  operator delete (void* ptr, size_t len);
};

// Information class
//
class CInfo : public CHeapObject
{
public:
    CInfo (DWORD pid);
    ~CInfo();

public:
    operator LPCTSTR() {return m_str;}

private:
    TCHAR* m_str;
};

// Stack class
//
class CStack : public CHeapObject
{
public:
    CStack() : m_pid (0), m_idx (0) {::memset (m_arr, 0, sizeof (m_arr));}
    ~CStack();

public:
    bool IsEmpty() {return (m_idx == 0);}
    bool IsFull()  {return (m_idx == (sizeof (m_arr) / sizeof (m_arr[0])));}

    // Get/Set process id
    //
    DWORD GetPID()           {return m_pid;}
    void  SetPID (DWORD pid) {m_pid = pid;}

    //
    void   Push (CInfo* o);
    CInfo* Pop();

private:
    DWORD m_pid;
    int   m_idx;
    DWORD m_arr[64];
};

#endif // __HEAPTST_H__

