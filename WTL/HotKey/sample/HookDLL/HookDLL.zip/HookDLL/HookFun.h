
#ifndef __HOOKFUN_H
#define __HOOKFUN_H
#include <windows.h>
bool Dis_F1ToF12(int nCode,  WPARAM wParam, LPARAM lParam);
bool set_Ctrl_A(bool bl);
bool set_Ctrl_B(bool bl);
#endif