//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by testhookDll.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_TESTHOOKDLL_DIALOG          102
#define IDR_MAINFRAME                   128
#define IDC_BNTShielding_ALL_HOTKEY     1000
#define IDC_BUTTON_DISABLE_ALL          1000
#define IDC_BUTTON2                     1001
#define IDC_BUTTON_ACTION               1001
#define IDC_CHECKTaskmgr                1003
#define IDC_CHECK_WIN_LR                1005
#define IDC_CHECK_ALT                   1014
#define IDC_CHECK_PrtSc                 1015
#define IDC_CHECK_ESC                   1016
#define IDC_CHECK_MENU                  1017
#define IDC_CHECK_PAUSE                 1018
#define IDC_CHECK_TAB                   1019
#define IDC_CHECK_F1                    1021
#define IDC_CHECK_CTRL_A                1022
#define IDC_CHECK_DELTE                 1023
#define IDC_BUTTON_OPEN_ALL             1024
#define IDC_BUTTONSAVASETING            1025
#define IDC_BUTTONDefault               1026
#define IDC_CHECK1                      1027
#define IDC_CHECK2                      1028
#define IDC_CHECK_F2                    1029
#define IDC_CHECK_F3                    1030
#define IDC_CHECK_F4                    1031
#define IDC_CHECK_F5                    1032
#define IDC_CHECK_F6                    1033
#define IDC_CHECK_F7                    1034
#define IDC_CHECK_F8                    1035
#define IDC_CHECK_F9                    1036
#define IDC_CHECK_F10                   1037
#define IDC_CHECK_F11                   1038
#define IDC_CHECK_F12                   1039
#define IDC_CHECK_CTRL_B                1040
#define IDC_CHECK_F13                   1040
#define IDC_CHECK_CTRL_C                1041
#define IDC_CHECK_CTRL_D                1042
#define IDC_CHECK_CTRL_E                1043
#define IDC_CHECK_CTRL_B2               1044
#define IDC_CHECK_CTRL_F                1044
#define IDC_CHECK_CTRL_X                1045
#define IDC_CHECK_CTRL_V                1046
#define IDC_CHECK_CTRL_Z                1047
#define IDC_CHECK_CTRL_F2               1048
#define IDC_CHECK_CTRL_X2               1049
#define IDC_CHECK_CTRL_V2               1050
#define IDC_CHECK_DELTE2                1051
#define IDC_CHECK_SHIFT_DELTE           1051

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        134
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1029
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
