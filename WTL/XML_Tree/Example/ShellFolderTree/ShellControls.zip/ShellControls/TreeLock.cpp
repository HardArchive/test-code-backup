// ShellFolderTree.cpp : Implementation of CShellFolderTree

#include "stdafx.h"
#include "ShellControls.h"
#include "ShellFolderTree.h"

/////////////////////////////////////////////////////////////////////////////
// CShellFolderTree::CTreeLock

CShellFolderTree::CTreeLock::CTreeLock(CShellFolderTree* pTree)
{
	m_hmtx = pTree->m_hmtxTreeLock;

	if (::GetCurrentThreadId() == pTree->m_ctlTree.GetWindowThreadID())
	{
		// wait for the tree to become available:
		for (MSG msg ; WAIT_OBJECT_0 != ::WaitForSingleObject(m_hmtx, 0) ; )
		{
			// we must process any messages that queue up for the tree while we're waiting, however...
			DWORD dwRet  = ::MsgWaitForMultipleObjects(1, &m_hmtx, FALSE, INFINITE, QS_ALLINPUT);
			switch (dwRet)
			{
			case WAIT_OBJECT_0:		// our thread signaled the hevComplete event:
				break;

			case WAIT_OBJECT_0+1:	// a windows message to be processed:

			 	while (::PeekMessage(&msg, pTree->m_ctlTree.m_hWnd, 0, 0, PM_REMOVE))
  					::DispatchMessage(&msg);

				break;

			default:						// some error:
				return;
			}
		}
	}
	else
	{
		::WaitForSingleObject(m_hmtx, INFINITE);
	}
}

CShellFolderTree::CTreeLock::~CTreeLock()
{
	ReleaseMutex(m_hmtx);
}
