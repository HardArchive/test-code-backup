// stdafx.h : include file for standard system include files,
//      or project specific include files that are used frequently,
//      but are changed infrequently

#if !defined(AFX_STDAFX_H__A80B8960_07C2_47BF_B090_253B7C3EE4E3__INCLUDED_)
#define AFX_STDAFX_H__A80B8960_07C2_47BF_B090_253B7C3EE4E3__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define _WIN32_IE		0x0400
#define _WIN32_WINNT 0x0400

#define _ATL_APARTMENT_THREADED

#include <atlbase.h>
extern CComModule _Module;
#include <atlcom.h>
#include <atlctl.h>

#include "shlobj.h"
#include "shlwapi.h"

#include <vector>
#include <map>

#include "comdef.h"

#pragma comment(lib, "comctl32.lib")

#define TreeView_SetItemState(hwndTV, hti, data, _mask) \
{ TVITEM _ms_TVi;\
  _ms_TVi.mask = TVIF_STATE; \
  _ms_TVi.hItem = hti; \
  _ms_TVi.stateMask = _mask;\
  _ms_TVi.state = data;\
  SNDMSG((hwndTV), TVM_SETITEM, 0, (LPARAM)(TV_ITEM FAR *)&_ms_TVi);\
}

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_STDAFX_H__A80B8960_07C2_47BF_B090_253B7C3EE4E3__INCLUDED)
