// ShellFolderTree.h : Declaration of the CShellFolderTree

#ifndef __SHELLFOLDERTREE_H_
#define __SHELLFOLDERTREE_H_

#include "resource.h"       // main symbols
#include "pidl.h"
#include "ShellControlsCP.h"

/////////////////////////////////////////////////////////////////////////////
// CShellFolderTree

class ATL_NO_VTABLE CShellFolderTree : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComControl<CShellFolderTree>,
	public CComCoClass<CShellFolderTree, &CLSID_ShellFolderTree>,
	public CStockPropImpl<CShellFolderTree, IShellFolderTree, &IID_IShellFolderTree, &LIBID_SHLCTLS>,
	public CProxy_IShellFolderTreeEvents<CShellFolderTree>,
	public IPersistStreamInitImpl<CShellFolderTree>,
	public IOleControlImpl<CShellFolderTree>,
	public IOleObjectImpl<CShellFolderTree>,
	public IOleInPlaceActiveObjectImpl<CShellFolderTree>,
	public IViewObjectExImpl<CShellFolderTree>,
	public IOleInPlaceObjectWindowlessImpl<CShellFolderTree>,
	public IConnectionPointContainerImpl<CShellFolderTree>,
	public IPersistStorageImpl<CShellFolderTree>,
	public ISpecifyPropertyPagesImpl<CShellFolderTree>,
	public IQuickActivateImpl<CShellFolderTree>,
	public IDataObjectImpl<CShellFolderTree>,
	public IProvideClassInfo2Impl<&CLSID_ShellFolderTree, &DIID__IShellFolderTreeEvents, &LIBID_SHLCTLS>,
	public IPropertyNotifySinkCP<CShellFolderTree>,
	public IDropSource,
	public IDropTarget
{
public:

DECLARE_REGISTRY_RESOURCEID(IDR_SHELLFOLDERTREE)

DECLARE_PROTECT_FINAL_CONSTRUCT()

DECLARE_VIEW_STATUS(VIEWSTATUS_SOLIDBKGND | VIEWSTATUS_OPAQUE)

BEGIN_COM_MAP(CShellFolderTree)
	COM_INTERFACE_ENTRY(IShellFolderTree)
	COM_INTERFACE_ENTRY(IDispatch)
	COM_INTERFACE_ENTRY(IViewObjectEx)
	COM_INTERFACE_ENTRY(IViewObject2)
	COM_INTERFACE_ENTRY(IViewObject)
	COM_INTERFACE_ENTRY(IOleInPlaceObjectWindowless)
	COM_INTERFACE_ENTRY(IOleInPlaceObject)
	COM_INTERFACE_ENTRY2(IOleWindow, IOleInPlaceObjectWindowless)
	COM_INTERFACE_ENTRY(IOleInPlaceActiveObject)
	COM_INTERFACE_ENTRY(IOleControl)
	COM_INTERFACE_ENTRY(IOleObject)
	COM_INTERFACE_ENTRY(IPersistStreamInit)
	COM_INTERFACE_ENTRY2(IPersist, IPersistStreamInit)
	COM_INTERFACE_ENTRY(IConnectionPointContainer)
	COM_INTERFACE_ENTRY(ISpecifyPropertyPages)
	COM_INTERFACE_ENTRY(IQuickActivate)
	COM_INTERFACE_ENTRY(IPersistStorage)
	COM_INTERFACE_ENTRY(IDataObject)
	COM_INTERFACE_ENTRY(IProvideClassInfo)
	COM_INTERFACE_ENTRY(IProvideClassInfo2)
	COM_INTERFACE_ENTRY(IDropSource)
	COM_INTERFACE_ENTRY(IDropTarget)
	COM_INTERFACE_ENTRY_IMPL(IConnectionPointContainer)
END_COM_MAP()

BEGIN_PROP_MAP(CShellFolderTree)
	PROP_DATA_ENTRY("_cx", m_sizeExtent.cx, VT_UI4)
	PROP_DATA_ENTRY("_cy", m_sizeExtent.cy, VT_UI4)
	PROP_ENTRY("Appearance",				DISPID_APPEARANCE,					CLSID_NULL)
	PROP_ENTRY("AutoUpdate",				DISPID_CD_AUTOUPDATE,				CLSID_NULL)
	PROP_ENTRY("BorderStyle",				DISPID_BORDERSTYLE,					CLSID_NULL)
	PROP_ENTRY("Enabled",					DISPID_ENABLED,						CLSID_NULL)
	PROP_ENTRY("EnableDefaultAction",	DISPID_CD_ENABLEDEFAULTACTION,	CLSID_NULL)
	PROP_ENTRY("EnableDragDrop", 			DISPID_CD_ENABLEDRAGDROP,			CLSID_NULL)
	PROP_ENTRY("EnableShellMenu",			DISPID_CD_ENABLESHELLMENU,			CLSID_NULL)
	PROP_ENTRY("HasButtons",				DISPID_CD_HASBUTTONS,				CLSID_NULL)
	PROP_ENTRY("HasLines",					DISPID_CD_HASLINES,					CLSID_NULL)
	PROP_ENTRY("HasLinesAtRoot",			DISPID_CD_HASLINESATROOT,			CLSID_NULL)
	PROP_ENTRY("HasIcons",					DISPID_CD_HASICONS,					CLSID_NULL)
	PROP_ENTRY("HasOverlayIcons",			DISPID_CD_HASOVERLAYICONS,			CLSID_NULL)
	PROP_ENTRY("RootFolder",				DISPID_CD_ROOTFOLDER,   			CLSID_NULL)
	PROP_ENTRY("ShowFiles",					DISPID_CD_SHOWFILES, 				CLSID_NULL)
	PROP_ENTRY("ShowHidden",				DISPID_CD_SHOWHIDDEN,				CLSID_NULL)
	PROP_ENTRY("ShowSelAlways",			DISPID_CD_SHOWSELALWAYS,			CLSID_NULL)
END_PROP_MAP()

BEGIN_CONNECTION_POINT_MAP(CShellFolderTree)
	CONNECTION_POINT_ENTRY(IID_IPropertyNotifySink)
	CONNECTION_POINT_ENTRY(DIID__IShellFolderTreeEvents)
END_CONNECTION_POINT_MAP()

BEGIN_MSG_MAP(CShellFolderTree)
	MESSAGE_HANDLER(WM_CREATE, OnCreate)
	MESSAGE_HANDLER(WM_SETFOCUS, OnSetFocus)
	MESSAGE_HANDLER(WM_CONTEXTMENU, OnContextMenu)
	NOTIFY_HANDLER(100, TVN_KEYDOWN, OnKeyDown)
	NOTIFY_HANDLER(100, TVN_DELETEITEM, OnDeleteItem)
	NOTIFY_HANDLER(100, TVN_ITEMEXPANDING, OnItemExpanding)
	NOTIFY_HANDLER(100, TVN_ITEMEXPANDED, OnItemExpanded)
	NOTIFY_HANDLER(100, TVN_SELCHANGING, OnSelChanged)
	NOTIFY_HANDLER(100, TVN_BEGINDRAG, OnBeginDrag)
	NOTIFY_HANDLER(100, TVN_BEGINRDRAG, OnBeginDrag)
	NOTIFY_HANDLER(100, NM_RCLICK, OnRightClick)
	NOTIFY_HANDLER(100, NM_DBLCLK, OnDblClick)
	CHAIN_MSG_MAP(CComControl<CShellFolderTree>)
ALT_MSG_MAP(1)
	MESSAGE_HANDLER(WM_SETCURSOR, OnSetCursor)
	MESSAGE_HANDLER(WM_DESTROY, OnDestroy)
	MESSAGE_HANDLER(WM_LBUTTONDOWN, OnButtonDown)
	MESSAGE_HANDLER(WM_RBUTTONDOWN, OnButtonDown)
END_MSG_MAP()
// Handler prototypes:
//  LRESULT MessageHandler(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);
//  LRESULT CommandHandler(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled);
//  LRESULT NotifyHandler(int idCtrl, LPNMHDR pnmh, BOOL& bHandled);

	friend class CTreeLock;

	class CTreeLock
	{
	private:

		HANDLE				m_hmtx;

	private:
								CTreeLock() {};
	public:

								CTreeLock(CShellFolderTree* pTree);

								~CTreeLock();
	};

	typedef struct tagFolderTreeInsertStruct : private TVINSERTSTRUCT
	{
		char					m_szBuff[_MAX_PATH],
								m_szPath[_MAX_PATH];

		DWORD					m_dwAttributes;

		tagFolderTreeInsertStruct(HTREEITEM hParentSet = NULL)
		{
			hParent					 = hParentSet;
			itemex.lParam			 = 0;
			itemex.cChildren		 = 0;
			itemex.iImage			 = 0;
			itemex.iSelectedImage = 0;
			m_szBuff[0]				 = 0x00;
			m_szPath[0]				 = 0x00;
		}

		void Set(CPIDL* ppidl, char* szText, DWORD dwAttributes, INT iImage, INT iSelectedImage, DWORD dwState = 0)
		{
			lstrcpy(m_szBuff, szText);
			itemex.lParam			 = reinterpret_cast<LPARAM>(ppidl);
			itemex.cChildren		 = dwAttributes & SFGAO_HASSUBFOLDER ? 1 : 0;
			itemex.iImage			 = iImage;
			itemex.iSelectedImage = iSelectedImage;
			itemex.state			 = dwState;
			itemex.stateMask		 = dwState;
			m_dwAttributes        = dwAttributes;
		}

		void DestroyPidl()
		{
			delete reinterpret_cast<CPIDL*>(itemex.lParam);
			itemex.lParam = 0;
		}

		TVINSERTSTRUCT* GetTVINSERTSTRUCT(BOOL bIcons)
		{
			hInsertAfter	= TVI_LAST;
			itemex.mask		= TVIF_TEXT | TVIF_PARAM | TVIF_CHILDREN | TVIF_STATE | (bIcons ? TVIF_IMAGE | TVIF_SELECTEDIMAGE : 0);
			itemex.pszText	= m_szBuff;
			return static_cast<TVINSERTSTRUCT*>(this);
		}

	} SFolderTreeInsertStruct;

	typedef std::vector<SFolderTreeInsertStruct> V_InsertStruct;

	typedef std::map<HANDLE, HTREEITEM> M_HandleToTreeitem;
	typedef std::map<HTREEITEM, HANDLE> M_TreeitemToHandle;

	CComPtr<IShellFolder> m_piDesktopFolder;

	CContainedWindow		m_ctlTree;

	_variant_t				m_vtRoot;

	bool						m_bWaitCursor;

	DWORD						m_dwMonitorThreadID;

	HANDLE					m_hMonitorThread;

	HANDLE					m_hmtxTreeLock;

	HIMAGELIST				m_himl;

	HTREEITEM				m_htiSelected;

	HTREEITEM				m_hDT;
	CComPtr<IDropTarget>	m_piDT;
	CComPtr<IDataObject>	m_piDO;

	short						m_nAppearance;

	LONG						m_nBorderStyle;
	
	VARIANT_BOOL			m_bEnabled;

	unsigned					m_bAutoUpdate				:	1,
								m_bEnableDefaultAction	:	1,
								m_bEnableDragDrop			:	1,
								m_bEnableShellMenu   	:  1,
								m_bHasButtons				:	1,
								m_bHasIcons					:	1,
								m_bHasLines					:	1,
								m_bHasLinesAtRoot			:	1,
								m_bHasOverlayIcons		:	1,
								m_bShowFiles				:	1,
								m_bShowHidden				:	1,
								m_bShowSelAlways			:	1;

public:

								CShellFolderTree();	

	HRESULT					FinalConstruct();

	HRESULT					FireOnChanged(DISPID dispID);

	BOOL						PreTranslateAccelerator(LPMSG pMsg, HRESULT& hRet);

	BOOL						GetTreeItemAbsPIDL(HTREEITEM hItem, CPIDL& pidlRet);

	BOOL						GetTreeItemAbsPath(HTREEITEM hITem, char* pszPathRet, bool bFileSystemOnly = false);

	HRESULT					PidlFromVariant(VARIANT& vt, CPIDL& pidlRet);

	HRESULT					EnsureVisibleImpl(CPIDL& pidl, BOOL bSelect);

	HRESULT					BuildInsertList(HTREEITEM hFolder, V_InsertStruct* pvecInserts, char* pszFolderPathRet, bool bIncludePaths);

	DWORD						AddFolderContents(HTREEITEM hParent);

	DWORD 					RefreshFolderContents(HTREEITEM hParent);

	void						InvokeSelectedItemCommand(long lCmd);

	CComPtr<IDropTarget>	UpdateDropTarget(IDataObject* piDO, POINTL pt);

	void						SortFolder(HTREEITEM hFolder);

	static int CALLBACK	SortFunc(LPARAM lParam1, LPARAM lParam2, LPARAM lParamSort);

	static DWORD WINAPI 
								MonitorThreadProc(LPVOID pvThis);

	void						MonitorFolder(M_HandleToTreeitem& mapHdlToTi, M_TreeitemToHandle& mapTiToHdl, HTREEITEM hti, bool bMonitor);

public:

	LRESULT					OnSetFocus(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);

	LRESULT					OnCreate(UINT /*uMsg*/, WPARAM /*wParam*/, LPARAM /*lParam*/, BOOL& /*bHandled*/);

	LRESULT					OnDestroy(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);
	
	LRESULT					OnDeleteItem(int idCtrl, LPNMHDR pnmh, BOOL& bHandled);

	LRESULT					OnItemExpanding(int idCtrl, LPNMHDR pnmh, BOOL& bHandled);

	LRESULT					OnItemExpanded(int idCtrl, LPNMHDR pnmh, BOOL& bHandled);

	LRESULT	      		OnSelChanged(int idCtrl, LPNMHDR pnmh, BOOL& bHandled);

	LRESULT					OnBeginDrag(int idCtrl, LPNMHDR pnmh, BOOL& bHandled);

	LRESULT					OnButtonDown(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);

	LRESULT					OnRightClick(int idCtrl, LPNMHDR pnmh, BOOL& bHandled);

	LRESULT					OnDblClick(int idCtrl, LPNMHDR pnmh, BOOL& bHandled);

	LRESULT					OnContextMenu(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);

	LRESULT					OnSetCursor(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);

	LRESULT	      		OnKeyDown(int idCtrl, LPNMHDR pnmh, BOOL& bHandled);
	
// IShellFolderTree
public:
	STDMETHOD(EnsureVisible)(VARIANT vtItem);
	STDMETHOD(Refresh)(VARIANT_BOOL bRebuildTree);
	STDMETHOD(get_ShowSelAlways)(/*[out, retval]*/ VARIANT_BOOL *pVal);
	STDMETHOD(put_ShowSelAlways)(/*[in]*/ VARIANT_BOOL newVal);
	STDMETHOD(get_ShowHidden)(/*[out, retval]*/ VARIANT_BOOL *pVal);
	STDMETHOD(put_ShowHidden)(/*[in]*/ VARIANT_BOOL newVal);
	STDMETHOD(get_ShowFiles)(/*[out, retval]*/ VARIANT_BOOL *pVal);
	STDMETHOD(put_ShowFiles)(/*[in]*/ VARIANT_BOOL newVal);
	STDMETHOD(get_SelectedItemPath)(/*[out, retval]*/ BSTR *pVal);
	STDMETHOD(put_SelectedItemPath)(/*[in]*/ BSTR newVal);
	STDMETHOD(get_RootFolder)(/*[out, retval]*/ VARIANT *pVal);
	STDMETHOD(put_RootFolder)(/*[in]*/ VARIANT newVal);
	STDMETHOD(get_HasOverlayIcons)(/*[out, retval]*/ VARIANT_BOOL *pVal);
	STDMETHOD(put_HasOverlayIcons)(/*[in]*/ VARIANT_BOOL newVal);
	STDMETHOD(get_HasIcons)(/*[out, retval]*/ VARIANT_BOOL *pVal);
	STDMETHOD(put_HasIcons)(/*[in]*/ VARIANT_BOOL newVal);
	STDMETHOD(get_HasLinesAtRoot)(/*[out, retval]*/ VARIANT_BOOL *pVal);
	STDMETHOD(put_HasLinesAtRoot)(/*[in]*/ VARIANT_BOOL newVal);
	STDMETHOD(get_HasLines)(/*[out, retval]*/ VARIANT_BOOL *pVal);
	STDMETHOD(put_HasLines)(/*[in]*/ VARIANT_BOOL newVal);
	STDMETHOD(get_HasButtons)(/*[out, retval]*/ VARIANT_BOOL *pVal);
	STDMETHOD(put_HasButtons)(/*[in]*/ VARIANT_BOOL newVal);
	STDMETHOD(get_EnableShellMenu)(/*[out, retval]*/ VARIANT_BOOL *pVal);
	STDMETHOD(put_EnableShellMenu)(/*[in]*/ VARIANT_BOOL newVal);
	STDMETHOD(get_EnableDragDrop)(/*[out, retval]*/ VARIANT_BOOL *pVal);
	STDMETHOD(put_EnableDragDrop)(/*[in]*/ VARIANT_BOOL newVal);
	STDMETHOD(get_EnableDefaultAction)(/*[out, retval]*/ VARIANT_BOOL *pVal);
	STDMETHOD(put_EnableDefaultAction)(/*[in]*/ VARIANT_BOOL newVal);
	STDMETHOD(get_AutoUpdate)(/*[out, retval]*/ VARIANT_BOOL *pVal);
	STDMETHOD(put_AutoUpdate)(/*[in]*/ VARIANT_BOOL newVal);

// IOleInPlaceObject
	STDMETHOD(SetObjectRects)(LPCRECT prcPos,LPCRECT prcClip);

// IDropSource
	STDMETHOD(QueryContinueDrag)(BOOL fEscapePressed, DWORD grfKeyState);
	STDMETHOD(GiveFeedback)(DWORD dwEffect);
 
// IDropTarget
	STDMETHOD(DragEnter)(IDataObject * pDataObject, DWORD grfKeyState, POINTL pt, DWORD *pdwEffect);
	STDMETHOD(DragOver)(DWORD grfKeyState, POINTL pt, DWORD * pdwEffect);
	STDMETHOD(DragLeave)(void);
	STDMETHOD(Drop)(IDataObject * pDataObject, DWORD grfKeyState, POINTL pt, DWORD * pdwEffect);
};


#endif //__SHELLFOLDERTREE_H_
