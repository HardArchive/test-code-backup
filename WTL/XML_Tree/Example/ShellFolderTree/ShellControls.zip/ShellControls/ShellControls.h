
#pragma warning( disable: 4049 )  /* more than 64k source lines */

/* this ALWAYS GENERATED file contains the definitions for the interfaces */


 /* File created by MIDL compiler version 6.00.0347 */
/* at Wed May 15 10:41:50 2002
 */
/* Compiler settings for ShellControls.idl:
    Oicf, W1, Zp8, env=Win32 (32b run)
    protocol : dce , ms_ext, c_ext
    error checks: allocation ref bounds_check enum stub_data 
    VC __declspec() decoration level: 
         __declspec(uuid()), __declspec(selectany), __declspec(novtable)
         DECLSPEC_UUID(), MIDL_INTERFACE()
*/
//@@MIDL_FILE_HEADING(  )


/* verify that the <rpcndr.h> version is high enough to compile this file*/
#ifndef __REQUIRED_RPCNDR_H_VERSION__
#define __REQUIRED_RPCNDR_H_VERSION__ 440
#endif

#include "rpc.h"
#include "rpcndr.h"

#ifndef __ShellControls_h__
#define __ShellControls_h__

#if defined(_MSC_VER) && (_MSC_VER >= 1020)
#pragma once
#endif

/* Forward Declarations */ 

#ifndef __IShellFolderTree_FWD_DEFINED__
#define __IShellFolderTree_FWD_DEFINED__
typedef interface IShellFolderTree IShellFolderTree;
#endif 	/* __IShellFolderTree_FWD_DEFINED__ */


#ifndef ___IShellFolderTreeEvents_FWD_DEFINED__
#define ___IShellFolderTreeEvents_FWD_DEFINED__
typedef interface _IShellFolderTreeEvents _IShellFolderTreeEvents;
#endif 	/* ___IShellFolderTreeEvents_FWD_DEFINED__ */


#ifndef __ShellFolderTree_FWD_DEFINED__
#define __ShellFolderTree_FWD_DEFINED__

#ifdef __cplusplus
typedef class ShellFolderTree ShellFolderTree;
#else
typedef struct ShellFolderTree ShellFolderTree;
#endif /* __cplusplus */

#endif 	/* __ShellFolderTree_FWD_DEFINED__ */


/* header files for imported files */
#include "oaidl.h"
#include "ocidl.h"

#ifdef __cplusplus
extern "C"{
#endif 

void * __RPC_USER MIDL_user_allocate(size_t);
void __RPC_USER MIDL_user_free( void * ); 


#ifndef __SHLCTLS_LIBRARY_DEFINED__
#define __SHLCTLS_LIBRARY_DEFINED__

/* library SHLCTLS */
/* [helpstring][version][uuid] */ 

#define	DISPID_CD_AUTOUPDATE	( 10 )

#define	DISPID_CD_ENABLEDEFAULTACTION	( 20 )

#define	DISPID_CD_ENABLEDRAGDROP	( 30 )

#define	DISPID_CD_ENABLESHELLMENU	( 40 )

#define	DISPID_CD_ENSUREVISIBLE	( 50 )

#define	DISPID_CD_HASBUTTONS	( 60 )

#define	DISPID_CD_HASICONS	( 70 )

#define	DISPID_CD_HASLINES	( 80 )

#define	DISPID_CD_HASLINESATROOT	( 90 )

#define	DISPID_CD_HASOVERLAYICONS	( 100 )

#define	DISPID_CD_SELECTEDITEMPATH	( 120 )

#define	DISPID_CD_SHOWFILES	( 130 )

#define	DISPID_CD_SHOWHIDDEN	( 140 )

#define	DISPID_CD_SHOWSELALWAYS	( 150 )

#define	DISPID_CD_REFRESH	( 160 )

#define	DISPID_CD_ROOTFOLDER	( 170 )


EXTERN_C const IID LIBID_SHLCTLS;

#ifndef __IShellFolderTree_INTERFACE_DEFINED__
#define __IShellFolderTree_INTERFACE_DEFINED__

/* interface IShellFolderTree */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_IShellFolderTree;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("511C6710-CBC0-4b00-BFAE-B1427313462D")
    IShellFolderTree : public IDispatch
    {
    public:
        virtual /* [id][propput] */ HRESULT STDMETHODCALLTYPE put_Appearance( 
            /* [in] */ short appearance) = 0;
        
        virtual /* [id][propget] */ HRESULT STDMETHODCALLTYPE get_Appearance( 
            /* [retval][out] */ short *pappearance) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_AutoUpdate( 
            /* [retval][out] */ VARIANT_BOOL *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_AutoUpdate( 
            /* [in] */ VARIANT_BOOL newVal) = 0;
        
        virtual /* [id][propput] */ HRESULT STDMETHODCALLTYPE put_BorderStyle( 
            /* [in] */ long style) = 0;
        
        virtual /* [id][propget] */ HRESULT STDMETHODCALLTYPE get_BorderStyle( 
            /* [retval][out] */ long *pstyle) = 0;
        
        virtual /* [id][propput] */ HRESULT STDMETHODCALLTYPE put_Enabled( 
            /* [in] */ VARIANT_BOOL vbool) = 0;
        
        virtual /* [id][propget] */ HRESULT STDMETHODCALLTYPE get_Enabled( 
            /* [retval][out] */ VARIANT_BOOL *pbool) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_EnableDefaultAction( 
            /* [retval][out] */ VARIANT_BOOL *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_EnableDefaultAction( 
            /* [in] */ VARIANT_BOOL newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_EnableDragDrop( 
            /* [retval][out] */ VARIANT_BOOL *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_EnableDragDrop( 
            /* [in] */ VARIANT_BOOL newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_EnableShellMenu( 
            /* [retval][out] */ VARIANT_BOOL *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_EnableShellMenu( 
            /* [in] */ VARIANT_BOOL newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_HasIcons( 
            /* [retval][out] */ VARIANT_BOOL *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_HasIcons( 
            /* [in] */ VARIANT_BOOL newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_HasButtons( 
            /* [retval][out] */ VARIANT_BOOL *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_HasButtons( 
            /* [in] */ VARIANT_BOOL newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_HasLines( 
            /* [retval][out] */ VARIANT_BOOL *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_HasLines( 
            /* [in] */ VARIANT_BOOL newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_HasLinesAtRoot( 
            /* [retval][out] */ VARIANT_BOOL *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_HasLinesAtRoot( 
            /* [in] */ VARIANT_BOOL newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_HasOverlayIcons( 
            /* [retval][out] */ VARIANT_BOOL *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_HasOverlayIcons( 
            /* [in] */ VARIANT_BOOL newVal) = 0;
        
        virtual /* [id][propget] */ HRESULT STDMETHODCALLTYPE get_Window( 
            /* [retval][out] */ long *phwnd) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_SelectedItemPath( 
            /* [retval][out] */ BSTR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_SelectedItemPath( 
            /* [in] */ BSTR newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_ShowFiles( 
            /* [retval][out] */ VARIANT_BOOL *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_ShowFiles( 
            /* [in] */ VARIANT_BOOL newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_ShowHidden( 
            /* [retval][out] */ VARIANT_BOOL *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_ShowHidden( 
            /* [in] */ VARIANT_BOOL newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_ShowSelAlways( 
            /* [retval][out] */ VARIANT_BOOL *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_ShowSelAlways( 
            /* [in] */ VARIANT_BOOL newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_RootFolder( 
            /* [retval][out] */ VARIANT *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_RootFolder( 
            /* [in] */ VARIANT newVal) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE Refresh( 
            /* [defaultvalue][in] */ VARIANT_BOOL RebuildTree = 0) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE EnsureVisible( 
            VARIANT Folder) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IShellFolderTreeVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            IShellFolderTree * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            IShellFolderTree * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            IShellFolderTree * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            IShellFolderTree * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            IShellFolderTree * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            IShellFolderTree * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            IShellFolderTree * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS *pDispParams,
            /* [out] */ VARIANT *pVarResult,
            /* [out] */ EXCEPINFO *pExcepInfo,
            /* [out] */ UINT *puArgErr);
        
        /* [id][propput] */ HRESULT ( STDMETHODCALLTYPE *put_Appearance )( 
            IShellFolderTree * This,
            /* [in] */ short appearance);
        
        /* [id][propget] */ HRESULT ( STDMETHODCALLTYPE *get_Appearance )( 
            IShellFolderTree * This,
            /* [retval][out] */ short *pappearance);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE *get_AutoUpdate )( 
            IShellFolderTree * This,
            /* [retval][out] */ VARIANT_BOOL *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE *put_AutoUpdate )( 
            IShellFolderTree * This,
            /* [in] */ VARIANT_BOOL newVal);
        
        /* [id][propput] */ HRESULT ( STDMETHODCALLTYPE *put_BorderStyle )( 
            IShellFolderTree * This,
            /* [in] */ long style);
        
        /* [id][propget] */ HRESULT ( STDMETHODCALLTYPE *get_BorderStyle )( 
            IShellFolderTree * This,
            /* [retval][out] */ long *pstyle);
        
        /* [id][propput] */ HRESULT ( STDMETHODCALLTYPE *put_Enabled )( 
            IShellFolderTree * This,
            /* [in] */ VARIANT_BOOL vbool);
        
        /* [id][propget] */ HRESULT ( STDMETHODCALLTYPE *get_Enabled )( 
            IShellFolderTree * This,
            /* [retval][out] */ VARIANT_BOOL *pbool);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE *get_EnableDefaultAction )( 
            IShellFolderTree * This,
            /* [retval][out] */ VARIANT_BOOL *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE *put_EnableDefaultAction )( 
            IShellFolderTree * This,
            /* [in] */ VARIANT_BOOL newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE *get_EnableDragDrop )( 
            IShellFolderTree * This,
            /* [retval][out] */ VARIANT_BOOL *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE *put_EnableDragDrop )( 
            IShellFolderTree * This,
            /* [in] */ VARIANT_BOOL newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE *get_EnableShellMenu )( 
            IShellFolderTree * This,
            /* [retval][out] */ VARIANT_BOOL *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE *put_EnableShellMenu )( 
            IShellFolderTree * This,
            /* [in] */ VARIANT_BOOL newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE *get_HasIcons )( 
            IShellFolderTree * This,
            /* [retval][out] */ VARIANT_BOOL *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE *put_HasIcons )( 
            IShellFolderTree * This,
            /* [in] */ VARIANT_BOOL newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE *get_HasButtons )( 
            IShellFolderTree * This,
            /* [retval][out] */ VARIANT_BOOL *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE *put_HasButtons )( 
            IShellFolderTree * This,
            /* [in] */ VARIANT_BOOL newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE *get_HasLines )( 
            IShellFolderTree * This,
            /* [retval][out] */ VARIANT_BOOL *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE *put_HasLines )( 
            IShellFolderTree * This,
            /* [in] */ VARIANT_BOOL newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE *get_HasLinesAtRoot )( 
            IShellFolderTree * This,
            /* [retval][out] */ VARIANT_BOOL *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE *put_HasLinesAtRoot )( 
            IShellFolderTree * This,
            /* [in] */ VARIANT_BOOL newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE *get_HasOverlayIcons )( 
            IShellFolderTree * This,
            /* [retval][out] */ VARIANT_BOOL *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE *put_HasOverlayIcons )( 
            IShellFolderTree * This,
            /* [in] */ VARIANT_BOOL newVal);
        
        /* [id][propget] */ HRESULT ( STDMETHODCALLTYPE *get_Window )( 
            IShellFolderTree * This,
            /* [retval][out] */ long *phwnd);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE *get_SelectedItemPath )( 
            IShellFolderTree * This,
            /* [retval][out] */ BSTR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE *put_SelectedItemPath )( 
            IShellFolderTree * This,
            /* [in] */ BSTR newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE *get_ShowFiles )( 
            IShellFolderTree * This,
            /* [retval][out] */ VARIANT_BOOL *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE *put_ShowFiles )( 
            IShellFolderTree * This,
            /* [in] */ VARIANT_BOOL newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE *get_ShowHidden )( 
            IShellFolderTree * This,
            /* [retval][out] */ VARIANT_BOOL *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE *put_ShowHidden )( 
            IShellFolderTree * This,
            /* [in] */ VARIANT_BOOL newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE *get_ShowSelAlways )( 
            IShellFolderTree * This,
            /* [retval][out] */ VARIANT_BOOL *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE *put_ShowSelAlways )( 
            IShellFolderTree * This,
            /* [in] */ VARIANT_BOOL newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE *get_RootFolder )( 
            IShellFolderTree * This,
            /* [retval][out] */ VARIANT *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE *put_RootFolder )( 
            IShellFolderTree * This,
            /* [in] */ VARIANT newVal);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *Refresh )( 
            IShellFolderTree * This,
            /* [defaultvalue][in] */ VARIANT_BOOL RebuildTree);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *EnsureVisible )( 
            IShellFolderTree * This,
            VARIANT Folder);
        
        END_INTERFACE
    } IShellFolderTreeVtbl;

    interface IShellFolderTree
    {
        CONST_VTBL struct IShellFolderTreeVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IShellFolderTree_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IShellFolderTree_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IShellFolderTree_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IShellFolderTree_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define IShellFolderTree_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define IShellFolderTree_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define IShellFolderTree_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define IShellFolderTree_put_Appearance(This,appearance)	\
    (This)->lpVtbl -> put_Appearance(This,appearance)

#define IShellFolderTree_get_Appearance(This,pappearance)	\
    (This)->lpVtbl -> get_Appearance(This,pappearance)

#define IShellFolderTree_get_AutoUpdate(This,pVal)	\
    (This)->lpVtbl -> get_AutoUpdate(This,pVal)

#define IShellFolderTree_put_AutoUpdate(This,newVal)	\
    (This)->lpVtbl -> put_AutoUpdate(This,newVal)

#define IShellFolderTree_put_BorderStyle(This,style)	\
    (This)->lpVtbl -> put_BorderStyle(This,style)

#define IShellFolderTree_get_BorderStyle(This,pstyle)	\
    (This)->lpVtbl -> get_BorderStyle(This,pstyle)

#define IShellFolderTree_put_Enabled(This,vbool)	\
    (This)->lpVtbl -> put_Enabled(This,vbool)

#define IShellFolderTree_get_Enabled(This,pbool)	\
    (This)->lpVtbl -> get_Enabled(This,pbool)

#define IShellFolderTree_get_EnableDefaultAction(This,pVal)	\
    (This)->lpVtbl -> get_EnableDefaultAction(This,pVal)

#define IShellFolderTree_put_EnableDefaultAction(This,newVal)	\
    (This)->lpVtbl -> put_EnableDefaultAction(This,newVal)

#define IShellFolderTree_get_EnableDragDrop(This,pVal)	\
    (This)->lpVtbl -> get_EnableDragDrop(This,pVal)

#define IShellFolderTree_put_EnableDragDrop(This,newVal)	\
    (This)->lpVtbl -> put_EnableDragDrop(This,newVal)

#define IShellFolderTree_get_EnableShellMenu(This,pVal)	\
    (This)->lpVtbl -> get_EnableShellMenu(This,pVal)

#define IShellFolderTree_put_EnableShellMenu(This,newVal)	\
    (This)->lpVtbl -> put_EnableShellMenu(This,newVal)

#define IShellFolderTree_get_HasIcons(This,pVal)	\
    (This)->lpVtbl -> get_HasIcons(This,pVal)

#define IShellFolderTree_put_HasIcons(This,newVal)	\
    (This)->lpVtbl -> put_HasIcons(This,newVal)

#define IShellFolderTree_get_HasButtons(This,pVal)	\
    (This)->lpVtbl -> get_HasButtons(This,pVal)

#define IShellFolderTree_put_HasButtons(This,newVal)	\
    (This)->lpVtbl -> put_HasButtons(This,newVal)

#define IShellFolderTree_get_HasLines(This,pVal)	\
    (This)->lpVtbl -> get_HasLines(This,pVal)

#define IShellFolderTree_put_HasLines(This,newVal)	\
    (This)->lpVtbl -> put_HasLines(This,newVal)

#define IShellFolderTree_get_HasLinesAtRoot(This,pVal)	\
    (This)->lpVtbl -> get_HasLinesAtRoot(This,pVal)

#define IShellFolderTree_put_HasLinesAtRoot(This,newVal)	\
    (This)->lpVtbl -> put_HasLinesAtRoot(This,newVal)

#define IShellFolderTree_get_HasOverlayIcons(This,pVal)	\
    (This)->lpVtbl -> get_HasOverlayIcons(This,pVal)

#define IShellFolderTree_put_HasOverlayIcons(This,newVal)	\
    (This)->lpVtbl -> put_HasOverlayIcons(This,newVal)

#define IShellFolderTree_get_Window(This,phwnd)	\
    (This)->lpVtbl -> get_Window(This,phwnd)

#define IShellFolderTree_get_SelectedItemPath(This,pVal)	\
    (This)->lpVtbl -> get_SelectedItemPath(This,pVal)

#define IShellFolderTree_put_SelectedItemPath(This,newVal)	\
    (This)->lpVtbl -> put_SelectedItemPath(This,newVal)

#define IShellFolderTree_get_ShowFiles(This,pVal)	\
    (This)->lpVtbl -> get_ShowFiles(This,pVal)

#define IShellFolderTree_put_ShowFiles(This,newVal)	\
    (This)->lpVtbl -> put_ShowFiles(This,newVal)

#define IShellFolderTree_get_ShowHidden(This,pVal)	\
    (This)->lpVtbl -> get_ShowHidden(This,pVal)

#define IShellFolderTree_put_ShowHidden(This,newVal)	\
    (This)->lpVtbl -> put_ShowHidden(This,newVal)

#define IShellFolderTree_get_ShowSelAlways(This,pVal)	\
    (This)->lpVtbl -> get_ShowSelAlways(This,pVal)

#define IShellFolderTree_put_ShowSelAlways(This,newVal)	\
    (This)->lpVtbl -> put_ShowSelAlways(This,newVal)

#define IShellFolderTree_get_RootFolder(This,pVal)	\
    (This)->lpVtbl -> get_RootFolder(This,pVal)

#define IShellFolderTree_put_RootFolder(This,newVal)	\
    (This)->lpVtbl -> put_RootFolder(This,newVal)

#define IShellFolderTree_Refresh(This,RebuildTree)	\
    (This)->lpVtbl -> Refresh(This,RebuildTree)

#define IShellFolderTree_EnsureVisible(This,Folder)	\
    (This)->lpVtbl -> EnsureVisible(This,Folder)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [id][propput] */ HRESULT STDMETHODCALLTYPE IShellFolderTree_put_Appearance_Proxy( 
    IShellFolderTree * This,
    /* [in] */ short appearance);


void __RPC_STUB IShellFolderTree_put_Appearance_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [id][propget] */ HRESULT STDMETHODCALLTYPE IShellFolderTree_get_Appearance_Proxy( 
    IShellFolderTree * This,
    /* [retval][out] */ short *pappearance);


void __RPC_STUB IShellFolderTree_get_Appearance_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IShellFolderTree_get_AutoUpdate_Proxy( 
    IShellFolderTree * This,
    /* [retval][out] */ VARIANT_BOOL *pVal);


void __RPC_STUB IShellFolderTree_get_AutoUpdate_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IShellFolderTree_put_AutoUpdate_Proxy( 
    IShellFolderTree * This,
    /* [in] */ VARIANT_BOOL newVal);


void __RPC_STUB IShellFolderTree_put_AutoUpdate_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [id][propput] */ HRESULT STDMETHODCALLTYPE IShellFolderTree_put_BorderStyle_Proxy( 
    IShellFolderTree * This,
    /* [in] */ long style);


void __RPC_STUB IShellFolderTree_put_BorderStyle_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [id][propget] */ HRESULT STDMETHODCALLTYPE IShellFolderTree_get_BorderStyle_Proxy( 
    IShellFolderTree * This,
    /* [retval][out] */ long *pstyle);


void __RPC_STUB IShellFolderTree_get_BorderStyle_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [id][propput] */ HRESULT STDMETHODCALLTYPE IShellFolderTree_put_Enabled_Proxy( 
    IShellFolderTree * This,
    /* [in] */ VARIANT_BOOL vbool);


void __RPC_STUB IShellFolderTree_put_Enabled_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [id][propget] */ HRESULT STDMETHODCALLTYPE IShellFolderTree_get_Enabled_Proxy( 
    IShellFolderTree * This,
    /* [retval][out] */ VARIANT_BOOL *pbool);


void __RPC_STUB IShellFolderTree_get_Enabled_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IShellFolderTree_get_EnableDefaultAction_Proxy( 
    IShellFolderTree * This,
    /* [retval][out] */ VARIANT_BOOL *pVal);


void __RPC_STUB IShellFolderTree_get_EnableDefaultAction_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IShellFolderTree_put_EnableDefaultAction_Proxy( 
    IShellFolderTree * This,
    /* [in] */ VARIANT_BOOL newVal);


void __RPC_STUB IShellFolderTree_put_EnableDefaultAction_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IShellFolderTree_get_EnableDragDrop_Proxy( 
    IShellFolderTree * This,
    /* [retval][out] */ VARIANT_BOOL *pVal);


void __RPC_STUB IShellFolderTree_get_EnableDragDrop_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IShellFolderTree_put_EnableDragDrop_Proxy( 
    IShellFolderTree * This,
    /* [in] */ VARIANT_BOOL newVal);


void __RPC_STUB IShellFolderTree_put_EnableDragDrop_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IShellFolderTree_get_EnableShellMenu_Proxy( 
    IShellFolderTree * This,
    /* [retval][out] */ VARIANT_BOOL *pVal);


void __RPC_STUB IShellFolderTree_get_EnableShellMenu_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IShellFolderTree_put_EnableShellMenu_Proxy( 
    IShellFolderTree * This,
    /* [in] */ VARIANT_BOOL newVal);


void __RPC_STUB IShellFolderTree_put_EnableShellMenu_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IShellFolderTree_get_HasIcons_Proxy( 
    IShellFolderTree * This,
    /* [retval][out] */ VARIANT_BOOL *pVal);


void __RPC_STUB IShellFolderTree_get_HasIcons_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IShellFolderTree_put_HasIcons_Proxy( 
    IShellFolderTree * This,
    /* [in] */ VARIANT_BOOL newVal);


void __RPC_STUB IShellFolderTree_put_HasIcons_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IShellFolderTree_get_HasButtons_Proxy( 
    IShellFolderTree * This,
    /* [retval][out] */ VARIANT_BOOL *pVal);


void __RPC_STUB IShellFolderTree_get_HasButtons_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IShellFolderTree_put_HasButtons_Proxy( 
    IShellFolderTree * This,
    /* [in] */ VARIANT_BOOL newVal);


void __RPC_STUB IShellFolderTree_put_HasButtons_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IShellFolderTree_get_HasLines_Proxy( 
    IShellFolderTree * This,
    /* [retval][out] */ VARIANT_BOOL *pVal);


void __RPC_STUB IShellFolderTree_get_HasLines_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IShellFolderTree_put_HasLines_Proxy( 
    IShellFolderTree * This,
    /* [in] */ VARIANT_BOOL newVal);


void __RPC_STUB IShellFolderTree_put_HasLines_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IShellFolderTree_get_HasLinesAtRoot_Proxy( 
    IShellFolderTree * This,
    /* [retval][out] */ VARIANT_BOOL *pVal);


void __RPC_STUB IShellFolderTree_get_HasLinesAtRoot_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IShellFolderTree_put_HasLinesAtRoot_Proxy( 
    IShellFolderTree * This,
    /* [in] */ VARIANT_BOOL newVal);


void __RPC_STUB IShellFolderTree_put_HasLinesAtRoot_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IShellFolderTree_get_HasOverlayIcons_Proxy( 
    IShellFolderTree * This,
    /* [retval][out] */ VARIANT_BOOL *pVal);


void __RPC_STUB IShellFolderTree_get_HasOverlayIcons_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IShellFolderTree_put_HasOverlayIcons_Proxy( 
    IShellFolderTree * This,
    /* [in] */ VARIANT_BOOL newVal);


void __RPC_STUB IShellFolderTree_put_HasOverlayIcons_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [id][propget] */ HRESULT STDMETHODCALLTYPE IShellFolderTree_get_Window_Proxy( 
    IShellFolderTree * This,
    /* [retval][out] */ long *phwnd);


void __RPC_STUB IShellFolderTree_get_Window_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IShellFolderTree_get_SelectedItemPath_Proxy( 
    IShellFolderTree * This,
    /* [retval][out] */ BSTR *pVal);


void __RPC_STUB IShellFolderTree_get_SelectedItemPath_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IShellFolderTree_put_SelectedItemPath_Proxy( 
    IShellFolderTree * This,
    /* [in] */ BSTR newVal);


void __RPC_STUB IShellFolderTree_put_SelectedItemPath_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IShellFolderTree_get_ShowFiles_Proxy( 
    IShellFolderTree * This,
    /* [retval][out] */ VARIANT_BOOL *pVal);


void __RPC_STUB IShellFolderTree_get_ShowFiles_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IShellFolderTree_put_ShowFiles_Proxy( 
    IShellFolderTree * This,
    /* [in] */ VARIANT_BOOL newVal);


void __RPC_STUB IShellFolderTree_put_ShowFiles_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IShellFolderTree_get_ShowHidden_Proxy( 
    IShellFolderTree * This,
    /* [retval][out] */ VARIANT_BOOL *pVal);


void __RPC_STUB IShellFolderTree_get_ShowHidden_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IShellFolderTree_put_ShowHidden_Proxy( 
    IShellFolderTree * This,
    /* [in] */ VARIANT_BOOL newVal);


void __RPC_STUB IShellFolderTree_put_ShowHidden_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IShellFolderTree_get_ShowSelAlways_Proxy( 
    IShellFolderTree * This,
    /* [retval][out] */ VARIANT_BOOL *pVal);


void __RPC_STUB IShellFolderTree_get_ShowSelAlways_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IShellFolderTree_put_ShowSelAlways_Proxy( 
    IShellFolderTree * This,
    /* [in] */ VARIANT_BOOL newVal);


void __RPC_STUB IShellFolderTree_put_ShowSelAlways_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IShellFolderTree_get_RootFolder_Proxy( 
    IShellFolderTree * This,
    /* [retval][out] */ VARIANT *pVal);


void __RPC_STUB IShellFolderTree_get_RootFolder_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IShellFolderTree_put_RootFolder_Proxy( 
    IShellFolderTree * This,
    /* [in] */ VARIANT newVal);


void __RPC_STUB IShellFolderTree_put_RootFolder_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IShellFolderTree_Refresh_Proxy( 
    IShellFolderTree * This,
    /* [defaultvalue][in] */ VARIANT_BOOL RebuildTree);


void __RPC_STUB IShellFolderTree_Refresh_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IShellFolderTree_EnsureVisible_Proxy( 
    IShellFolderTree * This,
    VARIANT Folder);


void __RPC_STUB IShellFolderTree_EnsureVisible_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IShellFolderTree_INTERFACE_DEFINED__ */


#ifndef ___IShellFolderTreeEvents_DISPINTERFACE_DEFINED__
#define ___IShellFolderTreeEvents_DISPINTERFACE_DEFINED__

/* dispinterface _IShellFolderTreeEvents */
/* [helpstring][uuid] */ 


EXTERN_C const IID DIID__IShellFolderTreeEvents;

#if defined(__cplusplus) && !defined(CINTERFACE)

    MIDL_INTERFACE("6011D552-973E-42ce-A049-1F62B156D957")
    _IShellFolderTreeEvents : public IDispatch
    {
    };
    
#else 	/* C style interface */

    typedef struct _IShellFolderTreeEventsVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            _IShellFolderTreeEvents * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            _IShellFolderTreeEvents * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            _IShellFolderTreeEvents * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            _IShellFolderTreeEvents * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            _IShellFolderTreeEvents * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            _IShellFolderTreeEvents * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            _IShellFolderTreeEvents * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS *pDispParams,
            /* [out] */ VARIANT *pVarResult,
            /* [out] */ EXCEPINFO *pExcepInfo,
            /* [out] */ UINT *puArgErr);
        
        END_INTERFACE
    } _IShellFolderTreeEventsVtbl;

    interface _IShellFolderTreeEvents
    {
        CONST_VTBL struct _IShellFolderTreeEventsVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define _IShellFolderTreeEvents_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define _IShellFolderTreeEvents_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define _IShellFolderTreeEvents_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define _IShellFolderTreeEvents_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define _IShellFolderTreeEvents_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define _IShellFolderTreeEvents_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define _IShellFolderTreeEvents_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)

#endif /* COBJMACROS */


#endif 	/* C style interface */


#endif 	/* ___IShellFolderTreeEvents_DISPINTERFACE_DEFINED__ */


EXTERN_C const CLSID CLSID_ShellFolderTree;

#ifdef __cplusplus

class DECLSPEC_UUID("A11BEB14-DEA0-4e1d-98AE-99B5E538DB31")
ShellFolderTree;
#endif
#endif /* __SHLCTLS_LIBRARY_DEFINED__ */

/* Additional Prototypes for ALL interfaces */

/* end of Additional Prototypes */

#ifdef __cplusplus
}
#endif

#endif


