// ShellFolderTree.cpp : Implementation of CShellFolderTree

#include "stdafx.h"
#include "ShellControls.h"
#include "ShellFolderTree.h"
#include "GetSystemImageList.h"

#define IDM_SHELLCTXFIRST			20000
#define IDM_SHELLCTXLAST			29999
#define IDM_SENDTOFIRST				30000
#define IDM_SENDTOLAST				32767

#define PPIDL_FROM_LPARAM(l)		(reinterpret_cast<CPIDL*>(l))
#define PIDL_FROM_LPARAM(l)		(*reinterpret_cast<CPIDL*>(l))

#define WM_USER_MONITOR_FOLDER	(WM_USER+1)
#define WM_USER_MONITOR_RESET		(WM_USER+2)

struct __declspec(uuid("000214e4-0000-0000-c000-000000000046")) IContextMenu;


/////////////////////////////////////////////////////////////////////////////
// CShellFolderTree

CShellFolderTree::CShellFolderTree()
:	m_ctlTree(_T("SysTreeView32"), this, 1),
	m_dwMonitorThreadID(0),
	m_htiSelected(NULL),
	m_hDT(0),
	m_himl(NULL),
	m_bWaitCursor(false),
	m_vtRoot((long)CSIDL_DESKTOP),
	m_nAppearance(1),
	m_nBorderStyle(0),
	m_bEnabled(VARIANT_TRUE),
	m_bAutoUpdate(0x1),
	m_bEnableDefaultAction(0x1),
	m_bEnableDragDrop(0x1),
	m_bEnableShellMenu(0x1),
	m_bHasButtons(0x1),
	m_bHasIcons(0x1),
	m_bHasLines(0x1),
	m_bHasLinesAtRoot(0x0),
	m_bHasOverlayIcons(0x1),
	m_bShowFiles(0x1),
	m_bShowHidden(0x0),
	m_bShowSelAlways(0x1)
{
	// no windowless:
	m_bWindowOnly = TRUE;
}

HRESULT CShellFolderTree::FinalConstruct()
{
	// cache a pointer to the desktop IShellFolder interface:
	HRESULT hr = ::SHGetDesktopFolder(&m_piDesktopFolder);
	if (FAILED(hr)) return hr;

	// cache the system image list:
	m_himl = GetSystemImageList(TRUE);

	return S_OK;
}

HRESULT CShellFolderTree::FireOnChanged(DISPID dispID)
{
	if (m_ctlTree.m_hWnd)
	{
		switch (dispID)
		{
		case DISPID_APPEARANCE:
			m_ctlTree.ModifyStyleEx(m_nAppearance == 0 ? WS_EX_CLIENTEDGE : 0, m_nAppearance != 0 ? WS_EX_CLIENTEDGE : 0);
			break;

		case DISPID_BORDERSTYLE:
			m_ctlTree.ModifyStyle(m_nBorderStyle == 0 ? WS_BORDER : 0, m_nAppearance != 0 ? WS_BORDER : 0);
			break;

		case DISPID_ENABLED:
			m_ctlTree.EnableWindow(m_bEnabled == VARIANT_TRUE ? TRUE : FALSE);
			break;

		case DISPID_CD_HASBUTTONS:
			m_ctlTree.ModifyStyle(m_bHasButtons == 0x0 ? TVS_HASBUTTONS : 0, m_bHasButtons != 0 ? TVS_HASBUTTONS : 0);
			break;

		case DISPID_CD_HASLINES:
			m_ctlTree.ModifyStyle(m_bHasLines == 0x0 ? TVS_HASLINES : 0, m_bHasLines != 0 ? TVS_HASLINES : 0);
			break;

		case DISPID_CD_HASLINESATROOT:
			m_ctlTree.ModifyStyle(m_bHasLinesAtRoot == 0x0 ? TVS_LINESATROOT : 0, m_bHasLinesAtRoot != 0 ? TVS_LINESATROOT : 0);
			break;

		case DISPID_CD_SHOWSELALWAYS:
			m_ctlTree.ModifyStyle(m_bShowSelAlways == 0x0 ? TVS_SHOWSELALWAYS : 0, m_bShowSelAlways != 0 ? TVS_SHOWSELALWAYS : 0);
			break;
		}
	}

	return CComControl<CShellFolderTree>::FireOnChanged(dispID);
}


void CShellFolderTree::MonitorFolder(M_HandleToTreeitem& mapHdlToTi, M_TreeitemToHandle& mapTiToHdl, HTREEITEM hti, bool bMonitor)
{
	// find by treeitem:
	M_TreeitemToHandle::iterator itFindTi = mapTiToHdl.find(hti);

	// begin or end monitoring?
	if (true == bMonitor) 
	{
		// ensure we're not already monitoring this item:
		if (mapTiToHdl.end() == itFindTi)
		{
			// ensure this item is expanded:
			TVITEM tvi;
			tvi.hItem	  = hti;
			tvi.mask		  = TVIF_STATE;
			tvi.stateMask = TVIS_EXPANDED;
			if (TreeView_GetItem(m_ctlTree.m_hWnd, &tvi) && !(tvi.state & TVIS_EXPANDED))
				return;

			// determine the path to monitor:
			char szPath[_MAX_PATH];
			if (TRUE == GetTreeItemAbsPath(hti, szPath, true) && 0x00 != szPath[0])
			{
				// create monitor:
				HANDLE hChange = ::FindFirstChangeNotification(szPath, FALSE, FILE_NOTIFY_CHANGE_FILE_NAME | FILE_NOTIFY_CHANGE_DIR_NAME | FILE_NOTIFY_CHANGE_ATTRIBUTES);
				if (hChange)
				{
					mapTiToHdl.insert(M_TreeitemToHandle::value_type(hti, hChange));
					mapHdlToTi.insert(M_HandleToTreeitem::value_type(hChange, hti));
				}
			}
		}
	}
	else
	{
		// monitor exists?
		if (itFindTi != mapTiToHdl.end())
		{
			// stop monitoring this folder:
			::FindCloseChangeNotification(itFindTi->second);
			mapHdlToTi.erase(itFindTi->second);
			mapTiToHdl.erase(itFindTi);
		}
	}

	// now, apply same monitoring request to any child folders that are expanded:
	HTREEITEM htiChild = TreeView_GetChild(m_ctlTree.m_hWnd, hti);
	while (htiChild)
	{
		TVITEM tvi;
		tvi.hItem	  = htiChild;
		tvi.mask		  = TVIF_STATE;
		tvi.stateMask = TVIS_EXPANDED;
		if (TreeView_GetItem(m_ctlTree.m_hWnd, &tvi) && (tvi.state & TVIS_EXPANDED))
			MonitorFolder(mapHdlToTi, mapTiToHdl, htiChild, bMonitor);

		htiChild = TreeView_GetNextSibling(m_ctlTree.m_hWnd, htiChild);
	}
}

DWORD CShellFolderTree::MonitorThreadProc(LPVOID pvThis)
{
	// get our context:
	CShellFolderTree* pThis = reinterpret_cast<CShellFolderTree*>(pvThis);

	// maps track the change-handles/tree items we're monitoring:
	M_HandleToTreeitem mapHdlToTi;
	M_TreeitemToHandle mapTiToHdl;

	// cycle
	for (;;)
	{
		// generate an array of handles to monitor:
		typedef std::vector<HANDLE> V_Handle;
		V_Handle vecHandles;
		for (M_HandleToTreeitem::iterator it = mapHdlToTi.begin() ; it != mapHdlToTi.end() ; it++)
			vecHandles.push_back(it->first);

		// wait efficiently for something to happen:
		DWORD dwWaitRet = ::MsgWaitForMultipleObjects(vecHandles.size(), &vecHandles[0], FALSE, INFINITE, QS_ALLINPUT);

		// what triggered?
		if (dwWaitRet >= WAIT_OBJECT_0 && dwWaitRet < WAIT_OBJECT_0 + vecHandles.size())
		{
			// change notification:

			// refresh folder:
			M_HandleToTreeitem::iterator it = mapHdlToTi.find(vecHandles[dwWaitRet]);
			if (it != mapHdlToTi.end())
				pThis->RefreshFolderContents(it->second);

			// get next change notification for this folder:
         ::FindNextChangeNotification(vecHandles[dwWaitRet]);
		}
		else
		if (dwWaitRet == WAIT_OBJECT_0 + vecHandles.size())
		{
			// message in thread message queue:
			MSG msg;
			while (::PeekMessage(&msg, NULL, 0, 0, PM_REMOVE))
			{
				switch (msg.message)
				{
				case WM_QUIT:
				case WM_USER_MONITOR_RESET:
					{
						// close any remaining change-notification handles:
						for (M_HandleToTreeitem::iterator it = mapHdlToTi.begin() ; it != mapHdlToTi.end() ; it++)
							::FindCloseChangeNotification(it->first);

						mapHdlToTi.clear();
						mapTiToHdl.clear();

						if (WM_QUIT == msg.message)
							::ExitThread(0);
					}
					break;

				case WM_USER_MONITOR_FOLDER:

					if (0x1 == pThis->m_bAutoUpdate)
					{
						// add or remove folder monitor:
						CTreeLock lock(pThis);
						pThis->MonitorFolder(mapHdlToTi, mapTiToHdl, reinterpret_cast<HTREEITEM>(msg.wParam), msg.lParam ? true : false);
					}
					break;

				default:
					break;
				}
			}
		}
	}

	return 0;
}

int CShellFolderTree::SortFunc(LPARAM lParam1, LPARAM lParam2, LPARAM lParamSort)
{
	// sort info:
	IShellFolder* piSF = reinterpret_cast<IShellFolder*>(lParamSort);

	HRESULT hr = piSF->CompareIDs(0, PIDL_FROM_LPARAM(lParam1), PIDL_FROM_LPARAM(lParam2));
	if (SUCCEEDED(hr))
		return (SHORT)(hr & SHCIDS_COLUMNMASK);

	return 0;
}

void CShellFolderTree::SortFolder(HTREEITEM hFolder)
{
	CPIDL pidlFolder;
	GetTreeItemAbsPIDL(hFolder, pidlFolder);

	// get folder IShellFolder interface:
	IShellFolderPtr piFolder;
	HRESULT hr = m_piDesktopFolder->BindToObject(pidlFolder, NULL, IID_IShellFolder, reinterpret_cast<void**>(&piFolder));
	if (FAILED(hr)) 
		m_piDesktopFolder.QueryInterface(&piFolder);
		
	TVSORTCB tvscb;
	tvscb.hParent		= hFolder;
	tvscb.lpfnCompare = SortFunc;
	tvscb.lParam		= (LPARAM)piFolder.GetInterfacePtr();
	TreeView_SortChildrenCB(m_ctlTree.m_hWnd, &tvscb, 0);
}


BOOL CShellFolderTree::GetTreeItemAbsPIDL(HTREEITEM hItem, CPIDL& pidlRet)
{
	// get item relative pidl
	TVITEM tvi;	tvi.hItem = hItem, tvi.mask = TVIF_PARAM;
	if (FALSE == TreeView_GetItem(m_ctlTree.m_hWnd, &tvi))
		return FALSE;

	CPIDL& pidlThis = PIDL_FROM_LPARAM(tvi.lParam);

	// get parent absolute pidl:
	CPIDL pidlParent;
	HTREEITEM hParent = TreeView_GetParent(m_ctlTree.m_hWnd, hItem);
	if (hParent && FALSE == GetTreeItemAbsPIDL(hParent, pidlParent))
		return FALSE;

	// combine pidls:
	CPIDL::Concat(pidlParent, pidlThis, pidlRet);

	return TRUE;
}

BOOL CShellFolderTree::GetTreeItemAbsPath(HTREEITEM hItem, char* pszPathRet, bool bFileSystemOnly)
{
	// ensure we're operating:
	if (NULL == m_ctlTree.m_hWnd)
		return FALSE;

	// get item's pidl:
	CPIDL pidlAbsItem;
	if (FALSE == GetTreeItemAbsPIDL(hItem, pidlAbsItem))
		return FALSE;

	// determine item path (display name for non-filesystem objects:
	if (FALSE == ::SHGetPathFromIDList(pidlAbsItem, pszPathRet))
	{
		if (bFileSystemOnly)
			return FALSE;

		SHFILEINFO sfi; ::ZeroMemory(&sfi, sizeof(SHFILEINFO));
		::SHGetFileInfo((LPCSTR)(LPCITEMIDLIST)pidlAbsItem, 0, &sfi, sizeof(SHFILEINFO), SHGFI_PIDL | SHGFI_DISPLAYNAME);
		lstrcpy(pszPathRet, sfi.szDisplayName);
	}

	return TRUE;
}

HRESULT CShellFolderTree::PidlFromVariant(VARIANT& vt, CPIDL& pidlRet)
{
	// passed a path or CSIDL?
	HRESULT hr;
	if (vt.vt == VT_BSTR)
	{
		// obtain the corresponding pidl:
		hr = m_piDesktopFolder->ParseDisplayName(NULL, NULL, vt.bstrVal, NULL, pidlRet, NULL);
		if (SUCCEEDED(hr)) return hr;
	}

	if (vt.vt == VT_I4 || SUCCEEDED(::VariantChangeType(&vt, &vt, 0, VT_I4)))
	{
		// passed
		hr = ::SHGetSpecialFolderLocation(NULL, vt.lVal, pidlRet);
		if (FAILED(hr)) return hr;
	}
	else
	{
		return E_INVALIDARG;
	}

	return S_OK;
}

HRESULT CShellFolderTree::EnsureVisibleImpl(CPIDL& pidlItem, BOOL bSelect)
{
	// we manipulate the tree...
	CTreeLock lock(this);

	// start with root folder for search:
	HTREEITEM	htiCur = TreeView_GetChild(m_ctlTree.m_hWnd, TVI_ROOT);
	SHFILEINFO	sfi, 
					sfi2;
	char			pidlCur[1024]; ::ZeroMemory(pidlCur, sizeof(pidlCur));
	long			pidlCurLen(0);
	for (LPSHITEMID pidlRel = pidlItem.GetFirstItemID() ; pidlRel->cb ; )
	{
		// if it exceeds buffer length, we bail.
		if (pidlCurLen + pidlRel->cb > sizeof(pidlCur)-4)
			return E_FAIL;
		::CopyMemory(&pidlCur[pidlCurLen], pidlRel, pidlRel->cb);
		pidlCurLen += pidlRel->cb;
		::SHGetFileInfo((LPCSTR)(LPCITEMIDLIST)pidlCur, 0, &sfi, sizeof(SHFILEINFO), SHGFI_PIDL | SHGFI_DISPLAYNAME);

		// advance
		pidlItem.GetNextItemID(pidlRel);

		for (htiCur = TreeView_GetChild(m_ctlTree.m_hWnd, htiCur) ; htiCur ; htiCur = TreeView_GetNextSibling(m_ctlTree.m_hWnd, htiCur))
		{
			CPIDL pidlTreeItem;
			GetTreeItemAbsPIDL(htiCur, pidlTreeItem);
			::SHGetFileInfo((LPCSTR)(LPCITEMIDLIST)pidlTreeItem, 0, &sfi2, sizeof(SHFILEINFO), SHGFI_PIDL | SHGFI_DISPLAYNAME);

			if (0 == lstrcmp(sfi.szDisplayName, sfi2.szDisplayName))
			{
				if (pidlRel->cb)
				{
					TreeView_Expand(m_ctlTree.m_hWnd, htiCur, TVE_EXPAND);
				}
				else
				{
					TreeView_EnsureVisible(m_ctlTree.m_hWnd, htiCur);
					if (bSelect)
						TreeView_Select(m_ctlTree.m_hWnd, htiCur, TVGN_CARET);
				}
				break;
			}
		}
	}

	return S_OK;
}

HRESULT CShellFolderTree::BuildInsertList(HTREEITEM hFolder, V_InsertStruct* pvecInserts, char* pszFolderPathRet, bool bIncludePaths)
{
	// get item's pidl:
	CPIDL pidlFolder;
	if (FALSE == GetTreeItemAbsPIDL(hFolder, pidlFolder))
		return FALSE;
	if (pszFolderPathRet)
		::SHGetPathFromIDList(pidlFolder, pszFolderPathRet);

	// get folder interface:
	IShellFolderPtr piFolder;
	HRESULT hr = m_piDesktopFolder->BindToObject(pidlFolder, NULL, __uuidof(IShellFolder), reinterpret_cast<void**>(&piFolder));
	if (FAILED(hr)) 
		m_piDesktopFolder.QueryInterface(&piFolder);


	// enumerate objects in folder:
	IEnumIDListPtr piEnum;
	hr = piFolder->EnumObjects(NULL, SHCONTF_FOLDERS | (m_bShowHidden ? SHCONTF_INCLUDEHIDDEN : 0) | (m_bShowFiles ? SHCONTF_NONFOLDERS : 0) , &piEnum);
	if (FAILED(hr)) return hr;

	INT			 iOverlayIndex(0);
	DWORD			 dwStyle(0);
	LPITEMIDLIST pidlNext;
	SHFILEINFO   sfi;
	MSG			 msg;
	while (S_OK == piEnum->Next(1, &pidlNext, NULL))
	{
		// pump messages
		while (::PeekMessage(&msg, NULL, 0, 0, PM_REMOVE))
			::DispatchMessage(&msg);

		// wrap the pidl, generate an absolute pidl:
		CPIDL* ppidlChild = new CPIDL(pidlNext);
		if (NULL == ppidlChild) return E_OUTOFMEMORY;
		CPIDL pidlAbsChild; CPIDL::Concat(pidlFolder, *ppidlChild, pidlAbsChild);

		// get object info: icon, display name, attributes:
		sfi.iIcon = 0;
		::SHGetFileInfo((LPCSTR)(LPCITEMIDLIST)pidlAbsChild, 0, &sfi, sizeof(SHFILEINFO), SHGFI_PIDL | SHGFI_DISPLAYNAME | SHGFI_ATTRIBUTES | (m_bHasIcons ? SHGFI_SYSICONINDEX | SHGFI_SMALLICON : 0));

		// fix odd bug where all bits get lit for control panel objects
		if (0xFFFFFFFF == sfi.dwAttributes) 
			sfi.dwAttributes = 0;

		// determine if folder is empty or not:
		if (sfi.dwAttributes & SFGAO_FOLDER && !(sfi.dwAttributes & SFGAO_HASSUBFOLDER))
		{
			char szPath[_MAX_PATH];
			if (::SHGetPathFromIDList(pidlAbsChild, szPath))
			{
				lstrcat(szPath, "\\*.*");
				BOOL bRet(FALSE);
				WIN32_FIND_DATA fd;
				HANDLE hff = ::FindFirstFile(szPath, &fd);
				while (hff && fd.cFileName[0] == '.' && (bRet = ::FindNextFile(hff, &fd)));
				if (bRet)
					sfi.dwAttributes |= SFGAO_HASSUBFOLDER;
				::FindClose(hff);
			}
		}

		// ghosted image for hidden files, overlay image for shortcuts, shares:
		dwStyle = sfi.dwAttributes & SFGAO_GHOSTED ? TVIS_CUT : 0;

		if (m_bHasIcons && m_bHasOverlayIcons)
		{
			dwStyle |= sfi.dwAttributes & SFGAO_LINK    ? INDEXTOOVERLAYMASK(2) : 0;
			dwStyle |= sfi.dwAttributes & SFGAO_SHARE   ? INDEXTOOVERLAYMASK(1) : 0;
		}

		// initialize new insert item:
		SFolderTreeInsertStruct ftis(hFolder);
		ftis.Set(ppidlChild, sfi.szDisplayName, sfi.dwAttributes, sfi.iIcon, sfi.iIcon, dwStyle);

		// store path too?
		if (bIncludePaths)
			::SHGetPathFromIDList(pidlAbsChild, ftis.m_szPath);

		// store
		pvecInserts->push_back(ftis);
	}

	return S_OK;
}

DWORD CShellFolderTree::AddFolderContents(HTREEITEM hFolder)
{
	CTreeLock lock(this);

	HRESULT hr(S_OK);

	// get list of items to insert:
	V_InsertStruct vecInserts;
	char szFolderPath[_MAX_PATH];
	if (FAILED(BuildInsertList(hFolder, &vecInserts, szFolderPath, false)))
		return 0;

	// remove existing items first:
	for (HTREEITEM htiDel = TreeView_GetChild(m_ctlTree.m_hWnd, hFolder) ; NULL != htiDel ; htiDel = TreeView_GetChild(m_ctlTree.m_hWnd, hFolder) )
		TreeView_DeleteItem(m_ctlTree.m_hWnd, htiDel);

	// insert items to tree:
	for (V_InsertStruct::iterator it = vecInserts.begin() ; it != vecInserts.end() ; it++)
	{
		SFolderTreeInsertStruct& ftis = *it;
		TreeView_InsertItem(m_ctlTree.m_hWnd, ftis.GetTVINSERTSTRUCT(m_bHasIcons));
	}

	SortFolder(hFolder);

	return vecInserts.size();
}

DWORD CShellFolderTree::RefreshFolderContents(HTREEITEM hFolder)
{
	{ // scope for lock:
	CTreeLock lock(this);

	HRESULT	hr(S_OK);

	// get list of items that should be in the folder:
	V_InsertStruct vecInserts;
	if (FAILED(BuildInsertList(hFolder, &vecInserts, NULL, true)))
		return 0;

	// find items in the tree that should no longer exist, 
	// or that have changed in some manner
	for (HTREEITEM htiChild = TreeView_GetChild(m_ctlTree.m_hWnd, hFolder), htiNext(NULL) ; NULL != htiChild ; htiChild = htiNext)
	{
		// determine next item:
		htiNext = TreeView_GetNextSibling(m_ctlTree.m_hWnd, htiChild);

		// get the item's pidl:
		CPIDL pidlAbsChild;
		if (FALSE == GetTreeItemAbsPIDL(htiChild, pidlAbsChild))
			continue;

		// get the item's path:
		char szPath[_MAX_PATH];
		if (FAILED(::SHGetPathFromIDList(pidlAbsChild, szPath)) || 0x00 == szPath[0])
			continue;

		// determine if it exists in the updated insert list:
		bool bRemove = true;
		for (V_InsertStruct::iterator it = vecInserts.begin() ; it != vecInserts.end() ; it++)
		{
			SFolderTreeInsertStruct& ftis = *it;
			if (0 == lstrcmpi(ftis.m_szPath, szPath))
			{
				// ensure the item has appropriate display name, icon:
				char szBuff[_MAX_PATH];
				TVITEMEX tvi; ::ZeroMemory(&tvi, sizeof(tvi));
				tvi.cchTextMax = sizeof(szBuff);
				tvi.mask			= TVIF_IMAGE | TVIF_SELECTEDIMAGE | TVIF_TEXT | TVIF_STATE | TVIF_CHILDREN;
				tvi.stateMask	= TVIS_OVERLAYMASK | TVIS_CUT;
				tvi.hItem		= htiChild;
				tvi.pszText		= szBuff;
				if (TRUE == TreeView_GetItem(m_ctlTree.m_hWnd, &tvi))
				{
					TVITEMEX tviUpdate = ftis.GetTVINSERTSTRUCT(m_bHasIcons)->itemex;
					tvi.mask = 0;

					// check display name:
					if (0 != lstrcmp(tvi.pszText, tviUpdate.pszText))
					{
						lstrcpy(tvi.pszText, tviUpdate.pszText);
						tvi.mask |= TVIF_TEXT;
					}

					// check icons:
					if (tvi.iImage != tviUpdate.iImage || tvi.iSelectedImage != tviUpdate.iSelectedImage)
					{
						tvi.iImage = tviUpdate.iImage;
						tvi.iSelectedImage = tviUpdate.iSelectedImage;
						tvi.mask |= (m_bHasIcons ? TVIF_IMAGE | TVIF_SELECTEDIMAGE : 0);
					}

					// check state (overlay image):
					if (tvi.state != tviUpdate.state)
					{
						tvi.state = tviUpdate.state;
						tvi.mask |= TVIF_STATE;
					}

					if (tvi.cChildren |= tviUpdate.cChildren)
					{
						tvi.cChildren = tviUpdate.cChildren;
						tvi.mask |= TVIF_CHILDREN;
					}

					// update tree item:
					if (0 != tvi.mask)
						TreeView_SetItem(m_ctlTree.m_hWnd, &tvi);
				}

				// ensure we don't insert a new item, 
				// or remove the existing item in the next step:
				ftis.DestroyPidl();
				vecInserts.erase(it);
				bRemove = false;
				break;
			}
		}

		// remove the item if it no longer exists:
		if (true == bRemove)
			TreeView_DeleteItem(m_ctlTree.m_hWnd, htiChild);
	}

	// now insert remaining items:
	for (V_InsertStruct::iterator it = vecInserts.begin() ; it != vecInserts.end() ; it++)
	{																								 
		SFolderTreeInsertStruct& ftis = *it;
		if (ftis.m_dwAttributes & SFGAO_FILESYSTEM)
			TreeView_InsertItem(m_ctlTree.m_hWnd, ftis.GetTVINSERTSTRUCT(m_bHasIcons));
		else
			ftis.DestroyPidl();
	}

	// sort if items added:
	if (vecInserts.size())
		SortFolder(hFolder);

	} // end scope for lock

	// now, refresh any child folders that are expanded:
	HTREEITEM htiChild = TreeView_GetChild(m_ctlTree.m_hWnd, hFolder);
	while (htiChild)
	{
		TVITEM tvi;
		tvi.hItem	  = htiChild;
		tvi.mask		  = TVIF_STATE;
		tvi.stateMask = TVIS_EXPANDED;
		if (TreeView_GetItem(m_ctlTree.m_hWnd, &tvi) && (tvi.state & TVIS_EXPANDED))
			RefreshFolderContents(htiChild);

		htiChild = TreeView_GetNextSibling(m_ctlTree.m_hWnd, htiChild);
	}

	// fire updated event:
	char szPath[_MAX_PATH];
	GetTreeItemAbsPath(hFolder, szPath, false);
	_variant_t vtPath = szPath;
	Fire_FolderUpdated(vtPath);

	return 0;
}

void CShellFolderTree::InvokeSelectedItemCommand(long lCmd)
{
	// TODO fix this
	return;

	// get item's pidl:
	CPIDL pidlFolder;
	if (FALSE == GetTreeItemAbsPIDL(m_htiSelected, pidlFolder))
		return;

	// stop monitoring this folder for now:
	::PostThreadMessage(m_dwMonitorThreadID, WM_USER_MONITOR_FOLDER, (WPARAM)m_htiSelected, 0);
	::Sleep(1);

	IContextMenu* piMenu;
	if (SUCCEEDED(pidlFolder.GetUIObjectOf(__uuidof(IContextMenu), reinterpret_cast<void**>(&piMenu))))
	{
		HMENU hMenu = ::CreatePopupMenu();
		if (SUCCEEDED(piMenu->QueryContextMenu(hMenu, 0, IDM_SHELLCTXFIRST, IDM_SHELLCTXLAST, CMF_NORMAL)))
		{
			// display user menu?
			if (0 == lCmd)
			{
				POINT pt; ::GetCursorPos(&pt);
				lCmd = ::TrackPopupMenuEx(hMenu, TPM_LEFTALIGN | TPM_TOPALIGN | TPM_RETURNCMD, pt.x, pt.y, m_hWnd, NULL);
			}
		}
		::DestroyMenu(hMenu);

		// have a command id?
		if (lCmd)
		{
			// Shell command
			CMINVOKECOMMANDINFO cmi;
			cmi.cbSize       = sizeof(cmi);
			cmi.fMask        = 0;
			cmi.hwnd         = m_hWnd;
			cmi.lpVerb       = MAKEINTRESOURCE(lCmd - IDM_SHELLCTXFIRST);
			cmi.lpParameters = NULL;
			cmi.lpDirectory  = NULL;
			cmi.nShow        = SW_SHOWNORMAL;
			cmi.dwHotKey     = 0;
			cmi.hIcon        = NULL;
			piMenu->InvokeCommand(&cmi);
		}
	}

	// start monitoring this item again:
	::PostThreadMessage(m_dwMonitorThreadID, WM_USER_MONITOR_FOLDER, (WPARAM)m_htiSelected, 0);

}

CComPtr<IDropTarget> CShellFolderTree::UpdateDropTarget(IDataObject* piDO, POINTL pt)
{
	// TODO fix this
	return NULL;

	// hittest to determine if new drop target:
	TVHITTESTINFO hti;
	hti.pt.x = pt.x;
	hti.pt.y = pt.y;
	::MapWindowPoints(NULL, m_ctlTree.m_hWnd, &hti.pt, 1);
	HTREEITEM hDT = TreeView_HitTest(m_ctlTree.m_hWnd, &hti);
	if (hDT == m_hDT) 
		return m_piDT;

	// set any new target state:
	if (NULL != m_hDT)
	{
		TreeView_SetItemState(m_ctlTree.m_hWnd, m_hDT, 0, TVIS_DROPHILITED);
		::UpdateWindow(m_ctlTree.m_hWnd);
	}

	if (NULL != m_piDT.p)
		m_piDT.Release();

	m_hDT  = hDT;

	if (piDO)
		m_piDO = piDO;

	if (m_hDT)
	{
		// mark item hilited:
		TreeView_SetItemState(m_ctlTree.m_hWnd, m_hDT, TVIS_DROPHILITED, TVIS_DROPHILITED);
		::UpdateWindow(m_ctlTree.m_hWnd);

		// get drop target interface:
		CPIDL pidlTarget;	
		if (FALSE == GetTreeItemAbsPIDL(m_hDT, pidlTarget))
			return NULL;

		// get IShellFolder:
		IShellFolderPtr piFolder;
		HRESULT hr = m_piDesktopFolder->BindToObject(pidlTarget, NULL, IID_IShellFolder, reinterpret_cast<void**>(&piFolder));
		if (FAILED(hr)) 
			m_piDesktopFolder.QueryInterface(&piFolder);

		if (FAILED(piFolder->CreateViewObject(NULL, __uuidof(IDropTarget), reinterpret_cast<void**>(&m_piDT))))
			return NULL;
	}

	return m_piDT;
}

BOOL CShellFolderTree::PreTranslateAccelerator(LPMSG pMsg, HRESULT& hRet)
{
	if (WM_KEYDOWN == pMsg->message)
	{
		if ((VK_LEFT	== pMsg->wParam) ||
			 (VK_RIGHT	== pMsg->wParam) ||
			 (VK_UP		== pMsg->wParam) ||
			 (VK_DOWN	== pMsg->wParam) ||
			 (VK_DELETE == pMsg->wParam) ||
			 (VK_F5		== pMsg->wParam) )
		{
			hRet = S_FALSE;
			return TRUE;
		}
	}

	return FALSE;
}

/////////////////////////////////////////////////////////////////////////////
// Message Handlers

LRESULT CShellFolderTree::OnCreate(UINT /*uMsg*/, WPARAM /*wParam*/, LPARAM /*lParam*/, BOOL& /*bHandled*/)
{
	// create our child control:
	DWORD dwStyle	 = WS_CHILD|WS_VISIBLE|WS_TABSTOP|WS_HSCROLL,
			dwExStyle = 0;

	dwStyle		|= (	(  0 == m_nBorderStyle		? WS_BORDER				: 0)	| 
							(0x1 == m_bHasButtons		? TVS_HASBUTTONS  	: 0)	|
							(0x1 == m_bHasLines			? TVS_HASLINES			: 0)	|
							(0x1 == m_bHasLinesAtRoot	? TVS_LINESATROOT		: 0)	|
							(0x1 == m_bShowSelAlways	? TVS_SHOWSELALWAYS	: 0)  );

	dwExStyle	|= (	(  1 == m_nAppearance		? WS_EX_CLIENTEDGE	: 0)	);

	RECT rcl; GetClientRect(&rcl);
	if (NULL == m_ctlTree.Create(m_hWnd, rcl, NULL, dwStyle, dwExStyle, 100))
		return -1;
	m_ctlTree.EnableWindow(m_bEnabled == VARIANT_TRUE ? TRUE : FALSE);

	// create tree-lock mutex
	m_hmtxTreeLock = ::CreateMutex(NULL, FALSE, NULL);

	// launch the folder-monitoring thread:
	m_hMonitorThread = ::CreateThread(NULL, 0, MonitorThreadProc, this, 0, &m_dwMonitorThreadID);
	if (-1 == (long)m_hMonitorThread)
		return -1;

	// set image list -- use our copy of the system image list:
	TreeView_SetImageList(m_ctlTree.m_hWnd, m_bHasIcons ? m_himl : 0, TVSIL_NORMAL);

	// register tree as drop target:
	put_EnableDragDrop(m_bEnableDragDrop ? VARIANT_TRUE : VARIANT_FALSE);

	// initialize root to Desktop folder:
	put_RootFolder(m_vtRoot);

	return 0;
}

LRESULT CShellFolderTree::OnDestroy(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
{
	// signal monitor thread to end:
	if (::PostThreadMessage(m_dwMonitorThreadID, WM_QUIT, 0, 0))
		::WaitForSingleObject(m_hMonitorThread, INFINITE);

	// destroy tree-lock mutex
	::CloseHandle(m_hmtxTreeLock);

	// destroy all tree items:
	TreeView_DeleteAllItems(m_ctlTree.m_hWnd);

	// no longer a drop target:
	::RevokeDragDrop(m_ctlTree.m_hWnd);

	return 0;
}

LRESULT CShellFolderTree::OnSetFocus(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
{
	LRESULT lRes = CComControl<CShellFolderTree>::OnSetFocus(uMsg, wParam, lParam, bHandled);
	if (m_bInPlaceActive)
	{
		DoVerbUIActivate(&m_rcPos,  NULL);
		if (!IsChild(::GetFocus()))
			m_ctlTree.SetFocus();
	}

	return lRes;
}

LRESULT CShellFolderTree::OnItemExpanding(int idCtrl, LPNMHDR pnmh, BOOL& bHandled)
{
	NMTREEVIEW* pnmtv = reinterpret_cast<NMTREEVIEW*>(pnmh);

	// item is expanding or collapsing?
	if (pnmtv->action & TVE_EXPAND) 
	{
		m_bWaitCursor = true;
		BOOL x; OnSetCursor(0,0,0,x);
		m_ctlTree.SetRedraw(FALSE);

		// item has been previously expanded?
		if (NULL == TreeView_GetChild(pnmh->hwndFrom, pnmtv->itemNew.hItem))
		{
			// no, populate:
			if (0 == AddFolderContents(pnmtv->itemNew.hItem))
			{
				// remove '+' if empty folder.
				pnmtv->itemNew.mask = TVIF_CHILDREN;
				pnmtv->itemNew.cChildren = 0;
				TreeView_SetItem(pnmh->hwndFrom, &pnmtv->itemNew);
			}
		}
		else
		{
			// yes, refresh:
			RefreshFolderContents(pnmtv->itemNew.hItem);
		}

		m_ctlTree.SetRedraw(TRUE);
		m_bWaitCursor = false;

		// begin monitoring this folder for changes:
		::PostThreadMessage(m_dwMonitorThreadID, WM_USER_MONITOR_FOLDER, (WPARAM)pnmtv->itemNew.hItem, 1);
	}
	else
	if (pnmtv->action & TVE_COLLAPSE)
	{
		// withdraw monitoring of this folder:
		::PostThreadMessage(m_dwMonitorThreadID, WM_USER_MONITOR_FOLDER, (WPARAM)pnmtv->itemNew.hItem, 0);
	}

	return 0;
}

LRESULT CShellFolderTree::OnItemExpanded(int idCtrl, LPNMHDR pnmh, BOOL& bHandled)
{
	NMTREEVIEW* pnmtv = reinterpret_cast<NMTREEVIEW*>(pnmh);

	char szPath[_MAX_PATH];
	GetTreeItemAbsPath(pnmtv->itemNew.hItem, szPath, false);
	_variant_t vtItem = szPath;

	// item expanded or collapsed?
	if (pnmtv->action & TVE_EXPAND) 
		Fire_FolderExpanded(vtItem);
	else
	if (pnmtv->action & TVE_COLLAPSE)
		Fire_FolderCollapsed(vtItem);

	return 0;
}

LRESULT CShellFolderTree::OnDeleteItem(int idCtrl, LPNMHDR pnmh, BOOL& bHandled)
{
	NMTREEVIEW* pnmtv = reinterpret_cast<NMTREEVIEW*>(pnmh);
	TVITEM&		tvi   = pnmtv->itemOld;

	// stop monitoring the folder:
	::PostThreadMessage(m_dwMonitorThreadID, WM_USER_MONITOR_FOLDER, (WPARAM)tvi.hItem, 0);

	// destroy the item's pidl:
	delete PPIDL_FROM_LPARAM(tvi.lParam);

	return 0;
}

LRESULT CShellFolderTree::OnSelChanged(int idCtrl, LPNMHDR pnmh, BOOL& bHandled)
{
	NMTREEVIEW* pnmtv = reinterpret_cast<NMTREEVIEW*>(pnmh);
	m_htiSelected = pnmtv->itemNew.hItem;

	// fire sel-changed event:
	_variant_t vtSel; vtSel.vt = VT_BSTR;
	get_SelectedItemPath(&vtSel.bstrVal);
	Fire_SelectionChanged(vtSel);

	return 0;
}

LRESULT CShellFolderTree::OnButtonDown(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
{
	DragLeave();

	TVHITTESTINFO hit;
	hit.pt.x = LOWORD(lParam);
	hit.pt.y = HIWORD(lParam);
	HTREEITEM hDT = TreeView_HitTest(m_ctlTree.m_hWnd, &hit);
	if (NULL != hDT)
	{
		TreeView_SetItemState(m_ctlTree.m_hWnd, hDT, 0, TVIS_DROPHILITED);
		::UpdateWindow(m_ctlTree.m_hWnd);
	}

	bHandled = FALSE;
	return 0;
}

LRESULT CShellFolderTree::OnRightClick(int idCtrl, LPNMHDR pnmh, BOOL& bHandled)
{
	NMTREEVIEW* pnmtv = reinterpret_cast<NMTREEVIEW*>(pnmh);

	TVHITTESTINFO hit;
	::GetCursorPos(&hit.pt);
	::MapWindowPoints(NULL, pnmh->hwndFrom, &hit.pt, 1);

	HTREEITEM hDT = TreeView_HitTest(m_ctlTree.m_hWnd, &hit);
	if (NULL != hDT)
	{
		TreeView_SelectItem(m_ctlTree.m_hWnd, hit.hItem);
		::UpdateWindow(m_ctlTree.m_hWnd);
	}

	bHandled = FALSE;
	return 0;
}

LRESULT CShellFolderTree::OnDblClick(int idCtrl, LPNMHDR pnmh, BOOL& bHandled)
{
	// feature enabled?
	if (!m_bEnableDefaultAction)
		return 0;

	// for non-folder items, we trigger the default shell action for the item:
	TVITEM tvi;
	tvi.hItem = TreeView_GetSelection(m_ctlTree.m_hWnd);
	tvi.mask = TVIF_CHILDREN;
	TreeView_GetItem(m_ctlTree.m_hWnd, &tvi);
	if (0 == tvi.cChildren)
	{
		CPIDL pidlItem;
		GetTreeItemAbsPIDL(tvi.hItem, pidlItem);

		// trigger default action:
		SHELLEXECUTEINFO ei;	::ZeroMemory(&ei, sizeof(ei));
		ei.cbSize	= sizeof(ei);
		ei.fMask		= SEE_MASK_IDLIST | SEE_MASK_INVOKEIDLIST | SEE_MASK_FLAG_DDEWAIT;
		ei.lpIDList = (void*)(LPCITEMIDLIST)pidlItem;
		ei.nShow    = SW_SHOWNORMAL;
	   ::ShellExecuteEx(&ei);
	}

	bHandled = FALSE;
	return 0;
}

LRESULT CShellFolderTree::OnContextMenu(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
{
	if (0x1 == m_bEnableShellMenu)
		InvokeSelectedItemCommand(0);

	return 0;
}

LRESULT CShellFolderTree::OnSetCursor(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
{
	if (m_bWaitCursor)
		::SetCursor(::LoadCursor(NULL, IDC_WAIT));
	else
		bHandled = FALSE;

	return 0;
}

LRESULT CShellFolderTree::OnKeyDown(int idCtrl, LPNMHDR pnmh, BOOL& bHandled)
{
	NMTVKEYDOWN* pkd = (NMTVKEYDOWN*)pnmh;

	if (VK_F5 == pkd->wVKey)
	{
		m_ctlTree.InvalidateRect(NULL, TRUE);
		RefreshFolderContents(TreeView_GetRoot(m_ctlTree.m_hWnd));
	}
	else
	if (VK_DELETE == pkd->wVKey)
	{
		InvokeSelectedItemCommand(20017);
	}
	else
	{
		bHandled = FALSE;
	}

	return 0;
}

LRESULT CShellFolderTree::OnBeginDrag(int idCtrl, LPNMHDR pnmh, BOOL& bHandled)
{
	// feature enabled?
	if (!m_bEnableDragDrop)
		return 0;

	// determine the item being dragged:
	NMTREEVIEW* pnmtv = (NMTREEVIEW*)pnmh;

	// get its dataobject interface:
	CPIDL pidlFolder;
	if (FALSE == GetTreeItemAbsPIDL(pnmtv->itemNew.hItem, pidlFolder))
		return 0;

	IDataObjectPtr piDO;
	if (SUCCEEDED(pidlFolder.GetUIObjectOf(__uuidof(IDataObject), reinterpret_cast<void**>(&piDO))))
	{
		DWORD dwOKEffects(DROPEFFECT_COPY | DROPEFFECT_MOVE | DROPEFFECT_LINK),
				dwEffect(0);

		// initiate the drag-drop operation:
		::DoDragDrop(piDO, this, dwOKEffects, &dwEffect);
	}

	return 0;
}

/////////////////////////////////////////////////////////////////////////////
// IOleInPlaceObject

STDMETHODIMP CShellFolderTree::SetObjectRects(LPCRECT prcPos,LPCRECT prcClip)
{
	IOleInPlaceObjectWindowlessImpl<CShellFolderTree>::SetObjectRects(prcPos, prcClip);

	if (m_ctlTree.m_hWnd)
	{
		RECT rcl; GetClientRect(&rcl);
		m_ctlTree.SetWindowPos(NULL, 0, 0, rcl.right, rcl.bottom, SWP_NOZORDER | SWP_NOACTIVATE | SWP_NOMOVE);
	}

	return S_OK;
}

/////////////////////////////////////////////////////////////////////////////
// IDropSource

STDMETHODIMP CShellFolderTree::QueryContinueDrag(BOOL fEscapePressed, DWORD grfKeyState)
{
	// check for cancel:
	if (fEscapePressed)
		return DRAGDROP_S_CANCEL;

	// check for end drop:
	if (grfKeyState & MK_LBUTTON || grfKeyState & MK_RBUTTON)
		return S_OK;

	return DRAGDROP_S_DROP;
}
 
STDMETHODIMP CShellFolderTree::GiveFeedback(DWORD dwEffect)
{
	// use OLE defaults:
	return DRAGDROP_S_USEDEFAULTCURSORS;
}

/////////////////////////////////////////////////////////////////////////////
// IDropTarget

STDMETHODIMP CShellFolderTree::DragEnter(IDataObject* piDO, DWORD grfKeyState, POINTL pt, DWORD *pdwEffect)
{
	// locate and cache our drop target, if available:
	CComPtr<IDropTarget> piDT = UpdateDropTarget(piDO, pt);
	if (NULL == piDT.p) return S_OK;

	// pass on the drag-enter:
	pt.x = pt.y = 0;
	HRESULT hr = piDT->DragEnter(piDO, grfKeyState, pt, pdwEffect);
	piDT->DragLeave();

	return hr;
}

STDMETHODIMP CShellFolderTree::DragOver(DWORD grfKeyState, POINTL pt, DWORD* pdwEffect)
{
	// locate and cache our drop target, if available:
	CComPtr<IDropTarget> piDT = UpdateDropTarget(NULL, pt);
	if (NULL == piDT.p || NULL == m_piDO.p) return S_OK;

	// pass on the drag-over:
	pt.x = pt.y = 0;
	HRESULT hr = piDT->DragEnter(m_piDO, grfKeyState, pt, pdwEffect);
	if (SUCCEEDED(hr))
		hr = piDT->DragOver(grfKeyState, pt, pdwEffect);

	piDT->DragLeave();

	return hr;
}

STDMETHODIMP CShellFolderTree::DragLeave(void)
{
	if (NULL != m_hDT)
	{
		TreeView_SetItemState(m_ctlTree.m_hWnd, m_hDT, 0, TVIS_DROPHILITED);
		::UpdateWindow(m_ctlTree.m_hWnd);
		m_hDT = NULL;
	}

	if (NULL != m_piDT.p)
		m_piDT.Release();
	
	if (NULL != m_piDO.p)
		m_piDO.Release();

	return S_OK;
}

STDMETHODIMP CShellFolderTree::Drop(IDataObject* piDO, DWORD grfKeyState, POINTL pt, DWORD *pdwEffect)
{
	// locate and cache our drop target, if available:
	CComPtr<IDropTarget> piDT = UpdateDropTarget(piDO, pt);
	if (NULL == piDT.p) return S_OK;

	// pass on the drag-over:
	pt.x = pt.y = 0;
	HRESULT hr = piDT->DragEnter(piDO, grfKeyState, pt, pdwEffect);
	if (SUCCEEDED(hr) && *pdwEffect)
		hr = piDT->Drop(piDO, grfKeyState, pt, pdwEffect);

	piDT->DragLeave();

	TreeView_SetItemState(m_ctlTree.m_hWnd, m_hDT, 0, TVIS_DROPHILITED);
	::UpdateWindow(m_ctlTree.m_hWnd);

	return hr;
}

/////////////////////////////////////////////////////////////////////////////
// IShellFolderTree

STDMETHODIMP CShellFolderTree::get_AutoUpdate(VARIANT_BOOL *pbAutoUpdateRet)
{
	*pbAutoUpdateRet = (m_bAutoUpdate == 0x1) ? VARIANT_TRUE : VARIANT_FALSE;
	return S_OK;
}

STDMETHODIMP CShellFolderTree::put_AutoUpdate(VARIANT_BOOL bAutoUpdate)
{
	unsigned bNewVal = (bAutoUpdate == VARIANT_TRUE) ? 0x1 : 0x0;

	if (m_bAutoUpdate != bNewVal)
	{
		m_bAutoUpdate = bNewVal;
		if (VARIANT_FALSE == m_bAutoUpdate)
			::PostThreadMessage(m_dwMonitorThreadID, WM_USER_MONITOR_RESET, 0, 0);
	}

	return S_OK;
}

STDMETHODIMP CShellFolderTree::get_EnableDefaultAction(VARIANT_BOOL *pbEnableDefaultActionRet)
{
	*pbEnableDefaultActionRet = (m_bEnableDefaultAction == 0x1) ? VARIANT_TRUE : VARIANT_FALSE;
	return S_OK;
}

STDMETHODIMP CShellFolderTree::put_EnableDefaultAction(VARIANT_BOOL bEnableDefaultAction)
{
	m_bEnableDefaultAction = (VARIANT_TRUE == bEnableDefaultAction ? 0x1 : 0x0);
	return S_OK;
}

STDMETHODIMP CShellFolderTree::get_EnableDragDrop(VARIANT_BOOL *pbEnableDragDropRet)
{
	*pbEnableDragDropRet = (m_bEnableDragDrop == 0x1) ? VARIANT_TRUE : VARIANT_FALSE;
	return S_OK;
}

STDMETHODIMP CShellFolderTree::put_EnableDragDrop(VARIANT_BOOL bEnableDragDrop)
{
	m_bEnableDragDrop = (VARIANT_TRUE == bEnableDragDrop ? 0x1 : 0x0);
	
	if (m_bEnableDragDrop && m_ctlTree.m_hWnd)
		::RegisterDragDrop(m_ctlTree.m_hWnd, this);
	else
	if (m_ctlTree.m_hWnd)
		::RevokeDragDrop(m_ctlTree.m_hWnd);

	return S_OK;
}

STDMETHODIMP CShellFolderTree::get_EnableShellMenu(VARIANT_BOOL *pbEnableShellMenuRet)
{
	*pbEnableShellMenuRet = (m_bEnableShellMenu == 0x1) ? VARIANT_TRUE : VARIANT_FALSE;
	return S_OK;
}

STDMETHODIMP CShellFolderTree::put_EnableShellMenu(VARIANT_BOOL bEnableShellMenu)
{
	m_bEnableShellMenu = (VARIANT_TRUE == bEnableShellMenu ? 0x1 : 0x0);
	return S_OK;
}

STDMETHODIMP CShellFolderTree::get_HasButtons(VARIANT_BOOL *pbHasButtonsRet)
{
	*pbHasButtonsRet = (m_bHasButtons == 0x1) ? VARIANT_TRUE : VARIANT_FALSE;
	return S_OK;
}

STDMETHODIMP CShellFolderTree::put_HasButtons(VARIANT_BOOL bHasButtons)
{
	m_bHasButtons = (VARIANT_TRUE == bHasButtons ? 0x1 : 0x0);
	FireOnChanged(DISPID_CD_HASBUTTONS);
	return S_OK;
}

STDMETHODIMP CShellFolderTree::get_HasLines(VARIANT_BOOL *pbHasLinesRet)
{
	*pbHasLinesRet = (m_bHasLines == 0x1) ? VARIANT_TRUE : VARIANT_FALSE;
	return S_OK;
}

STDMETHODIMP CShellFolderTree::put_HasLines(VARIANT_BOOL bHasLines)
{
	m_bHasLines = (VARIANT_TRUE == bHasLines ? 0x1 : 0x0);
	FireOnChanged(DISPID_CD_HASLINES);
	return S_OK;
}

STDMETHODIMP CShellFolderTree::get_HasLinesAtRoot(VARIANT_BOOL *pbHasLinesAtRootRet)
{
	*pbHasLinesAtRootRet = (m_bHasLinesAtRoot == 0x1) ? VARIANT_TRUE : VARIANT_FALSE;
	return S_OK;
}

STDMETHODIMP CShellFolderTree::put_HasLinesAtRoot(VARIANT_BOOL bHasLinesAtRoot)
{
	m_bHasLinesAtRoot = (VARIANT_TRUE == bHasLinesAtRoot ? 0x1 : 0x0);
	FireOnChanged(DISPID_CD_HASLINESATROOT);
	return S_OK;
}

STDMETHODIMP CShellFolderTree::get_ShowHidden(VARIANT_BOOL *pbShowHiddenRet)
{
	*pbShowHiddenRet = (m_bShowHidden == 0x1) ? VARIANT_TRUE : VARIANT_FALSE;
	return S_OK;
}

STDMETHODIMP CShellFolderTree::put_ShowHidden(VARIANT_BOOL bShowHidden)
{
	m_bShowHidden = (VARIANT_TRUE == bShowHidden ? 0x1 : 0x0);
	return Refresh(VARIANT_FALSE);
}

STDMETHODIMP CShellFolderTree::get_HasIcons(VARIANT_BOOL *pbHasIconsRet)
{
	*pbHasIconsRet = (m_bHasIcons == 0x1) ? VARIANT_TRUE : VARIANT_FALSE;
	return S_OK;
}

STDMETHODIMP CShellFolderTree::put_HasIcons(VARIANT_BOOL bHasIcons)
{
	m_bHasIcons = (VARIANT_TRUE == bHasIcons ? 0x1 : 0x0);
	TreeView_SetImageList(m_ctlTree.m_hWnd, m_bHasIcons ? m_himl : 0, TVSIL_NORMAL);
	return Refresh(VARIANT_FALSE);
}

STDMETHODIMP CShellFolderTree::get_HasOverlayIcons(VARIANT_BOOL *pbHasOverlayIconsRet)
{				
	*pbHasOverlayIconsRet = (m_bHasOverlayIcons == 0x1) ? VARIANT_TRUE : VARIANT_FALSE;
	return S_OK;
}

STDMETHODIMP CShellFolderTree::put_HasOverlayIcons(VARIANT_BOOL bHasOverlayIcons)
{
	m_bHasOverlayIcons = (VARIANT_TRUE == bHasOverlayIcons ? 0x1 : 0x0);
	return Refresh(VARIANT_FALSE);
}

//STDMETHODIMP CShellFolderTree::get_LicenseKey(BSTR *pbstrLicenseRet)
//{
//	*pbstrLicenseRet = m_bstrLicense.copy();	
//	return S_OK;
//}
//
//STDMETHODIMP CShellFolderTree::put_LicenseKey(BSTR bstrLicense)
//{
//	m_bstrLicense = bstrLicense;
//	return Refresh(VARIANT_TRUE);
//}

STDMETHODIMP CShellFolderTree::get_RootFolder(VARIANT *pvtRootRet)
{
	return ::VariantCopy(pvtRootRet, &m_vtRoot);
}

STDMETHODIMP CShellFolderTree::put_RootFolder(VARIANT vtRoot)
{
	CPIDL pidlRoot;  
	HRESULT hr = PidlFromVariant(vtRoot, pidlRoot);
	if (FAILED(hr)) return hr;

	// store:
	m_vtRoot = vtRoot;

	// running?
	if (NULL == m_ctlTree.m_hWnd)
		return S_OK;

	// reset:
	::PostThreadMessage(m_dwMonitorThreadID, WM_USER_MONITOR_RESET, 0, 0);
	TreeView_DeleteAllItems(m_ctlTree.m_hWnd);

	// get root folder info
   SHFILEINFO sfi;
	::SHGetFileInfo((LPCSTR)(LPCITEMIDLIST)pidlRoot, 0, &sfi, sizeof(SHFILEINFO), SHGFI_PIDL | SHGFI_SYSICONINDEX | SHGFI_SMALLICON | SHGFI_DISPLAYNAME);

	// insert as root item:
	TVINSERTSTRUCT tvi;
	tvi.hParent						= NULL;
	tvi.hInsertAfter				= TVI_LAST;
	tvi.itemex.mask				= TVIF_TEXT | TVIF_PARAM | TVIF_CHILDREN | (m_bHasIcons ? TVIF_IMAGE | TVIF_SELECTEDIMAGE : 0);
	tvi.itemex.lParam				= reinterpret_cast<LPARAM>(new CPIDL(pidlRoot));
	tvi.itemex.cChildren			= 1;
	tvi.itemex.iImage				= sfi.iIcon;
	tvi.itemex.iSelectedImage	= sfi.iIcon;
	tvi.itemex.pszText			= sfi.szDisplayName;
	
	HTREEITEM htiRoot = TreeView_InsertItem(m_ctlTree.m_hWnd, &tvi);
	if (htiRoot)
		TreeView_Expand(m_ctlTree.m_hWnd, htiRoot, TVE_EXPAND);

	return (NULL != htiRoot) ? S_OK : E_FAIL;
}

STDMETHODIMP CShellFolderTree::get_SelectedItemPath(BSTR *pbstrPathRet)
{
	*pbstrPathRet = NULL;

	char szPath[_MAX_PATH];
	if (!GetTreeItemAbsPath(m_htiSelected, szPath, false))
		return S_FALSE;

	*pbstrPathRet = _bstr_t(szPath).copy();
	return S_OK;
}

STDMETHODIMP CShellFolderTree::put_SelectedItemPath(BSTR bstrPath)
{
	// determine item's pidl:
	CPIDL	pidlItem;
	_variant_t vtItem = bstrPath;
	HRESULT hr = PidlFromVariant(vtItem, pidlItem);
	if (FAILED(hr)) return hr;

	return EnsureVisibleImpl(pidlItem, TRUE);
}

STDMETHODIMP CShellFolderTree::get_ShowFiles(VARIANT_BOOL *pbShowFilesRet)
{
	*pbShowFilesRet = (m_bShowFiles == 0x1) ? VARIANT_TRUE : VARIANT_FALSE;
	return S_OK;
}

STDMETHODIMP CShellFolderTree::put_ShowFiles(VARIANT_BOOL bShowFiles)
{
	m_bShowFiles = (VARIANT_TRUE == bShowFiles ? 0x1 : 0x0);
	return Refresh(VARIANT_FALSE);
}

STDMETHODIMP CShellFolderTree::get_ShowSelAlways(VARIANT_BOOL *pbShowSelAlwaysRet)
{
	*pbShowSelAlwaysRet = (m_bShowSelAlways == 0x1) ? VARIANT_TRUE : VARIANT_FALSE;
	return S_OK;
}

STDMETHODIMP CShellFolderTree::put_ShowSelAlways(VARIANT_BOOL bShowSelAlways)
{
	m_bShowSelAlways = (VARIANT_TRUE == bShowSelAlways ? 0x1 : 0x0);
	FireOnChanged(DISPID_CD_SHOWSELALWAYS);
	return S_OK;
}

STDMETHODIMP CShellFolderTree::Refresh(VARIANT_BOOL bRebuildTree)
{
	if (m_ctlTree.m_hWnd)
	{
		if (VARIANT_TRUE == bRebuildTree)
			return put_RootFolder(m_vtRoot);

		m_ctlTree.InvalidateRect(NULL, TRUE);
		RefreshFolderContents(TreeView_GetRoot(m_ctlTree.m_hWnd));
	}

	return S_OK;
}

STDMETHODIMP CShellFolderTree::EnsureVisible(VARIANT vtItem)
{
	// determine item's pidl:
	CPIDL	pidlItem;
	HRESULT hr = PidlFromVariant(vtItem, pidlItem);
	if (FAILED(hr)) return hr;

	return EnsureVisibleImpl(pidlItem, TRUE);
}



