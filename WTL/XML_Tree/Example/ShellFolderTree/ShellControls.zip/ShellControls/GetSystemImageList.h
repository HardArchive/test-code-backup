#ifndef GETSYSTEMIMAGELIST_H
#define GETSYSTEMIMAGELIST_H

HIMAGELIST GetSystemImageList(BOOL fSmall);

#endif
