#include "stdafx.h"
#include "SocketClient.h"
#include "../WaitFor.h"

#ifndef _WIN32_WCE
	#include <process.h>
#else
	#define _beginthreadex	::CreateThread
#endif

#define FireConnect(id)					m_pListener->OnConnect(id)
#define FireSend(id, data, len)			(m_bStarted ? m_pListener->OnSend(id, data, len)	: ISocketListener::HR_IGNORE)
#define FireReceive(id, data, len)		(m_bStarted ? m_pListener->OnReceive(id, data, len)	: ISocketListener::HR_IGNORE)
#define FireClose(id)					(m_bStarted ? m_pListener->OnClose(id)				: ISocketListener::HR_IGNORE)
#define FireError(id, op, code)			(m_bStarted ? m_pListener->OnError(id, op, code)	: ISocketListener::HR_IGNORE)

#ifndef _WIN32_WCE
	__declspec(thread) ISocketClient::En_ISC_Error CSocketClient::sm_enLastError = ISocketClient::ISC_OK;
#endif


BOOL CSocketClient::Start(LPCTSTR pszRemoteAddress, USHORT usPort)
{
	BOOL isOK = FALSE;

	if(HasStarted())
	{
		SetLastError(ISC_CLIENT_HAD_STARTED, _T(__FUNCTION__), 0);
		return isOK;
	}

	if(CreateClientSocket())
	{
		if(ConnectToServer(pszRemoteAddress, usPort))
		{
			if(CreateWorkerThread())
				isOK = TRUE;
			else
				SetLastError(ISC_WORKER_CREATE_FAIL, _T(__FUNCTION__), 0);
		}
		else
			SetLastError(ISC_CONNECT_SERVER_FAIL, _T(__FUNCTION__), ::WSAGetLastError());
	}
	else
		SetLastError(ISC_SOCKET_CREATE_FAIL, _T(__FUNCTION__), ::WSAGetLastError());

	isOK ? m_bStarted = TRUE : Stop();

	return isOK;
}

BOOL CSocketClient::CreateClientSocket()
{
	BOOL isOK = FALSE;

	m_soClient = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
	if(m_soClient != INVALID_SOCKET)
	{
#ifndef _WIN32_WCE
		VERIFY(::SSO_KeepAliveVals(m_soClient, TRUE, DEFALUT_KEEPALIVE_TIMES, DEFALUT_KEEPALIVE_INTERVAL) == 0);
		// VERIFY(::SSO_NoDelay(m_soClient, TRUE) == 0);
#endif

		m_evSocket	= ::WSACreateEvent();
		ASSERT(m_evSocket != WSA_INVALID_EVENT);

		m_dwConnID	= (DWORD)m_evSocket;
		isOK		= TRUE;
	}

	return isOK;
}

BOOL CSocketClient::ConnectToServer(LPCTSTR pszRemoteAddress, USHORT usPort)
{
	CStringA strAddress;
	if(!::GetIPAddress(pszRemoteAddress, strAddress))
		return FALSE;

	SOCKADDR_IN addr;
	addr.sin_family			= AF_INET;
	addr.sin_addr.s_addr	= inet_addr(strAddress);
	addr.sin_port			= htons(usPort);

	BOOL isOK = FALSE;

	if(connect(m_soClient, (SOCKADDR*)&addr, sizeof(SOCKADDR_IN)) != SOCKET_ERROR)
	{
		if(::WSAEventSelect(m_soClient, m_evSocket, FD_READ | FD_WRITE | FD_CLOSE) != SOCKET_ERROR)
		{
			FireConnect(m_dwConnID);
			isOK = TRUE;
		}
	}

	return isOK;
}

BOOL CSocketClient::CreateWorkerThread()
{
	m_hWorker = (HANDLE)_beginthreadex(NULL, 0, WorkerThreadProc, (LPVOID)this, 0, &m_dwWorkerID);

	return m_hWorker != NULL;
}

#ifndef _WIN32_WCE
	UINT
#else
	DWORD
#endif
	WINAPI CSocketClient::WorkerThreadProc(LPVOID pv)
{
	CSocketClient* pClient = (CSocketClient*)pv;

	TRACE("---------------> ���������߳� <---------------\n");

	HANDLE hEvents[] = {pClient->m_evSocket, pClient->m_evBuffer, pClient->m_evStop};

	while(pClient->HasStarted())
	{
		DWORD retval = ::MsgWaitForMultipleObjectsEx(3, hEvents, WSA_INFINITE, QS_ALLINPUT, MWMO_INPUTAVAILABLE);

		if(retval == WSA_WAIT_EVENT_0)
		{
			if(!pClient->ProcessNetworkEvent())
			{
				if(pClient->HasStarted())
					pClient->Stop();

				break;
			}
		}
		else if(retval == WSA_WAIT_EVENT_0 + 1)
		{
			if(!pClient->SendData())
			{
				if(pClient->HasStarted())
					pClient->Stop();

				break;
			}
		}
		else if(retval == WSA_WAIT_EVENT_0 + 2)
			break;
		else if(retval == WSA_WAIT_EVENT_0 + 3)
			::PeekMessageLoop();
		else
			ASSERT(FALSE);
	}

	TRACE("---------------> �˳������߳� <---------------\n");

	return 0;
}

BOOL CSocketClient::ProcessNetworkEvent()
{
	::WSAResetEvent(m_evSocket);

	WSANETWORKEVENTS events;
	
	int rc = ::WSAEnumNetworkEvents(m_soClient, m_evSocket, &events);
	
	if(rc == SOCKET_ERROR)
	{
		int code = ::WSAGetLastError();
		SetLastError(ISC_NETWORK_ERROR, _T(__FUNCTION__), code);
		FireError(m_dwConnID, SO_UNKNOWN, code);

		return FALSE;
	}

	if(events.lNetworkEvents & FD_READ)
	{
		int iCode = events.iErrorCode[FD_READ_BIT];

		if(iCode == 0)
			return ReadData();
		else
		{
			SetLastError(ISC_NETWORK_ERROR, _T(__FUNCTION__), iCode);
			FireError(m_dwConnID, SO_RECEIVE, iCode);
			return FALSE;
		}
	}

	if(events.lNetworkEvents & FD_WRITE)
	{
		int iCode = events.iErrorCode[FD_WRITE_BIT];

		if(iCode == 0)
			return SendData();
		else
		{
			SetLastError(ISC_NETWORK_ERROR, _T(__FUNCTION__), iCode);
			FireError(m_dwConnID, SO_SEND, iCode);
			return FALSE;
		}
	}

	if(events.lNetworkEvents & FD_CLOSE)
	{
		int iCode = events.iErrorCode[FD_CLOSE_BIT];

		if(iCode == 0)
			FireClose(m_dwConnID);
		else
		{
			SetLastError(ISC_NETWORK_ERROR, _T(__FUNCTION__), iCode);
			FireError(m_dwConnID, SO_UNKNOWN, iCode);
		}

		return FALSE;
	}

	return TRUE;
}

BOOL CSocketClient::ReadData()
{
	static BYTE szBuffer[RECEIVE_BUFFER_SIZE];

	CBufferPtr rcBuffer;

	BOOL isOK = FALSE;
	while(TRUE)
	{
		int rc = recv(m_soClient, (char*)szBuffer, RECEIVE_BUFFER_SIZE, 0);

		if(rc == SOCKET_ERROR)
		{
			int code = ::WSAGetLastError();
			if(code == WSAEWOULDBLOCK)
			{
				if(rcBuffer.Size() > 0)
				{
					if(FireReceive(m_dwConnID, rcBuffer, rcBuffer.Size()) == ISocketListener::HR_ERROR)
					{
						TRACE1("<CNNID: %d> FireReceive() ���� HR_ERROR, ���ر�����", m_dwConnID);

						SetLastError(ISC_PROTOCOL_ERROR, _T(__FUNCTION__), WSAEPROTOTYPE);
						FireError(m_dwConnID, SO_RECEIVE, WSAEPROTOTYPE);
					}
					else
						isOK = TRUE;
				}
				else
					isOK = TRUE;
			}
			else
			{
				SetLastError(ISC_NETWORK_ERROR, _T(__FUNCTION__), code);
				FireError(m_dwConnID, SO_RECEIVE, code);
			}

			break;
		}
		else if(rc == 0)
		{
			FireClose(m_dwConnID);
			break;
		}
		else
			rcBuffer.Cat(szBuffer, rc);
	}

	return isOK;
}

BOOL CSocketClient::SendData()
{
	CCriSecLock locallock(m_scBuffer);

	size_t total	= m_sndBuffer.Size();
	size_t left		= total;
	BYTE* pBuffer	= m_sndBuffer;

	BOOL isOK = TRUE;
	while(left > 0)
	{
		int rc = send(m_soClient, (char*)pBuffer, left, 0);

		if(rc == SOCKET_ERROR)
		{
			int code = ::WSAGetLastError();
			if(code != WSAEWOULDBLOCK)
			{
				SetLastError(ISC_NETWORK_ERROR, _T(__FUNCTION__), code);
				FireError(m_dwConnID, SO_SEND, code);
				
				isOK = FALSE;
			}

			break;
		}
		else
		{
			left	-= rc;
			pBuffer += rc;
		}
	}

	// ��ʽһ
	if(isOK && total > left)
	{
		CBufferPtr sndBuffer((BYTE*)m_sndBuffer, total - left);
		
		if(left > 0)
		{
			BYTE* pTemp = m_sndBuffer;
			memcpy(pTemp, pBuffer, left);
		}

		m_sndBuffer.Realloc(left);
		FireSend(m_dwConnID, sndBuffer, sndBuffer.Size());
	}

	/* ͨ������£��ϲ�Ӧ�ò����ڴ��� OnSend() �¼��Ĺ����е��� Send() �����������ݣ���˿������������Ż� */
	// ��ʽ��
	/*
	if(isOK && total > left)
	{
		FireSend(m_dwConnID, m_sndBuffer, total - left);
		
		if(left > 0)
		{
			BYTE* pTemp = m_sndBuffer;
			memcpy(pTemp, pBuffer, left);
		}

		m_sndBuffer.Realloc(left);
	}
	*/
	
	return isOK;
}

BOOL CSocketClient::Stop()
{
	{
		CCriSecLock locallock(m_scStop);

		m_bStarted = FALSE;

		if(m_hWorker != NULL)
		{
			if(::GetCurrentThreadId() != m_dwWorkerID)
				WaitForWorkerThreadEnd();

			::CloseHandle(m_hWorker);
			m_hWorker		= NULL;
			m_dwWorkerID	= 0;
		}

		if(m_evSocket != NULL)
		{
			::WSACloseEvent(m_evSocket);
			m_evSocket	= NULL;
		}

		if(m_soClient != INVALID_SOCKET)
		{
			shutdown(m_soClient, SD_SEND);
			closesocket(m_soClient);
			m_soClient	= INVALID_SOCKET;
		}

		m_dwConnID = 0;
	}

	m_sndBuffer.Free();
	m_evBuffer.Reset();
	m_evStop.Reset();

	return TRUE;
}

void CSocketClient::WaitForWorkerThreadEnd()
{
	m_evStop.Set();

	VERIFY(::WaitForSingleObject(m_hWorker, INFINITE) == WAIT_OBJECT_0);

	//if(!::MsgWaitForSingleObject(m_hWorker, /*INFINITE*/ WORKER_THREAD_END_TIME))

	/*
	DWORD dwResult = ::WaitForSingleObject(m_hWorker, WORKER_THREAD_END_TIME);
	ASSERT(dwResult != WAIT_FAILED);

	if(dwResult == WAIT_TIMEOUT)
		::TerminateThread(m_hWorker, -1);
	*/
}

BOOL CSocketClient::Send(DWORD dwConnID, const BYTE* pBuffer, int iLen)
{
	ASSERT(iLen > 0);

	if(!HasStarted())
	{
		SetLastError(ISC_CLIENT_NOT_STARTED, _T(__FUNCTION__), 0);
		return FALSE;
	}

	CCriSecLock locallock(m_scBuffer);
	m_sndBuffer.Cat(pBuffer, iLen);

	m_evBuffer.Set();

	return TRUE;
}

void CSocketClient::SetLastError(En_ISC_Error code, LPCTSTR func, int ec)
{
	sm_enLastError = code;

	TRACE3("%s --> Error: %d, EC: %d\n", func, code, ec);
}

LPCTSTR CSocketClient::GetLastErrorDesc()
{
	switch(sm_enLastError)
	{
	case ISC_OK:					return _T("Client Socket �����ɹ�");
	case ISC_CLIENT_HAD_STARTED:	return _T("�����Ѵ���");
	case ISC_CLIENT_NOT_STARTED:	return _T("���Ӳ�����");
	case ISC_SOCKET_CREATE_FAIL:	return _T("���� Client Socket ʧ��");
	case ISC_CONNECT_SERVER_FAIL:	return _T("���ӷ�����ʧ��");
	case ISC_WORKER_CREATE_FAIL:	return _T("���������߳�ʧ��");
	case ISC_NETWORK_ERROR:			return _T("�������");
	case ISC_PROTOCOL_ERROR:		return _T("ͨ��Э�����");
	default: ASSERT(FALSE);			return _T("");
	}
}
