// TestFreeeyesClient.cpp : �������̨Ӧ�ó������ڵ㡣
//

#include "stdafx.h"
#include <ace/SOCK_Stream.h>
#include <ace/SOCK_Connector.h>
#include <ace/INET_Addr.h>
#include <ace/Time_Value.h> 
#include "ace/OS.h"

#ifndef uint8
typedef ACE_UINT8 uint8;
#endif

#ifndef uint16
typedef ACE_UINT16 uint16;
#endif

#ifndef uint32
typedef ACE_UINT32 uint32;
#endif


bool ConnectToServer(int nIndex, const char* szIP, int nPort)
{
	ACE_INET_Addr remoteAddr(nPort, szIP);    //�����ӵ�Զ�̵�ַ
	ACE_SOCK_Connector connector;
	ACE_SOCK_Stream peer;

	if(connector.connect(peer, remoteAddr) == -1)
	{
		printf_s("[ConnectToServer]Connect error(%d).\n", errno);
		return false;
	}

	char szName[20]      = {'\0'};
	char szSendData[100] = {'\0'};

	uint16 u2CommandID = 0x1000;

	uint32 u4Len = 2 + 5 + 1;

	sprintf_s(szName, 20, "freeeyes");

	uint8 u1Len = (uint8)strlen(szName);

	memcpy_s(szSendData, 100, (char*)&u4Len, sizeof(uint32));
	memcpy_s(&szSendData[4], 100 - 4, (char*)&u2CommandID, sizeof(uint16));
	memcpy_s(&szSendData[6], 100 - 6, (char*)&u1Len, sizeof(uint8));
	memcpy_s(&szSendData[7], 100 - 7, szName, strlen(szName));

	peer.send_n(szSendData, u4Len + 4);
	printf_s("[ConnectToServer](%d)Send OK.\n", nIndex);

	return true;
}

int _tmain(int argc, _TCHAR* argv[])
{
	for(int i = 0; i < 1000; i++)
	{
		ConnectToServer(i, "192.168.1.8", 10077);
	}

	getchar();
	return 0;
}

