//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by NetWorkClient.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDD_MAINDLG                     129
#define IDC_BUTTON_SEND                 1001
#define IDC_BUTTON_FILE_SEND            1002
#define IDC_BUTTON_CLEAR                1003
#define IDC_BUTTON_CONNECT              1004
#define IDC_IPADDRESS1                  1006
#define IDC_EDIT3                       1007
#define IDC_PROGRESS2                   1008
#define IDC_BUTTON_CLOSE                1009
#define IDC_RICHEDIT2_SHOW              1010
#define IDC_RICHEDIT22                  1011
#define IDC_RICHEDIT2_INPUT             1011
#define IDC_BUTTON_STOP                 1012
#define IDC_BUTTON_FACE                 1013
#define IDC_BUTTON_FONT                 1014

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        201
#define _APS_NEXT_COMMAND_VALUE         32775
#define _APS_NEXT_CONTROL_VALUE         1012
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
