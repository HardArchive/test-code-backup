// rcversionDlg.cpp : implementation file
//

#include "stdafx.h"
#include "rcversion.h"
#include "rcversionDlg.h"
#include "version.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif





CString ST_OK;
CString ST_BAD;


static char g_help[]="** RCVersion by BzcToons [bzctoons@free.fr] **\r\n"\
"\r\n"\
"** RC File Constants **\r\n"\
"FileVersion        : "		__FILEVERSION__		"\r\n"\
"SnapShot           : "		__SNAPSHOT__		"\r\n"\
"Product Version    : "		__PRODUCTVERSION__	"\r\n"\
"Company            : "		__COMPANY__			"\r\n"\
"Product Name       : "		__PRODUCT__			"\r\n"\
"Product decription : "		__DESCRIPTION__		"\r\n"\
"Private Build      : "		__PRIVATEBUILD__	"\r\n"\
"Copyright          : "		__COPYRIGHT__		"\r\n"\
"\r\n"\
"** ClassBuilder Constants **\r\n"\
"Date   : "				__CB_DATE__			"\r\n"\
"Time   : "				__CB_TIME__			"\r\n"\
"Version:"				__CB_VERSION__		"\r\n"\
"\r\n"\
"** Usage **\r\n"\
"rcversion [-q] [-i input]\r\n"\
"   -q   quiet: don't show the UI. Usefull for Custom Build Step in Visual Studio.\r\n"\
"	-i   input:	specify the input file. The input file could be *.rc or *.h.\r\n"\
"               The filename wihout extension will be used as Data Model name.\r\n"\
"\r\n"\
"** To use it in Visual Studio **\r\n"\
"1. Add a file to project : version.h\r\n"\
"2. Define Custom Build Step\r\n"\
"    Command Line : rcversion -q -i $(TargetName) \r\n"\
"    Description: rcversion -q -i $(TargetName) \r\n"\
"    Output: version.h \r\n"\
"    Dependencies: $(TargetName).h \r\n"\
"3. You can now put #include 'version.h' in your '$(TargetName).h' or in 'stdafx.h'.\r\n"\
"\r\n"\
"DON'T FORGET TO PUT RCVERSION IN PATH\r\n"\
"  or \r\n"\
"TO SET VISUAL STUDIO EXECUTABLE PATH TO THE DIRECTORY RCVERSION IS INSTALLED \r\n"\
"\r\n"\
"\r\n";



/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About
class CAboutDlg : public CDialog
{
public:
	CAboutDlg();
	// Dialog Data
	enum { IDD = IDD_ABOUTBOX };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	DECLARE_MESSAGE_MAP()

public:
	CString m_strAbout;
	BOOL OnInitDialog(void);
	afx_msg void OnMainmenuAbout();
};


BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	ON_COMMAND(ID_MAINMENU_ABOUT, OnMainmenuAbout)
END_MESSAGE_MAP()



CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
, m_strAbout(_T(""))
{
}



void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_STATIC_ABOUT, m_strAbout);
}



BOOL CAboutDlg::OnInitDialog(void)
{
	CString sTmp;
	sTmp.Format("RCVersion %s [%s]",__PRIVATEBUILD__,__SNAPSHOT__);
	m_strAbout+=sTmp;	
	UpdateData(false);
	return 0;
}



void CAboutDlg::OnMainmenuAbout()
{
	// TODO : ajoutez ici le code de votre gestionnaire de commande
	DoModal();
}





/////////////////////////////////////////////////////////////////////////////
// CRcversionDlg dialog

// Globals
extern CString g_strRcFileName;
extern CString g_strPrefix;

// EVENTS

BEGIN_MESSAGE_MAP(CRcversionDlg, CTrayDialog)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_BUTTON_ABOUT, OnBnClickedButtonAbout)
	ON_BN_CLICKED(IDC_BROWSE, OnBnClickedBrowse)
	ON_EN_CHANGE(IDC_EDIT_DATAMODEL, OnEnChangeEditDatamodel)
	ON_BN_CLICKED(IDC_SAVE, OnBnClickedSave)
	ON_BN_CLICKED(IDC_SYNCHRONIZE, OnBnClickedSynchronize)
	ON_BN_CLICKED(IDC_BUTTON_PREVIEW, OnBnClickedButtonPreview)
	ON_WM_CTLCOLOR()
	ON_BN_CLICKED(IDC_CHECK_AUTO_PRIVBUILD, OnBnClickedCheckAutoPrivbuild)
	ON_BN_CLICKED(IDC_CHECK_AUTO_FVERSION, OnBnClickedCheckAutoFVersion)
	ON_COMMAND(ID_MAINMENU_ABOUT, OnMainmenuAbout)
	ON_BN_CLICKED(IDC_VIEW_VERSION_H, OnBnClickedViewVersionH)
	ON_EN_CHANGE(IDC_EDIT_VERSION, OnEnChangeEditVersion)
	ON_BN_CLICKED(IDC_RELOAD, OnBnClickedReload)
	ON_EN_CHANGE(IDC_EDIT_DATE, OnEnChangeEditDate)
	ON_BN_CLICKED(IDC_VIEW_RCFILE, OnBnClickedViewRcfile)
	ON_BN_CLICKED(IDC_BUTTON_PREVIEW_RCFILE, OnBnClickedButtonPreviewRcfile)
	ON_BN_CLICKED(IDOK, OnBnClickedOk)
END_MESSAGE_MAP()



/**
* Constructor
* \param Parent Window
*/
CRcversionDlg::CRcversionDlg(CWnd* pParent /*=NULL*/)
: CTrayDialog(CRcversionDlg::IDD, pParent)
, m_strPrefix(g_strPrefix)
, m_strPreview(_T(""))
{
	m_strRCFileName = _T("");
	m_strOutputFile =_T("");
	m_strMHeaderFile= _T("");
	m_strDatamodel = _T("");
	m_strCBDFile = _T("");

	m_strCompanyName = _T("");
	m_strFileVersion = _T("");
	m_strProductName = _T("");
	m_strProductVersion = _T("");
	m_strFileDesc = _T("");
	m_strCopyright = _T("");
	m_strPrivateBuild = _T("");
	m_strPreview = g_help;

	m_strRcFileStatus =  _T("");
	m_strOutputFileStatus =  _T("");
	m_strMHeaderFileStatus =  _T("");
	m_strCBDFileStatus =  _T("");
	m_strDatamodelStatus =  _T("");

	m_strCompanyStatus =  _T("");
	m_strProductStatus =  _T("");
	m_strDescriptionStatus =  _T("");
	m_strPVersionStatus =  _T("");
	m_strCopyrigthStatus =  _T("");

	m_strTime = _T("");
	m_strDate = _T("");
	m_strVersion = _T("");
	m_strTimeStatus = _T("");
	m_strDateStatus = _T("");
	m_strVersionStatus = _T("");
	m_bAutoPrivBuild = FALSE;
	m_strPrivateBuildBackup = _T("");
	m_bAutoFVersion = FALSE;
	m_strFileVersionBackup = _T("");

	ST_OK.LoadString(IDS_FOUND);
	ST_BAD.LoadString(IDS_NOT_FOUND);

	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}



void CRcversionDlg::DoDataExchange(CDataExchange* pDX)
{
	CTrayDialog::DoDataExchange(pDX);

	DDX_Text(pDX, IDC_EDIT_RCFILENAME, m_strRCFileName);
	DDX_Text(pDX, IDC_EDIT_OUTPUT_FILENAME, m_strOutputFile);
	DDX_Text(pDX, IDC_EDIT_MHEADER_FILENAME, m_strMHeaderFile);
	DDX_Text(pDX, IDC_EDIT_DATAMODEL , m_strDatamodel);
	DDX_Text(pDX, IDC_EDIT_CBD_FILENAME, m_strCBDFile);

	DDX_Text(pDX, IDC_EDIT_COMPANYNAME, m_strCompanyName);
	DDX_Text(pDX, IDC_EDIT_FILEVERSION, m_strFileVersion);
	DDX_Text(pDX, IDC_EDIT_PRODUCTNAME, m_strProductName);
	DDX_Text(pDX, IDC_EDIT_PRODUCTVERSION, m_strProductVersion);
	DDX_Text(pDX, IDC_EDIT_FILEDESC, m_strFileDesc);
	DDX_Text(pDX, IDC_EDIT_COPYRIGHT, m_strCopyright);
	DDX_Text(pDX, IDC_EDIT_PRIVBUILD, m_strPrivateBuild);
//	DDX_Text(pDX, IDC_EDIT_HELP, m_editHelp);

	DDX_Text(pDX, IDC_STATIC_RCFILE_OK, m_strRcFileStatus);
	DDX_Text(pDX, IDC_STATIC_OUTFILE_OK, m_strOutputFileStatus);
	DDX_Text(pDX, IDC_STATIC_MHEADER_FILE_OK, m_strMHeaderFileStatus);
	DDX_Text(pDX, IDC_STATIC_CBDFILE_OK, m_strCBDFileStatus);
	DDX_Text(pDX, IDC_STATIC_DATAMODEL_OK, m_strDatamodelStatus);

	DDX_Text(pDX, IDC_STATIC_COMPANY_OK, m_strCompanyStatus);
	DDX_Text(pDX, IDC_STATIC_PRODUCT_OK, m_strProductStatus);
	DDX_Text(pDX, IDC_STATIC_DESCRIPTION_OK, m_strDescriptionStatus);
	DDX_Text(pDX, IDC_STATIC_PVERSION_OK, m_strPVersionStatus);
	DDX_Text(pDX, IDC_STATIC_COPYRIGHT_OK, m_strCopyrigthStatus);

	DDX_Text(pDX, IDC_EDIT_TIME, m_strTime);
	DDX_Text(pDX, IDC_EDIT_DATE, m_strDate);
	DDX_Text(pDX, IDC_EDIT_VERSION, m_strVersion);
	DDX_Text(pDX, IDC_STATIC_TIME_OK, m_strTimeStatus);
	DDX_Text(pDX, IDC_STATIC_DATE_OK, m_strDateStatus);
	DDX_Text(pDX, IDC_STATIC_VERSION_OK, m_strVersionStatus);
//	DDX_Control(pDX, IDC_EDIT_HELP, m_ctrlEditHelp);
	DDX_Control(pDX, IDC_EDIT_PRIVBUILD, m_ctrlEditPrivBuild);
	DDX_Check(pDX, IDC_CHECK_AUTO_PRIVBUILD, m_bAutoPrivBuild);
	DDX_Check(pDX, IDC_CHECK_AUTO_FVERSION, m_bAutoFVersion);
	DDX_Control(pDX, IDC_EDIT_FILEVERSION, m_ctrlEditFVersion);
	DDX_Text(pDX, IDC_EDIT_PREFIX, m_strPrefix);
	DDX_Text(pDX, IDC_RICHEDIT_PREVIEW, m_strPreview);
	DDX_Control(pDX, IDC_RICHEDIT_PREVIEW, m_ctrlRichEditPreview);
}



/////////////////////////////////////////////////////////////////////////////
// CRcversionDlg message handlers

void CRcversionDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CTrayDialog::OnSysCommand(nID, lParam);
	}
}



void CRcversionDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CTrayDialog::OnPaint();
	}
}



HCURSOR CRcversionDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}



void CRcversionDlg::PostNcDestroy() 
{
	// TODO: Add your specialized code here and/or call the base class
	CTrayDialog::PostNcDestroy();
}



BOOL CRcversionDlg::OnInitDialog()
{
	CTrayDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}
	
	// tray init
	TraySetIcon(IDR_MAINFRAME);
	TraySetToolTip("ToolTip for tray icon");
	TraySetMenu(IDR_MENU1);

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	// TODO: Add extra initialization here
	// Richedit contrl init
	CHARFORMAT2 cf;
	memset(&cf,0,sizeof(CHARFORMAT2));
	cf.cbSize = sizeof(CHARFORMAT2);
	cf.dwMask = CFM_FACE| CFM_SIZE |CFM_COLOR;
	sprintf(cf.szFaceName,"Courier new");
	cf.yHeight = 170;
	cf.crTextColor =RGB(0,0,0x40);


	m_ctrlRichEditPreview.SetDefaultCharFormat(cf);

	g_strRcFileName = AjustPath(g_strRcFileName);
	UpdateFilenames(g_strRcFileName);
	UpdateData(FALSE);	
	ParseRcFile();
	return TRUE;  // return TRUE  unless you set the focus to a control
}



void CRcversionDlg::OnOK() 
{
	// TODO: Add extra validation here
	UpdateData(TRUE);	
	CopyFile(m_strRCFileName,m_strRCFileName+".bak",false);
	CopyFile("version.h","version.h.bak",false);
	OnBnClickedSave();
	CTrayDialog::OnOK();
}



void CRcversionDlg::OnBnClickedButtonAbout()
{
	// TODO : ajoutez ici le code de votre gestionnaire de notification de contr�le
	CAboutDlg dlgAbout;
	dlgAbout.DoModal();
}



void CRcversionDlg::OnBnClickedBrowse()
{
	// TODO : ajoutez ici le code de votre gestionnaire de notification de contr�le

	CFileDialog dlgFileOpen(true,	"rc","*.rc"	);
	if(dlgFileOpen.DoModal()== IDOK)
	{
		CString fileName = dlgFileOpen.GetFileTitle();
		ResetDialog();
		UpdateFilenames(fileName);
	}
}



void CRcversionDlg::OnEnChangeEditDatamodel()
{
	// TODO :  Ajoutez ici le code de votre gestionnaire de notification de contr�le
	UpdateData(TRUE);
	m_strDatamodel = AjustPath(m_strDatamodel);
	UpdateFilenames(m_strDatamodel);
}



void CRcversionDlg::OnBnClickedSave()
{
	// TODO : ajoutez ici le code de votre gestionnaire de notification de contr�le
	UpdateData(TRUE);	

	if(!WriteRcFile())
	{
		AfxMessageBox("Can't save RcFile !!");
		return;
	}

	if(!WriteHeaderFile())
	{
		AfxMessageBox("Can't save Version.h !!");
		return;
	}

	UpdateFilenames(m_strDatamodel);
}



void CRcversionDlg::OnBnClickedSynchronize()
{
	// TODO : ajoutez ici le code de votre gestionnaire de notification de contr�le
	UpdateData();
	if(m_strMHeaderFileStatus == ST_OK)
	{
		ParseMasterHeaderFile(m_strMHeaderFile);
	}
	else
	{
		AfxMessageBox("Master Header file not found!");
	}
}



void CRcversionDlg::OnBnClickedButtonPreview()
{
	// TODO : ajoutez ici le code de votre gestionnaire de notification de contr�le
	UpdateData(true);
	CString sTmp = MakeHeaderFile();
	sTmp.Replace("\n","\r\n");
	//m_editHelp = sTmp;
	m_strPreview = sTmp;
	UpdateData(false);
}



HBRUSH CRcversionDlg::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor)
{
	HBRUSH hbr = CTrayDialog::OnCtlColor(pDC, pWnd, nCtlColor);

	// TODO :  Modifier ici les attributs du DC
	switch(nCtlColor) 
	{
	case CTLCOLOR_STATIC:
		// Set the text color to red

		if (pWnd->GetDlgCtrlID() == IDC_STATIC)
		{
			pDC->SetTextColor(RGB(0, 0, 0));

		}
		else if(pWnd->GetDlgCtrlID() == IDC_EDIT_HELP)
		{
			pDC->SetBkColor(RGB(255, 255, 255));
		}
		else
		{
			CString sLabel;
			pWnd->GetWindowText(sLabel);
			if (sLabel==ST_OK) 
			{
				pDC->SetTextColor(RGB(0, 0, 255));
			}
			else if (sLabel==ST_BAD) 
			{
				pDC->SetTextColor(RGB(255, 0, 0));
			}
			else
			{
				pDC->SetTextColor(RGB(0, 0, 0));
			}
		}
		break;

	case CTLCOLOR_EDIT:
		// Set the text color to red
		pDC->SetTextColor(RGB(0, 0, 0));
		pDC->SetBkColor(RGB(255, 255, 255));

		break;
	default:;
	} 

	return hbr;
}



void CRcversionDlg::OnBnClickedCheckAutoPrivbuild()
{
	// TODO : ajoutez ici le code de votre gestionnaire de notification de contr�le

	static BOOL bStaticAutoPrivBuild;

	UpdateData(true);	
	m_ctrlEditPrivBuild.SendMessage( EM_SETREADONLY, (WPARAM) m_bAutoPrivBuild, (LPARAM) 0);
	if(m_bAutoPrivBuild)
	{
		CString sTmp = m_strDatamodel;
		sTmp.MakeUpper();
		m_strPrivateBuildBackup = m_strPrivateBuild;
		m_strPrivateBuild.Format("%s-%s_%s",sTmp,m_strDate,m_strVersion);
	}
	else
	{
		if(bStaticAutoPrivBuild != m_bAutoPrivBuild)
		{
			m_strPrivateBuild = m_strPrivateBuildBackup;
		}
	}

	bStaticAutoPrivBuild = m_bAutoPrivBuild;
	UpdateData(false);
}



void CRcversionDlg::OnBnClickedCheckAutoFVersion()
{
	// TODO : ajoutez ici le code de votre gestionnaire de notification de contr�le
	static BOOL bStaticAutoFVersion;

	UpdateData(true);	
	m_ctrlEditFVersion.SendMessage( EM_SETREADONLY, (WPARAM) m_bAutoFVersion, (LPARAM) 0  );
	if(m_bAutoFVersion)
	{
		CString sTmp = m_strDatamodel;
		sTmp.MakeUpper();
		if(!m_strVersion.IsEmpty())
		{
			sTmp.Format("%s",m_strVersion);
		}
		else
		{
			sTmp.Format("%d",0);
		}

		m_strFileVersionBackup = m_strFileVersion;
		int iPos = m_strFileVersion.ReverseFind(',');
		if(iPos ==-1)
		{
			m_strFileVersion = "1, 0, 0, ";
		}
		else
		{
			m_strFileVersion = m_strFileVersion.Left(iPos);
			m_strFileVersion += ", ";
		}

		m_strFileVersion += sTmp;
	}
	else
	{
		if(bStaticAutoFVersion != m_bAutoFVersion)
		{
			m_strFileVersion = m_strFileVersionBackup;
		}
	}

	bStaticAutoFVersion = m_bAutoFVersion;
	UpdateData(false);
}



void CRcversionDlg::OnMainmenuAbout()
{
	// TODO : ajoutez ici le code de votre gestionnaire de commande
}



void CRcversionDlg::OnBnClickedViewVersionH()
{
	// TODO : ajoutez ici le code de votre gestionnaire de notification de contr�le
	UpdateData();
	ShellExecute(NULL,"open","notepad", m_strOutputFile,NULL,SW_NORMAL);
}



void CRcversionDlg::OnEnChangeEditVersion()
{
	// TODO :  Ajoutez ici le code de votre gestionnaire de notification de contr�le
	UpdateData(true);
	OnBnClickedCheckAutoFVersion();
}



void CRcversionDlg::OnBnClickedReload()
{
	// TODO : ajoutez ici le code de votre gestionnaire de notification de contr�le
	CString fileName = m_strDatamodel;
	ResetDialog();
	UpdateFilenames(fileName);
}



void CRcversionDlg::OnEnChangeEditDate()
{
	// TODO :  Ajoutez ici le code de votre gestionnaire de notification de contr�le
	UpdateData(true);
	OnBnClickedCheckAutoPrivbuild();
}



void CRcversionDlg::OnBnClickedViewRcfile()
{
	// TODO : ajoutez ici le code de votre gestionnaire de notification de contr�le
	UpdateData();
	ShellExecute(NULL,"open","notepad", m_strRCFileName,NULL,SW_NORMAL);
}



void CRcversionDlg::OnBnClickedButtonPreviewRcfile()
{
	// TODO : ajoutez ici le code de votre gestionnaire de notification de contr�le
	UpdateData(true);
	CString sTmp = MakeRcFile();
	if (sTmp.IsEmpty())
	{
		sTmp = "RCFile not exists !!\n";
	}

	sTmp.Replace("\n","\r\n");
	m_strPreview = sTmp;

	UpdateData(false);
}



void CRcversionDlg::OnBnClickedOk()
{
	// TODO : ajoutez ici le code de votre gestionnaire de notification de contr�le
	OnOK();
}

/**
* 
* \param rsVariable 
* \param sLine 
* \param sVName 
* \return 
*/
bool GetRcVersionValue(CString& rsVariable,CString sLine,CString sVName)
{
	CString sPattern ;
	sPattern.Format("VALUE \"%s\"",sVName);
	if(sLine.Find(sPattern) != -1)
	{
		int iSepPos = sLine.Find(',');
		rsVariable = sLine.Right(sLine.GetLength()-iSepPos-1);
		rsVariable.Trim();
		rsVariable.Replace("\"","");
		rsVariable.Replace("\\0","");
		return true;
	}
	return false;
}



/**
* 
* \param sVariable 
* \param rsLine 
* \param sVName 
* \return 
*/
bool SetRcVersionValue(CString sVariable,CString& rsLine,CString sVName)
{

	CString sTmpVName = sVName;
	sTmpVName.MakeUpper();

	CString sPattern ;
	sPattern.Format("VALUE \"%s\"",sVName);
	rsLine.Trim();
	if(rsLine.Find("FILEVERSION ") == 0)
	{
		if(sTmpVName == "FILEVERSION")
		{
			rsLine.Format("FILEVERSION %s",sVariable);
			return true;
		}
	}
	else if(rsLine.Find("PRODUCTVERSION ") == 0)
	{
		if(sTmpVName == "PRODUCTVERSION")
		{
			rsLine.Format("PRODUCTVERSION %s",sVariable);
			return true;
		}
	}
	else if(rsLine.Find(sPattern) != -1)
	{
		int iSepPos = rsLine.Find(',');
		CString sTmp;
		sTmp = rsLine.Left(iSepPos);
		rsLine.Format("%s, \"%s\"",sTmp,sVariable);

		return true;
	}
	return false;
}



/**
* 
* \param dwLastError 
*/
void ShowLastError(DWORD dwLastError)
{
	LPVOID lpMsgBuf;
	FormatMessage( 
		FORMAT_MESSAGE_ALLOCATE_BUFFER | 
		FORMAT_MESSAGE_FROM_SYSTEM | 
		FORMAT_MESSAGE_IGNORE_INSERTS,
		NULL,dwLastError,
		MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT), 
		(LPTSTR) &lpMsgBuf,		0,		NULL 		);

	AfxMessageBox( (LPCTSTR)lpMsgBuf, MB_OK | MB_ICONINFORMATION );

	// Free the buffer.
	LocalFree( lpMsgBuf );
}



/**
* 
* \param void 
*/
void CRcversionDlg::ResetDialog(void)
{
	m_strRCFileName = _T("");
	m_strOutputFile =_T("");
	m_strMHeaderFile= _T("");
	m_strDatamodel = _T("");
	m_strCBDFile = _T("");

	m_strCompanyName = _T("");
	m_strFileVersion = _T("");
	m_strProductName = _T("");
	m_strProductVersion = _T("");
	m_strFileDesc = _T("");
	m_strCopyright = _T("");
	m_strPrivateBuild = _T("");
	m_strPreview = g_help;

	m_strRcFileStatus =  _T("");
	m_strOutputFileStatus =  _T("");
	m_strMHeaderFileStatus =  _T("");
	m_strCBDFileStatus =  _T("");
	m_strDatamodelStatus =  _T("");

	m_strCompanyStatus =  _T("");
	m_strProductStatus =  _T("");
	m_strDescriptionStatus =  _T("");
	m_strPVersionStatus =  _T("");
	m_strCopyrigthStatus =  _T("");

	m_strTime = _T("");
	m_strDate = _T("");
	m_strVersion = _T("");
	m_strTimeStatus = _T("");
	m_strDateStatus = _T("");
	m_strVersionStatus = _T("");
	m_strPrivateBuildBackup = _T("");
	m_strFileVersionBackup = _T("");

	if(m_bAutoFVersion) 
	{
		m_bAutoFVersion=false;
		UpdateData(false);
		OnBnClickedCheckAutoFVersion();
	}

	if (m_bAutoPrivBuild) 
	{
		m_bAutoPrivBuild=false;
		UpdateData(false);
		OnBnClickedCheckAutoPrivbuild();
	}

	UpdateData(false);
}



/**
 * 
 * \param sName 
 * \param sValue 
 * \return 
 */
CString CRcversionDlg::SetHeaderConstantValue(CString sName, CString sValue,int iDepth)
{
	CString sTmp;
	
	m_strPrefix.MakeUpper();
	CString sTmpName;
	CString sTmpPrefix = m_strPrefix;
	CString sEndingUnderscores;
	if(m_strPrefix.IsEmpty())
	{
		sTmpName.Format("__%s__",sName);	
	}
	else
	{
		sTmpName.Format("%s_%s",m_strPrefix,sName);	
	}
	
	int iTotalWidth = 25 + strlen(m_strPrefix);
	int iTabSize = 2;
	int iNameWidth = 7+iDepth*iTabSize;
	int iValueWidth = iTotalWidth - iNameWidth;
	//#define HEADER_CONSTANT_FORMAT "%*s %-20s \"%s\"\n"	// #define, prefix+name, value
	sTmp.Format("%*s %-*s \"%s\"\n",iNameWidth, "#define", iValueWidth,sTmpName,sValue);
	return sTmp;
}



/**
* 
* \param sFullPath 
* \return 
*/
CString CRcversionDlg::AjustPath(CString sFullPath)
{

	if (sFullPath.IsEmpty()) 
	{
		return sFullPath;
	}

	CString sTmpFileTitle = sFullPath;
	CString sExt;
	int iExtPos = sTmpFileTitle.ReverseFind('.');

	if (iExtPos ==-1) 
	{
		sTmpFileTitle += ".rc";
	}
	else
	{

	}

	CFileFind fileFinder;
	if(fileFinder.FindFile(sTmpFileTitle))
	{
		fileFinder.FindNextFile();

		sTmpFileTitle = fileFinder.GetFileTitle();
		//		CString sTmpFileName = fileFinder.GetFileName();
		//		CString sTmpFilePath = fileFinder.GetFilePath();
		CString sTmpFileRoot = fileFinder.GetRoot();

		SetCurrentDirectory(sTmpFileRoot);
	}
	return sTmpFileTitle;
}



/**
* 
* \return 
*/
bool CRcversionDlg::ParseRcFile(void)
{
	CheckFiles();
	ParseMasterHeaderFile(m_strMHeaderFile);
	m_strCompanyName.Empty();
	m_strFileDesc.Empty();
	m_strProductName.Empty();
	m_strFileVersion.Empty();
	m_strProductVersion.Empty();
	m_strFileDesc.Empty();
	CStdioFile fileIni;

	if (fileIni.Open(m_strRCFileName, CFile::modeRead))
	{
		CString sLine;
		while (fileIni.ReadString(sLine))
		{
			//GetRcVersionValue(m_strComments,sLine,"Comments");
			GetRcVersionValue(m_strCompanyName, sLine,"CompanyName");
			GetRcVersionValue(m_strFileDesc, sLine,"FileDescription");
			GetRcVersionValue(m_strFileVersion, sLine,"FileVersion");
			//GetRcVersionValue(m_strInternalName,sLine,"InternalName");
			GetRcVersionValue(m_strCopyright, sLine,"LegalCopyright");
			// GetRcVersionValue(m_strOriginalFilename,sLine,"OriginalFilename");
			GetRcVersionValue(m_strPrivateBuild, sLine,"PrivateBuild");
			GetRcVersionValue(m_strProductName,sLine,"ProductName");
			GetRcVersionValue(m_strProductVersion, sLine,"ProductVersion");
		}
		fileIni.Close();
		UpdateData(FALSE);

		return true;
	}
	return false;
}



/**
* 
* \param sMHFilename 
* \return 
*/
bool CRcversionDlg::ParseMasterHeaderFile(CString sMHFilename)
{
	CStdioFile fileMHeader;
	CString sDataModel = m_strDatamodel;
	CString sPatternDate;
	CString sPatternTime;
	CString sPatternVersion;
	CString sTmpLine;

	m_strDateStatus = ST_BAD;
	m_strTimeStatus = ST_BAD;
	m_strVersionStatus = ST_BAD;

	if(fileMHeader.Open(sMHFilename,CFile::modeRead))
	{
		sDataModel.MakeUpper();
		sPatternDate.Format("#define %s_DATE ",sDataModel);
		sPatternTime.Format("#define %s_TIME ",sDataModel);
		sPatternVersion.Format("#define %s_VERSION ",sDataModel);

		while (fileMHeader.ReadString(sTmpLine)) 
		{
			if (sTmpLine.Find(sPatternDate)==0) 
			{
				//m_strDate = sPatternDate + GetValueFromDefineConstant(sTmpLine);
				m_strDate = GetValueFromDefineConstant(sTmpLine);
				m_strDateStatus = ST_OK;
			}

			if (sTmpLine.Find(sPatternTime)==0) 
			{
				//m_strTime= sPatternTime + GetValueFromDefineConstant(sTmpLine);
				m_strTime= GetValueFromDefineConstant(sTmpLine);
				m_strTimeStatus = ST_OK;
			}

			if (sTmpLine.Find(sPatternVersion)==0) 
			{
				//m_strVersion= sPatternVersion + GetValueFromDefineConstant(sTmpLine);
				m_strVersion= GetValueFromDefineConstant(sTmpLine);
				m_strVersionStatus = ST_OK;
			}
		}
		UpdateData(false);
		return true;
	}
	return false;
}




/**
* 
* \param void 
* \return 
*/
bool CRcversionDlg::WriteRcFile(void)
{
	CString sOutput;
	sOutput = MakeRcFile();
	if (sOutput.IsEmpty()) 
	{
		return false;
	}

	CStdioFile fileOut;

	if (fileOut.Open(m_strRCFileName+".tmp",CFile::modeWrite |CFile::modeCreate))
	{
		fileOut.WriteString(sOutput);
		fileOut.Close();

		if(CopyFile(m_strRCFileName+".tmp",m_strRCFileName,false) ==0 )
		{
			ShowLastError(GetLastError());
			return false;
		}

		ASSERT(DeleteFile(m_strRCFileName+".tmp"));

		UpdateData(FALSE);
		return true;
	}

	return false;
}



/**
* 
* \param void 
* \return 
*/
bool CRcversionDlg::WriteHeaderFile(void)
{
	CString sOutput;
	sOutput = MakeHeaderFile();
	CStdioFile fileHOut;
	if (fileHOut.Open("version.h", CFile::modeCreate|CFile::modeWrite))
	{
		fileHOut.WriteString(sOutput);
		fileHOut.Close();
		return true;
	}

	return false;
}



/**
* 
* \param void 
* \return 
*/
CString CRcversionDlg::MakeHeaderFile(void)
{
	CString sOutput;
	CString sTmp;

	// header 
	sTmp.Format("// Generated by RCVersion %s \n//  build %s (%s)\n",__PRODUCTVERSION__,__PRIVATEBUILD__,__SNAPSHOT__);
	sOutput+=sTmp;

	sTmp.Format("// %s\n",__COPYRIGHT__);
	sOutput+=sTmp;

	CTime   t = CTime::GetCurrentTime();
	CString sDate = t.Format( "%d/%m/%Y %H:%m:%S");
	CString sDateSym = t.Format( "%Y%m%d-%H%m%S");

	sTmp.Format("// Generated on %s from resource file %s\n",sDate,m_strRCFileName);
	sOutput.Append(sTmp);

	// snapshot
	sOutput += SetHeaderConstantValue("SNAPSHOT", sDateSym);
	
	// fileversion
	CString sTmpFileVersion = m_strFileVersion;
	sTmpFileVersion.Replace(" ","");
	sTmpFileVersion.Replace(',','.');
	sOutput += SetHeaderConstantValue("FILEVERSION", sTmpFileVersion);
	
	// productversion
	CString sTmpProductVersion = m_strProductVersion;
	sTmpProductVersion.Replace(" ","");
	sTmpProductVersion.Replace(',','.');
	sOutput += SetHeaderConstantValue("PRODUCTVERSION",sTmpProductVersion);
	
	// CompanyName
	sOutput += SetHeaderConstantValue("COMPANY",m_strCompanyName);
		
	// #ifdef
	sOutput+="#ifdef _DEBUG\n";

	// ProductName
	sOutput += SetHeaderConstantValue("PRODUCT",m_strProductName+" (Debug)",1);

	// FileDesc
	sOutput += SetHeaderConstantValue("DESCRIPTION",m_strFileDesc+" (Debug)",1);

	// PrivateBuild
	sOutput += SetHeaderConstantValue("PRIVATEBUILD",m_strPrivateBuild+"-Debug",1);

	// #else
	sOutput+="#else //_DEBUG\n";

	// ProductName
	sOutput += SetHeaderConstantValue("PRODUCT",m_strProductName,1);

	// FileDesc
	sOutput += SetHeaderConstantValue("DESCRIPTION",m_strFileDesc,1);

	// PrivateBuild
	sOutput += SetHeaderConstantValue("PRIVATEBUILD",m_strPrivateBuild,1);

	// #endif
	sOutput+="#endif //_DEBUG\n";

	// Copyright
	sOutput += SetHeaderConstantValue("COPYRIGHT",m_strCopyright);



	// Classbuilder
	sOutput+="\n// Master Header Values (ClassBuilder)!!\n";

	// CB DATE
	sOutput += SetHeaderConstantValue("CB_DATE",m_strDate);

	// CB TIME
	sOutput += SetHeaderConstantValue("CB_TIME",m_strTime);

	// CB VERSION
	sOutput += SetHeaderConstantValue("CB_VERSION",m_strVersion);

	// end, flush & close
	sOutput+="\n";
	sOutput+="// Do Not Modify !!\n";

	return sOutput;
}



/**
* 
* \param void 
* \return 
*/
CString CRcversionDlg::MakeRcFile(void)
{
	CString sOutput;
	CStdioFile fileIni;
	if (fileIni.Open(m_strRCFileName, CFile::modeRead))
	{
		CString sLine;
		while (fileIni.ReadString(sLine))
		{
			//GetRcVersionValue(m_strComments,sLine,"Comments");
			SetRcVersionValue(m_strCompanyName, sLine,"CompanyName");
			SetRcVersionValue(m_strFileVersion, sLine,"FileVersion");
			//GetRcVersionValue(m_strInternalName,sLine,"InternalName");
			SetRcVersionValue(m_strCopyright, sLine,"LegalCopyright");
			// GetRcVersionValue(m_strOriginalFilename,sLine,"OriginalFilename");
			SetRcVersionValue(m_strProductVersion, sLine,"ProductVersion");
/*#ifdef _DEBUG
			SetRcVersionValue(m_strPrivateBuild+"-Debug", sLine,"PrivateBuild");
			SetRcVersionValue(m_strProductName+" (Debug)",sLine,"ProductName");
			SetRcVersionValue(m_strFileDesc+" (Debug)", sLine,"FileDescription");
#else //_DEBUG
*/
			SetRcVersionValue(m_strPrivateBuild, sLine,"PrivateBuild");
			SetRcVersionValue(m_strProductName,sLine,"ProductName");
			SetRcVersionValue(m_strFileDesc, sLine,"FileDescription");
//#endif //_DEBUG
	


			sOutput += sLine +"\n";
		}
		fileIni.Close();
	}
	return sOutput;	
}



/**
* 
* \param void 
*/
void CRcversionDlg::CheckFiles(void)
{
	char szCurrentDir[1024];
	GetCurrentDirectory(1024,szCurrentDir);
	//SetTitle("RCVersion - " + szCurrentDir);
	CString sTitle = "RCVersion - ";
	sTitle += szCurrentDir;
	SetWindowText(sTitle);

	m_strRcFileStatus = GetFileStatus(m_strRCFileName);
	m_strMHeaderFileStatus= GetFileStatus(m_strMHeaderFile);
	m_strCBDFileStatus= GetFileStatus(m_strCBDFile);
	m_strOutputFileStatus= GetFileStatus(m_strOutputFile);
	UpdateData(false);
}



/**
* 
* \param sFileTitle 
*/
void CRcversionDlg::UpdateFilenames(CString sFileTitle)
{
	m_strDatamodel = sFileTitle;
	m_strRCFileName = sFileTitle +".rc";
	m_strMHeaderFile= sFileTitle +".h";
	m_strCBDFile= sFileTitle +".cbd";
	m_strOutputFile = "version.h";
	UpdateData(false);
	ParseRcFile(); 
}



/**
* 
* \param sFilename 
* \return 
*/
CString CRcversionDlg::GetFileStatus(CString sFilename)
{
	CFile fileTmp;
	if(fileTmp.Open(sFilename,CFile::modeRead))
	{
		fileTmp.Close();
		return ST_OK;
	}
	else
	{
		return  ST_BAD;
	}
}



/**
* 
* \param sLine 
* \param bIsString 
* \return 
*/
CString CRcversionDlg::GetValueFromDefineConstant(CString sLine, bool bIsString)
{
	CString sRet;
	CString sTmp;
	int iLastSpacePos = sLine.ReverseFind(' ');

	sTmp= sLine.Right(sLine.GetLength() - iLastSpacePos);
	sTmp.Trim();
	if(bIsString)
		sRet.Format("\"%s\"",sTmp);
	else
		sRet.Format("%s",sTmp);
	return sRet;
}







