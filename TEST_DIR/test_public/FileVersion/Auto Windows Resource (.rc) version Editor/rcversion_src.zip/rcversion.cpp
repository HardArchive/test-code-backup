// rcversion.cpp : Defines the class behaviors for the application.
//

#include "stdafx.h"
#include "rcversion.h"
#include "rcversionDlg.h"
#include "XGetopt.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


// Globals
bool g_bQuiet = false;



/////////////////////////////////////////////////////////////////////////////
// CRcversionApp

BEGIN_MESSAGE_MAP(CRcversionApp, CWinApp)
	//{{AFX_MSG_MAP(CRcversionApp)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG
	ON_COMMAND(ID_HELP, CWinApp::OnHelp)
END_MESSAGE_MAP()
CString g_strRcFileName;
CString g_strPrefix;

/////////////////////////////////////////////////////////////////////////////
// CRcversionApp construction

CRcversionApp::CRcversionApp()
{
	// TODO: add construction code here,
	// Place all significant initialization in InitInstance
}

/////////////////////////////////////////////////////////////////////////////
// The one and only CRcversionApp object

CRcversionApp theApp;

/////////////////////////////////////////////////////////////////////////////
// CRcversionApp initialization

BOOL CRcversionApp::InitInstance()
{
	AfxEnableControlContainer();
	AfxInitRichEdit( );

	// Standard initialization
	// If you are not using these features and wish to reduce the size
	//  of your final executable, you should remove from the following
	//  the specific initialization routines you do not need.
	//g_strRcFileName = __argv[1];
	ProcessCommandLine( __argc,  __argv);

	CRcversionDlg dlg;
	if(g_bQuiet)
	{
		dlg.Create(IDD_RCVERSION_DIALOG);
		dlg.ShowWindow(SW_MINIMIZE);
		
		dlg.m_bAutoFVersion = true;
		dlg.m_bAutoPrivBuild= true;
		dlg.UpdateData(false);
		
		dlg.OnBnClickedCheckAutoFVersion();
		dlg.OnBnClickedCheckAutoPrivbuild();
		

		dlg.OnBnClickedOk();
		dlg.DestroyWindow();
		
		//AfxMessageBox("Wait...");
	}
	else
	{	
		int nResponse = dlg.DoModal();
		if (nResponse == IDOK)
		{
			// TODO: Place code here to handle when the dialog is
			//  dismissed with OK
		}
		else if (nResponse == IDCANCEL)
		{
			// TODO: Place code here to handle when the dialog is
			//  dismissed with Cancel
		}
	}
	// Since the dialog has been closed, return FALSE so that we exit the
	//  application, rather than start the application's message pump.
	return FALSE;
}

/**
 * ProcessCommandLine
 * Supported Options:
 * q : quiet
 * i : input file (rc)
 * p : prefix
 * m : datamodel
 * ?/h : help
 * \param argc 
 * \param argv 
 * \return 
 */
bool CRcversionApp::ProcessCommandLine(int argc, char** argv)
{

	int c;

	while ((c = getopt(argc, argv, "qi:p:")) != EOF)
	{
		switch (c)
		{
		case 'q':
			g_bQuiet=true;
			break;

		case 'i':
			g_strRcFileName = optarg;
			//
			// set some other flag here
			//
			break;

		case 'p':
			g_strPrefix = optarg;
			//
			// do something with value here
			//
			break;

		case '?':
			TRACE(_T("ERROR: illegal option %s\n"), argv[optind-1]);
			return FALSE;
			break;

		default:
			TRACE(_T("WARNING: no handler for option %c\n"), c);
			return FALSE;
			break;
		}  
	}
	//
	// check for non-option args here
	//
	return TRUE;
}
