// rcversionDlg.h : header file
//

#include "afxwin.h"
#if !defined(AFX_RCVERSIONDLG_H__43347C08_1952_4E3B_8A3A_93B9438889D4__INCLUDED_)
#define AFX_RCVERSIONDLG_H__43347C08_1952_4E3B_8A3A_93B9438889D4__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include "TrayDialog.h"
#include "afxcmn.h"
/////////////////////////////////////////////////////////////////////////////
// CRcversionDlg dialog

class CRcversionDlg : public CTrayDialog
{

public:
	// Construction
	CRcversionDlg(CWnd* pParent = NULL);	// standard constructor

	// Dialog Data
	enum { IDD = IDD_RCVERSION_DIALOG };

protected:
	// overrides
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	virtual void PostNcDestroy();

	HICON m_hIcon;

	// Generated message map functions
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	virtual void OnOK();

	DECLARE_MESSAGE_MAP()

public:
	bool ParseRcFile(void);
	afx_msg void OnBnClickedButtonAbout();
	bool WriteRcFile(void);
	bool BackupFile(CString sFilename,	CString sSuffix=".bak");
	bool WriteHeaderFile(void);

	CString	m_strRCFileName;
	CString m_strOutputFile;
	CString m_strMHeaderFile;
	CString m_strDatamodel;
	CString m_strCBDFile;

	CString	m_strCompanyName;
	CString	m_strFileVersion;
	CString	m_strProductName;
	CString	m_strProductVersion;
	CString	m_strFileDesc;
	CString	m_strCopyright;
	CString m_strPrivateBuild;
	//CString	m_editHelp;

	CString m_strRcFileStatus;
	CString m_strOutputFileStatus;
	CString m_strMHeaderFileStatus;
	CString m_strCBDFileStatus;
	CString m_strDatamodelStatus;

	CString m_strCompanyStatus;
	CString m_strProductStatus;
	CString m_strDescriptionStatus;
	CString m_strPVersionStatus;
	CString m_strCopyrigthStatus;

	CString m_strTime;
	CString m_strDate;
	CString m_strVersion;
	CString m_strTimeStatus;
	CString m_strDateStatus;
	CString m_strVersionStatus;

	//CEdit m_ctrlEditHelp;

	CEdit m_ctrlEditPrivBuild;
	BOOL m_bAutoPrivBuild;
	CString m_strPrivateBuildBackup;
	BOOL m_bAutoFVersion;
	CEdit m_ctrlEditFVersion;
	CString m_strFileVersionBackup;

	afx_msg void OnBnClickedBrowse();
	afx_msg void OnEnChangeEditDatamodel();
	afx_msg void OnBnClickedSave();
	afx_msg void OnBnClickedSynchronize();
	afx_msg void OnBnClickedButtonPreview();
	afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);
	afx_msg void OnBnClickedCheckAutoPrivbuild();
	afx_msg void OnBnClickedCheckAutoFVersion();
	afx_msg void OnMainmenuAbout();
	afx_msg void OnBnClickedViewVersionH();
	afx_msg void OnEnChangeEditVersion();
	afx_msg void OnBnClickedReload();
	afx_msg void OnEnChangeEditDate();
	afx_msg void OnBnClickedViewRcfile();
	afx_msg void OnBnClickedButtonPreviewRcfile();

	void CheckFiles(void);
	CString GetFileStatus(CString sFilename);
	void UpdateFilenames(CString sFileTitle);
	bool ParseMasterHeaderFile(CString sMHFilename);
	CString GetValueFromDefineConstant(CString sLine, bool bIsString=false);
	CString MakeHeaderFile(void);
	void ResetDialog(void);
	CString MakeRcFile(void);
	CString AjustPath(CString sFullPath);
	afx_msg void OnBnClickedOk();
	CString m_strPrefix;
	CString SetHeaderConstantValue(CString sName, CString sValue,int iDepth=0);
	CString m_strPreview;
	CRichEditCtrl m_ctrlRichEditPreview;
};


//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_RCVERSIONDLG_H__43347C08_1952_4E3B_8A3A_93B9438889D4__INCLUDED_)
