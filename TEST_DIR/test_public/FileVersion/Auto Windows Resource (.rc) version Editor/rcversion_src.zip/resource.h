//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by rcversion.rc
//
#define IDC_SAVE                        3
#define IDC_SYNCHRONIZE                 4
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_RCVERSION_DIALOG            102
#define IDS_OK                          102
#define IDS_NOT_FOUND                   103
#define IDS_FOUND                       104
#define IDR_MAINFRAME                   128
#define IDR_MENU1                       129
#define ID_MAINMENU_ABOUT               133
#define IDC_EDIT_DATAMODEL              900
#define IDC_EDIT_COMPANYNAME            901
#define IDC_EDIT_PRODUCTNAME            902
#define IDC_EDIT_FILEDESC               903
#define IDC_EDIT_FILEVERSION            904
#define IDC_CHECK_AUTO_FVERSION         905
#define IDC_EDIT_PRODUCTVERSION         906
#define IDC_EDIT_COPYRIGHT              907
#define IDC_EDIT_PRIVBUILD              908
#define IDC_CHECK_AUTO_PRIVBUILD        910
#define IDC_EDIT_RCFILENAME             1000
#define IDC_EDIT_HELP                   1007
#define IDC_EDIT_OUTPUT_FILENAME        1009
#define IDC_EDIT_OUTPUT_FILENAME2       1010
#define IDC_EDIT_MHEADER_FILENAME       1010
#define IDC_BUTTON_ABOUT                1011
#define IDC_STATIC_RCFILE_OK            1012
#define IDC_STATIC_ABOUT                1013
#define IDC_STATIC_OUTFILE_OK           1013
#define IDC_STATIC_MHEADER_FILE_OK      1014
#define IDC_STATIC_COMPANY_OK           1015
#define IDC_STATIC_PRODUCT_OK           1016
#define IDC_STATIC_DESCRIPTION_OK       1017
#define IDC_STATIC_PVERSION_OK          1018
#define IDC_STATIC_COPYRIGHT_OK         1019
#define IDC_VIEW_VERSION_H              1020
#define IDC_RELOAD                      1021
#define IDC_EDIT_CBD_FILENAME           1022
#define IDC_STATIC_CBDFILE_OK           1023
#define IDC_STATIC_DATAMODEL_OK         1025
#define IDC_BROWSE                      1026
#define IDC_EDIT_DATE                   1027
#define IDC_STATIC_DATE_OK              1028
#define IDC_VIEW_RCFILE                 1030
#define IDC_EDIT_TIME                   1031
#define IDC_STATIC_TIME_OK              1032
#define IDC_EDIT_VERSION                1033
#define IDC_STATIC_VERSION_OK           1034
#define IDC_BUTTON_PREVIEW              1035
#define IDC_BUTTON_PREVIEW_RCFILE       1036
#define IDC_EDIT_PREFIX                 1037
#define IDC_RICHEDIT21                  1038
#define IDC_RICHEDIT_PREVIEW            1038

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        134
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1039
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
