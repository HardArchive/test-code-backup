/************************************
  REVISION LOG ENTRY
  Revision By:  Mihai Filimon 
  Revised on 12/16/99 9:32:41 AM
  Comments: DSAddIn.h : header file

  Revision By:  Jordan Walters 
  Revised on 29/11/2004
  Comments: IncVersion.cpp : Increments FileVersion and ProductVersion in resource.
 ************************************/

#if !defined(AFX_DSADDIN_H__6A1C8D9E_B32E_11D3_9890_AC32A9D3503E__INCLUDED_)
#define AFX_DSADDIN_H__6A1C8D9E_B32E_11D3_9890_AC32A9D3503E__INCLUDED_

#include "commands.h"

// {6A1C8D8B-B32E-11D3-9890-AC32A9D3503E}
DEFINE_GUID(CLSID_DSAddIn,
0x6a1c8d8b, 0xb32e, 0x11d3, 0x98, 0x90, 0xac, 0x32, 0xa9, 0xd3, 0x50, 0x3e);

/////////////////////////////////////////////////////////////////////////////
// CDSAddIn

class CDSAddIn : 
	public IDSAddIn,
	public CComObjectRoot,
	public CComCoClass<CDSAddIn, &CLSID_DSAddIn>
{
public:
	DECLARE_REGISTRY(CDSAddIn, "IncVersion.DSAddIn.1",
		"INCVERSION Developer Studio Add-in", IDS_INCVERSION_LONGNAME,
		THREADFLAGS_BOTH)

	CDSAddIn() {}
	BEGIN_COM_MAP(CDSAddIn)
		COM_INTERFACE_ENTRY(IDSAddIn)
	END_COM_MAP()
	DECLARE_NOT_AGGREGATABLE(CDSAddIn)

// IDSAddIns
public:
	STDMETHOD(OnConnection)(THIS_ IApplication* pApp, VARIANT_BOOL bFirstTime,
		long dwCookie, VARIANT_BOOL* OnConnection);
	STDMETHOD(OnDisconnection)(THIS_ VARIANT_BOOL bLastTime);

protected:
	CCommandsObj* m_pCommands;
	DWORD m_dwCookie;
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DSADDIN_H__6A1C8D9E_B32E_11D3_9890_AC32A9D3503E__INCLUDED)
