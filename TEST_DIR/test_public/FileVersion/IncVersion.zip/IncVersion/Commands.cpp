/************************************
  REVISION LOG ENTRY
  Revision By:  Mihai Filimon 
  Revised on 12/16/99 9:35:23 AM
  Comments: Commands.cpp : implementation file

  Revision By:  Jordan Walters 
  Revised on 29/11/2004
  Comments: IncVersion.cpp : Increments FileVersion and ProductVersion in resource.
 ************************************/

#include "stdafx.h"
#include "IncVersion.h"
#include "Commands.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#define FileVersion "FILEVERSION "
#define ProductVersion "PRODUCTVERSION "
#define FileVersionText "VALUE \"FileVersion\", \""
#define ProductVersionText "VALUE \"ProductVersion\", \""
#define VersionInfo "VERSIONINFO"

/////////////////////////////////////////////////////////////////////////////
// CCommands

CCommands::CCommands()
{
	m_pApplication = NULL;
	m_pApplicationEventsObj = NULL;
	m_pDebuggerEventsObj = NULL;
}

CCommands::~CCommands()
{
	ASSERT (m_pApplication != NULL);
	m_pApplication->Release();
}

void CCommands::SetApplicationObject(IApplication* pApplication)
{
	// This function assumes pApplication has already been AddRef'd
	//  for us, which CDSAddIn did in its QueryInterface call
	//  just before it called us.
	m_pApplication = pApplication;

	// Create Application event handlers
	XApplicationEventsObj::CreateInstance(&m_pApplicationEventsObj);
	m_pApplicationEventsObj->AddRef();
	m_pApplicationEventsObj->Connect(m_pApplication);
	m_pApplicationEventsObj->m_pCommands = this;

	// Create Debugger event handler
	CComPtr<IDispatch> pDebugger;
	if (SUCCEEDED(m_pApplication->get_Debugger(&pDebugger)) 
		&& pDebugger != NULL)
	{
		XDebuggerEventsObj::CreateInstance(&m_pDebuggerEventsObj);
		m_pDebuggerEventsObj->AddRef();
		m_pDebuggerEventsObj->Connect(pDebugger);
		m_pDebuggerEventsObj->m_pCommands = this;
	}
}

void CCommands::UnadviseFromEvents()
{
	ASSERT (m_pApplicationEventsObj != NULL);
	m_pApplicationEventsObj->Disconnect(m_pApplication);
	m_pApplicationEventsObj->Release();
	m_pApplicationEventsObj = NULL;

	if (m_pDebuggerEventsObj != NULL)
	{
		// Since we were able to connect to the Debugger events, we
		//  should be able to access the Debugger object again to
		//  unadvise from its events (thus the VERIFY_OK below--see stdafx.h).
		CComPtr<IDispatch> pDebugger;
		VERIFY_OK(m_pApplication->get_Debugger(&pDebugger));
		ASSERT (pDebugger != NULL);
		m_pDebuggerEventsObj->Disconnect(pDebugger);
		m_pDebuggerEventsObj->Release();
		m_pDebuggerEventsObj = NULL;
	}
}


/////////////////////////////////////////////////////////////////////////////
// Event handlers

// TODO: Fill out the implementation for those events you wish handle
//  Use m_pCommands->GetApplicationObject() to access the Developer
//  Studio Application object

// Application events

// Function name	: CCommands::XApplicationEvents::BeforeBuildStart
// Description	    : Called when I build the current project
// Return type		: HRESULT 
HRESULT CCommands::XApplicationEvents::BeforeBuildStart()
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());
	m_pCommands->IncVersionCommandMethod();
	return S_OK;
}

// Function name	: CCommands::XApplicationEvents::BuildFinish
// Description	    : Called when Build command ends.
// Return type		: HRESULT 
// Argument         : long nNumErrors
// Argument         : long nNumWarnings
HRESULT CCommands::XApplicationEvents::BuildFinish(long nNumErrors, long nNumWarnings)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());
	if ( nNumErrors != 0 )
	{
		// Reset the resource to the original content
		m_pCommands->UpdateResource( &m_pCommands->m_strResourceContent );
	}
	return S_OK;
}

HRESULT CCommands::XApplicationEvents::BeforeApplicationShutDown()
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());
	return S_OK;
}

HRESULT CCommands::XApplicationEvents::DocumentOpen(IDispatch* theDocument)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());
	return S_OK;
}

HRESULT CCommands::XApplicationEvents::BeforeDocumentClose(IDispatch* theDocument)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());
	return S_OK;
}

HRESULT CCommands::XApplicationEvents::DocumentSave(IDispatch* theDocument)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());
	return S_OK;
}

HRESULT CCommands::XApplicationEvents::NewDocument(IDispatch* theDocument)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());
	return S_OK;
}

HRESULT CCommands::XApplicationEvents::WindowActivate(IDispatch* theWindow)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());
	return S_OK;
}

HRESULT CCommands::XApplicationEvents::WindowDeactivate(IDispatch* theWindow)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());
	return S_OK;
}

HRESULT CCommands::XApplicationEvents::WorkspaceOpen()
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());
	return S_OK;
}

HRESULT CCommands::XApplicationEvents::WorkspaceClose()
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());
	return S_OK;
}

HRESULT CCommands::XApplicationEvents::NewWorkspace()
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());
	return S_OK;
}

// Debugger event

HRESULT CCommands::XDebuggerEvents::BreakpointHit(IDispatch* pBreakpoint)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());
	return S_OK;
}


/////////////////////////////////////////////////////////////////////////////
// CCommands methods

// Function name	: CCommands::IncVersionCommandMethod
// Description	    : This is my contribution
// Return type		: STDMETHODIMP 
STDMETHODIMP CCommands::IncVersionCommandMethod() 
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());

	IGenericProject* pProject = NULL;
	if ( SUCCEEDED( GetApplicationObject()->get_ActiveProject( (LPDISPATCH*)&pProject ) ) )
	{
		USES_CONVERSION;
		CComBSTR bstrProjectName;
		if ( SUCCEEDED( pProject->get_FullName( &bstrProjectName.m_str ) ) )
		{
			CString strProjectName( OLE2T( bstrProjectName.m_str ) );
			
			// Changes for using rc2 file in res directory.
			m_strResourceName = strProjectName.Left( strProjectName.GetLength() - 4 ) + ".rc2";
			// place res\\ after last backslash in path
			int nBackslash = m_strResourceName.ReverseFind('\\');
			m_strResourceName.Insert(nBackslash + 1, "res\\");

			TRY
			{
				CString strrcFile;
				m_strResourceContent.Empty();
				CFile ifile;
				// Reads the resource file into memory, and copy it to m_strResourceContent
				if(ifile.Open(m_strResourceName, CFile::modeRead))
				{
					ifile.Read( strrcFile.GetBufferSetLength( ifile.GetLength() ), ifile.GetLength() );
					ifile.Close();
					m_strResourceContent = strrcFile;
				}

				// Does the rc2 file actually contain the VERSIONINFO block(s)
				if(m_strResourceContent.Find(VersionInfo) < 0)
				{
					m_strResourceName = strProjectName.Left( strProjectName.GetLength() - 4 ) + ".rc";

					if(ifile.Open(m_strResourceName, CFile::modeRead))
					{
						ifile.Read( strrcFile.GetBufferSetLength( ifile.GetLength() ), ifile.GetLength() );
						ifile.Close();
						m_strResourceContent = strrcFile;
					}
				}

//				CString strInfo;
//				strInfo.Format(_T("Resource file %s"), m_strResourceName);
//				AfxMessageBox(strInfo);
				//Replaces the FILEVERSION Key from resource File
				CString strFileVersion(FileVersion);
				long nPos = strrcFile.Find( strFileVersion );
				if ( nPos >= 0 )
				{
					do
					{
						long nStart = nPos += strFileVersion.GetLength(), nEnd = nStart;
						// Shift along past three commas
						nPos = strrcFile.Find(_T(","), nStart);
						if(nPos >= 0){nStart = nPos + 1; nPos = strrcFile.Find(_T(","), nStart);}
						if(nPos >= 0){nStart = nPos + 1; nPos = strrcFile.Find(_T(","), nStart);}
						if(nPos >= 0){nStart = nPos + 1;}
						long nFileVersion = NULL;
						for ( nEnd = nStart ; ( nEnd < strrcFile.GetLength() ) && isdigit( strrcFile.GetAt( nEnd ) ) ; nEnd++ )
							nFileVersion = nFileVersion * 10 + strrcFile.GetAt( nEnd ) - '0';
						nFileVersion++;
						CString strNewFileVersion; strNewFileVersion.Format( "%i", nFileVersion );
						strrcFile = strrcFile.Left( nStart ) + strNewFileVersion + strrcFile.Mid( nEnd );
						nPos = strrcFile.Find( strFileVersion, nStart );
					}while(nPos >= 0);
				}
				else
				{
				}

				//Replaces the PRODUCTVERSION Key from resource File
				CString strProductVersion(ProductVersion);
				nPos = strrcFile.Find( strProductVersion );
				if ( nPos >= 0 )
				{
					do
					{
						long nStart = nPos += strProductVersion.GetLength(), nEnd = nStart;
						// Shift along past three commas
						nPos = strrcFile.Find(_T(","), nStart);
						if(nPos >= 0){nStart = nPos + 1; nPos = strrcFile.Find(_T(","), nStart);}
						if(nPos >= 0){nStart = nPos + 1; nPos = strrcFile.Find(_T(","), nStart);}
						if(nPos >= 0){nStart = nPos + 1;}
						long nProductVersion = NULL;
						for ( nEnd = nStart ; ( nEnd < strrcFile.GetLength() ) && isdigit( strrcFile.GetAt( nEnd ) ) ; nEnd++ )
							nProductVersion = nProductVersion * 10 + strrcFile.GetAt( nEnd ) - '0';
						nProductVersion++;
						CString strNewProductVersion; strNewProductVersion.Format( "%i", nProductVersion );
						strrcFile = strrcFile.Left( nStart ) + strNewProductVersion + strrcFile.Mid( nEnd );
						nPos = strrcFile.Find( strProductVersion, nStart );
					}while(nPos >= 0);
				}
				else
				{
				}

				//Replaces the FileVersion Key from resource File
				CString strFileVersionText(ProductVersionText);
				nPos = strrcFile.Find( strFileVersionText );
				if ( nPos >= 0 )
				{
					do
					{
						long nStart = nPos += strFileVersionText.GetLength(), nEnd = nStart;
						// Shift along past three commas
						nPos = strrcFile.Find(_T(","), nStart);
						if(nPos >= 0){nStart = nPos + 1; nPos = strrcFile.Find(_T(","), nStart);}
						if(nPos >= 0){nStart = nPos + 1; nPos = strrcFile.Find(_T(","), nStart);}
						if(nPos >= 0){nStart = nPos + 2;}
						long nFileVersionText = NULL;
						for ( nEnd = nStart ; ( nEnd < strrcFile.GetLength() ) && isdigit( strrcFile.GetAt( nEnd ) ) ; nEnd++ )
							nFileVersionText = nFileVersionText * 10 + strrcFile.GetAt( nEnd ) - '0';
						nFileVersionText++;
						CString strNewFileVersionText; strNewFileVersionText.Format( "%i", nFileVersionText );
						strrcFile = strrcFile.Left( nStart ) + strNewFileVersionText + strrcFile.Mid( nEnd );
						nPos = strrcFile.Find( strFileVersionText, nStart );
					}while(nPos >= 0);
				}
				else
				{
				}

				//Replaces the ProductVersion Key from resource File
				CString strProductVersionText(FileVersionText);
				nPos = strrcFile.Find( strProductVersionText );
				if ( nPos >= 0 )
				{
					do
					{
						long nStart = nPos += strProductVersionText.GetLength(), nEnd = nStart;
						// Shift along past three commas
						nPos = strrcFile.Find(_T(","), nStart);
						if(nPos >= 0){nStart = nPos + 1; nPos = strrcFile.Find(_T(","), nStart);}
						if(nPos >= 0){nStart = nPos + 1; nPos = strrcFile.Find(_T(","), nStart);}
						if(nPos >= 0){nStart = nPos + 2;}
						long nProductVersionText = NULL;
						for ( nEnd = nStart ; ( nEnd < strrcFile.GetLength() ) && isdigit( strrcFile.GetAt( nEnd ) ) ; nEnd++ )
							nProductVersionText = nProductVersionText * 10 + strrcFile.GetAt( nEnd ) - '0';
						nProductVersionText++;
						CString strNewProductVersionText; strNewProductVersionText.Format( "%i", nProductVersionText );
						strrcFile = strrcFile.Left( nStart ) + strNewProductVersionText + strrcFile.Mid( nEnd );
						nPos = strrcFile.Find( strProductVersionText, nStart );
					}while(nPos >= 0);
				}
				else
				{
				}
				UpdateResource( &strrcFile );
			}
			CATCH( CFileException, e )
			{
				#ifdef _DEBUG
					afxDump << "Resource file " << strProjectName << " couldn't be opened " << e->m_cause << "\n";
				#else
					CString strError;
					strError.Format(_T("Resource file %s couldn't be opened %n"), strProjectName, e->m_cause);
					AfxMessageBox(strError);
				#endif
			}
			END_CATCH
		}
		pProject->Release();
	}

	return S_OK;
}

// Function name	: CCommands::UpdateResource
// Description	    : Update the resource file
// Return type		: void 
// Argument         : LPCTSTR pszResourceName
// Argument         : CString *pResourceContent
void CCommands::UpdateResource( CString *pResourceContent )
{
	if ( pResourceContent )
		if ( LPCTSTR pszResourceName = m_strResourceName.operator LPCTSTR() )
		{
			
			TRY
			{
				CFile oFile( pszResourceName, CFile::modeCreate | CFile::modeWrite );
					oFile.Write( pResourceContent->operator LPCTSTR(), pResourceContent->GetLength() );
				oFile.Close();
			}
			CATCH( CFileException, e )
			{
				#ifdef _DEBUG
					afxDump << "Resource file " << m_strResourceName << " couldn't be saved " << e->m_cause << "\n";
				#endif
			}
			END_CATCH
		}
}
