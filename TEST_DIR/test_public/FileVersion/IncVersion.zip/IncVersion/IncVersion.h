/************************************
  REVISION LOG ENTRY
  Revision By:  Mihai Filimon 
  Revised on 12/16/99 9:35:59 AM
  Comments: ...

  Revision By:  Jordan Walters 
  Revised on 29/11/2004
  Comments: IncVersion.cpp : Increments FileVersion and ProductVersion in resource.
 ************************************/

#if !defined(AFX_INCVERSION_H__6A1C8D94_B32E_11D3_9890_AC32A9D3503E__INCLUDED_)
#define AFX_INCVERSION_H__6A1C8D94_B32E_11D3_9890_AC32A9D3503E__INCLUDED_

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

#include <ObjModel\addguid.h>
#include <ObjModel\appguid.h>
#include <ObjModel\bldguid.h>
#include <ObjModel\textguid.h>
#include <ObjModel\dbgguid.h>
#include <ObjModel\bldauto.h>


//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_INCVERSION_H__6A1C8D94_B32E_11D3_9890_AC32A9D3503E__INCLUDED_)
