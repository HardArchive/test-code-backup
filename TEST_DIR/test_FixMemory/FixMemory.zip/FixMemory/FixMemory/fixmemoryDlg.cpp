
// fixmemoryDlg.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "fixmemory.h"
#include "fixmemoryDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


#define PAGE_SIZE 4096
#define KERNEL_ADDRESS 0x80000000


#define TRUE 1
#define FALSE 0
#define FAIL -1

typedef struct note_address{
	unsigned long address;
	struct note_address *next;
}note_addr;

note_addr *n_addr_list;

int flag = 0;
HANDLE t_process;

// ����Ӧ�ó��򡰹��ڡ��˵���� CAboutDlg �Ի���

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// �Ի�������
	enum { IDD = IDD_ABOUTBOX };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

// ʵ��
protected:
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
END_MESSAGE_MAP()


// CfixmemoryDlg �Ի���




CfixmemoryDlg::CfixmemoryDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CfixmemoryDlg::IDD, pParent)
	, m_proname(_T(""))
	, m_provalue(0)
	, m_fixvalue(0)
	, m_order(_T(""))
	, m_plist(_T(""))
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CfixmemoryDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_PRO_LIST, m_prolist);
	DDX_Text(pDX, IDC_PROT, m_proname);
	DDX_Text(pDX, IDC_FINDT, m_provalue);
	DDX_Text(pDX, IDC_FIXT, m_fixvalue);
	DDX_CBString(pDX, IDC_ORDER, m_order);
	DDX_Text(pDX, IDC_PLIST, m_plist);
}

BEGIN_MESSAGE_MAP(CfixmemoryDlg, CDialog)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	//}}AFX_MSG_MAP
	ON_BN_CLICKED(IDC_GETB, &CfixmemoryDlg::OnBnClickedGetb)
	ON_BN_CLICKED(IDC_CHOOSEB, &CfixmemoryDlg::OnBnClickedChooseb)
	ON_BN_CLICKED(IDC_FINDB, &CfixmemoryDlg::OnBnClickedFindb)
	ON_BN_CLICKED(IDC_FIXB, &CfixmemoryDlg::OnBnClickedFixb)
END_MESSAGE_MAP()


// CfixmemoryDlg ��Ϣ��������

BOOL CfixmemoryDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// ��������...���˵������ӵ�ϵͳ�˵��С�

	// IDM_ABOUTBOX ������ϵͳ���Χ�ڡ�
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		BOOL bNameValid;
		CString strAboutMenu;
		bNameValid = strAboutMenu.LoadString(IDS_ABOUTBOX);
		ASSERT(bNameValid);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// ���ô˶Ի����ͼ�ꡣ��Ӧ�ó��������ڲ��ǶԻ���ʱ����ܽ��Զ�
	//  ִ�д˲���
	SetIcon(m_hIcon, TRUE);			// ���ô�ͼ��
	SetIcon(m_hIcon, FALSE);		// ����Сͼ��

	
	m_prolist.SetExtendedStyle(LVS_EX_FULLROWSELECT|LVS_EX_GRIDLINES);
	LV_COLUMN lvColumn;
	lvColumn.mask=LVCF_FMT|LVCF_SUBITEM|LVCF_TEXT|LVCF_WIDTH;
	lvColumn.fmt=LVCFMT_LEFT;
	lvColumn.cx=151;
	lvColumn.pszText=_T(" ����ID");
	m_prolist.InsertColumn(0,&lvColumn);
	lvColumn.pszText=_T(" ������");
	m_prolist.InsertColumn(1,&lvColumn);

	((CComboBox*) GetDlgItem(IDC_ORDER))->SetCurSel(0);
	return TRUE;  // ���ǽ��������õ��ؼ������򷵻� TRUE
}

void CfixmemoryDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// �����Ի���������С����ť������Ҫ����Ĵ���
//  �����Ƹ�ͼ�ꡣ����ʹ���ĵ�/��ͼģ�͵� MFC Ӧ�ó���
//  �⽫�ɿ���Զ���ɡ�

void CfixmemoryDlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // ���ڻ��Ƶ��豸������

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// ʹͼ���ڹ����������о���
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// ����ͼ��
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

//���û��϶���С������ʱϵͳ���ô˺���ȡ�ù��
//��ʾ��
HCURSOR CfixmemoryDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}

void CfixmemoryDlg::PrintAllProcess()
{
	HANDLE snapshot = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
	PROCESSENTRY32 p;
    if (snapshot == INVALID_HANDLE_VALUE) {
		MessageBox(_T("CreateToolhelp32Snapshot failed"),_T("error"),0);
		exit(-1);
    }

	p.dwSize = sizeof(PROCESSENTRY32);
	if(Process32First(snapshot, &p))
	{
		do {
			int k;
			CString text;
			text.Format(_T("0x%08X"), p.th32ProcessID);
			k = m_prolist.InsertItem(0, text);
			text.Format(_T("%s"), p.szExeFile);
			m_prolist.SetItemText(k, 1, text); 
		} while (Process32Next(snapshot, &p));
	}
	//Invalidate(FALSE);
	CloseHandle(snapshot);
}

void CfixmemoryDlg::PrintMemory(HANDLE process)
{
	MEMORY_BASIC_INFORMATION info;
	TCHAR *protect;
	unsigned long address;
    for(address = 0; address < KERNEL_ADDRESS;address += info.RegionSize) 
    {
        // ��ѯָ�����̵�MEMORY_BASIC_INFOMATION
        VirtualQueryEx(process, (void *)address, &info, sizeof(info));
        if (info.State != MEM_COMMIT)
            continue;
		
        
        if (info.Protect & PAGE_READONLY)
            protect = _T("RO");
        else if (info.Protect & PAGE_READWRITE)
            protect = _T("RW");
        else
           protect = _T("--");
		CString text;
		text.Format(_T("0x%08x\t%s\t%dK\r\n"), info.BaseAddress, 
            protect,
            info.RegionSize/PAGE_SIZE);
		m_plist += text;
		UpdateData(false);
		//UpdateData(true);
    }
}

DWORD CfixmemoryDlg::FindProcess(CString name)
{
	 HANDLE snapshot = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
	 DWORD pid = 0;
    
    PROCESSENTRY32 p;
	
    if (snapshot == INVALID_HANDLE_VALUE) {
        MessageBox(_T("CreateToolhelp32Snapshot failed\n"), _T("error"), 0);
        exit(-1);
    }
	
    p.dwSize = sizeof(PROCESSENTRY32);
    if(Process32First(snapshot, &p))
	{
		do {
				CString text;
				text.Format(_T("%s"), p.szExeFile);
				if (text == name) {
					pid = p.th32ProcessID;
					break;
				}
		} while (Process32Next(snapshot, &p));
	}
    CloseHandle(snapshot);
	
    return pid;
}

void CfixmemoryDlg::get()
{
	CString p_name;
	DWORD pid;
	UpdateData(true);
	p_name = m_proname;
	pid = FindProcess(p_name);
	t_process = OpenProcess(PROCESS_ALL_ACCESS, FALSE, pid);
	if(t_process == NULL)
		MessageBox(_T("no handle found...\n"), _T("fail"), 0);
}

int CfixmemoryDlg::FindMemory(long value, HANDLE process)
{
	MEMORY_BASIC_INFORMATION info;
	unsigned long address;
	unsigned long t_buff[1024];
	DWORD n_read;
	char *protect;
	note_addr* p;
	int cnt = 0;
	unsigned long j;
	int i;
	CString text;
	n_addr_list = (note_addr*)malloc(sizeof(note_addr));
	n_addr_list->next = NULL;
	
    for(address = 0; address < KERNEL_ADDRESS;address += info.RegionSize) 
    {
        VirtualQueryEx(process, (void *)address, &info, sizeof(info));
        if (info.State != MEM_COMMIT)
            continue;
		
		if(info.Protect & PAGE_READONLY || info.Protect &PAGE_READWRITE)
		{
			for(j = (unsigned long)info.BaseAddress; j < (unsigned long)info.BaseAddress + info.RegionSize; j += 4096)
			{
				if(ReadProcessMemory(t_process,(void *)j,t_buff,4096,&n_read))
				{
					for(i = 0; i < 1024; i++)
					{
						if(t_buff[i] == value)
						{
							p = (note_addr*)malloc(sizeof(note_addr));
							p->address = j + i*4;
							p->next = n_addr_list->next;
							n_addr_list->next = p;
							text.Format(_T("0x%08x	%d\r\n"), p->address, t_buff[i]);
							m_plist += text;
							UpdateData(false);
							cnt++;
							//WriteProcessMemory(tmp,address,&t_buff,512,&n_write);
						}
					}
				}
			}
		}
		else 
		{
			protect = "--";
			continue;
		}
	}
	
	if(cnt == 0)
	{
		text.Format(_T("find nothing...\r\n"));
		m_plist += text;
		UpdateData(false);
		return FAIL;
	}
	text.Format(_T("%d notes found...\r\n"), cnt);
	m_plist += text;
	UpdateData(false);
	return TRUE;
}

int CfixmemoryDlg::FindList(long value)
{
	unsigned long t_buff;
	note_addr *p, *q;
	int cnt = 0;
	DWORD n_read;
	p = n_addr_list;
	q = n_addr_list->next;
	CString text;

	while(q != NULL)
	{
		if(ReadProcessMemory(t_process, (void *)q->address, &t_buff, 4, &n_read))
		{
			if(t_buff == value)
			{
				text.Format(_T("0x%08x	%d\r\n"), q->address, t_buff);
				m_plist += text;
				UpdateData(false);
				cnt++;
				p = q;
				q = q->next;
			}
			else
			{
				p->next = q->next;
				free(q);
				q = p->next;
			}
		}
	}
	text.Format(_T("%d notes found...\r\n"), cnt);
	m_plist += text;
	UpdateData(false);
	return TRUE;
}

void CfixmemoryDlg::Find()
{
	long value;
	value = m_provalue;
	if(flag == 0)
		flag = FindMemory(value, t_process);
	else
		FindList(value);
}

int CfixmemoryDlg::Fix()
{
	note_addr *p;
	unsigned long t_buff;
	DWORD n_write;
	if(n_addr_list == NULL)
		return FAIL;
	p = n_addr_list->next;
	CString text;

	if(p == NULL || p->next != NULL)
	{
		text.Format(_T("not find the memory...\r\n"));
		MessageBox(text);
		return FAIL;
	}
	t_buff = m_fixvalue;
	if(!WriteProcessMemory(t_process, (void *)p->address, &t_buff, 4, &n_write))
	{
		MessageBox(_T("fix memory value failed...\r\n"), _T("error"), 0);
	}
	//free(p);
	return TRUE;
}

void CfixmemoryDlg::OnBnClickedGetb()
{
	UpdateData(true);
	if(m_order == _T("�г�����"))
	{
		PrintAllProcess();
		UpdateData(false);
	}
	if(m_order == _T("��ӡ�ڴ�"))
	{
		m_plist = _T("");
		PrintMemory(t_process);
		UpdateData(false);
	}
}

void CfixmemoryDlg::OnBnClickedChooseb()
{
	UpdateData(true);
	get();
	UpdateData(false);
}

void CfixmemoryDlg::OnBnClickedFindb()
{
	UpdateData(true);
	m_plist = _T("");
	Find();
	UpdateData(false);
}

void CfixmemoryDlg::OnBnClickedFixb()
{
	UpdateData(true);
	Fix();
	UpdateData(false);
}
