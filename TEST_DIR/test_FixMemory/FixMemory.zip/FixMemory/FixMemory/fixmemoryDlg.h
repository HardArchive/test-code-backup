
// fixmemoryDlg.h : ͷ�ļ�
//

#pragma once
#include "afxcmn.h"
#include <tlhelp32.h>


// CfixmemoryDlg �Ի���
class CfixmemoryDlg : public CDialog
{
// ����
public:
	CfixmemoryDlg(CWnd* pParent = NULL);	// ��׼���캯��

// �Ի�������
	enum { IDD = IDD_FIXMEMORY_DIALOG };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV ֧��


// ʵ��
protected:
	HICON m_hIcon;

	// ���ɵ���Ϣӳ�亯��
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
public:
	CListCtrl m_prolist;
	CString m_proname;
	long m_provalue;
	long m_fixvalue;
	CString m_order;
	CString m_plist;
	afx_msg void OnBnClickedGetb();
	void PrintMemory(HANDLE process);
	void PrintAllProcess();
	DWORD FindProcess(CString name);
	void get();
	int FindMemory(long value, HANDLE process);
	int FindList(long value);
	void Find();
	int Fix();
	afx_msg void OnBnClickedChooseb();
	afx_msg void OnBnClickedFindb();
	afx_msg void OnBnClickedFixb();
};
