 /*++
 Copyright (c) 2002 - 2006 Microsoft Corporation.  All Rights Reserved.

 THIS CODE AND INFORMATION IS PROVIDED "AS-IS" WITHOUT WARRANTY OF
 ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO
 THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
 PARTICULAR PURPOSE.

 THIS CODE IS NOT SUPPORTED BY MICROSOFT. 

--*/



#ifndef _PRECOMP_H_
#define _PRECOMP_H_

#ifndef UNICODE
    #define UNICODE
#endif

#include    <windows.h>
#include    <stdio.h>
#include    <stdlib.h>
#include    <strsafe.h>
#include    <wininet.h>
#include    <Winternl.h>

#endif  // _PRECOMP_H_

