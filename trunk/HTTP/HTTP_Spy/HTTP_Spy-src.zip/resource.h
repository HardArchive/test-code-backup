//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by HTTP Spy.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_HTTPSPY_DIALOG              102
#define IDP_SOCKETS_INIT_FAILED         103
#define IDR_MAINFRAME                   128
#define IDD_RESPONSE_DIALOG             129
#define IDC_RESPONSE_LIST               1001
#define IDC_EDIT_URL                    1003
#define IDC_STATIC_URL                  1004
#define IDC_COMBO1                      1005
#define IDC_COMBO_USRAGENT              1005
#define IDC_CHECK_PORT                  1006
#define IDC_EDIT_PORT                   1007
#define IDC_BUTTON_DOIT                 1010
#define IDC_TAB_RESPONSE                1011
#define IDC_TARGET_PORT                 1012
#define IDC_REQUEST_METHOD              1013
#define IDC_METHOD_HEAD                 1016
#define IDC_METHOD_GET                  1017
#define IDC_EDIT_HTTPRES                1018
#define IDC_RESET_SETTING               1020
#define IDC_RESET_RESULT                1021
#define IDC_RESET                       1022
#define IDC_BUTTON_RESET                1023
#define IDC_DIRECT_INTERNET             1024
#define IDC_HTTP_PROXY                  1025
#define IDC_PROXY_IPADDRESS             1026
#define IDC_EDIT_PROXY_PORT             1027
#define IDC_PROXY_PORT                  1028
#define IDC_STATIC_UA                   1029
#define IDC_STATIC_PROXYIP              1030

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1031
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
