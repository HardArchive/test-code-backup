/*
* copyright (c)2011,borlittle (borlittle@qq.com)
* All rights reserved
* Redistribution and use in source and binary forms, with or without modification, are permitted provided 
* that the following conditions are met. Redistributions of source code must retain the above 
* copyright notice, this list of conditions and the following disclaimer.
* Redistributions in binary form must reproduce the above copyright notice, this list of conditions and 
* the following disclaimer in the documentation and/or other materials provided with the distribution.
* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED
* WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED  WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
* PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, 
* INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE 
* GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF 
* LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT 
* OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE  POSSIBILITY OF SUCH DAMAGE.
*
* FileName:adderalc.h
* Note:The header file of this project.
* Version:1.0
* CreateTime:2011-8-29
* OriginalAuthor:borlittle
* Referrence:http://www.viksoe.dk/code/index.htm http://code.google.com/p/duilib/ 
* ThanksList:Bjarke Viksoe (bjarke@viksoe.dk)
*           DuilibTeam(wangchyz@gmail.com, taxueliuyun@gmail.com, achellies@hotmail.com, tojen.me@gmail.com, ljh_0110@163.com)
* 
* UpdateRecord:
* Note:
* Version:
* UpdateTime:
* UpdateAuthor:
* Referrence:
* ThanksList��
*/


#pragma once

#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <errno.h>

#include "resource.h"
#include "stdafx.h"
#include"math.h"

class CAdderCalc :
	public CWindowWnd , public INotifyUI//Ӧ�ó��򴰿���
{
public:
	CAdderCalc(void);
	~CAdderCalc(void);
	
	UINT const GetClassStyle();
	void OnFinalMessage(HWND /*hWnd*/);
	void Init();
	void OnPrepare();
	void Notify(TNotifyUI& msg);
	LRESULT OnCreate(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);
	LRESULT OnDestroy(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);
	LRESULT OnNcActivate(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);
	LRESULT OnNcCalcSize(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);
	LRESULT OnNcPaint(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);
	LRESULT OnNcHitTest(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);
	LRESULT OnSize(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);
	LRESULT OnClose(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);
	LRESULT OnGetMinMaxInfo(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);
	LRESULT OnSysCommand(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);
	LRESULT HandleMessage(unsigned int uMsg, WPARAM wParam, LPARAM lParam);


	LPCTSTR  GetWindowClassName()//�麯��������������ʽʵ��
		const
	{ 
		return _T("UIMainFrame");//���ڵ���������SPY++�ܿ�����
	};

public:
	CPaintManagerUI m_pm;//��ؼ����ƺ���Ϣ������������
private:
	//���尴ť�ؼ�ָ��
	CButtonUI* m_pBtnClose;//�ر�
	CButtonUI* m_pBtnMax;//���
	CButtonUI* m_pBtnMin;//��С��
	CButtonUI* m_pBtnCalc;//���㰴ť

	CEditUI* m_pEditSource1;//����
	CEditUI* m_pEditSource2;//������
	CEditUI* m_pEditResult;//������

};

