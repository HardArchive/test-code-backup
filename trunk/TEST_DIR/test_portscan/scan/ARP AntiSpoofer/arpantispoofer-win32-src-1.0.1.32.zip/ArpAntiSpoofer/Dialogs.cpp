#include "Dialogs.h"
#include "resource.h"

INT_PTR CALLBACK AntiSpoofIntervalProc( HWND dlg, UINT msg, WPARAM wparam, LPARAM lparam )
{
	static HWND thiswnd = NULL;

	switch( msg )
		{
		case WM_COMMAND:
			{
			switch( LOWORD( wparam ) )
				{
				case IDOK:
					{
					thiswnd = NULL;
					EndDialog( dlg, GetDlgItemInt( dlg, IDC_ASPINTV, NULL, FALSE ) );
					}break;//end IDOK

				default:
					{
					return FALSE;
					}break;
				}//end switch
			}break;//end WM_COMMAND

		case WM_CLOSE:
			{
			thiswnd = NULL;
			EndDialog( dlg, 0 );
			}break;//end WM_CLOSE

		case WM_INITDIALOG:
			{
			if( thiswnd != NULL )
				{		
				ShowWindow( thiswnd, SW_RESTORE );
				SetForegroundWindow( thiswnd );
				EndDialog( dlg, 0 );
				break;
				}//end if
			thiswnd = dlg;

			SetClassLongPtr( dlg, GCLP_HICON, reinterpret_cast<LONG_PTR>(reinterpret_cast<IntvParam*>(lparam)->icon) );
			SetDlgItemInt( dlg, IDC_ASPINTV, reinterpret_cast<IntvParam*>(lparam)->intv, FALSE );
			}break;//end WM_INITDIALOG

		default:
			{
			return FALSE;
			}break;
		}//end switch

	return TRUE;
}//end AntiSpoofIntervalProc

INT_PTR CALLBACK Reply4HostsIntervalProc( HWND dlg, UINT msg, WPARAM wparam, LPARAM lparam )
{
	static HWND thiswnd = NULL;

	switch( msg )
		{
		case WM_COMMAND:
			{
			switch( LOWORD( wparam ) )
				{
				case IDOK:
					{
					thiswnd = NULL;
					EndDialog( dlg, GetDlgItemInt( dlg, IDC_R4HINTV, NULL, FALSE ) );
					}break;//end IDOK

				default:
					{
					return FALSE;
					}break;
				}//end switch
			}break;//end WM_COMMAND

		case WM_CLOSE:
			{
			thiswnd = NULL;
			EndDialog( dlg, 0 );
			}break;//end WM_CLOSE

		case WM_INITDIALOG:
			{
			if( thiswnd != NULL )
				{		
				ShowWindow( thiswnd, SW_RESTORE );
				SetForegroundWindow( thiswnd );
				EndDialog( dlg, 0 );
				break;
				}//end if
			thiswnd = dlg;

			SetClassLongPtr( dlg, GCLP_HICON, reinterpret_cast<LONG_PTR>(reinterpret_cast<IntvParam*>(lparam)->icon) );
			SetDlgItemInt( dlg, IDC_R4HINTV, reinterpret_cast<IntvParam*>(lparam)->intv, FALSE );
			}break;//end WM_INITDIALOG

		default:
			{
			return FALSE;
			}break;
		}//end switch

	return TRUE;
}//end Reply4HostsIntervalProc

void ShowLog( HWND editwnd, int days, const AntiSpoof* as )
{
	const int kBuffSize = 65536;
	char *buff;
	time_t t;

	buff = new char[kBuffSize];

	time( &t );
	t -= days * 24 * 60 * 60;
	buff[as->show_log( t, buff, kBuffSize )] = '\0';

	SetWindowTextA( editwnd, buff );

	delete [] buff;
}//end ShowLog

INT_PTR CALLBACK ViewLogsProc( HWND dlg, UINT msg, WPARAM wparam, LPARAM lparam )
{
	static HWND thiswnd = NULL;

	switch( msg )
		{
		case WM_COMMAND:
			{
			switch( LOWORD( wparam ) )
				{
				case IDOK:
					{
					ShowLog( GetDlgItem( dlg, IDC_LOGS ), GetDlgItemInt( dlg, IDC_DAYS, NULL, FALSE ),
						reinterpret_cast<AntiSpoof*>(GetWindowLongPtr( dlg, DWLP_USER )) );
					}break;//end IDOK

				default:
					{
					return FALSE;
					}break;
				}//end switch
			}break;//end WM_COMMAND

		case WM_CLOSE:
			{
			thiswnd = NULL;
			EndDialog( dlg, 0 );
			}break;//end WM_CLOSE

		case WM_INITDIALOG:
			{
			if( thiswnd != NULL )
				{		
				ShowWindow( thiswnd, SW_RESTORE );
				SetForegroundWindow( thiswnd );
				EndDialog( dlg, 0 );
				break;
				}//end if
			thiswnd = dlg;

			SetClassLongPtr( dlg, GCLP_HICON, reinterpret_cast<LONG_PTR>(reinterpret_cast<ViewLogsParam*>(lparam)->icon) );
			SetWindowLongPtr( dlg, DWLP_USER, reinterpret_cast<LONG_PTR>(reinterpret_cast<ViewLogsParam*>(lparam)->as) );
			SetDlgItemInt( dlg, IDC_DAYS, 1, FALSE );
			ShowLog( GetDlgItem( dlg, IDC_LOGS ), 1, reinterpret_cast<ViewLogsParam*>(lparam)->as );
			}break;//end WM_INITDIALOG

		default:
			{
			return FALSE;
			}break;
		}//end switch

	return TRUE;
}//end ViewLogsProc

