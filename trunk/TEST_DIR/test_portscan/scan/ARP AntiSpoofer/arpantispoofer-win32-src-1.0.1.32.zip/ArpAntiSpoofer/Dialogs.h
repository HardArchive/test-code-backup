#ifndef CTQY_DIALOGS_H
#define CTQY_DIALOGS_H

#include "../antispoof/antispoof.h"

typedef struct
{
	HICON icon;
	int	intv;
} IntvParam;

typedef struct
{
	HICON icon;
	const AntiSpoof *as;
} ViewLogsParam;

// lparam is the &IntvParam
// return the interval in ms, or 0 if not set
INT_PTR CALLBACK AntiSpoofIntervalProc( HWND dlg, UINT msg, WPARAM wparam, LPARAM lparam );

// lparam is the &IntvParam
// return the interval in sec, or 0 if not set
INT_PTR CALLBACK Reply4HostsIntervalProc( HWND dlg, UINT msg, WPARAM wparam, LPARAM lparam );

// lparam is the &ViewLogsParam
INT_PTR CALLBACK ViewLogsProc( HWND dlg, UINT msg, WPARAM wparam, LPARAM lparam );

#endif // CTQY_DIALOGS_H
