#include <tchar.h>
#include <pcap.h>
#include "../antispoof/common.h"
#include "ConfigDlg.h"
#include <commctrl.h>

#include "resource.h"

static const TCHAR kTitle[] = TEXT("Preferences");
static const char kYes[] = "Yes";
static const char kNo[] = "No";

typedef struct
{
	Config* cfg;
	char desc[128];
} AdapterParam;

inline int ListView_InsertItemA( HWND listwnd, const LPLVITEMA pitem )
{
	return SendMessageA( listwnd, LVM_INSERTITEMA, 0, reinterpret_cast<LPARAM>(pitem) );
}//end ListView_InsertItemA

inline void ListView_SetItemTextA( HWND listwnd, int i, int subindex, LPCSTR pszText )
{
	LVITEMA lvi;
	lvi.iSubItem = subindex;
	lvi.pszText = const_cast<LPSTR>(pszText);
	SendMessageA( listwnd, LVM_SETITEMTEXTA, static_cast<WPARAM>(i), reinterpret_cast<LPARAM>(&lvi) );
}//end ListView_SetItemTextA

inline void ListView_GetItemTextA( HWND listwnd, int i, int subindex, LPSTR pszText, int cchTextMax )
{
	LV_ITEMA lvi;

	lvi.iSubItem = subindex;
	lvi.cchTextMax = cchTextMax;
	lvi.pszText = pszText;
	SendMessageA( listwnd, LVM_GETITEMTEXTA, static_cast<WPARAM>(i), reinterpret_cast<LPARAM>(&lvi) );
}//end ListView_GetItemTextA

static void FindAdapterDescription( const char adapter[], char desc[], int len )
{
	char errbuf[PCAP_ERRBUF_SIZE];
	pcap_if_t *alldevs;
	pcap_if_t *d;
	int i;

	desc[0] = '\0';
	if( pcap_findalldevs( &alldevs, errbuf ) == -1 )
		{
		return;
		}//end if

	for( i = 0, d = alldevs; d != NULL; d = d->next, ++i )
		{
		if( strcmp( d->name, adapter ) == 0 )
			{
			if( d->description != NULL )
				{
				strncpy( desc, d->description, len );
				desc[len-1] = '\0';
				}//end if
			break;
			}//end if
		}//end for

	pcap_freealldevs(alldevs);
}//end FindAdapterDescription

static void PrintMac( const MacAddr* mac, char buff[] )
{
	sprintf( buff, "%02X-%02X-%02X-%02X-%02X-%02X", mac->addr[0], mac->addr[1], mac->addr[2],
		mac->addr[3], mac->addr[4], mac->addr[5] );
}//end PrintMac

static void InitCAListView( HWND listwnd )
{	
	LVCOLUMN lvc;

	ListView_SetExtendedListViewStyle( listwnd, LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES | LVS_EX_LABELTIP );

	lvc.mask = LVCF_FMT | LVCF_WIDTH | LVCF_TEXT | LVCF_SUBITEM;
	lvc.fmt = LVCFMT_LEFT;

    lvc.cx = 200;
	lvc.pszText = TEXT("Network adapter");
	ListView_InsertColumn( listwnd, 0, &lvc );
    lvc.cx = 90;
	lvc.pszText = TEXT("IP address");
	ListView_InsertColumn( listwnd, 1, &lvc );
    lvc.cx = 370;
	lvc.pszText = TEXT("Description");
	ListView_InsertColumn( listwnd, 2, &lvc );
}//end InitCAListView

static INT_PTR CALLBACK ChooseAdapterProc( HWND dlg, UINT msg, WPARAM wparam, LPARAM lparam )
{
	static pcap_if_t* alldevs = NULL;
	static AdapterParam *ap;
	static int devnum = 0;
	static HWND listwnd;

	pcap_if_t* d;
	pcap_addr_t *a;
	int i;

	switch( msg )
		{
		case WM_COMMAND:
			{
			switch( LOWORD( wparam ) )
				{
				case IDOK:
					{
					i = ListView_GetSelectionMark( listwnd );
					if( i >= 0 )
						{
						for( d = alldevs; i > 0 && d != NULL; --i, d = d->next );//end for
						strncpy( ap->cfg->adapter, d->name, sizeof( ap->cfg->adapter ) );
						strncpy( ap->desc, d->description, sizeof( ap->desc ) );
						ap->desc[sizeof(ap->desc)-1] = '\0';
						for( a = d->addresses; a != NULL; a = a->next )
							{
							if( a->addr->sa_family == AF_INET )
								{
								break;
								}//end if
							}//end for
						if( a != NULL )
							{
							ap->cfg->local.ip.dw = reinterpret_cast<struct sockaddr_in*>(a->addr)->sin_addr.s_addr;
							ap->cfg->netmask.dw = reinterpret_cast<struct sockaddr_in*>(a->netmask)->sin_addr.s_addr;
							}
						else{
							ap->cfg->local.ip.dw = 0;
							ap->cfg->netmask.dw = 0x00ffffff;
							}//end if
						memset( &ap->cfg->local.mac, 0, sizeof( ap->cfg->local.mac ) );
						GetMacAddress( d->name, &ap->cfg->local.mac );
						pcap_freealldevs( alldevs );
						EndDialog( dlg, TRUE );
						}
					else{
						MessageBox( dlg, TEXT("Please choose a network adapter"), NULL, MB_ICONWARNING );
						}//end if
					}break;//end IDOK

				default:
					{
					return FALSE;
					}break;
				}//end switch
			}break;//end WM_COMMAND

		case WM_CLOSE:
			{
			pcap_freealldevs( alldevs );
			EndDialog( dlg, FALSE );
			}break;//end WM_CLOSE

		case WM_INITDIALOG:
			{
			char errbuf[PCAP_ERRBUF_SIZE];
			LVITEMA item;

			ap = reinterpret_cast<AdapterParam*>(lparam);
			listwnd = GetDlgItem( dlg, IDC_ADAPTERLIST );

			// init list view
			InitCAListView( listwnd );

			if( pcap_findalldevs( &alldevs, errbuf ) == -1 )
				{
				EndDialog( dlg, FALSE );
				break;
				}//end if

			// show devs and init devnum
			memset( &item, 0, sizeof( item ) );
			item.mask = LVIF_TEXT;
			item.iSubItem = 0;
			for( devnum = 0, d = alldevs; d != NULL; d = d->next, ++devnum )
				{
				item.iItem = devnum;
				item.pszText = d->name;
				ListView_InsertItemA( listwnd, &item );
				for( a = d->addresses; a != NULL; a = a->next )
					{
					if( a->addr->sa_family == AF_INET )
						{
						break;
						}//end if
					}//end for
				ListView_SetItemTextA( listwnd, devnum, 1,
					( a != NULL ) ? inet_ntoa( reinterpret_cast<struct sockaddr_in*>(a->addr)->sin_addr ) : "N/A" );
				if( d->description != NULL )
					{
					ListView_SetItemTextA( listwnd, devnum, 2, d->description );
					}//end if
				}//end for
			}break;//end WM_INITDIALOG

		default:
			{
			return FALSE;
			}break;
		}//end switch

	return TRUE;
}//end ChooseAdapterProc

static INT_PTR CALLBACK ProtectedHostProc( HWND dlg, UINT msg, WPARAM wparam, LPARAM lparam )
{
	ProtAddr* pa;

	switch( msg )
		{
		case WM_COMMAND:
			{
			switch( LOWORD( wparam ) )
				{
				case IDOK:
					{
					char buff[32];

					pa = reinterpret_cast<ProtAddr*>(GetWindowLongPtr( dlg, DWLP_USER ));

					SendDlgItemMessage( dlg, IDC_IPADDR, IPM_GETADDRESS, 0, reinterpret_cast<LPARAM>(&pa->ip.dw) );
					if( pa->ip.dw == 0 )
						{
						MessageBox( dlg, TEXT("Please enter valid IP address!"), NULL, MB_ICONWARNING );
						SetFocus( GetDlgItem( dlg, IDC_IPADDR ) );
						break;
						}//end if
					pa->ip.dw = ntohl( pa->ip.dw );

					GetDlgItemTextA( dlg, IDC_MACADDR, buff, sizeof( buff ) );
					if( !readmac( buff, &pa->mac ) || iszeromac( &pa->mac ) )
						{
						MessageBox( dlg, TEXT("Please enter valid MAC address!"), NULL, MB_ICONWARNING );
						SetFocus( GetDlgItem( dlg, IDC_MACADDR ) );
						break;
						}//end if

					pa->type = 0;
					if( IsDlgButtonChecked( dlg, IDC_ASHOST ) == BST_CHECKED )
						{
						pa->type |= PROT_TYPE_HOST;
						}//end if
					if( IsDlgButtonChecked( dlg, IDC_ASGATEWAY ) == BST_CHECKED )
						{
						pa->type |= PROT_TYPE_GATEWAY;
						}//end if
					EndDialog( dlg, TRUE );
					}break;//end IDOK

				default:
					{
					return FALSE;
					}break;
				}//end switch
			}break;//end WM_COMMAND

		case WM_CLOSE:
			{
			EndDialog( dlg, FALSE );
			}break;//end WM_CLOSE

		case WM_INITDIALOG:
			{
			char buff[32];

			SetWindowLongPtr( dlg, DWLP_USER, lparam );

			pa = reinterpret_cast<ProtAddr*>(lparam);
			if( pa->ip.dw != 0 )
				{
				SendDlgItemMessage( dlg, IDC_IPADDR, IPM_SETADDRESS, 0, htonl( pa->ip.dw ) );
				PrintMac( &pa->mac, buff );
				SetDlgItemTextA( dlg, IDC_MACADDR, buff );
				}//end if
			CheckDlgButton( dlg, IDC_ASHOST, (pa->type & PROT_TYPE_HOST) ? BST_CHECKED : BST_UNCHECKED );
			CheckDlgButton( dlg, IDC_ASGATEWAY, (pa->type & PROT_TYPE_GATEWAY) ? BST_CHECKED : BST_UNCHECKED );
			}break;//end WM_INITDIALOG

		default:
			{
			return FALSE;
			}break;
		}//end switch

	return TRUE;
}//end ProtectedHostProc

static INT_PTR CALLBACK ChooseGatewayMacProc( HWND dlg, UINT msg, WPARAM wparam, LPARAM lparam )
{
	Config* cfg;

	switch( msg )
		{
		case WM_COMMAND:
			{
			switch( LOWORD( wparam ) )
				{
				case IDC_DETECT:
					{
					MacAddr mac[8];
					char buff[32];
					int timeout;
					int n;
					int i;

					cfg = reinterpret_cast<Config*>(GetWindowLongPtr( dlg, DWLP_USER ));

					SendDlgItemMessage( dlg, IDC_GWADDRLIST, LB_RESETCONTENT, 0, 0 );

					timeout = GetDlgItemInt( dlg, IDC_CGMTIMEOUT, NULL, FALSE );
					n = GetMacForIp( cfg->adapter, cfg->netmask.dw, &cfg->local, cfg->gateway.ip, timeout,
							mac, sizeof( mac ) / sizeof( mac[0] ) );
					for( i = 0; i < n; ++i )
						{
						PrintMac( mac + i, buff );
						SendDlgItemMessageA( dlg, IDC_GWADDRLIST, LB_INSERTSTRING, -1, reinterpret_cast<LPARAM>(buff) );
						}//end for
					}break;//end IDC_DETECT

				case IDOK:
					{
					char buff[32];
					int i;

					cfg = reinterpret_cast<Config*>(GetWindowLongPtr( dlg, DWLP_USER ));

					i = SendDlgItemMessage( dlg, IDC_GWADDRLIST, LB_GETCURSEL, 0, 0 );
					if( i == LB_ERR )
						{
						MessageBox( dlg, TEXT("Please select an MAC address!"), NULL, MB_ICONWARNING );
						break;
						}//end if

					SendDlgItemMessageA( dlg, IDC_GWADDRLIST, LB_GETTEXT, i, reinterpret_cast<LPARAM>(buff) );
					readmac( buff, &cfg->gateway.mac );

					EndDialog( dlg, TRUE );
					}break;//end IDOK

				default:
					{
					return FALSE;
					}break;
				}//end switch
			}break;//end WM_COMMAND

		case WM_CLOSE:
			{
			EndDialog( dlg, FALSE );
			}break;//end WM_CLOSE

		case WM_INITDIALOG:
			{
			char buff[32];

			SetWindowLongPtr( dlg, DWLP_USER, lparam );

			cfg = reinterpret_cast<Config*>(lparam);
			SetDlgItemTextA( dlg, IDC_LOCALIP, inet_ntoa( cfg->local.ip.ia ) );
			PrintMac( &cfg->local.mac, buff );
			SetDlgItemTextA( dlg, IDC_LOCALMAC, buff );
			SetDlgItemTextA( dlg, IDC_GWIP, inet_ntoa( cfg->gateway.ip.ia ) );
			SetDlgItemTextA( dlg, IDC_NETMASK, inet_ntoa( cfg->netmask.ia ) );
			SetDlgItemInt( dlg, IDC_CGMTIMEOUT, 2, FALSE );
			}break;//end WM_INITDIALOG

		default:
			{
			return FALSE;
			}break;
		}//end switch

	return TRUE;
}//end ChooseGatewayMacProc

static void InitPHListView( HWND listwnd )
{	
	LVCOLUMN lvc;

	ListView_SetExtendedListViewStyle( listwnd, LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES | LVS_EX_LABELTIP );

	lvc.mask = LVCF_FMT | LVCF_WIDTH | LVCF_TEXT | LVCF_SUBITEM;
	lvc.fmt = LVCFMT_LEFT;

    lvc.cx = 100;
	lvc.pszText = TEXT("Host IP");
	ListView_InsertColumn( listwnd, 0, &lvc );
    lvc.cx = 120;
	lvc.pszText = TEXT("Host MAC");
	ListView_InsertColumn( listwnd, 1, &lvc );
    lvc.cx = 100;
	lvc.pszText = TEXT("Host Antispoof");
	ListView_InsertColumn( listwnd, 2, &lvc );
    lvc.cx = 120;
	lvc.pszText = TEXT("Gateway Antispoof");
	ListView_InsertColumn( listwnd, 3, &lvc );
}//end InitPHListView

static void GetProtAddrItem( HWND listwnd, int i, ProtAddr* pa )
{
	char buff[32];

	ListView_GetItemTextA( listwnd, i, 0, buff, sizeof( buff ) );
	readip( buff, &pa->ip );
	ListView_GetItemTextA( listwnd, i, 1, buff, sizeof( buff ) );
	readmac( buff, &pa->mac );
	pa->type = 0;
	ListView_GetItemTextA( listwnd, i, 2, buff, sizeof( buff ) );
	if( buff[0] == kYes[0] )
		{
		pa->type |= PROT_TYPE_HOST;
		}//end if
	ListView_GetItemTextA( listwnd, i, 3, buff, sizeof( buff ) );
	if( buff[0] == kYes[0] )
		{
		pa->type |= PROT_TYPE_GATEWAY;
		}//end if
}//end GetProtAddrItem

static void SetProtAddrItem( HWND listwnd, int i, const ProtAddr* pa )
{
	char buff[32];
	LVITEMA item;

	memset( &item, 0, sizeof( item ) );
	item.mask = LVIF_TEXT;
	item.iItem = i;
	item.iSubItem = 0;
	item.pszText = inet_ntoa( pa->ip.ia );
	i = ListView_InsertItemA( listwnd, &item );
	PrintMac( &pa->mac, buff );
	ListView_SetItemTextA( listwnd, i, 1, buff );
	ListView_SetItemTextA( listwnd, i, 2, (pa->type & PROT_TYPE_HOST) ? kYes : kNo );
	ListView_SetItemTextA( listwnd, i, 3, (pa->type & PROT_TYPE_GATEWAY) ? kYes : kNo );
}//end SetProtAddrItem

static void ModifyProtAddrItem( HWND listwnd, int i, const ProtAddr* pa )
{
	char buff[32];

	ListView_SetItemTextA( listwnd, i, 0, inet_ntoa( pa->ip.ia ) );
	PrintMac( &pa->mac, buff );
	ListView_SetItemTextA( listwnd, i, 1, buff );
	ListView_SetItemTextA( listwnd, i, 2, (pa->type & PROT_TYPE_HOST) ? kYes : kNo );
	ListView_SetItemTextA( listwnd, i, 3, (pa->type & PROT_TYPE_GATEWAY) ? kYes : kNo );
}//end ModifyProtAddrItem

// get adapter, local ip and mac, subnet mask and gateway ip
static bool GetParams( HWND dlg, CfgParam *cp )
{
	char buff[128];

	if( cp->cfg.adapter[0] == '\0' )
		{
		MessageBox( dlg, TEXT("Please choose a network adapter!"), NULL, MB_ICONWARNING );
		SetFocus( GetDlgItem( dlg, IDC_CHGADAPTER ) );
		return false;
		}//end if

	SendDlgItemMessage( dlg, IDC_LOCALIP, IPM_GETADDRESS, 0, reinterpret_cast<LPARAM>(&cp->cfg.local.ip.dw) );
	if( cp->cfg.local.ip.dw == 0 )
		{
		MessageBox( dlg, TEXT("Please enter valid local IP address!"), NULL, MB_ICONWARNING );
		SetFocus( GetDlgItem( dlg, IDC_LOCALIP ) );
		return false;
		}//end if
	cp->cfg.local.ip.dw = ntohl( cp->cfg.local.ip.dw );

	GetDlgItemTextA( dlg, IDC_LOCALMAC, buff, sizeof( buff ) );
	if( !readmac( buff, &cp->cfg.local.mac ) || iszeromac( &cp->cfg.local.mac ) )
		{
		MessageBox( dlg, TEXT("Please enter valid local MAC address!"), NULL, MB_ICONWARNING );
		SetFocus( GetDlgItem( dlg, IDC_LOCALMAC ) );
		return false;
		}//end if

	SendDlgItemMessage( dlg, IDC_SUBMASK, IPM_GETADDRESS, 0, reinterpret_cast<LPARAM>(&cp->cfg.netmask.dw) );
	if( cp->cfg.netmask.dw == 0 )
		{
		MessageBox( dlg, TEXT("Please enter valid subnet mask address!"), NULL, MB_ICONWARNING );
		SetFocus( GetDlgItem( dlg, IDC_SUBMASK ) );
		return false;
		}//end if
	cp->cfg.netmask.dw = ntohl( cp->cfg.netmask.dw );

	SendDlgItemMessage( dlg, IDC_GWIP, IPM_GETADDRESS, 0, reinterpret_cast<LPARAM>(&cp->cfg.gateway.ip.dw) );
	if( cp->cfg.gateway.ip.dw == 0 )
		{
		MessageBox( dlg, TEXT("Please enter valid gateway IP address!"), NULL, MB_ICONWARNING );
		SetFocus( GetDlgItem( dlg, IDC_GWIP ) );
		return false;
		}//end if
	cp->cfg.gateway.ip.dw = ntohl( cp->cfg.gateway.ip.dw );

	return true;
}//end GetParams

INT_PTR CALLBACK ConfigProc( HWND dlg, UINT msg, WPARAM wparam, LPARAM lparam )
{
	static HWND thiswnd = NULL;
	CfgParam *cp;

	switch( msg )
		{
		case WM_COMMAND:
			{
			switch( LOWORD( wparam ) )
				{
				case IDC_CHGADAPTER:
					{
					AdapterParam ap;
					char buff[32];

					cp = reinterpret_cast<CfgParam*>(GetWindowLongPtr( dlg, DWLP_USER ));
					ap.cfg = &cp->cfg;
					if( DialogBoxParam( cp->inst, MAKEINTRESOURCE( IDD_CHOOSEADAPTER ), dlg, ChooseAdapterProc,
							reinterpret_cast<LPARAM>(&ap) ) )
						{
						SetDlgItemTextA( dlg, IDC_ADAPTER, ap.desc );
						SendDlgItemMessage( dlg, IDC_LOCALIP, IPM_SETADDRESS, 0, htonl( cp->cfg.local.ip.dw ) );
						PrintMac( &cp->cfg.local.mac, buff );
						SetDlgItemTextA( dlg, IDC_LOCALMAC, buff );
						SendDlgItemMessage( dlg, IDC_SUBMASK, IPM_SETADDRESS, 0, htonl( cp->cfg.netmask.dw ) );

						cp->cfg.gateway.ip.dw &= ~cp->cfg.netmask.dw;
						cp->cfg.gateway.ip.dw |= cp->cfg.netmask.dw & cp->cfg.local.ip.dw;
						SendDlgItemMessage( dlg, IDC_GWIP, IPM_SETADDRESS, 0, htonl( cp->cfg.gateway.ip.dw ) );
						}//end if
					}break;//end IDC_CHGADAPTER

				case IDC_GETGWMAC:
					{
					char buff[32];

					cp = reinterpret_cast<CfgParam*>(GetWindowLongPtr( dlg, DWLP_USER ));
					
					if( !GetParams( dlg, cp ) )
						{
						break;
						}//end if

					//show choose gw mac dlg
					if( DialogBoxParam( cp->inst, MAKEINTRESOURCE( IDD_CHOOSEGWMAC ), dlg, ChooseGatewayMacProc,
							reinterpret_cast<LPARAM>(&cp->cfg) ) )
						{
						PrintMac( &cp->cfg.gateway.mac, buff );
						SetDlgItemTextA( dlg, IDC_GWMAC, buff );
						}//end if
					}break;//end IDC_GETGWMAC

				case IDC_REPLY4H:
					{
					if( IsDlgButtonChecked( dlg, IDC_REPLY4H ) == BST_UNCHECKED )
						{
						EnableWindow( GetDlgItem( dlg, IDC_R4HINTV ), FALSE );
						}
					else{
						EnableWindow( GetDlgItem( dlg, IDC_R4HINTV ), TRUE );
						}//end if
					}break;//end IDC_REPLY4H
					
				case IDC_REMOTECTRL:
					{
					if( IsDlgButtonChecked( dlg, IDC_REMOTECTRL ) == BST_UNCHECKED )
						{
						EnableWindow( GetDlgItem( dlg, IDC_RCPORT ), FALSE );
						EnableWindow( GetDlgItem( dlg, IDC_RCPSWD ), FALSE );
						}
					else{
						EnableWindow( GetDlgItem( dlg, IDC_RCPORT ), TRUE );
						EnableWindow( GetDlgItem( dlg, IDC_RCPSWD ), TRUE );
						}//end if
					}break;//end IDC_REMOTECTRL

				case IDC_ADD:
					{
					ProtAddr pa;
					HWND listwnd;

					cp = reinterpret_cast<CfgParam*>(GetWindowLongPtr( dlg, DWLP_USER ));
					listwnd = GetDlgItem( dlg, IDC_PROTHOSTS );
					pa.ip.dw = 0;
					if( DialogBoxParam( cp->inst, MAKEINTRESOURCE( IDD_PROTADDR ), dlg, ProtectedHostProc, reinterpret_cast<LPARAM>(&pa) ) )
						{
						SetProtAddrItem( listwnd, 0, &pa );
						}//end if
					}break;//end IDC_ADD

				case IDC_MODIFY:
					{
					ProtAddr pa;
					HWND listwnd;

					cp = reinterpret_cast<CfgParam*>(GetWindowLongPtr( dlg, DWLP_USER ));
					listwnd = GetDlgItem( dlg, IDC_PROTHOSTS );
					int i = ListView_GetSelectionMark( listwnd );
					if( i >= 0 )
						{
						GetProtAddrItem( listwnd, i, &pa );
						if( DialogBoxParam( cp->inst, MAKEINTRESOURCE( IDD_PROTADDR ), dlg, ProtectedHostProc, reinterpret_cast<LPARAM>(&pa) ) )
							{
							ModifyProtAddrItem( listwnd, i, &pa );
							}//end if
						}//end if
					}break;//end IDC_MODIFY

				case IDC_DELETE:
					{
					HWND listwnd = GetDlgItem( dlg, IDC_PROTHOSTS );
					int i = ListView_GetSelectionMark( listwnd );
					if( i >= 0 )
						{
						if( MessageBox( dlg, TEXT("Are you sure to delete it?"), kTitle, MB_YESNO | MB_ICONWARNING ) == IDYES )
							{
							ListView_DeleteItem( listwnd, i );
							EnableWindow( GetDlgItem( dlg, IDC_RCPORT ), FALSE );
							EnableWindow( GetDlgItem( dlg, IDC_RCPSWD ), FALSE );
							}//end if
						}//end if
					}break;//end IDC_DELETE

				case IDCANCEL:
					{
					thiswnd = NULL;
					EndDialog( dlg, FALSE );
					}break;//end IDCANCEL

				case IDOK:
					{
					char buff[128];
					HWND listwnd;
					int i;

					cp = reinterpret_cast<CfgParam*>(GetWindowLongPtr( dlg, DWLP_USER ));

					if( !GetParams( dlg, cp ) )
						{
						break;
						}//end if

					GetDlgItemTextA( dlg, IDC_GWMAC, buff, sizeof( buff ) );
					if( !readmac( buff, &cp->cfg.gateway.mac ) || iszeromac( &cp->cfg.gateway.mac ) )
						{
						MessageBox( dlg, TEXT("Please enter valid gateway MAC address!"), NULL, MB_ICONWARNING );
						SetFocus( GetDlgItem( dlg, IDC_GWMAC ) );
						break;
						}//end if

					if( CheckAbuse_Gateway( &cp->cfg ) )
						{
						MessageBox( dlg, TEXT("Gateway MAC should not be same as local MAC!"), NULL, MB_ICONWARNING );
						SetFocus( GetDlgItem( dlg, IDC_GWMAC ) );
						break;
						}//end if

					cp->cfg.bindgateway = (IsDlgButtonChecked( dlg, IDC_BINDGW ) == BST_CHECKED);

					cp->cfg.autodetect = (IsDlgButtonChecked( dlg, IDC_AUTODETECT ) == BST_CHECKED);
					cp->cfg.keepprotstat = (IsDlgButtonChecked( dlg, IDC_KEEPSTATUS ) == BST_CHECKED);
					cp->cfg.multiple = GetDlgItemInt( dlg, IDC_MULTIPLE, NULL, FALSE );

					cp->cfg.spoof_range = 1000 * GetDlgItemInt( dlg, IDC_SPOOFRANGE, NULL, FALSE );

					GetDlgItemTextA( dlg, IDC_LOGFILE, cp->cfg.logfile, sizeof( cp->cfg.logfile ) );

					cp->cfg.reply4gw = (IsDlgButtonChecked( dlg, IDC_REPLY4GW ) == BST_CHECKED);
					cp->cfg.reply4h = (IsDlgButtonChecked( dlg, IDC_REPLY4H ) == BST_CHECKED);
					cp->cfg.reply4hintv = GetDlgItemInt( dlg, IDC_R4HINTV, NULL, FALSE );

					cp->cfg.remotectrl = (IsDlgButtonChecked( dlg, IDC_REMOTECTRL ) == BST_CHECKED);
					cp->cfg.rc_port = GetDlgItemInt( dlg, IDC_RCPORT, NULL, FALSE );
					GetDlgItemTextA( dlg, IDC_RCPSWD, cp->cfg.rc_pswd, sizeof( cp->cfg.rc_pswd ) );

					cp->notifyspoof = (IsDlgButtonChecked( dlg, IDC_NOTIFYSPOOF ) == BST_CHECKED);

					listwnd = GetDlgItem( dlg, IDC_PROTHOSTS );
					cp->cfg.prot_num = ListView_GetItemCount( listwnd );
					cp->cfg.protaddr = new ProtAddr[cp->cfg.prot_num];
					for( i = 0; i < cp->cfg.prot_num; ++i )
						{
						GetProtAddrItem( listwnd, i, &cp->cfg.protaddr[i] );
						if( cp->cfg.protaddr[i].ip.dw == 0 || iszeromac( &cp->cfg.protaddr[i].mac ) )
							{
							break;
							}//end if
						}//end for
					if( i < cp->cfg.prot_num )
						{
						delete [] cp->cfg.protaddr;
						MessageBox( dlg, TEXT("Please enter valid host MAC address!"), NULL, MB_ICONWARNING );
						SetFocus( GetDlgItem( dlg, IDC_PROTHOSTS ) );
						break;
						}//end if

					if( CheckAbuse_ProtHosts( &cp->cfg ) )
						{
						delete [] cp->cfg.protaddr;
						MessageBox( dlg, TEXT("Other hosts' MAC address should not be same as local MAC\r\nwhen 'Gateway Antispoof' is enabled!"),
							NULL, MB_ICONWARNING );
						SetFocus( GetDlgItem( dlg, IDC_PROTHOSTS ) );
						break;
						}//end if

					thiswnd = NULL;
					EndDialog( dlg, TRUE );
					}break;//end IDOK

				default:
					{
					return FALSE;
					}break;
				}//end switch
			}break;//end WM_COMMAND

		case WM_NOTIFY:
			{
			switch( reinterpret_cast<LPNMHDR>(lparam)->idFrom )
				{
				case IDC_PROTHOSTS:
					{
					switch( reinterpret_cast<LPNMHDR>(lparam)->code )
						{
						case NM_CLICK:
						case NM_RCLICK:
							{
							if( reinterpret_cast<LPNMITEMACTIVATE>(lparam)->iItem == -1 )
								{
								EnableWindow( GetDlgItem( dlg, IDC_MODIFY ), FALSE );
								EnableWindow( GetDlgItem( dlg, IDC_DELETE ), FALSE );
								}//end if
							}break;//end NM_xCLICK

						case LVN_ITEMCHANGED:
							{
							if( reinterpret_cast<LPNMLISTVIEW>(lparam)->iItem != -1 )
								{
								EnableWindow( GetDlgItem( dlg, IDC_MODIFY ), TRUE );
								EnableWindow( GetDlgItem( dlg, IDC_DELETE ), TRUE );
								}//end if
							}break;//end LVN_ITEMCHANGED

						default:
							{
							return FALSE;
							}break;
						}//end switch
					}break;//end IDC_PROTHOSTS

				default:
					{
					return FALSE;
					}break;
				}//end switch
			}break;//end WM_NOTIFY

		case WM_CLOSE:
			{
			thiswnd = NULL;
			EndDialog( dlg, FALSE );
			}break;//end WM_CLOSE

		case WM_INITDIALOG:
			{
			char buff[128];
			HWND listwnd;
			int i;
			
			if( thiswnd != NULL )
				{		
				ShowWindow( thiswnd, SW_RESTORE );
				SetForegroundWindow( thiswnd );
				EndDialog( dlg, 0 );
				break;
				}//end if
			thiswnd = dlg;

			cp = reinterpret_cast<CfgParam*>(lparam);
			SetClassLongPtr( dlg, GCLP_HICON, reinterpret_cast<LONG_PTR>(cp->icon) );
			SetWindowLongPtr( dlg, DWLP_USER, lparam );

			listwnd = GetDlgItem( dlg, IDC_PROTHOSTS );
			InitPHListView( listwnd );

			FindAdapterDescription( cp->cfg.adapter, buff, sizeof( buff ) );
			SetDlgItemTextA( dlg, IDC_ADAPTER, ( buff[0] != '\0' ) ? buff : cp->cfg.adapter );

			SendDlgItemMessage( dlg, IDC_LOCALIP, IPM_SETADDRESS, 0, htonl( cp->cfg.local.ip.dw ) );
			PrintMac( &cp->cfg.local.mac, buff );
			SetDlgItemTextA( dlg, IDC_LOCALMAC, buff );

			SendDlgItemMessage( dlg, IDC_SUBMASK, IPM_SETADDRESS, 0, htonl( cp->cfg.netmask.dw ) );

			SendDlgItemMessage( dlg, IDC_GWIP, IPM_SETADDRESS, 0, htonl( cp->cfg.gateway.ip.dw ) );
			PrintMac( &cp->cfg.gateway.mac, buff );
			SetDlgItemTextA( dlg, IDC_GWMAC, buff );

			CheckDlgButton( dlg, IDC_BINDGW, cp->cfg.bindgateway ? BST_CHECKED : BST_UNCHECKED );

			CheckDlgButton( dlg, IDC_AUTODETECT, cp->cfg.autodetect ? BST_CHECKED : BST_UNCHECKED );
			CheckDlgButton( dlg, IDC_KEEPSTATUS, cp->cfg.keepprotstat ? BST_CHECKED : BST_UNCHECKED );
			SetDlgItemInt( dlg, IDC_MULTIPLE, cp->cfg.multiple, FALSE );
			SetDlgItemInt( dlg, IDC_SPOOFRANGE, cp->cfg.spoof_range / 1000, FALSE );
			SetDlgItemTextA( dlg, IDC_LOGFILE, cp->cfg.logfile );

			CheckDlgButton( dlg, IDC_REPLY4GW, cp->cfg.reply4gw ? BST_CHECKED : BST_UNCHECKED );
			CheckDlgButton( dlg, IDC_REPLY4H, cp->cfg.reply4h ? BST_CHECKED : BST_UNCHECKED );
			SetDlgItemInt( dlg, IDC_R4HINTV, cp->cfg.reply4hintv, FALSE );
			if( !cp->cfg.reply4h )
				{
				EnableWindow( GetDlgItem( dlg, IDC_R4HINTV ), FALSE );
				}//end if

			CheckDlgButton( dlg, IDC_REMOTECTRL, cp->cfg.remotectrl ? BST_CHECKED : BST_UNCHECKED );
			SetDlgItemInt( dlg, IDC_RCPORT, cp->cfg.rc_port, FALSE );
			SetDlgItemTextA( dlg, IDC_RCPSWD, cp->cfg.rc_pswd );
			if( !cp->cfg.remotectrl )
				{
				EnableWindow( GetDlgItem( dlg, IDC_RCPORT ), FALSE );
				EnableWindow( GetDlgItem( dlg, IDC_RCPSWD ), FALSE );
				}//end if

			CheckDlgButton( dlg, IDC_NOTIFYSPOOF, cp->notifyspoof ? BST_CHECKED : BST_UNCHECKED );

			for( i = 0; i < cp->cfg.prot_num; ++i )
				{
				SetProtAddrItem( listwnd, i, &cp->cfg.protaddr[i] );
				}//end for
			EnableWindow( GetDlgItem( dlg, IDC_MODIFY ), FALSE );
			EnableWindow( GetDlgItem( dlg, IDC_DELETE ), FALSE );

			CleanupProtAddr( &cp->cfg );
			}break;//end WM_INITDIALOG

		default:
			{
			return FALSE;
			}break;
		}//end switch

	return TRUE;
}//end ConfigProc

