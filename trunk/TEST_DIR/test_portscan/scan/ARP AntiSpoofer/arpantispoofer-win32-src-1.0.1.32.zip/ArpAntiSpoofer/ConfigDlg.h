#ifndef CTQY_CONFIGDLG_H
#define CTQY_CONFIGDLG_H

#include "../antispoof/config.h"
#include <windows.h>


typedef struct
{
	HINSTANCE inst;
	HICON icon;
	Config cfg;
	bool notifyspoof;
} CfgParam;


INT_PTR CALLBACK ConfigProc( HWND dlg, UINT msg, WPARAM wparam, LPARAM lparam );

#endif // CTQY_CONFIGDLG_H
