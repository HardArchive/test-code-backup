#include <tchar.h>
#include "../antispoof/antispoof.h"
#include <commctrl.h>
#include "Dialogs.h"
#include "ConfigDlg.h"

#include "resource.h"

#define TRAYICON_ID 0
#define WM_ICONCALLBACK ( WM_USER + 0x1234 )


const TCHAR kServiceName[] = TEXT("ArpAntiSpoofer");
const TCHAR kSvcDisplayName[] = TEXT("ARP BIDIRECTIONAL Anti-Spoofing service");
const TCHAR kStartSvcCmd[] = TEXT("-s");

const TCHAR kTitle[] = TEXT("ARP AntiSpoofer");
const TCHAR kWindowClass[] = TEXT("ArpAntiSpoofer_class");

const TCHAR kHomePage[] = TEXT("http://sf.net/projects/arpantispoofer/");

const TCHAR kStartFailed[] = TEXT("Failed to start it!");

const char kConfigFile[] = "arpas.ini";

UINT msg_taskbar_created = 0;

AntiSpoof *as;
char cfgfile[MAX_PATH_LEN];
bool runasservice = false;
bool notifyspoof;
HINSTANCE instance;
HMENU rootmenu;
HMENU popmenu;


static void NotifySpoof( HWND wnd, bool startspoof, IpAddr ip, const MacAddr* mac )
{	
	NOTIFYICONDATA ni=
	{
		sizeof( NOTIFYICONDATA ),
		wnd,
		TRAYICON_ID,
		NIF_ICON | NIF_TIP
	};
	int i;

	if( startspoof )
		{
		ni.hIcon = LoadIcon( instance, MAKEINTRESOURCE( IDI_WARN ) );
		_stprintf( ni.szTip, TEXT("%s (spoofing detected)"), kTitle );
		if( notifyspoof )
			{
			ni.uFlags |= NIF_INFO;
			i = 0;
			if( ip.dw != 0 )
				{
				i = _stprintf( ni.szInfo, _T("%u.%u.%u.%u "), ip.addr[0], ip.addr[1], ip.addr[2], ip.addr[3] );
				}//end if
			_stprintf( ni.szInfo + i, _T("%02X-%02X-%02X-%02X-%02X-%02X is spoofing!\r\nStart antispoofing."),
				mac->addr[0], mac->addr[1], mac->addr[2], mac->addr[3], mac->addr[4], mac->addr[5] );
			_tcscpy( ni.szInfoTitle, kTitle );
			ni.dwInfoFlags = NIIF_WARNING;
			ni.uTimeout = 5000;
			}//end if
		}
	else{
		ni.hIcon = LoadIcon( instance, MAKEINTRESOURCE( IDI_ICONSM ) );
		_tcscpy( ni.szTip, kTitle );
		}//end if

	Shell_NotifyIcon( NIM_MODIFY, &ni );
}//end NotifySpoof

static void CleanupMem(void)
{
	SetProcessWorkingSetSize( GetCurrentProcess(), -1, -1 );
}//end CleanupMem

static BOOL AddTrayIcon( HWND wnd )
{
	NOTIFYICONDATA ni =
	{
		sizeof( NOTIFYICONDATA ),
		wnd,
		TRAYICON_ID,
		NIF_ICON | NIF_MESSAGE | NIF_TIP,
		WM_ICONCALLBACK,
		LoadIcon( instance, MAKEINTRESOURCE( IDI_ICONSM ) )		
	};

	_tcscpy( ni.szTip, kTitle );

	return Shell_NotifyIcon( NIM_ADD, &ni );
}//end AddTrayIcon

static void OnDestroy( HWND wnd )
{
	NOTIFYICONDATA ni = { sizeof( NOTIFYICONDATA ), wnd, TRAYICON_ID };
	
	Shell_NotifyIcon( NIM_DELETE, &ni );

	PostQuitMessage(0);
}//end OnDestroy

static void GetServiceCmdLine( HINSTANCE inst, TCHAR cmdline[] )
{
	int i;

	cmdline[0] = '\"';
	GetModuleFileName( inst, cmdline + 1, MAX_PATH - 1 );
	i = _tcslen( cmdline );
	cmdline[i++] = '\"';
	cmdline[i++] = ' ';
	_tcscpy( cmdline + i, kStartSvcCmd );
}//end GetServiceCmdLine

static LRESULT CALLBACK WndProc( HWND wnd, UINT msg, WPARAM wparam, LPARAM lparam )
{
	switch( msg )
		{
		case WM_INITMENUPOPUP:
			{
			if( reinterpret_cast<HMENU>(wparam) == popmenu )
				{
				CheckMenuItem( popmenu, IDM_AUTODETECT, (as->get_auto() ? MF_CHECKED : MF_UNCHECKED) | MF_BYCOMMAND );
				CheckMenuItem( popmenu, IDM_ANTISPOOF, (as->get_prot_run() ? MF_CHECKED : MF_UNCHECKED) | MF_BYCOMMAND );
				CheckMenuItem( popmenu, IDM_REPLY4GW, (as->get_repl_run() ? MF_CHECKED : MF_UNCHECKED) | MF_BYCOMMAND );
				CheckMenuItem( popmenu, IDM_REPLY4HOSTS, (as->get_r4h_run() ? MF_CHECKED : MF_UNCHECKED) | MF_BYCOMMAND );
				}//end if
			}break;//end WM_INITMENUPOPUP

		case WM_COMMAND:
			{
			switch( LOWORD( wparam ) )
				{
				case IDM_AUTODETECT:
					{
					if( !as->get_auto() )
						{
						if( !as->StartDetect() )
							{
							MessageBox( wnd, kStartFailed, NULL, MB_ICONERROR );
							}//end if
						}
					else{
						as->StopDetect();
						}//end if

					CleanupMem();
					}break;//end IDM_AUTODETECT

				case IDM_ANTISPOOF:
					{
					if( !as->get_auto() ||
						MessageBox( wnd, TEXT("You'd better turn off \"Auto Detect\" first, or it will disturb your operation.\r\nDo you still want to continue?"),
							kTitle, MB_YESNO | MB_ICONWARNING | MB_DEFBUTTON2 ) == IDYES )
						{
						if( !as->get_prot_run() )
							{
							if( !as->StartProtect() )
								{
								MessageBox( wnd, kStartFailed, NULL, MB_ICONERROR );
								}//end if
							}
						else{
							as->StopProtect();
							}//end if
						}//end if

					CleanupMem();
					}break;//end IDM_ANTISPOOF

				case IDM_REPLY4GW:
					{
					if( !as->get_repl_run() )
						{
						if( !as->StartArpReply() )
							{
							MessageBox( wnd, kStartFailed, NULL, MB_ICONERROR );
							}//end if
						}
					else{
						as->StopArpReply();
						}//end if

					CleanupMem();
					}break;//end IDM_REPLY4GW

				case IDM_REPLY4HOSTS:
					{
					if( !as->get_r4h_run() )
						{
						if( !as->StartReply4Hosts() )
							{
							MessageBox( wnd, kStartFailed, NULL, MB_ICONERROR );
							}//end if
						}
					else{
						as->StopReply4Hosts();
						}//end if

					CleanupMem();
					}break;//end IDM_REPLY4HOSTS

				case IDM_ASPINTV:
					{
					IntvParam intv =
						{ LoadIcon( instance, MAKEINTRESOURCE( IDI_ICONSM ) ), as->get_prot_pktintv() };

					intv.intv = DialogBoxParam( instance, MAKEINTRESOURCE( IDD_ASPINTV ), wnd,
						AntiSpoofIntervalProc, reinterpret_cast<LPARAM>(&intv) );
					if( intv.intv > 0 )
						{
						as->set_prot_pktintv( intv.intv );
						}//end if

					CleanupMem();
					}break;//end IDM_ASPINTV

				case IDM_R4HINTV:
					{
					IntvParam intv =
						{ LoadIcon( instance, MAKEINTRESOURCE( IDI_ICONSM ) ), as->get_r4h_pktintv() };

					intv.intv = DialogBoxParam( instance, MAKEINTRESOURCE( IDD_R4HINTV ), wnd,
						Reply4HostsIntervalProc, reinterpret_cast<LPARAM>(&intv) );
					if( intv.intv > 0 )
						{
						as->set_r4h_pktintv( intv.intv );
						}//end if

					CleanupMem();
					}break;//end IDM_R4HINTV

				case IDM_VIEWLOG:
					{
					ViewLogsParam vp = { LoadIcon( instance, MAKEINTRESOURCE( IDI_ICONSM ) ), as };

					DialogBoxParam( instance, MAKEINTRESOURCE( IDD_VIEWLOGS ), wnd,
						ViewLogsProc, reinterpret_cast<LPARAM>(&vp) );

					CleanupMem();
					}break;//end IDM_VIEWLOG

				case IDM_CONFIG:
					{
					CfgParam cp = { instance, LoadIcon( instance, MAKEINTRESOURCE( IDI_ICONSM ) ), {}, notifyspoof };
					LoadConfig( cfgfile, &cp.cfg, true );
					if( DialogBoxParam( instance, MAKEINTRESOURCE( IDD_CONFIG ), NULL, ConfigProc,
							reinterpret_cast<LPARAM>(&cp) ) )
						{
						// save config
						SaveAllConfig( cfgfile, &cp.cfg, cp.notifyspoof );
						notifyspoof = cp.notifyspoof;
						}//end if
					CleanupProtAddr( &cp.cfg );

					CleanupMem();
					}break;//end IDM_CONFIG

				case IDM_AUTORUN:
					{
					TCHAR cmdline[MAX_PATH];
					SC_HANDLE scmhandle;
					SC_HANDLE svchandle;
					bool succ = false;
					bool exist = false;

					scmhandle = OpenSCManager( NULL, SERVICES_ACTIVE_DATABASE, SC_MANAGER_CREATE_SERVICE );
					if( scmhandle != NULL )
						{
						GetServiceCmdLine( instance, cmdline );
						svchandle = CreateService( scmhandle,
												   kServiceName,
												   kSvcDisplayName,
												   SERVICE_START | SERVICE_CHANGE_CONFIG,
												   SERVICE_WIN32_OWN_PROCESS | SERVICE_INTERACTIVE_PROCESS,
												   SERVICE_AUTO_START,
												   SERVICE_ERROR_IGNORE,
												   cmdline,
												   NULL, NULL, NULL, NULL, NULL );
						if( svchandle != NULL )
							{
							succ = true;
							CloseServiceHandle( svchandle );
							}
						else{
							if( GetLastError() == ERROR_SERVICE_EXISTS )
								{
								exist = true;
								}//end if
							}//end if
						CloseServiceHandle( scmhandle );
						}//end if
					if( succ )
						{
						MessageBox( wnd, TEXT("Register succeeded."), kTitle, MB_OK );
						}
					else{
						if( exist )
							{
							MessageBox( wnd, TEXT("Service already exists!"), NULL, MB_ICONWARNING );
							}
						else{
							MessageBox( wnd, TEXT("Register failed!"), NULL, MB_ICONERROR );
							}//end if
						}//end if

					CleanupMem();
					}break;//end IDM_AUTORUN

				case IDM_UNREG:
					{
					SC_HANDLE scmhandle;
					SC_HANDLE svchandle;
					bool succ = false;
					bool exist = true;

					scmhandle = OpenSCManager( NULL, SERVICES_ACTIVE_DATABASE, SC_MANAGER_CONNECT );
					if( scmhandle != NULL )
						{
						svchandle = OpenService( scmhandle, kServiceName, DELETE );
						if( svchandle != NULL )
							{
							DeleteService( svchandle );
							succ = true;
							CloseServiceHandle( svchandle );
							}
						else{
							if( GetLastError() == ERROR_SERVICE_DOES_NOT_EXIST )
								{
								exist = false;
								}//end if
							}//end if
						CloseServiceHandle( scmhandle );
						}//end if
					if( succ )
						{
						MessageBox( wnd, TEXT("Unregister succeeded."), kTitle, MB_OK );
						}
					else{
						if( exist )
							{
							MessageBox( wnd, TEXT("Unregister failed!"), NULL, MB_ICONERROR );
							}
						else{
							MessageBox( wnd, TEXT("Service does not exist!"), NULL, MB_ICONWARNING );
							}//end if
						}//end if

					CleanupMem();
					}break;//end IDM_UNREG

				case IDM_HOMEPAGE:
					{
					ShellExecute( wnd, TEXT("open"), kHomePage, NULL, NULL, SW_SHOWDEFAULT );
					}break;//end IDM_HOMEPAGE

				case IDM_ABOUT:
					{
					static const TCHAR fmt[] =
						TEXT("ARP AntiSpoofer\r\n\r\n")
						TEXT("Version:  %u.%u.%u.%u\r\n\r\n")
						TEXT("Author:   CTQY <qiyi.caitian@gmail.com>\r\n\r\n")
						TEXT("Homepage: %s\r\n\r\n")
						TEXT("Copyright (C) 2009 CTQY");

					TCHAR file[MAX_PATH];
					TCHAR buff[256];
					MSGBOXPARAMS msgbox=
						{
						sizeof(MSGBOXPARAMS),
						NULL,
						instance,
						buff,
						TEXT("About ARP AntiSpoofer"),
						MB_USERICON,
						MAKEINTRESOURCE(IDI_ICON),
						0,
						NULL,
						GetUserDefaultLangID()
						};
					HANDLE heap;
					VS_FIXEDFILEINFO *vffi;
					LPVOID data;
					DWORD size;
					UINT len;

					GetModuleFileName( NULL, file, MAX_PATH );
					size = GetFileVersionInfoSize( file, NULL );
					heap = GetProcessHeap();
					data = HeapAlloc( heap, GMEM_FIXED, size );

					GetFileVersionInfo( file, 0, size, data );
					VerQueryValue( data, TEXT("\\"), reinterpret_cast<LPVOID*>(&vffi), &len );
					_stprintf( buff, fmt, HIWORD(vffi->dwProductVersionMS), LOWORD(vffi->dwProductVersionMS),
						HIWORD(vffi->dwProductVersionLS), LOWORD(vffi->dwProductVersionLS), kHomePage );

					HeapFree( heap, 0, data );

					MessageBoxIndirect( &msgbox );

					CleanupMem();
					}break;//end IDM_ABOUT

				case IDM_EXIT:
					{
					if( !as->get_prot_run() ||
						MessageBox( wnd, TEXT("Are you sure to exit?"), kTitle, MB_YESNO | MB_ICONWARNING ) == IDYES )
						{
						OnDestroy( wnd );
						}//end if
					}break;//end IDM_EXIT

				default:
					{
					return DefWindowProc( wnd, msg, wparam, lparam );
					}break;
				}//end switch
			}break;//end WM_COMMAND

		case WM_ICONCALLBACK:
			{
			switch( lparam )
				{
				case WM_LBUTTONUP:
				case WM_RBUTTONUP:
					{
					POINT pt;

					GetCursorPos( &pt );
					SetForegroundWindow( wnd );
					TrackPopupMenu( popmenu,
									TPM_LEFTBUTTON,
									pt.x,
									pt.y,
									0,
									wnd,
									NULL );
					}break;//end WM_xBUTTONUP

				default:
					{
					return DefWindowProc( wnd, msg, wparam, lparam );
					}break;
				}//end switch
			}break;//end WM_ICONCALLBACK

		case WM_ENDSESSION:
			{
			if( wparam )
				{
				if( (lparam & ENDSESSION_LOGOFF) && runasservice )
					{
					// do nothing. a service need not to exit when logoff
					}
				else{// exit
					OnDestroy( wnd );
					}//end if
				}//end if
			}break;//end WM_ENDSESSION

		case WM_DESTROY:
			{
			OnDestroy( wnd );
			}break;//end WM_DESTROY

		case WM_CREATE:
			{
			msg_taskbar_created = RegisterWindowMessage( TEXT("TaskbarCreated") );
			AddTrayIcon( wnd );
			as->set_notifyspoof( reinterpret_cast<NotifySpoofRoutine>(NotifySpoof), wnd );
			}break;//end WM_CREATE

		default:
			{
			if( msg == msg_taskbar_created )
				{
				AddTrayIcon( wnd );
				}
			else{
				return DefWindowProc( wnd, msg, wparam, lparam );
				}//end if
			}break;
		}//end switch

	return 0;
}//end WndProc

static HWND Init(void)
{
	WNDCLASSEX wce =
	{
		sizeof(WNDCLASSEX),
		CS_NOCLOSE,
		WndProc,
		0,
		0,
		instance,
		LoadIcon( instance, MAKEINTRESOURCE( IDI_ICON ) ),
		NULL,
		(HBRUSH)COLOR_WINDOW,
		NULL,
		kWindowClass,
		LoadIcon( instance, MAKEINTRESOURCE( IDI_ICONSM ) )
	};
	INITCOMMONCONTROLSEX icce = { sizeof( icce ), ICC_INTERNET_CLASSES | ICC_LISTVIEW_CLASSES };
	WSADATA wsadata;
	HWND wnd = NULL;

	InitCommonControlsEx( &icce );

	if( WSAStartup( MAKEWORD( 2, 2 ), &wsadata ) != 0 )
		{
		MessageBox( NULL, TEXT("Could not find a usable WinSock DLL!"), NULL, MB_ICONERROR );
		return NULL;
		}//end if

	as = new AntiSpoof();

	if( !as->LoadCfg( cfgfile ) )
		{
		// show config dialog
		CfgParam cp = { instance, LoadIcon( instance, MAKEINTRESOURCE( IDI_ICONSM ) ), {}, notifyspoof };
		LoadConfig( cfgfile, &cp.cfg, true );
		LoadNotifySpoof( cfgfile, &cp.notifyspoof );
		if( DialogBoxParam( instance, MAKEINTRESOURCE( IDD_CONFIG ), NULL, ConfigProc,
				reinterpret_cast<LPARAM>(&cp) ) )
			{
			// save config
			SaveAllConfig( cfgfile, &cp.cfg, cp.notifyspoof );
			}//end if
		CleanupProtAddr( &cp.cfg );

		if( !as->LoadCfg( cfgfile ) )
			{
			return NULL;
			}//end if
		}//end if
	LoadNotifySpoof( cfgfile, &notifyspoof );

	if( !as->Start() )
		{
		return NULL;
		}//end if

	if( RegisterClassEx( &wce ) != 0 )
		{
		wnd = CreateWindow( kWindowClass, TEXT(""), WS_POPUP, 0, 0, 1, 1, NULL, NULL, instance, NULL );
		if( wnd != NULL )
			{
			// load menu
			rootmenu = LoadMenu( instance, MAKEINTRESOURCE( IDR_MENU ) );
			popmenu = GetSubMenu( rootmenu, 0 );
			}//end if
		}//end if

	return wnd;
}//end Init

static void Cleanup(void)
{
	DestroyMenu( rootmenu );
	
	delete as;

	WSACleanup();
}//end Cleanup

static bool MainProc(void)
{
	if( Init() )
		{
		MSG msg;

		CleanupMem();

		while( GetMessage( &msg, NULL, 0, 0 ) )
			{
			TranslateMessage( &msg );
			DispatchMessage( &msg );
			}//end while

		Cleanup();
		return true;
		}//end if
	return false;
}//end MainProc

static BOOL SendStatusToSCM( SERVICE_STATUS_HANDLE sshandle,
							 DWORD current_state,
							 DWORD controls_accepted,
							 DWORD win32_exitcode,
							 DWORD svc_specific_exitcode,
							 DWORD check_point,
							 DWORD wait_hint )
{
	SERVICE_STATUS svc_status =
	{
		SERVICE_WIN32_OWN_PROCESS | SERVICE_INTERACTIVE_PROCESS,
		current_state,
		controls_accepted,
		win32_exitcode,
		svc_specific_exitcode,
		check_point,
		wait_hint
	};

	return SetServiceStatus( sshandle, &svc_status );
}//end SendStatusToSCM

static DWORD WINAPI HandlerEx( DWORD dwControl, DWORD dwEventType, LPVOID lpEventData, SERVICE_STATUS_HANDLE* sshandle )
{
	switch( dwControl )
		{
		case SERVICE_CONTROL_SHUTDOWN:
			{
			SendStatusToSCM( *sshandle, SERVICE_STOP_PENDING, 0, 0, 0, 1, 2000 );
			}break;//end SERVICE_CONTROL_SHUTDOWN

		default:
			{
			SendStatusToSCM( *sshandle, SERVICE_RUNNING, SERVICE_ACCEPT_SHUTDOWN, 0, 0, 0, 0 );
			}break;
		}//end switch

	return NO_ERROR;
}//end HandlerEx

static VOID WINAPI ServiceMain( DWORD argc, LPTSTR* argv )
{
	SERVICE_STATUS_HANDLE sshandle = RegisterServiceCtrlHandlerEx( kServiceName,
										reinterpret_cast<LPHANDLER_FUNCTION_EX>(HandlerEx), &sshandle );
	if( sshandle == 0 )
		{
		return;
		}//end if

	SendStatusToSCM( sshandle, SERVICE_RUNNING, SERVICE_ACCEPT_SHUTDOWN, 0, 0, 0, 0 );

	MainProc();

	SendStatusToSCM( sshandle, SERVICE_STOPPED, 0, 0, 0, 0, 0 );
}//end ServiceMain

int APIENTRY wWinMain( HINSTANCE inst, HINSTANCE, LPWSTR cmd, int show )
{	
	LPWSTR *argv;
	int argc;
	bool succ = true;
	bool conf = false;
	int i;

	instance = inst;

	runasservice = false;
	if( cmd[0] != '\0' )
		{
		argv = CommandLineToArgvW( cmd, &argc );
		for( i = 0; i < argc; ++i )
			{
			if( !runasservice && _wcsicmp( argv[i], kStartSvcCmd ) == 0 )
				{
				runasservice = true;
				}
			else if( !conf && _wcsicmp( argv[i], L"-c" ) == 0 && i + 1 < argc )
				{
				conf = true;
				++i;
				WideCharToMultiByte( CP_ACP, 0, argv[i], -1, cfgfile, sizeof( cfgfile ), NULL, NULL );
				}
			else{
				MessageBox( NULL, TEXT("Usage: ArpAntiSpoofer [-c config]\r\n")
					TEXT("-c\tUse [config] as configuration file"), kTitle, MB_ICONWARNING );
				succ = false;
				break;
				}//end if
			}//end for
		LocalFree( argv );
		}//end if

	if( succ )
		{
		if( !conf )
			{
			GetConfigFullName( kConfigFile, cfgfile );
			}//end if

		if( runasservice )
			{
			SERVICE_TABLE_ENTRY ste[] =
				{
				TEXT(""), ServiceMain,
				NULL, NULL
				};
			StartServiceCtrlDispatcher( ste );
			}
		else{
			if( !MainProc() )
				{
				MessageBox( NULL, TEXT("Start failed!"), NULL, MB_ICONERROR );
				}//end if
			}//end if
		}//end if

	return 0;
}//end _tWinMain
