//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by ArpAntiSpoofer.rc
//
#define IDI_ICON                        101
#define IDI_ICONSM                      102
#define IDI_WARN                        103
#define IDR_MENU                        104
#define IDD_ASPINTV                     105
#define IDD_R4HINTV                     106
#define IDD_VIEWLOGS                    107
#define IDD_CONFIG                      108
#define IDD_CHOOSEADAPTER               109
#define IDD_PROTADDR                    110
#define IDD_CHOOSEGWMAC                 111
#define IDC_ASPINTV                     1001
#define IDC_R4HINTV                     1002
#define IDC_DAYS                        1003
#define IDC_LOGS                        1004
#define IDC_ADAPTER                     1005
#define IDC_CHGADAPTER                  1006
#define IDC_LOCALIP                     1007
#define IDC_EDIT2                       1008
#define IDC_LOCALMAC                    1008
#define IDC_BINDGW                      1009
#define IDC_SUBMASK                     1010
#define IDC_GWIP                        1011
#define IDC_GWMAC                       1012
#define IDC_NETMASK                     1012
#define IDC_AUTODETECT                  1013
#define IDC_NETMASK2                    1013
#define IDC_KEEPSTATUS                  1014
#define IDC_MULTIPLE                    1015
#define IDC_MACADDR                     1015
#define IDC_SPOOFRANGE                  1016
#define IDC_REPLY4GW                    1017
#define IDC_REPLY4H                  1018
#define IDC_REMOTECTRL                  1020
#define IDC_RCPORT                      1021
#define IDC_RCPSWD                      1022
#define IDC_LOGFILE                     1023
#define IDC_PROTHOSTS                   1024
#define IDC_ADD                         1025
#define IDC_MODIFY                      1026
#define IDC_DELETE                      1027
#define IDC_NOTIFYSPOOF                 1028
#define IDC_ADAPTERLIST                 1029
#define IDC_IPADDR                      1030
#define IDC_ASHOST                      1031
#define IDC_ASGATEWAY                   1032
#define IDC_GETGWMAC                    1033
#define IDC_NETINFO                     1034
#define IDC_CGMTIMEOUT                  1035
#define IDC_GWADDRLIST                  1036
#define IDC_DETECT                      1037
#define IDM_AUTODETECT                  40001
#define IDM_ANTISPOOF                   40002
#define IDM_REPLY4GW                    40003
#define IDM_REPLY4HOSTS                 40004
#define IDM_ASPINTV                     40005
#define IDM_R4HINTV                     40006
#define IDM_CONFIG                      40007
#define IDM_EXIT                        40008
#define IDM_VIEWLOG                     40009
#define IDM_AUTORUN                     40010
#define IDM_UNREG                       40011
#define IDM_ABOUT                       40012
#define IDM_HOMEPAGE                    40013

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        112
#define _APS_NEXT_COMMAND_VALUE         40014
#define _APS_NEXT_CONTROL_VALUE         1038
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
