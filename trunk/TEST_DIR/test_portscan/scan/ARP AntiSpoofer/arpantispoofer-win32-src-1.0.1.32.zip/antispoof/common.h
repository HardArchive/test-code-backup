#ifndef CTQY_COMMON_H
#define CTQY_COMMON_H

#include "arpdef.h"
#include "config.h"

inline bool iszeromac( const MacAddr* mac )
{
	return( *reinterpret_cast<const int*>(mac->addr) == 0 && *reinterpret_cast<const short*>(mac->addr + sizeof(int)) == 0 );
}//end iszeromac

int GetMacForIp( const char adapter[], // pcap adapter
				 unsigned long netmask,
				 const AddrPair* local, // locap ip and mac
				 IpAddr gatewayip,
				 int timeout, // timeout in second
				 MacAddr gwmac[], // gateway mac
				 int maxnum ); // man length of gwmac

bool CheckAbuse( const Config* cfg );
bool CheckAbuse_Gateway( const Config* cfg );
bool CheckAbuse_ProtHosts( const Config* cfg );

#endif // CTQY_COMMON_H
