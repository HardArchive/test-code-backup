#ifndef CTQY_ANTISPOOF_H
#define CTQY_ANTISPOOF_H

#include "protector.h"
#include "arpreplier.h"
#include "reply4hosts.h"
#include "config.h"


typedef void (*NotifySpoofRoutine)( void* arg, bool startspoof, IpAddr ip, const MacAddr* mac );

class AntiSpoof
{
public:
	AntiSpoof(void);
	bool Start(void); // auto start detect, arp replier and reply4hosts if needed
	bool StartDetect(void); // start detection, this may stop protect if !keepprotstat_
	void StopDetect(void); // stop detection, this may stop protect if !keepprotstat_
	bool StartProtect(void); // manually start protect
	void StopProtect(void); // manually stop protect
	bool StartArpReply(void); // start arp replier
	void StopArpReply(void);
	bool StartReply4Hosts(void);
	void StopReply4Hosts(void);
	bool StartRemoteCtrl(void);
	void StopRemoteCtrl(void);
	int ExecCmd( char cmd[], bool remctrl, char reply[], int replylen, bool* logoff );
	bool LoadCfg( const char cfgfile[] );
	int show_log( time_t tmbefore, char log[], int loglen ) const;
	void set_notifyspoof( NotifySpoofRoutine notifyspoof, void* arg ) { notifyspoof_ = notifyspoof; nsarg_ = arg; }
	bool get_protector_run_state(void) const { return prot_.get_run(); }
	bool get_auto(void) const { return auto_; }
	bool get_prot_run(void) const { return prot_.get_run(); }
	bool get_repl_run(void) const { return repl_.get_run(); }
	bool get_r4h_run(void) const { return r4h_.get_run(); }
	int get_prot_pktintv(void) const { return prot_.get_pktintv(); }
	void set_prot_pktintv( int pktintv ) { prot_.set_pktintv( pktintv ); }
	int get_r4h_pktintv(void) const { return r4h_.get_pktintv(); }
	void set_r4h_pktintv( int pktintv ) { cfg_.reply4hintv = pktintv; r4h_.set_pktintv( pktintv ); }
	~AntiSpoof();

private:
	bool start_prot(void);
	bool netgetline( char buff[], int bufflen );
	void log_spoof( bool startspoof, IpAddr ip, const MacAddr* mac ) const;
	static CALL_BACK detect_routine( void* thisptr );
	static CALL_BACK rc_routine( void* thisptr );

	Protector prot_;
	ArpReplier repl_;
	Reply4Hosts r4h_;
	Config cfg_;

	bool auto_; // true: start detection and start protector automatically when spoofing is detected;
				// false: stop spoofing detection, start protector manually
	pcap_t *caphandle_;
	Thread_h thread_;

	bool rc_run_;
	Thread_h rc_thread_;
	SOCKET listen_sock_;
	SOCKET session_sock_;

	NotifySpoofRoutine notifyspoof_;
	const void *nsarg_;
};

#endif // CTQY_ANTISPOOF_H
