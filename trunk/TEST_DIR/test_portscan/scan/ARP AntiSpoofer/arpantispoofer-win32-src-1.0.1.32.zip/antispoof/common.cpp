#include "common.h"
#include "platform.h"
#include <stdio.h>
#include <string.h>

// return the number of gotten MAC
int GetMacForIp( const char adapter[], unsigned long netmask, const AddrPair* local, IpAddr gatewayip,
				 int timeout, MacAddr gwmac[], int maxnum )
{
	char errbuf[PCAP_ERRBUF_SIZE];
	char filter[256];
	struct bpf_program fcode;
	EtherPkt reqpkt;
	pcap_t *caphandle;
	struct pcap_pkthdr *pkt_header;
	const EtherPkt *pkt;
	bool succ = false;
	int num = 0;
	int i;

	caphandle = pcap_open_live( adapter, 65535, 0, 1, errbuf );
	if( caphandle != NULL )
		{
		// compile filter
		// dst mac = unicast, arp reply, sender ip = gateway ip, target ip = local ip
		sprintf( filter, "ether[0] & 1 = 0 && arp[2:2] = 0x0800 && arp[6:2] = %d && arp[14:4] = %#x && arp[24:4] = %#x",
			ARPREPLY, ntohl( gatewayip.dw ), ntohl( local->ip.dw ) );
		if( pcap_compile( caphandle, &fcode, filter, 1, netmask ) >= 0 )
			{
			// apply filter
			if( pcap_setfilter( caphandle, &fcode ) >= 0 )
				{
				succ = true;
				}//end if
			pcap_freecode( &fcode );
			}//end if

		if( succ )
			{
			memset( reqpkt.dstaddr.addr, 0xff, sizeof( reqpkt.dstaddr.addr ) );
			memcpy( reqpkt.srcaddr.addr, local->mac.addr, sizeof( reqpkt.srcaddr.addr ) );
			reqpkt.ethertype = htons( ARP_TYPE );

			reqpkt.arppkt.hwtype = htons( ETHER_HWTYPE );
			reqpkt.arppkt.protype = htons( IP_PROTYPE );
			reqpkt.arppkt.hwaddrsize = sizeof( MacAddr );
			reqpkt.arppkt.proaddrsize = sizeof( IpAddr );
			reqpkt.arppkt.opcode = htons( ARPREQUEST );
			reqpkt.arppkt.sendermac = local->mac;
			reqpkt.arppkt.senderip = local->ip;
			memset( reqpkt.arppkt.targetmac.addr, 0, sizeof( reqpkt.arppkt.targetmac.addr ) );
			reqpkt.arppkt.targetip = gatewayip;

			memset( reqpkt.padding, 0, sizeof( reqpkt.padding ) );

			pcap_sendpacket( caphandle, reinterpret_cast<u_char*>(&reqpkt), sizeof( reqpkt ) );

			MsSleep( timeout * 1000 );
			pcap_setnonblock( caphandle, 1, NULL );
			while( 1 == pcap_next_ex( caphandle, &pkt_header, reinterpret_cast<const u_char**>(&pkt) ) )
				{
				for( i = 0; i < num; ++i )
					{
					if( memcmp( pkt->arppkt.sendermac.addr, gwmac[i].addr, sizeof( MacAddr ) ) == 0 )
						{
						break;
						}//end if
					}//end for
				if( i == num )
					{
					gwmac[num++] = pkt->arppkt.sendermac;
					}//end if
				}//end while
			}//end if

		pcap_close( caphandle );
		}//end if

	return num;
}//end GetMacForIp

bool CheckAbuse_Gateway( const Config* cfg )
{
	return( memcmp( cfg->local.mac.addr, cfg->gateway.mac.addr, sizeof( cfg->local.mac.addr ) ) == 0
		&& cfg->local.ip.dw != cfg->gateway.ip.dw );
}//end CheckAbuse_Gateway

bool CheckAbuse_ProtHosts( const Config* cfg )
{
	int i;

	for( i = 0; i < cfg->prot_num; ++i )
		{
		if( memcmp( cfg->local.mac.addr, cfg->protaddr[i].mac.addr, sizeof( cfg->local.mac.addr ) ) == 0
			&& cfg->local.ip.dw != cfg->protaddr[i].ip.dw
			&& ( cfg->protaddr[i].type & PROT_TYPE_GATEWAY ) )
			{
			return true;
			}//end if
		}//end for

	return false;
}//end CheckAbuse_ProtHosts

bool CheckAbuse( const Config* cfg )
{
	return( CheckAbuse_Gateway( cfg ) || CheckAbuse_ProtHosts( cfg ) );
}//end CheckAbuse
