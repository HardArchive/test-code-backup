#ifndef CTQY_CONFIG_H
#define CTQY_CONFIG_H

#include "arpdef.h"
#include "platform.h"


#define MAX_ADAPTER_NAME 128
#define MAX_PSWD_LEN 64
#define MAX_PATH_LEN 260


typedef struct
{
	char adapter[MAX_ADAPTER_NAME];
	IpAddr netmask;
	bool bindgateway; // bind the mac and ip of gateway

	bool autodetect; // auto start detection
	bool keepprotstat; // keep protect status or not when start/stop detection
	int multiple; // anti spoof frequency / spoof frequency
	int spoof_range; // period of validity of a spoofing packet, in ms

	bool reply4gw; // reply for gateway

	bool reply4h;
	int reply4hintv; // in millisecond

	bool remotectrl;
	unsigned short rc_port; // host byte order
	char rc_pswd[MAX_PSWD_LEN];

	char logfile[MAX_PATH_LEN];

	AddrPair local;
	AddrPair gateway;
	int prot_num;
	ProtAddr *protaddr;
} Config;

bool LoadConfig( const char file[], Config* cfg, bool loadprotaddr );
bool LoadNotifySpoof( const char file[], bool* notifyspoof );
void CleanupProtAddr( Config *cfg );
void SaveAllConfig( const char file[], const Config* cfg, bool notifyspoof );


#endif // CTQY_CONFIG_H
