#ifndef CTQY_ARPDEF_H
#define CTQY_ARPDEF_H

#ifdef WIN32
#include <Winsock2.h>
#else // Linux
#include <netinet/in.h>
#endif // WIN32

#pragma pack(push)
#pragma pack(2)

// mac address
typedef struct
{
	unsigned char addr[6];
} MacAddr;

typedef struct
{
	union
	{
		unsigned char addr[4];
		unsigned long dw;
		struct in_addr ia;
	};
} IpAddr;

// arp packet for ipv4
typedef struct
{
	unsigned short hwtype;
	unsigned short protype;
	unsigned char hwaddrsize;
	unsigned char proaddrsize;
	unsigned short opcode;
	MacAddr sendermac;
	IpAddr senderip;
	MacAddr targetmac;
	IpAddr targetip;
} ArpPkt;

// constants for hardware type
const unsigned short ETHER_HWTYPE = 0x0001;

// constants for protocal type
const unsigned short IP_PROTYPE = 0x0800;

// constants for opcode
const unsigned short ARPREQUEST = 0x0001;
const unsigned short ARPREPLY = 0x0002;

// ethernet pack
typedef struct
{
	MacAddr dstaddr;
	MacAddr srcaddr;
	unsigned short ethertype;
	ArpPkt arppkt;
	char padding[18];
} EtherPkt;

// constants for ethertype
const unsigned short ARP_TYPE = 0x0806;


typedef struct
{
	MacAddr mac;
	IpAddr ip;
} AddrPair;

typedef struct
{
	MacAddr mac;
	IpAddr ip;
	unsigned short type;
} ProtAddr;

#define PROT_TYPE_HOST		0x1
#define PROT_TYPE_GATEWAY	0x2

#pragma pack(pop)

#endif // CTQY_ARPDEF_H
