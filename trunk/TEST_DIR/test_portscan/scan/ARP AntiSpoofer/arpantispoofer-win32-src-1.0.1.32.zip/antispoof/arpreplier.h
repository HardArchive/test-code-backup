#ifndef CTQY_ARPREPLIER_H
#define CTQY_ARPREPLIER_H

#include "arpdef.h"
#include <pcap.h>
#include "platform.h"

class ArpReplier
{
public:
	ArpReplier(void);
	bool Start( const char adapter[], unsigned long netmask, const AddrPair* local, const AddrPair* gateway );
	void Stop(void);
	bool get_run(void) const { return run_; }
	~ArpReplier();

private:
	bool run_;

	AddrPair local_;
	AddrPair gateway_;

	pcap_t *caphandle_;
	Thread_h thread_;

	static CALL_BACK reply_routine( void* thisptr );
};


#endif // CTQY_ARPREPLIER_H
