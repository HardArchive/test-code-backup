#ifndef CTQY_PROTECT_H
#define CTQY_PROTECT_H

#include "arpdef.h"
#include <pcap.h>
#include "platform.h"


#define MAX_PKT_INTV 1000
#define MIN_PKT_INTV 10


class Protector
{
public:
	Protector(void);
	bool Start( const char* adapter, const AddrPair* local, const AddrPair* gateway,
				int prot_num, const ProtAddr protaddr[] );
	void set_pktintv( int pktintv );
	int get_pktintv(void) const { return pktintv_; }
	bool get_run(void) const { return run_; }
	void Stop(void);
	~Protector();

private:
	bool run_;

	AddrPair local_;
	AddrPair gateway_;
	int prot_num_;
	const ProtAddr *protaddr_;

	pcap_t *caphandle_;
	Thread_h thread_;
	volatile int pktintv_; // in ms

	static CALL_BACK prot_routine( void* thisptr );
};


#endif // CTQY_PROTECT_H
