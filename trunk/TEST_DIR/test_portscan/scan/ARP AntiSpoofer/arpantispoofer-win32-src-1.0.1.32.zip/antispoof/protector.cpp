#include "protector.h"
#include <string.h>

const char kPadTag[] = "CTQY's AntiSpoofer";

Protector::Protector(void) : run_( false ), prot_num_( 0 ), protaddr_( NULL ),
						 caphandle_( NULL ), thread_( NULL ), pktintv_( MAX_PKT_INTV )
{
}//end Protector::Protector

bool Protector::Start( const char* adapter, const AddrPair* local, const AddrPair* gateway,
		int prot_num, const ProtAddr protaddr[] )
{
	char errbuf[PCAP_ERRBUF_SIZE];
	bool succ = false;

	if( run_ )
		{
		return true;
		}//end if

	local_ = *local;
	gateway_ = *gateway;

	caphandle_ = pcap_open_live( adapter, 0, 0, 1, errbuf );
	if( caphandle_ != NULL )
		{
		prot_num_ = prot_num;
		protaddr_ = new ProtAddr[prot_num];
		memcpy( const_cast<ProtAddr*>(protaddr_), protaddr, sizeof( protaddr[0] ) * prot_num );

		run_ = true;
		// start the thread
		thread_ = ThreadCreate( prot_routine, this );
		if( thread_ != Thread_h(NULL) )
			{
			succ = true;
			}
		else{
			Stop();
			}//end if
		}//end if

	return succ;
}//end Protector::Start

void Protector::set_pktintv( int pktintv )
{
	if( pktintv > MAX_PKT_INTV )
		{
		pktintv = MAX_PKT_INTV;
		}
	else if( pktintv < MIN_PKT_INTV )
		{
		pktintv = MIN_PKT_INTV;
		}//end if

	pktintv_ = pktintv;
}//end Protector::set_pktintv

void Protector::Stop(void)
{
	if( run_ )
		{
		run_ = false;

		if( thread_ != Thread_h(NULL) )
			{
			// waiting for the thread
			ThreadWaitForExit( thread_ );
			ThreadCloseHandle( thread_ );
			thread_ = NULL;
			}//end if

		delete [] protaddr_;
		protaddr_ = NULL;
		prot_num_ = 0;

		if( caphandle_ != NULL )
			{
			pcap_close( caphandle_ );
			caphandle_ = NULL;
			}//end if
		}//end if
}//end Protector::Stop

CALL_BACK Protector::prot_routine( void* thisptr )
{
	Protector const *prot = reinterpret_cast<Protector*>(thisptr);
	EtherPkt pkt;
	int i;

	pkt.srcaddr = prot->local_.mac;
	pkt.ethertype = htons( ARP_TYPE );

	pkt.arppkt.hwtype = htons( ETHER_HWTYPE );
	pkt.arppkt.protype = htons( IP_PROTYPE );
	pkt.arppkt.hwaddrsize = sizeof( MacAddr );
	pkt.arppkt.proaddrsize = sizeof( IpAddr );
	pkt.arppkt.opcode = htons( ARPREPLY );

	memset( pkt.padding, 0, sizeof( pkt.padding ) );
	memcpy( pkt.padding, kPadTag, min( sizeof( pkt.padding ), sizeof( kPadTag ) ) );

	while( prot->run_ )
		{
		// anti-spoofing

		// protect hosts from spoofing
		pkt.arppkt.sendermac = prot->gateway_.mac;
		pkt.arppkt.senderip = prot->gateway_.ip;
		for( i = 0; i < prot->prot_num_; ++i )
			{
			if( prot->protaddr_[i].type & PROT_TYPE_HOST )
				{
				pkt.dstaddr = prot->protaddr_[i].mac;
				pkt.arppkt.targetmac = prot->protaddr_[i].mac;
				pkt.arppkt.targetip = prot->protaddr_[i].ip;
				pcap_sendpacket( prot->caphandle_, reinterpret_cast<u_char*>(&pkt), sizeof( pkt ) );
				}//end if
			}//end for

		// protect the gateway from spoofing
		pkt.dstaddr = prot->gateway_.mac;
		pkt.arppkt.targetmac = prot->gateway_.mac;
		pkt.arppkt.targetip = prot->gateway_.ip;
		for( i = 0; i < prot->prot_num_; ++i )
			{
			if( prot->protaddr_[i].type & PROT_TYPE_GATEWAY )
				{
				pkt.arppkt.sendermac = prot->protaddr_[i].mac;
				pkt.arppkt.senderip = prot->protaddr_[i].ip;
				pcap_sendpacket( prot->caphandle_, reinterpret_cast<u_char*>(&pkt), sizeof( pkt ) );
				}//end if
			}//end for

		MsSleep( prot->pktintv_ );
		}//end while

	return 0;
}//end Protector::prot_routine

Protector::~Protector()
{
	Stop();
}//end Protector::~Protector
