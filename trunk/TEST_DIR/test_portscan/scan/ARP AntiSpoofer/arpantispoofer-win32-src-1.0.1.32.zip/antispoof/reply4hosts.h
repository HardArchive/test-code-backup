#ifndef CTQY_REPLY4HOSTS_H
#define CTQY_REPLY4HOSTS_H

#include "arpdef.h"
#include <pcap.h>
#include "platform.h"


class Reply4Hosts
{
public:
	Reply4Hosts(void);
	bool Start( const char* adapter, const AddrPair* local, const AddrPair* gateway,
				int prot_num, const ProtAddr protaddr[], int pktintv );
	void Stop(void);
	bool get_run(void) const { return run_; }
	void set_pktintv( int pktintv );
	int get_pktintv(void) const { return pktintv_; }
	~Reply4Hosts();

private:
	bool run_;

	AddrPair local_;
	AddrPair gateway_;
	int prot_num_;
	const ProtAddr *protaddr_;

	pcap_t *caphandle_;
	Thread_h thread_;
	volatile int pktintv_; // in millisecond

	static CALL_BACK reply_routine( void* thisptr );
};


#endif // CTQY_REPLY4HOSTS_H
