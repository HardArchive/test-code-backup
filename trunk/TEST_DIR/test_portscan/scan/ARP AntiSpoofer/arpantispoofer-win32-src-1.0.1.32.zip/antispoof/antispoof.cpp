#include "antispoof.h"
#include "platform.h"
#include <stdlib.h>
#include <string.h>
#include <sys/timeb.h>
#include <sys/stat.h>

#define DETECT_TIMESLICE 50
#define DETECT_TIMECOUNT 2000
#define SPOOF_TIMERANGE 60000

#define MAX_CMD_NUM 32

AntiSpoof::AntiSpoof(void) : cfg_(), auto_( false ), caphandle_( NULL ), thread_( NULL ), rc_run_( false), rc_thread_( NULL ),
	listen_sock_( INVALID_SOCKET ), session_sock_( INVALID_SOCKET ), notifyspoof_( NULL ), nsarg_( NULL )
{
	memset( &cfg_, 0, sizeof( cfg_ ) );
}//end AntiSpoof::AntiSpoof

bool AntiSpoof::Start(void)
{
	bool succ = true;

	if( cfg_.reply4gw )
		{
		succ = StartArpReply() && succ;
		}//end if
	if( cfg_.reply4h )
		{
		succ = StartReply4Hosts() && succ;
		}
	else{
		r4h_.set_pktintv( cfg_.reply4hintv );
		}//end if
	if( cfg_.autodetect )
		{
		succ = StartDetect() && succ;
		}//end if
	if( cfg_.remotectrl )
		{
		succ = StartRemoteCtrl() && succ;
		}//end if
	return succ;
}//end AntiSpoof::Start

// return a - b
static int TimeDelta( struct timeb* a, struct timeb* b )
{
	return static_cast<int>( ( a->time - b->time ) * 1000 + ( a->millitm - b->millitm ) );
}//end TimeDelta

void AntiSpoof::log_spoof( bool startspoof, IpAddr ip, const MacAddr* mac ) const
{
	FILE *f;
	char *str;
	time_t t;

	if( cfg_.logfile[0] == '\0' )
		{
		return;
		}//end if

	time( &t );

	f = fopen( cfg_.logfile, "ab" );
	if( f != NULL )
		{
		str = ctime( &t );
		*strchr( str, '\n' ) = '\0';
		fprintf( f, "%s\r\n\t", str );

		if( startspoof )
			{
			if( ip.dw != 0 )
				{
				fprintf( f, "%u.%u.%u.%u ", ip.addr[0], ip.addr[1], ip.addr[2], ip.addr[3] );
				}//end if
			fprintf( f, "%02X-%02X-%02X-%02X-%02X-%02X is spoofing!\r\n", mac->addr[0],
				mac->addr[1], mac->addr[2], mac->addr[3], mac->addr[4], mac->addr[5] );
			}
		else{
			fprintf( f, "No more spoofing now.\r\n" );
			}//end if

		fclose( f );
		}//end if
}//end AntiSpoof::log_spoof

int AntiSpoof::show_log( time_t tmbefore, char log[], int loglen ) const
{
	struct stat st;
	struct tm tm;
	FILE *f;
	char *buff;
	char *p;
	int len = 0;

	if( stat( cfg_.logfile, &st ) == 0 )
		{
		f = fopen( cfg_.logfile, "rb" );
		if( f != NULL )
			{
			buff = new char[st.st_size + 1];
			fread( buff, st.st_size, 1, f );
			buff[st.st_size] = '\0';
			fclose( f );

			for( p = buff - 1; p != NULL; p = strchr( p, '\n' ) )
				{
				++p;
				if( strtotm( p, &tm ) && tmbefore <= mktime( &tm ) )
					{
					break;
					}//end if
				}//end for

			if( p != NULL )
				{
				len = min( loglen, buff + st.st_size - p );
				memcpy( log, p, len );
				}//end if

			delete [] buff;
			}//end if
		}//end if

	return len;
}//end Antispoof::show_log

CALL_BACK AntiSpoof::detect_routine( void* thisptr )
{
	AntiSpoof* const as = reinterpret_cast<AntiSpoof*>(thisptr);
	struct pcap_pkthdr *pkt_header;
	const EtherPkt *pkt;
	IpAddr ip;
	long pktcount = 0; // packet count when tick doesn't change
	struct timeb lasttick; // last time tick
	struct timeb tick;
	struct timeb tmp;
	int delta;
	int ret;

	lasttick.time = 0;
	lasttick.millitm = 0;
	tick.time = 0;
	tick.millitm = 0;

	pcap_setnonblock( as->caphandle_, 1, NULL );
	while( as->auto_ )
		{
		ret = pcap_next_ex( as->caphandle_, &pkt_header, reinterpret_cast<const u_char**>(&pkt) );
		if( ret == 1 )
			{
			ftime( &tick );
			if( !as->prot_.get_run() )
				{
				as->prot_.set_pktintv( MAX_PKT_INTV );
				as->start_prot();
				ip = MacToIp( &pkt->srcaddr, 1, &as->cfg_.gateway.ip );
				as->log_spoof( true, ip, &pkt->srcaddr );
				if( as->notifyspoof_ != NULL )
					{
					as->notifyspoof_( const_cast<void*>(as->nsarg_), true, ip, &pkt->srcaddr );
					}//end if
				}//end if

			++pktcount;
			if( lasttick.time > 0 )
				{
				delta = TimeDelta( &tick, &lasttick );
				if( delta >= DETECT_TIMECOUNT )
					{
					as->prot_.set_pktintv( delta / ( pktcount * as->cfg_.multiple ) );
					pktcount = 0;
					lasttick = tick;
					}//end if
				}
			else{
				lasttick = tick;
				}//end if
			}
		else if( ret == 0 )
			{// timeout
			MsSleep( DETECT_TIMESLICE );

			if( as->prot_.get_run() )
				{
				ftime( &tmp );
				if( TimeDelta( &tmp, &tick ) > as->cfg_.spoof_range )
					{
					as->prot_.Stop();
					ip.dw = 0;
					as->log_spoof( false, ip, NULL );
					if( as->notifyspoof_ != NULL )
						{
						as->notifyspoof_( const_cast<void*>(as->nsarg_), false, ip, NULL );
						}//end if
					}//end if
				}//end if
			}
		else{
			break;
			}//end if
		}//end while

	return 0;
}//end AntiSpoof::detect_routine

bool AntiSpoof::StartDetect(void)
{
	char errbuf[PCAP_ERRBUF_SIZE];
	char filter[256];
	struct bpf_program fcode;
	bool succ = false;

	if( auto_ )
		{
		return true;
		}//end if

	if( !cfg_.keepprotstat )
		{
		prot_.Stop();
		}//end if

	if( cfg_.bindgateway )
		{
		ArpBind( cfg_.gateway.ip, &cfg_.gateway.mac );
		}//end if

	caphandle_ = pcap_open_live( cfg_.adapter, 65535, 0, 1, errbuf );
	if( caphandle_ != NULL )
		{
		auto_ = true;
		// compile filter
		// dst mac = broadcast or local mac, arp, sender ip = gateway ip, sender mac != gateway mac
		sprintf( filter, "(ether dst %02x:%02x:%02x:%02x:%02x:%02x || ether[0] & 1 != 0) "
			"&& arp[2:2] = 0x0800 && arp[14:4] = %#x && (arp[8:2] != %#x || arp[10:4] != %#x )",
			cfg_.local.mac.addr[0], cfg_.local.mac.addr[1], cfg_.local.mac.addr[2], cfg_.local.mac.addr[3],
			cfg_.local.mac.addr[4], cfg_.local.mac.addr[5], ntohl( cfg_.gateway.ip.dw ),
			ntohs( *reinterpret_cast<const u_short*>(&cfg_.gateway.mac.addr[0]) ),
			ntohl( *reinterpret_cast<const u_long*>(&cfg_.gateway.mac.addr[sizeof(u_short)]) ) );
		if( pcap_compile( caphandle_, &fcode, filter, 1, cfg_.netmask.dw ) >= 0 )
			{
			// apply filter
			if( pcap_setfilter( caphandle_, &fcode ) >= 0 )
				{
				// start the thread
				thread_ = ThreadCreate( detect_routine, this );
				if( thread_ != Thread_h(NULL) )
					{
					succ = true;
					}//end if
				}//end if
			pcap_freecode( &fcode );
			}//end if

		if( !succ )
			{
			StopDetect();
			}//end if
		}//end if

	return succ;
}//end AntiSpoof::StartDetect

void AntiSpoof::StopDetect(void)
{
	if( auto_ )
		{
		auto_ = false;

		if( thread_ != Thread_h(NULL) )
			{
			// waiting for the thread
			ThreadWaitForExit( thread_ );
			ThreadCloseHandle( thread_ );
			thread_ = NULL;
			}//end if

		if( caphandle_ != NULL )
			{
			pcap_close( caphandle_ );
			caphandle_ = NULL;
			}//end if

		if( !cfg_.keepprotstat )
			{
			prot_.Stop();
			}//end if
		}//end if
}//end AntiSpoof::StopDetect

bool AntiSpoof::StartProtect(void)
{
	return start_prot();
}//end AntiSpoof::StartProtect

void AntiSpoof::StopProtect(void)
{
	prot_.Stop();
}//end AntiSpoof::StopProtect

bool AntiSpoof::StartArpReply(void)
{
	return repl_.Start( cfg_.adapter, cfg_.netmask.dw, &cfg_.local, &cfg_.gateway );
}//end AntiSpoof::StartArpReply

void AntiSpoof::StopArpReply(void)
{
	repl_.Stop();
}//end AntiSpoof::StopArpReply

bool AntiSpoof::StartReply4Hosts(void)
{
	return r4h_.Start( cfg_.adapter, &cfg_.local, &cfg_.gateway, cfg_.prot_num, cfg_.protaddr, cfg_.reply4hintv );
}//end AntiSpoof::StartReply4Hosts

void AntiSpoof::StopReply4Hosts(void)
{
	r4h_.Stop();
}//end AntiSpoof::StopReply4Hosts

bool AntiSpoof::netgetline( char buff[], int bufflen )
{
	fd_set fds;
	struct timeval timeout;
	int nfds;
	int size;
	int res;
	int i, j;

	FD_ZERO( &fds );
	nfds = session_sock_ + 1;
	size = 0;
	do	{
		do	{
			FD_SET( session_sock_, &fds );
			timeout.tv_sec = 1;
			timeout.tv_usec = 0;
			} while( select( nfds, &fds, NULL, NULL, &timeout ) == 0 && rc_run_ );
		if( !rc_run_ )
			{
			return false;
			}//end if
		res = recv( session_sock_, buff + size, bufflen - size, 0 );
		if( res == 0 || res == SOCKET_ERROR )
			{
			return false;
			}//end if
		size += res;
		} while( size < bufflen && buff[size-1] != '\r' && buff[size-1] != '\n' );
	// remove backspace
	for( i = j = 0; i < size; buff[j++] = buff[i++] )
		{
		while( buff[i] == '\b' && i < size )
			{
			++i;
			--j;
			}//end if
		if( j < 0 )
			{
			j = 0;
			}//end if
		if( i >= size )
			{
			break;
			}//end if
		}//end for
	size = j;
	if( size < bufflen )
		{
		buff[size] = '\0';
		}
	else{
		buff[bufflen - 1] = '\0';
		}//end if

	return true;
}//end AntiSpoof::netgetline

CALL_BACK AntiSpoof::rc_routine( void* thisptr )
{
	static const char kGreeting[] = "This is ARP AntiSpoofer! Welcome!\r\n";
	static const int kBuffSize = 65536;
	AntiSpoof* const as = reinterpret_cast<AntiSpoof*>(thisptr);
	char inbuff[256];
	char *outbuff = new char[kBuffSize];
	fd_set fds;
	struct timeval timeout;
	int nfds;
	sockaddr_in addr;
	socklen_t size;
	bool logoff;

	while( as->rc_run_ )
		{
		FD_ZERO( &fds );
		nfds = as->listen_sock_ + 1;

		do	{
			FD_SET( as->listen_sock_, &fds );
			timeout.tv_sec = 1;
			timeout.tv_usec = 0;
			} while( select( nfds, &fds, NULL, NULL, &timeout ) == 0 && as->rc_run_ );
		if( !as->rc_run_ )
			{
			return 0;
			}//end if

		size = sizeof( addr );
		as->session_sock_ = accept( as->listen_sock_, reinterpret_cast<struct sockaddr*>(&addr), &size );
		if( as->session_sock_ != INVALID_SOCKET )
			{
			// read pswd
			if( as->netgetline( inbuff, sizeof( inbuff ) ) )
				{
				for( size = strlen( inbuff ) - 1;
					 size >= 0 && ( inbuff[size] == '\r' || inbuff[size] == '\n' );
					 --size );//end for
				inbuff[size+1] = '\0';
				if( strcmp( inbuff, as->cfg_.rc_pswd ) == 0 )
					{
					send( as->session_sock_, kGreeting, sizeof( kGreeting ), 0 );
					logoff = false;
					do	{
						outbuff[0] = '>';
						send( as->session_sock_, outbuff, 1, 0 );
						if( !as->netgetline( inbuff, sizeof( inbuff ) ) )
							{
							break;
							}//end if
						size = as->ExecCmd( inbuff, true, outbuff, kBuffSize, &logoff );
						send( as->session_sock_, outbuff, size, 0 );
						} while( !logoff );
					}//end if
				}//end if
			shutdown( as->session_sock_, SD_BOTH );
			closesocket( as->session_sock_ );
			as->session_sock_ = INVALID_SOCKET;
			}//end if
		}//end while

	delete [] outbuff;
	return 0;
}//end AntiSpoof::rc_routine

bool AntiSpoof::StartRemoteCtrl(void)
{
	sockaddr_in addr;
	bool succ = false;
	int b;

	if( rc_run_ )
		{
		return true;
		}//end if

	listen_sock_ = socket( AF_INET, SOCK_STREAM, IPPROTO_TCP );
	if( listen_sock_ != INVALID_SOCKET )
		{
		rc_run_ = true;

		b = 1;
		setsockopt( listen_sock_, SOL_SOCKET, SO_REUSEADDR, reinterpret_cast<char*>(&b), sizeof( b ) );

		addr.sin_family = AF_INET;
		addr.sin_addr.s_addr = htonl( INADDR_ANY );
		addr.sin_port = htons( cfg_.rc_port );
		if( bind( listen_sock_, reinterpret_cast<struct sockaddr*>(&addr), sizeof( addr ) ) != SOCKET_ERROR
			&& listen( listen_sock_, 1 ) != SOCKET_ERROR )
			{
			rc_thread_ = ThreadCreate( rc_routine, this );
			if( rc_thread_ != Thread_h(NULL) )
				{
				succ = true;
				}//end if
			}//end if

		if( !succ )
			{
			StopRemoteCtrl();
			}//end if
		}//end if

	return succ;
}//end AntiSpoof::StartRemoteCtrl

void AntiSpoof::StopRemoteCtrl(void)
{
	if( rc_run_ )
		{
		rc_run_ = false;
		if( rc_thread_ != Thread_h(NULL) )
			{
			ThreadWaitForExit( rc_thread_ );
			ThreadCloseHandle( rc_thread_ );
			rc_thread_ = NULL;
			}//end if

		if( session_sock_ != INVALID_SOCKET )
			{
			closesocket( session_sock_ );
			session_sock_ = INVALID_SOCKET;
			}//end if

		if( listen_sock_ != INVALID_SOCKET )
			{
			closesocket( listen_sock_ );
			listen_sock_ = INVALID_SOCKET;
			}//end if
		}//end if
}//end AntiSpoof::StopRemoteCtrl

int AntiSpoof::ExecCmd( char cmd[], bool remctrl, char reply[], int replylen, bool* logoff )
{
	static const char kState[] = "state";
	static const char kStart[] = "start";
	static const char kStop[] = "stop";
	static const char kSetIntv[] = "setintv";
	static const char kShowLog[] = "showlog";
	static const char kLogoff[] = "logoff";
	static const char kHelp[] = "help";

	static const char kOn[] = "on";
	static const char kOff[] = "off";

	static const char kDetect[] = "detect";
	static const char kAntiSpoof[] = "antispoof";
	static const char kReplyArp[] = "replyarp";
	static const char kReply4Hosts[] = "reply4hosts";
	
	static const char kSpaces[] = " \t\r\n\v\f";
	char *argv[MAX_CMD_NUM];
	int argc;
	int len = 0;
	bool validcmd;
	bool succ;

	if( logoff != NULL )
		{
		*logoff = false;
		}//end if

	// parse the command line
	argc = 0;
	argv[0] = strtok( cmd, kSpaces );
	while( argv[argc] != NULL && argc < MAX_CMD_NUM - 1 )
		{
		argv[++argc] = strtok( NULL, kSpaces );
		}//end while

	if( argc == 0 )
		{
		return 0;
		}//end if
	if( strcasecmp( kState, argv[0] ) == 0 )
		{
		len = snprintf( reply, replylen, "Auto Detect: %s\r\nAnti-spoof: %s\r\nARP reply: %s\r\n"
			"Reply for hosts: %s\r\nAnti-spoof interval: %d ms\r\nReply for hosts interval: %d s\r\n",
			auto_ ? kOn : kOff, prot_.get_run() ? kOn : kOff, repl_.get_run() ? kOn : kOff,
			r4h_.get_run() ? kOn : kOff, prot_.get_pktintv(), r4h_.get_pktintv() );
		}
	else if( strcasecmp( kStart, argv[0] ) == 0 )
		{
		validcmd = false;
		succ = false;
		if( argc > 1 )
			{
			validcmd = true;
			if( strcasecmp( kDetect, argv[1] ) == 0 )
				{
				succ = StartDetect();
				}
			else if( strcasecmp( kAntiSpoof, argv[1] ) == 0 )
				{
				succ = StartProtect();
				}
			else if( strcasecmp( kReplyArp, argv[1] ) == 0 )
				{
				succ = StartArpReply();
				}
			else if( strcasecmp( kReply4Hosts, argv[1] ) == 0 )
				{
				succ = StartReply4Hosts();
				}
			else{
				validcmd = false;
				}//end if
			}//end if
		if( validcmd )
			{
			if( succ )
				{
				len = snprintf( reply, replylen, "Start succeeded.\r\n" );
				}
			else{
				len = snprintf( reply, replylen, "Start failed!\r\n" );
				}//end if
			}
		else{
			len = snprintf( reply, replylen, "Usage: %s [ %s | %s | %s | %s ]\r\n", kStart, kDetect, kAntiSpoof,
				kReplyArp, kReply4Hosts );
			}//end if
		}
	else if( strcasecmp( kStop, argv[0] ) == 0 )
		{
		validcmd = false;
		if( argc > 1 )
			{
			validcmd = true;
			if( strcasecmp( kDetect, argv[1] ) == 0 )
				{
				StopDetect();
				}
			else if( strcasecmp( kAntiSpoof, argv[1] ) == 0 )
				{
				StopProtect();
				}
			else if( strcasecmp( kReplyArp, argv[1] ) == 0 )
				{
				StopArpReply();
				}
			else if( strcasecmp( kReply4Hosts, argv[1] ) == 0 )
				{
				StopReply4Hosts();
				}
			else{
				validcmd = false;
				}//end if
			}//end if
		if( validcmd )
			{
			len = snprintf( reply, replylen, "Stop finished.\r\n" );
			}
		else{
			len = snprintf( reply, replylen, "Usage: %s [ %s | %s | %s | %s ]\r\n", kStop, kDetect, kAntiSpoof,
				kReplyArp, kReply4Hosts );
			}//end if
		}
	else if( strcasecmp( kSetIntv, argv[0] ) == 0 )
		{
		validcmd = false;
		if( argc > 2 )
			{
			validcmd = true;
			if( strcasecmp( kAntiSpoof, argv[1] ) == 0 )
				{
				prot_.set_pktintv( atoi( argv[2] ) );
				}
			else if( strcasecmp( kReply4Hosts, argv[1] ) == 0 )
				{
				r4h_.set_pktintv( atoi( argv[2] ) );
				}
			else{
				validcmd = false;
				}//end if
			}//end if
		if( validcmd )
			{
			len = snprintf( reply, replylen, "Set finished.\r\n" );
			}
		else{
			len = snprintf( reply, replylen, "Usage: %s [ %s | %s ] INTERVAL\r\nThe unit of %s is millisecond,"
				" and that of %s is second\r\n", kSetIntv, kAntiSpoof, kReply4Hosts, kAntiSpoof, kReply4Hosts );
			}//end if
		}
	else if( strcasecmp( kShowLog, argv[0] ) == 0 )
		{
		if( argc > 1 )
			{
			time_t t;
			int i;
			i = atoi( argv[1] );
			time( &t );
			t -= i * 24 * 60 * 60;
			len = snprintf( reply, replylen, "Logs in last %d day(s):\r\n", i );
			len += show_log( t, reply + len, replylen - len );
			}
		else{
			len = snprintf( reply, replylen, "Usage: %s DAYS\r\nShow logs in last DAYS.\r\n", kShowLog );
			}//end if
		}
	else if( strcasecmp( kHelp, argv[0] ) == 0 )
		{
		len = snprintf( reply, replylen, "Commands: %s %s %s %s %s %s\r\n", kState, kStart, kStop, kSetIntv, kShowLog, kLogoff );
		}
	else if( strcasecmp( kLogoff, argv[0] ) == 0 )
		{
		if( remctrl )
			{
			if( logoff != NULL )
				{
				*logoff = true;
				}//end if
			len = snprintf( reply, replylen, "Logged off.\r\n" );
			}
		else{
			len = snprintf( reply, replylen, "Only used for remote control.\r\n" );
			}//end if
		}
	else{
		len = snprintf( reply, replylen, "%s: unknow command.\r\n", argv[0] );
		}//end if

	return len;
}//end AntiSpoof::ExecCmd

bool AntiSpoof::LoadCfg( const char cfgfile[] )
{
	return LoadConfig( cfgfile, &cfg_, true );
}//end AntiSpoof::LoadCfg

bool AntiSpoof::start_prot(void)
{
	if( cfg_.bindgateway )
		{
		ArpBind( cfg_.gateway.ip, &cfg_.gateway.mac );
		}//end if

	return prot_.Start( cfg_.adapter, &cfg_.local, &cfg_.gateway, cfg_.prot_num, cfg_.protaddr );
}//end AntiSpoof::start_prot

AntiSpoof::~AntiSpoof()
{
	if( cfg_.remotectrl )
		{
		StopRemoteCtrl();
		}//end if
	StopDetect();
	CleanupProtAddr( &cfg_ );
}//end AntiSpoof::~AntiSpoof
