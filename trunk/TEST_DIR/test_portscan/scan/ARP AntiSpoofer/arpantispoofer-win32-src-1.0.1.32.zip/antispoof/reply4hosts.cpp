#include "reply4hosts.h"
#include <string.h>

#define DEF_PKT_INTV 60000

const char kPadTag[] = "CTQY's Reply4Hosts";

Reply4Hosts::Reply4Hosts(void) : run_( false ), prot_num_( 0 ), protaddr_( NULL ),
						 caphandle_( NULL ), thread_( NULL ), pktintv_( DEF_PKT_INTV )
{
}//end Reply4Hosts::Reply4Hosts

bool Reply4Hosts::Start( const char* adapter, const AddrPair* local, const AddrPair* gateway,
		int prot_num, const ProtAddr protaddr[], int pktintv )
{
	char errbuf[PCAP_ERRBUF_SIZE];
	bool succ = false;

	if( run_ )
		{
		return true;
		}//end if

	local_ = *local;
	gateway_ = *gateway;

	pktintv_ = pktintv;

	caphandle_ = pcap_open_live( adapter, 0, 0, 1, errbuf );
	if( caphandle_ != NULL )
		{
		prot_num_ = prot_num;
		protaddr_ = new ProtAddr[prot_num];
		memcpy( const_cast<ProtAddr*>(protaddr_), protaddr, sizeof( protaddr[0] ) * prot_num );

		run_ = true;
		// start the thread
		thread_ = ThreadCreate( reply_routine, this );
		if( thread_ != Thread_h(NULL) )
			{
			succ = true;
			}
		else{
			Stop();
			}//end if
		}//end if

	return succ;
}//end Reply4Hosts::Start

void Reply4Hosts::Stop(void)
{
	if( run_ )
		{
		run_ = false;

		if( thread_ != Thread_h(NULL) )
			{
			// waiting for the thread
			ThreadWaitForExit( thread_ );
			ThreadCloseHandle( thread_ );
			thread_ = NULL;
			}//end if

		delete [] protaddr_;
		protaddr_ = NULL;
		prot_num_ = 0;

		if( caphandle_ != NULL )
			{
			pcap_close( caphandle_ );
			caphandle_ = NULL;
			}//end if
		}//end if
}//end Reply4Hosts::Stop

void Reply4Hosts::set_pktintv( int pktintv )
{
	if( pktintv <= 0 )
		{
		pktintv = 1;
		}//end if

	pktintv_ = pktintv;
}//end Reply4Hosts::set_pktintv

CALL_BACK Reply4Hosts::reply_routine( void* thisptr )
{
	Reply4Hosts const *repl = reinterpret_cast<Reply4Hosts*>(thisptr);
	EtherPkt pkt;
	int i;

	memset( &pkt.dstaddr, 0xFF, sizeof( MacAddr ) );
	pkt.srcaddr = repl->local_.mac;
	pkt.ethertype = htons( ARP_TYPE );

	pkt.arppkt.hwtype = htons( ETHER_HWTYPE );
	pkt.arppkt.protype = htons( IP_PROTYPE );
	pkt.arppkt.hwaddrsize = sizeof( MacAddr );
	pkt.arppkt.proaddrsize = sizeof( IpAddr );
	pkt.arppkt.opcode = htons( ARPREPLY );

	memset( pkt.padding, 0, sizeof( pkt.padding ) );
	memcpy( pkt.padding, kPadTag, min( sizeof( pkt.padding ), sizeof( kPadTag ) ) );

	while( repl->run_ )
		{
		for( i = 0; i < repl->prot_num_; ++i )
			{
			pkt.arppkt.targetmac = pkt.arppkt.sendermac = repl->protaddr_[i].mac;
			pkt.arppkt.targetip = pkt.arppkt.senderip = repl->protaddr_[i].ip;
			pcap_sendpacket( repl->caphandle_, reinterpret_cast<u_char*>(&pkt), sizeof( pkt ) );
			}//end for

		for( i = 0; i < repl->pktintv_ && repl->run_; i += 500 )
			{
			MsSleep( min( 500, repl->pktintv_ - i ) );
			}//end for
		}//end while

	return 0;
}//end Reply4Hosts::reply_routine

Reply4Hosts::~Reply4Hosts()
{
	Stop();
}//end Reply4Hosts::~Reply4Hosts
