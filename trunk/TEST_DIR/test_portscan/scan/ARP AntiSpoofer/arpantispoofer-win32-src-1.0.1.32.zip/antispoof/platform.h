#ifndef CTQY_PLATFORM_H
#define CTQY_PLATFORM_H

#include "arpdef.h"
#include <pcap.h>

bool readip( const char buff[], IpAddr *ip );
bool readmac( const char buff[], MacAddr *mac );

#ifdef WIN32

#define CALL_BACK DWORD WINAPI

typedef HANDLE Thread_h;
typedef LPTHREAD_START_ROUTINE StartRoutine;

#define strncasecmp _strnicmp
#define strcasecmp _stricmp

#else // Linux

#include <pthread.h>
#include <sys/socket.h>
#include <sys/select.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <signal.h>

#define CALL_BACK void*

typedef pthread_t Thread_h;
typedef CALL_BACK (*StartRoutine)( void* arg );

typedef int SOCKET;

#define INVALID_SOCKET (SOCKET)(~0)

#define SOCKET_ERROR (-1)

#define SD_BOTH SHUT_RDWR

#define closesocket close

inline int min( int a, int b ){ return (a < b) ? a : b; }

char* itoa( int val, char *buf, int radix );

#endif

Thread_h ThreadCreate( StartRoutine start, void *arg );
int ThreadWaitForExit( Thread_h handle ); // return 0: success
void ThreadCloseHandle( Thread_h handle );

void MsSleep( int ms );

int ArpBind( IpAddr ip, const MacAddr *mac );
IpAddr MacToIp( const MacAddr *mac, int excipnum, const IpAddr excip[] );
bool GetMacAddress( const char* adapter, MacAddr* mac );

void GetConfigFullName( const char shortname[], char fullname[] );
void GetLogFullName( const char shortname[], char fullname[] );

bool strtotm( const char str[], struct tm* tm );

#endif // CTQY_PLATFORM_H
