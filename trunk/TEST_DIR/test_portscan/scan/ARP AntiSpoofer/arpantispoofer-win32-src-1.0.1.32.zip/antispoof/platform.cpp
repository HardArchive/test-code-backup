#include "platform.h"
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <stdio.h>

const char kPathArpTable[] = "/proc/net/arp";

bool readip( const char buff[], IpAddr *ip )
{
	unsigned int ipbuf[4];
	bool succ = false;
	int i;

	if( sscanf( buff, "%u.%u.%u.%u", &ipbuf[0], &ipbuf[1], &ipbuf[2], &ipbuf[3] ) == 4 )
		{
		for( i = 0; i < 4; ++i )
			{
			ip->addr[i] = ipbuf[i];
			}//end for
		succ = true;
		}//end if

	return succ;
}//end readip

bool readmac( const char buff[], MacAddr *mac )
{
	int macbuf[6];
	bool succ = false;
	int i;

	if( sscanf( buff, "%x%*c%x%*c%x%*c%x%*c%x%*c%x", &macbuf[0], &macbuf[1], &macbuf[2],
		&macbuf[3], &macbuf[4], &macbuf[5] ) == 6 )
		{
		for( i = 0; i < 6; ++i )
			{
			mac->addr[i] = macbuf[i];
			}//end for
		succ = true;
		}//end if

	return succ;
}//end readmac


#ifdef WIN32

#include <Iphlpapi.h>
#include <Packet32.h>
#include <Ntddndis.h>

Thread_h ThreadCreate( StartRoutine start, void *arg )
{
	return CreateThread( NULL, 0, start, arg, 0, NULL );
}//end ThreadCreate

int ThreadWaitForExit( Thread_h handle )
{
	WaitForSingleObject( handle, INFINITE );
	return GetLastError();
}//end ThreadWaitForExit

void ThreadCloseHandle( Thread_h handle )
{
	CloseHandle( handle );
}//end ThreadCloseHandle

void MsSleep( int ms )
{
	Sleep( ms );
}//end MsSleep

int ArpBind( IpAddr ip, const MacAddr *mac )
{
	MIB_IPFORWARDROW ipfrow;
	MIB_IPNETROW iprow;
	int ret;

	ret = GetBestRoute( ip.dw, 0, &ipfrow );
	if( ret != NO_ERROR )
		{
		return ret;
		}//end if

	iprow.dwIndex = ipfrow.dwForwardIfIndex;
	iprow.dwPhysAddrLen = sizeof( *mac );
	memset( iprow.bPhysAddr, 0, sizeof( iprow.bPhysAddr ) );
	memcpy( iprow.bPhysAddr, mac->addr, sizeof( *mac ) );
	iprow.dwAddr = ip.dw;
	iprow.dwType = 4; // static

	return CreateIpNetEntry( &iprow );
}//end ArpBind

IpAddr MacToIp( const MacAddr *mac, int excipnum, const IpAddr excip[] )
{
	PMIB_IPNETTABLE iptable;
	HANDLE heap;
	ULONG size;
	IpAddr ip;
	DWORD i;
	int j;

	ip.dw = 0;
	size = 0;
	GetIpNetTable( NULL, &size, FALSE );
	if( size > 0 )
		{
		heap = GetProcessHeap();
		iptable = reinterpret_cast<PMIB_IPNETTABLE>(HeapAlloc( heap, 0, size ));
		GetIpNetTable( iptable, &size, FALSE );
		for( i = 0; i < iptable->dwNumEntries; ++i )
			{
			if( memcmp( mac->addr, iptable->table[i].bPhysAddr, sizeof( mac->addr ) ) == 0 )
				{
				for( j = 0; j < excipnum; ++j )
					{
					if( iptable->table[i].dwAddr == excip[j].dw )
						{
						break;
						}//end if
					}//end for
				if( j >= excipnum )
					{
					ip.dw = iptable->table[i].dwAddr;
					break;
					}//end if
				}//end if
			}//end for
		HeapFree( heap, 0, iptable );
		}//end if

	return ip;
}//end MacToIp

bool GetMacAddress( const char* adapter, MacAddr* mac )
{
	HANDLE heap;
	LPADAPTER ad;
	PPACKET_OID_DATA od;
	bool succ = false;

	ad = PacketOpenAdapter( const_cast<char*>(adapter) );

	if( ad == NULL || ad->hFile == INVALID_HANDLE_VALUE )
		{
		return false;
		}//end if

	heap = GetProcessHeap();
	od = reinterpret_cast<PPACKET_OID_DATA>(HeapAlloc( heap, 0, sizeof( MacAddr ) + sizeof( PACKET_OID_DATA ) ));

	od->Oid = OID_802_3_CURRENT_ADDRESS;
	od->Length = sizeof( MacAddr );
	memset( od->Data, 0, sizeof( MacAddr ) );
	
	if( PacketRequest( ad, FALSE, od ) )
		{
		memcpy( mac, od->Data, sizeof( MacAddr ) );
		succ = true;
		}//end if
	
	HeapFree( heap, 0, od );

	PacketCloseAdapter( ad );
	
	return succ;
}//end GetMacAddress

void GetConfigFullName( const char shortname[], char fullname[] )
{
	size_t i;
	GetModuleFileNameA( NULL, fullname, MAX_PATH );
	for( i = strlen( fullname ) - 1; fullname[i] != '\\'; --i );//end for
	strcpy( fullname + i + 1, shortname );
}//end GetConfigFullName

void GetLogFullName( const char shortname[], char fullname[] )
{
	GetConfigFullName( shortname, fullname );
}//end GetLogFullName

bool strtotm( const char str[], struct tm* tm )
{
	static const char *kMonth[12] = { "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug",
		"Sep", "Oct", "Nov", "Dec" };
	char month[4];
	int i;

	memset( tm, 0, sizeof( *tm ) );

	if( sscanf( str, "%*s %3s %d %d:%d:%d %d", month, &tm->tm_mday,
			&tm->tm_hour, &tm->tm_min, &tm->tm_sec, &tm->tm_year ) == 6 )
		{
		month[3] = '\0';
		tm->tm_year -= 1900;
		for( i = 0; i < 12; ++i )
			{
			if( strncasecmp( kMonth[i], month, 3 ) == 0 )
				{
				tm->tm_mon = i;
				return true;
				}//end if
			}//end for
		}//end if

	return false;
}//end strtotm

#else // Linux

#include <sys/sysinfo.h>
#include <sys/ioctl.h>
#include <net/if.h>
#include <net/if_arp.h>
#include <unistd.h>
#include <stdio.h>
#include <errno.h>

char* itoa( int val, char *buf, int radix )
{
	const char aNumber[] = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ";
	char *p = buf;			/* pointer to traverse string */
	char *firstdig = buf;	/* pointer to first digit */
	char temp;			  /* temp char */
	div_t dv;

	if( val < 0 )
		{
		buf[0] = '-';
		++p;
		++firstdig;
		val = -val;
		}//end if

	dv.quot = val;
	do	{
		dv = div( (int)dv.quot, (int)radix );
		/* convert to ascii and store */
		*p++ = aNumber[dv.rem];
		} while( dv.quot > 0 );
		/* We now have the digit of the number in the buffer, but in reverse
		   order.  Thus we reverse them now. */

	*p-- = '\0';/* terminate string; p points to last digit */

	do	{
		temp = *p;
		*p = *firstdig;
		*firstdig = temp;   /* swap *p and *firstdig */
		--p;
		++firstdig;		 /* advance to next two digits */
		} while( firstdig < p ); /* repeat until halfway */

	return buf;
}//end itoa

Thread_h ThreadCreate( StartRoutine start, void *arg )
{
	Thread_h handle = NULL;
	pthread_create( &handle, NULL, start, arg );
	return handle;
}//end ThreadCreate

int ThreadWaitForExit( Thread_h handle )
{
	return pthread_join( handle, NULL );
}//end ThreadWaitForExit

void ThreadCloseHandle( Thread_h handle )
{
	pthread_detach( handle );
}//end ThreadCloseHandle

void MsSleep( int ms )
{
	usleep( ms * 1000 );
}//end MsSleep

int ArpBind( IpAddr ip, const MacAddr *mac )
{
	struct arpreq req;
	int sock;
	int ret = 0;

	sock = socket( AF_INET, SOCK_DGRAM, 0 );
	if( sock >= 0 )
		{
		memset( &req, 0, sizeof( req ) );
		req.arp_flags = ATF_PERM;
		req.arp_pa.sa_family = AF_INET;
		reinterpret_cast<struct sockaddr_in*>(&req.arp_pa)->sin_addr.s_addr = ip.dw;
		req.arp_ha.sa_family = AF_UNIX;
		memcpy( req.arp_ha.sa_data, mac, sizeof( *mac ) );
		ioctl( sock, SIOCSARP, &req );
		ret = errno;
		close( sock );
		}
	else{
		ret = errno;
		}//end if

	return ret;
}//end ArpBind

IpAddr MacToIp( const MacAddr *mac, int excipnum, const IpAddr excip[] )
{
	char buff[256];
	FILE *fp;
	IpAddr ip;
	MacAddr mactmp;
	int i, j;

	ip.dw = 0;
	fp = fopen( kPathArpTable, "r" );
	if( fp != NULL )
		{
		if( fgets( buff, sizeof( buff ), fp ) != NULL )
			{
			while( fgets( buff, sizeof( buff ), fp ) != NULL )
				{
				for( i = 0, j = 0; i < 3; ++i )
					{
					for( ; !isspace( buff[j] ); ++j );//end for
					for( ; isspace( buff[j] ); ++j );//end for
					}//end for
				if( readmac( buff + j, &mactmp )
					&& memcmp( mac->addr, mactmp.addr, sizeof( mac->addr ) ) == 0
					&& readip( buff, &ip ) )
					{
					for( i = 0; i < excipnum; ++i )
						{
						if( ip.dw == excip[i].dw )
							{
							break;
							}//end if
						}//end for
					if( i >= excipnum )
						{
						break;
						}//end if
					}//end if
				}//end while
			}//end if
		fclose( fp );
		}//end if

	return ip;
}//end MacToIp

bool GetMacAddress( const char* adapter, MacAddr* mac )
{
	struct ifreq ir;
	int sd;
	bool succ = false;

	sd = socket( AF_INET, SOCK_DGRAM, 0 );
	if( sd > 0 )
		{
		strncpy( ir.ifr_name, adapter, sizeof(ir.ifr_name) );
		if( ioctl( sd, SIOCGIFHWADDR, &ir ) == 0 )
			{
			memcpy( mac->addr, ir.ifr_ifru.ifru_hwaddr.sa_data, sizeof( mac->addr ) );
			succ = true;
			}//end if
		close( sd );
		}//end if

	return succ;
}//end GetMacAddress

void GetConfigFullName( const char shortname[], char fullname[] )
{
	sprintf( fullname, "/etc/%s", shortname );
}//end GetConfigFullName

void GetLogFullName( const char shortname[], char fullname[] )
{
	sprintf( fullname, "/var/log/%s", shortname );
}//end GetLogFullName

bool strtotm( const char str[], struct tm* tm )
{
	return( strptime( str, "%a %b %d %H:%M:%S %Y", tm ) != NULL );
}//end strtotm

#endif
