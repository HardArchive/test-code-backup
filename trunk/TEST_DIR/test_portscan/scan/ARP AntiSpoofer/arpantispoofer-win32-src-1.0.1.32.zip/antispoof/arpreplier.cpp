#include "arpreplier.h"
#include <string.h>

#define LISTEN_TIMESLICE 50

const char kPadTag[] = "CTQY's ArpReplier";

ArpReplier::ArpReplier(void) : run_( false ), caphandle_( NULL ), thread_( NULL )
{
}//end ArpReplier::ArpReplier

bool ArpReplier::Start( const char adapter[], unsigned long netmask, const AddrPair* local, const AddrPair* gateway )
{
	char errbuf[PCAP_ERRBUF_SIZE];
	char filter[256];
	struct bpf_program fcode;
	bool succ = false;

	if( run_ )
		{
		return true;
		}//end if

	local_ = *local;
	gateway_ = *gateway;

	caphandle_ = pcap_open_live( adapter, 65535, 0, 1, errbuf );
	if( caphandle_ != NULL )
		{
		run_ = true;
		// compile filter
		// dst mac = broadcast, arp, request, target ip = gateway ip
		sprintf( filter, "ether[0] & 1 != 0 && arp[2:2] = 0x0800 && arp[6:2] = %#x && arp[24:4] = %#x",
			ARPREQUEST, ntohl( gateway_.ip.dw ) );
		if( pcap_compile( caphandle_, &fcode, filter, 1, netmask ) >= 0 )
			{
			// apply filter
			if( pcap_setfilter( caphandle_, &fcode ) >= 0 )
				{
				// start the thread
				thread_ = ThreadCreate( reply_routine, this );
				if( thread_ != Thread_h(NULL) )
					{
					succ = true;
					}//end if
				}//end if
			pcap_freecode( &fcode );
			}//end if

		if( !succ )
			{
			Stop();
			}//end if
		}//end if

	return succ;
}//end ArpReplier::Start

void ArpReplier::Stop(void)
{
	if( run_ )
		{
		run_ = false;

		if( thread_ != Thread_h(NULL) )
			{
			// waiting for the thread
			ThreadWaitForExit( thread_ );
			ThreadCloseHandle( thread_ );
			thread_ = NULL;
			}//end if

		if( caphandle_ != NULL )
			{
			pcap_close( caphandle_ );
			caphandle_ = NULL;
			}//end if
		}//end if
}//end ArpReplier::Stop

CALL_BACK ArpReplier::reply_routine( void* thisptr )
{
	ArpReplier *ar = reinterpret_cast<ArpReplier*>(thisptr);
	struct pcap_pkthdr *pkt_header;
	const EtherPkt *pkt;
	EtherPkt replypkt;
	int ret;
	
	replypkt.srcaddr = ar->local_.mac;
	replypkt.ethertype = htons( ARP_TYPE );

	replypkt.arppkt.hwtype = htons( ETHER_HWTYPE );
	replypkt.arppkt.protype = htons( IP_PROTYPE );
	replypkt.arppkt.hwaddrsize = sizeof( MacAddr );
	replypkt.arppkt.proaddrsize = sizeof( IpAddr );
	replypkt.arppkt.opcode = htons( ARPREPLY );
	replypkt.arppkt.sendermac = ar->gateway_.mac;
	replypkt.arppkt.senderip = ar->gateway_.ip;

	memset( replypkt.padding, 0, sizeof( replypkt.padding ) );
	memcpy( replypkt.padding, kPadTag, min( sizeof( replypkt.padding ), sizeof( kPadTag ) ) );

	pcap_setnonblock( ar->caphandle_, 1, NULL );
	while( ar->run_ )
		{
		ret = pcap_next_ex( ar->caphandle_, &pkt_header, reinterpret_cast<const u_char**>(&pkt) );
		if( ret == 1 )
			{
			replypkt.dstaddr = replypkt.arppkt.targetmac = pkt->arppkt.sendermac;
			replypkt.arppkt.targetip = pkt->arppkt.senderip;
			pcap_sendpacket( ar->caphandle_, reinterpret_cast<u_char*>(&replypkt), sizeof( replypkt ) );
			}
		else if( ret == 0 )
			{
			// do nothing
			MsSleep( LISTEN_TIMESLICE );
			}
		else{
			break;
			}//end if
		}//end while

	return 0;
}//end ArpReplier::reply_routine

ArpReplier::~ArpReplier()
{
	Stop();
}//end ArpReplier::~ArpReplier
