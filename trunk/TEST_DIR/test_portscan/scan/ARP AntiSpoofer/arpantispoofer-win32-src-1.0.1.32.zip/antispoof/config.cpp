#include <pcap.h>
#include "config.h"
#include "common.h"
#include <ctype.h>
#include <stdio.h>
#include <string.h>

const char kMainSec[] = "main";

const char kAdapterKey[] = "adapter";
const char kNetmaskKey[] = "netmask";
const char kBindGatewayKey[] = "bind_gateway";
const char kAutoDetectKey[] = "auto_detect";
const char kKeepProtStatKey[] = "keep_protect_status";
const char kMultipleKey[] = "multiple";
const char kSpoofRangeSecKey[] = "spoof_range_second";
const char kReply4GwKey[] = "reply_for_gateway";
const char kReply4HostsKey[] = "reply_for_hosts_to_gw";
const char kReply4HostsIntvKey[] = "reply_for_hosts_intv";
const char kRemoteCtrlKey[] = "remote_ctrl";
const char kRemoteCtrlPortKey[] = "remote_ctrl_port";
const char kRemoteCtrlPswdKey[] = "remote_ctrl_pswd";
const char kLogFileKey[] = "log_file";
const char kLocalAddrKey[] = "local_addr";
const char kGatewayAddrKey[] = "gateway_addr";

const char kNotifySpoofKey[] = "notify_spoof";

const char kProtectHostsSec[] = "protect_hosts";

const char kDefNetmask[] = "255.255.255.0";
const int kDefBindGateway = 1;
const int kDefAutoDetect = 1;
const int kDefKeepProtStat = 1;
const int kDefMultiple = 3;
const int kDefSpoofRangeSec = 60;
const int kDefReply4Gw = 0;
const int kDefReply4Hosts = 0;
const int kDefReply4HostsIntv = 60000;
const int kDefRemoteCtrl = 1;
const unsigned short kDefRemoteCtrlPort = 23001;
const char kDefRemoteCtrlPswd[] = "admin";
const char kDefLogFile[] = "arpas.log";
const char kDefLocalAddr[] = "192.168.0.125|00:00:00:00:00:00";
const char kDefGatewayAddr[] = "192.168.0.1|00-00-00-00-00-00";
const int kDefNotifySpoof = 1;

const char kSplitter = '|';
const char kTypeHost = 'h';
const char kTypeGateway = 'g';

static bool TestAdapterName( const char adapter[] )
{
	char errbuf[PCAP_ERRBUF_SIZE];
	pcap_if_t *alldevs;
	pcap_if_t *d;
	int i;
	bool succ = false;

	if( pcap_findalldevs( &alldevs, errbuf ) == -1 )
		{
		return false;
		}//end if

	for( i = 0, d = alldevs; d != NULL; d = d->next, ++i )
		{
		if( strcmp( d->name, adapter ) == 0 )
			{
			succ = true;
			break;
			}//end if
		}//end for

	pcap_freealldevs(alldevs);

	return succ;
}//end TestAdapterName

#ifdef WIN32

const char kDefProtTypeWithComment[] = "192.168.0.125=00-00-00-00-00-00|hg # h: tell this host the true address; g: tell the gateway the true address\0\0";

bool LoadConfig( const char file[], Config *cfg, bool loadprotaddr )
{
	char buff[MAX_PATH_LEN];
	char *list;
	char *p, *p2;
	int i;
	bool succ = true;
	bool corr;

	memset( cfg, 0, sizeof( *cfg ) );

	corr = false;
	if( GetPrivateProfileStringA( kMainSec, kAdapterKey, NULL, cfg->adapter, sizeof( cfg->adapter ), file ) > 0
		&& TestAdapterName( cfg->adapter ) )
		{
		cfg->adapter[MAX_ADAPTER_NAME-1] = '\0';
		GetPrivateProfileStringA( kMainSec, kNetmaskKey, kDefNetmask, buff, sizeof( buff ), file );
		if( readip( buff, &cfg->netmask ) )
			{
			corr = true;
			}//end if
		}//end if
	succ = corr && succ;

	cfg->bindgateway = GetPrivateProfileIntA( kMainSec, kBindGatewayKey, kDefBindGateway, file );

	cfg->autodetect = GetPrivateProfileIntA( kMainSec, kAutoDetectKey, kDefAutoDetect, file );

	cfg->keepprotstat = GetPrivateProfileIntA( kMainSec, kKeepProtStatKey, kDefKeepProtStat, file );

	cfg->multiple = GetPrivateProfileIntA( kMainSec, kMultipleKey, kDefMultiple, file );

	cfg->spoof_range = 1000 * GetPrivateProfileIntA( kMainSec, kSpoofRangeSecKey, kDefSpoofRangeSec, file );

	cfg->reply4gw = GetPrivateProfileIntA( kMainSec, kReply4GwKey, kDefReply4Gw, file );

	cfg->reply4h = GetPrivateProfileIntA( kMainSec, kReply4HostsKey, kDefReply4Hosts, file );

	cfg->reply4hintv = GetPrivateProfileIntA( kMainSec, kReply4HostsIntvKey, kDefReply4HostsIntv, file );

	cfg->remotectrl = GetPrivateProfileIntA( kMainSec, kRemoteCtrlKey, kDefRemoteCtrl, file );
	cfg->rc_port = GetPrivateProfileIntA( kMainSec, kRemoteCtrlPortKey, kDefRemoteCtrlPort, file );
	cfg->rc_pswd[0] = '\0';
	if( GetPrivateProfileStringA( kMainSec, kRemoteCtrlPswdKey, NULL, cfg->rc_pswd,
			sizeof( cfg->rc_pswd ), file ) > 0 )
		{
		cfg->rc_pswd[MAX_PSWD_LEN-1] = '\0';
		}
	else{
		if( cfg->remotectrl )
			{
			succ = false;
			}//end if
		}//end if

	corr = false;
	if( GetPrivateProfileStringA( kMainSec, kLogFileKey, NULL, cfg->logfile,
			sizeof( cfg->logfile ), file ) > 0 )
		{
		cfg->logfile[MAX_PATH_LEN-1] = '\0';
		corr = true;
		}//end if
	succ = corr && succ;

	corr = false;
	if( GetPrivateProfileStringA( kMainSec, kLocalAddrKey, NULL, buff, sizeof( buff ), file ) > 0 )
		{
		if( readip( buff, &cfg->local.ip ) )
			{
			p = strchr( buff, kSplitter );
			if( p != NULL && readmac( p + 1, &cfg->local.mac ) )
				{
				corr = true;
				}//end if
			}//end if
		}//end if
	succ = corr && succ;

	corr = false;
	if( GetPrivateProfileStringA( kMainSec, kGatewayAddrKey, NULL, buff, sizeof( buff ), file ) > 0 )
		{
		if( readip( buff, &cfg->gateway.ip ) )
			{
			p = strchr( buff, kSplitter );
			if( p != NULL && readmac( p + 1, &cfg->gateway.mac ) )
				{
				corr = true;
				}//end if
			}//end if
		}//end if
	succ = corr && succ;

	cfg->prot_num = 0;
	cfg->protaddr = NULL;
	if( loadprotaddr )
		{
		list = new char[65536];
		if( GetPrivateProfileSectionA( kProtectHostsSec, list, 65536, file ) > 0 )
			{
			for( i = 0, p = list; p != NULL && p[1] != '\0'; ++i, p = strchr( p + 1, '\0' ) );//end for
			cfg->protaddr = new ProtAddr[i];
			for( p = list-1; p != NULL && p[1] != '\0'; ++i, p = strchr( p, '\0' ) )
				{
				++p;
				if( readip( p, &cfg->protaddr[cfg->prot_num].ip ) )
					{
					p2 = strchr( p, '=' );
					if( p2 != NULL && readmac( ++p2, &cfg->protaddr[cfg->prot_num].mac ) )
						{
						p2 = strchr( p2, kSplitter );
						if( p2 != NULL )
							{
							for( ++p2; isspace( *p2 ); ++p2 );//end for
							cfg->protaddr[cfg->prot_num].type = 0;
							if( *p2 != '\0' )
								{
								if( p2[0] == kTypeHost || p2[1] == kTypeHost )
									{
									cfg->protaddr[cfg->prot_num].type |= PROT_TYPE_HOST;
									}//end if
								if( p2[0] == kTypeGateway || p2[1] == kTypeGateway )
									{
									cfg->protaddr[cfg->prot_num].type |= PROT_TYPE_GATEWAY;
									}//end if
								}//end if
							++cfg->prot_num;
							}//end if
						}//end if
					}//end if
				}//end for
			}//end if
		delete [] list;
		}//end if

	if( !succ )
		{
		if( GetPrivateProfileStringA( kMainSec, kAdapterKey, NULL, buff, sizeof( buff ), file ) == 0 )
			{
			WritePrivateProfileStringA( kMainSec, kAdapterKey, "", file );
			}//end if

		if( GetPrivateProfileStringA( kMainSec, kNetmaskKey, NULL, buff, sizeof( buff ), file ) == 0 )
			{
			WritePrivateProfileStringA( kMainSec, kNetmaskKey, kDefNetmask, file );
			}//end if

		if( GetPrivateProfileStringA( kMainSec, kBindGatewayKey, NULL, buff, sizeof( buff ), file ) == 0 )
			{
			WritePrivateProfileStringA( kMainSec, kBindGatewayKey, _itoa( kDefBindGateway, buff, 10 ), file );
			}//end if

		if( GetPrivateProfileStringA( kMainSec, kAutoDetectKey, NULL, buff, sizeof( buff ), file ) == 0 )
			{
			WritePrivateProfileStringA( kMainSec, kAutoDetectKey, _itoa( kDefAutoDetect, buff, 10 ), file );
			}//end if

		if( GetPrivateProfileStringA( kMainSec, kKeepProtStatKey, NULL, buff, sizeof( buff ), file ) == 0 )
			{
			WritePrivateProfileStringA( kMainSec, kKeepProtStatKey, _itoa( kDefKeepProtStat, buff, 10 ), file );
			}//end if

		if( GetPrivateProfileStringA( kMainSec, kMultipleKey, NULL, buff, sizeof( buff ), file ) == 0 )
			{
			WritePrivateProfileStringA( kMainSec, kMultipleKey, _itoa( kDefMultiple, buff, 10 ), file );
			}//end if

		if( GetPrivateProfileStringA( kMainSec, kSpoofRangeSecKey, NULL, buff, sizeof( buff ), file ) == 0 )
			{
			WritePrivateProfileStringA( kMainSec, kSpoofRangeSecKey, _itoa( kDefSpoofRangeSec, buff, 10 ), file );
			}//end if

		if( GetPrivateProfileStringA( kMainSec, kReply4GwKey, NULL, buff, sizeof( buff ), file ) == 0 )
			{
			WritePrivateProfileStringA( kMainSec, kReply4GwKey, _itoa( kDefReply4Gw, buff, 10 ), file );
			}//end if

		if( GetPrivateProfileStringA( kMainSec, kReply4HostsKey, NULL, buff, sizeof( buff ), file ) == 0 )
			{
			WritePrivateProfileStringA( kMainSec, kReply4HostsKey, _itoa( kDefReply4Hosts, buff, 10 ), file );
			}//end if

		if( GetPrivateProfileStringA( kMainSec, kReply4HostsIntvKey, NULL, buff, sizeof( buff ), file ) == 0 )
			{
			WritePrivateProfileStringA( kMainSec, kReply4HostsIntvKey, _itoa( kDefReply4HostsIntv, buff, 10 ), file );
			}//end if

		if( GetPrivateProfileStringA( kMainSec, kRemoteCtrlKey, NULL, buff, sizeof( buff ), file ) == 0 )
			{
			WritePrivateProfileStringA( kMainSec, kRemoteCtrlKey, _itoa( kDefRemoteCtrl, buff, 10 ), file );
			}//end if

		if( GetPrivateProfileStringA( kMainSec, kRemoteCtrlPortKey, NULL, buff, sizeof( buff ), file ) == 0 )
			{
			WritePrivateProfileStringA( kMainSec, kRemoteCtrlPortKey, _itoa( kDefRemoteCtrlPort, buff, 10 ), file );
			}//end if

		if( GetPrivateProfileStringA( kMainSec, kRemoteCtrlPswdKey, NULL, buff, sizeof( buff ), file ) == 0 )
			{
			WritePrivateProfileStringA( kMainSec, kRemoteCtrlPswdKey, kDefRemoteCtrlPswd, file );
			}//end if

		if( GetPrivateProfileStringA( kMainSec, kLogFileKey, NULL, buff, sizeof( buff ), file ) == 0 )
			{
			GetLogFullName( kDefLogFile, buff );
			WritePrivateProfileStringA( kMainSec, kLogFileKey, buff, file );
			}//end if

		if( GetPrivateProfileStringA( kMainSec, kLocalAddrKey, NULL, buff, sizeof( buff ), file ) == 0 )
			{
			WritePrivateProfileStringA( kMainSec, kLocalAddrKey, kDefLocalAddr, file );
			}//end if

		if( GetPrivateProfileStringA( kMainSec, kGatewayAddrKey, NULL, buff, sizeof( buff ), file ) == 0 )
			{
			WritePrivateProfileStringA( kMainSec, kGatewayAddrKey, kDefGatewayAddr, file );
			}//end if

		if( GetPrivateProfileSectionA( kProtectHostsSec, buff, sizeof( buff ), file ) == 0 )
			{
			WritePrivateProfileSectionA( kProtectHostsSec, kDefProtTypeWithComment, file );
			}//end if
		}//end if

	if( succ )
		{
		succ = !CheckAbuse( cfg );
		}//end if

	return succ;
}//end LoadConfig

bool LoadNotifySpoof( const char file[], bool* notifyspoof )
{
	*notifyspoof = GetPrivateProfileIntA( kMainSec, kNotifySpoofKey, kDefNotifySpoof, file );
	return true;
}//end LoadNotifySpoof

void SaveAllConfig( const char file[], const Config* cfg, bool notifyspoof )
{
	const int kWidth = 38;
	char buff[64];
	char *sec;
	int i;
	int len;

	WritePrivateProfileStringA( kMainSec, kAdapterKey, cfg->adapter, file );

	WritePrivateProfileStringA( kMainSec, kNetmaskKey, inet_ntoa( cfg->netmask.ia ), file );

	WritePrivateProfileStringA( kMainSec, kBindGatewayKey, _itoa( cfg->bindgateway, buff, 10 ), file );

	WritePrivateProfileStringA( kMainSec, kAutoDetectKey, _itoa( cfg->autodetect, buff, 10 ), file );

	WritePrivateProfileStringA( kMainSec, kKeepProtStatKey, _itoa( cfg->keepprotstat, buff, 10 ), file );

	WritePrivateProfileStringA( kMainSec, kMultipleKey, _itoa( cfg->multiple, buff, 10 ), file );

	WritePrivateProfileStringA( kMainSec, kSpoofRangeSecKey, _itoa( cfg->spoof_range / 1000, buff, 10 ), file );

	WritePrivateProfileStringA( kMainSec, kReply4GwKey, _itoa( cfg->reply4gw, buff, 10 ), file );

	WritePrivateProfileStringA( kMainSec, kReply4HostsKey, _itoa( cfg->reply4h, buff, 10 ), file );

	WritePrivateProfileStringA( kMainSec, kReply4HostsIntvKey, _itoa( cfg->reply4hintv, buff, 10 ), file );

	WritePrivateProfileStringA( kMainSec, kRemoteCtrlKey, _itoa( cfg->remotectrl, buff, 10 ), file );

	WritePrivateProfileStringA( kMainSec, kRemoteCtrlPortKey, _itoa( cfg->rc_port, buff, 10 ), file );

	WritePrivateProfileStringA( kMainSec, kRemoteCtrlPswdKey, cfg->rc_pswd, file );

	WritePrivateProfileStringA( kMainSec, kLogFileKey, cfg->logfile, file );

	sprintf( buff, "%s|%02X-%02X-%02X-%02X-%02X-%02X",
		inet_ntoa( cfg->local.ip.ia ),
		cfg->local.mac.addr[0], cfg->local.mac.addr[1], cfg->local.mac.addr[2],
		cfg->local.mac.addr[3],	cfg->local.mac.addr[4], cfg->local.mac.addr[5] );
	WritePrivateProfileStringA( kMainSec, kLocalAddrKey, buff, file );

	sprintf( buff, "%s|%02X-%02X-%02X-%02X-%02X-%02X",
		inet_ntoa( cfg->gateway.ip.ia ),
		cfg->gateway.mac.addr[0], cfg->gateway.mac.addr[1], cfg->gateway.mac.addr[2],
		cfg->gateway.mac.addr[3], cfg->gateway.mac.addr[4], cfg->gateway.mac.addr[5] );
	WritePrivateProfileStringA( kMainSec, kGatewayAddrKey, buff, file );

	WritePrivateProfileStringA( kMainSec, kNotifySpoofKey, _itoa( notifyspoof, buff, 10 ), file );

	sec = new char[ cfg->prot_num * kWidth + 1 ];
	for( i = 0, len = 0; i < cfg->prot_num; ++i )
		{
		len += sprintf( sec + len, "%s=%02X-%02X-%02X-%02X-%02X-%02X|",
			inet_ntoa( cfg->protaddr[i].ip.ia ),
			cfg->protaddr[i].mac.addr[0], cfg->protaddr[i].mac.addr[1], cfg->protaddr[i].mac.addr[2],
			cfg->protaddr[i].mac.addr[3], cfg->protaddr[i].mac.addr[4], cfg->protaddr[i].mac.addr[5] );
		if( cfg->protaddr[i].type & PROT_TYPE_HOST )
			{
			sec[len++] = 'h';
			}//end if
		if( cfg->protaddr[i].type & PROT_TYPE_GATEWAY )
			{
			sec[len++] = 'g';
			}//end if
		sec[len++] = '\0';
		}//end for
	sec[len++] = '\0';
	WritePrivateProfileSectionA( kProtectHostsSec, sec, file );
	delete [] sec;
}//end SaveNotifySpoof

#else // Linux
#include <glib.h>

const char kDefProtAddr[] = "192.168.0.125";
const char kDefProtValueWithComment[] = "00:00:00:00:00:00|hg # h: tell this host the true address; g: tell the gateway the true address";

bool LoadConfig( const char file[], Config *cfg, bool loadprotaddr )
{
	char buff[MAX_PATH_LEN];
	FILE* fp;
	GKeyFile *keyfile;
	GError *err;
	gchar *str;
	gchar **astr;
	char *p;
	gsize len;
	gsize i;
	bool succ;
	bool refill;
	bool modify;

	succ = true;

	keyfile = g_key_file_new();
	g_key_file_load_from_file( keyfile, file,
		static_cast<GKeyFileFlags>(G_KEY_FILE_KEEP_COMMENTS | G_KEY_FILE_KEEP_TRANSLATIONS), NULL );

	modify = false;

	refill = true;
	str = g_key_file_get_value( keyfile, kMainSec, kAdapterKey, NULL );
	if( str != NULL )
		{
		if( str[0] != '\0' && TestAdapterName( str ) )
			{
			strncpy( cfg->adapter, str, MAX_ADAPTER_NAME );
			cfg->adapter[MAX_ADAPTER_NAME-1] = '\0';
			refill = false;
			}//end if
		g_free( str );
		}//end if
	if( refill )
		{
		succ = false;
		g_key_file_set_value( keyfile, kMainSec, kAdapterKey, "" );
		modify = true;
		}//end if

	refill = true;
	str = g_key_file_get_value( keyfile, kMainSec, kNetmaskKey, NULL );
	if( str != NULL )
		{
		refill = !readip( str, &cfg->netmask );
		g_free( str );
		}//end if
	if( refill )
		{
		succ = false;
		g_key_file_set_value( keyfile, kMainSec, kNetmaskKey, kDefNetmask );
		modify = true;
		}//end if

	err = NULL;
	cfg->bindgateway = g_key_file_get_integer( keyfile, kMainSec, kBindGatewayKey, &err );
	if( err != NULL )
		{
		succ = false;
		g_key_file_set_integer( keyfile, kMainSec, kBindGatewayKey, kDefBindGateway );
		modify = true;
		}//end if

	err = NULL;
	cfg->autodetect = g_key_file_get_integer( keyfile, kMainSec, kAutoDetectKey, &err );
	if( err != NULL )
		{
		succ = false;
		g_key_file_set_integer( keyfile, kMainSec, kAutoDetectKey, kDefAutoDetect );
		modify = true;
		}//end if

	err = NULL;
	cfg->keepprotstat = g_key_file_get_integer( keyfile, kMainSec, kKeepProtStatKey, &err );
	if( err != NULL )
		{
		succ = false;
		g_key_file_set_integer( keyfile, kMainSec, kKeepProtStatKey, kDefKeepProtStat );
		modify = true;
		}//end if

	err = NULL;
	cfg->multiple = g_key_file_get_integer( keyfile, kMainSec, kMultipleKey, &err );
	if( err != NULL )
		{
		succ = false;
		g_key_file_set_integer( keyfile, kMainSec, kMultipleKey, kDefMultiple );
		modify = true;
		}//end if

	err = NULL;
	cfg->spoof_range = 1000 * g_key_file_get_integer( keyfile, kMainSec, kSpoofRangeSecKey, &err );
	if( err != NULL )
		{
		succ = false;
		g_key_file_set_integer( keyfile, kMainSec, kSpoofRangeSecKey, kDefSpoofRangeSec );
		modify = true;
		}//end if

	err = NULL;
	cfg->reply4gw = g_key_file_get_integer( keyfile, kMainSec, kReply4GwKey, &err );
	if( err != NULL )
		{
		succ = false;
		g_key_file_set_integer( keyfile, kMainSec, kReply4GwKey, kDefReply4Gw );
		modify = true;
		}//end if

	err = NULL;
	cfg->reply4h = g_key_file_get_integer( keyfile, kMainSec, kReply4HostsKey, &err );
	if( err != NULL )
		{
		succ = false;
		g_key_file_set_integer( keyfile, kMainSec, kReply4HostsKey, kDefReply4Hosts );
		modify = true;
		}//end if

	err = NULL;
	cfg->reply4hintv = g_key_file_get_integer( keyfile, kMainSec, kReply4HostsIntvKey, &err );
	if( err != NULL )
		{
		succ = false;
		g_key_file_set_integer( keyfile, kMainSec, kReply4HostsIntvKey, kDefReply4HostsIntv );
		modify = true;
		}//end if

	err = NULL;
	cfg->remotectrl = g_key_file_get_integer( keyfile, kMainSec, kRemoteCtrlKey, &err );
	if( err != NULL )
		{
		succ = false;
		g_key_file_set_integer( keyfile, kMainSec, kRemoteCtrlKey, kDefRemoteCtrl );
		cfg->remotectrl = kDefRemoteCtrl;
		modify = true;
		}//end if

	err = NULL;
	cfg->rc_port = g_key_file_get_integer( keyfile, kMainSec, kRemoteCtrlPortKey, &err );
	if( err != NULL && cfg->remotectrl )
		{
		succ = false;
		g_key_file_set_integer( keyfile, kMainSec, kRemoteCtrlPortKey, kDefRemoteCtrlPort );
		modify = true;
		}//end if
		
	refill = true;
	str = g_key_file_get_value( keyfile, kMainSec, kRemoteCtrlPswdKey, NULL );
	if( str != NULL )
		{
		strncpy( cfg->rc_pswd, str, MAX_PSWD_LEN );
		cfg->rc_pswd[MAX_PSWD_LEN-1] = '\0';
		refill = false;
		g_free( str );
		}//end if
	if( refill && cfg->remotectrl )
		{
		succ = false;
		g_key_file_set_value( keyfile, kMainSec, kRemoteCtrlPswdKey, kDefRemoteCtrlPswd );
		modify = true;
		}//end if

	refill = true;
	str = g_key_file_get_value( keyfile, kMainSec, kLogFileKey, NULL );
	if( str != NULL )
		{
		strncpy( cfg->logfile, str, MAX_PATH_LEN );
		cfg->logfile[MAX_PATH_LEN-1] = '\0';
		refill = false;
		g_free( str );
		}//end if
	if( refill )
		{
		succ = false;
		GetLogFullName( kDefLogFile, buff );
		g_key_file_set_value( keyfile, kMainSec, kLogFileKey, buff );
		modify = true;
		}//end if

	refill = true;
	str = g_key_file_get_value( keyfile, kMainSec, kLocalAddrKey, NULL );
	if( str != NULL )
		{
		if( readip( str, &cfg->local.ip ) )
			{
			p = strchr( str, kSplitter );
			if( p != NULL && *p != '\0' && readmac( p + 1, &cfg->local.mac ) )
				{
				refill = false;
				}//end if
			}//end if
		g_free( str );
		}//end if
	if( refill )
		{
		succ = false;
		g_key_file_set_value( keyfile, kMainSec, kLocalAddrKey, kDefLocalAddr );
		modify = true;
		}//end if

	refill = true;
	str = g_key_file_get_value( keyfile, kMainSec, kGatewayAddrKey, NULL );
	if( str != NULL )
		{
		if( readip( str, &cfg->gateway.ip ) )
			{
			p = strchr( str, kSplitter );
			if( p != NULL && *p != '\0' && readmac( p + 1, &cfg->gateway.mac ) )
				{
				refill = false;
				}//end if
			}//end if
		g_free( str );
		}//end if
	if( refill )
		{
		succ = false;
		g_key_file_set_value( keyfile, kMainSec, kGatewayAddrKey, kDefGatewayAddr );
		modify = true;
		}//end if

	if( !succ )
		{
		astr = g_key_file_get_keys( keyfile, kProtectHostsSec, NULL, NULL );
		if( astr == NULL )
			{
			g_key_file_set_value( keyfile, kProtectHostsSec, kDefProtAddr, kDefProtValueWithComment );
			modify = true;
			}
		else{
			g_strfreev( astr );
			}//endif
		}//end if
	
	cfg->prot_num = 0;
	cfg->protaddr = NULL;
	if( loadprotaddr )
		{
		astr = g_key_file_get_keys( keyfile, kProtectHostsSec, &len, NULL );
		if( astr != NULL )
			{
			cfg->protaddr = new ProtAddr[len];
			for( i = 0; i < len; ++i )
				{
				p = astr[i];
				if( readip( p, &cfg->protaddr[cfg->prot_num].ip ) )
					{
					str = g_key_file_get_value( keyfile, kProtectHostsSec, p, NULL );
					if( str != NULL )
						{
						if( readmac( str, &cfg->protaddr[cfg->prot_num].mac ) )
							{
							p = strchr( str, kSplitter );
							if( p != NULL )
								{
								for( ++p; isspace( *p ); ++p );//end for
								cfg->protaddr[cfg->prot_num].type = 0;
								if( *p != '\0' )
									{
									if( p[0] == kTypeHost || p[1] == kTypeHost )
										{
										cfg->protaddr[cfg->prot_num].type |= PROT_TYPE_HOST;
										}//end if
									if( p[0] == kTypeGateway || p[1] == kTypeGateway )
										{
										cfg->protaddr[cfg->prot_num].type |= PROT_TYPE_GATEWAY;
										}//end if
									}//end if
								++cfg->prot_num;
								}//end if
							}//end if
						g_free( str );
						}//end if
					}//end if
				}//end for
			g_strfreev( astr );
			}//end if
		}//end if

	if( modify )
		{
		str = g_key_file_to_data( keyfile, &len, NULL );
		fp = fopen( file, "w" );
		if( fp != NULL )
			{
			fwrite( str, len, 1, fp );
			fclose( fp );
			}//end if
		g_free( str );
		}//end if

	g_key_file_free( keyfile );

	if( succ )
		{
		succ = !CheckAbuse( cfg );
		}//end if

	return succ;
}//end LoadConfig

bool LoadNotifySpoof( const char file[], bool* notifyspoof )
{
	GKeyFile *keyfile;
	GError *err;
	bool succ = false;

	keyfile = g_key_file_new();
	if( g_key_file_load_from_file( keyfile, file,
			static_cast<GKeyFileFlags>(G_KEY_FILE_KEEP_COMMENTS | G_KEY_FILE_KEEP_TRANSLATIONS), NULL ) )
		{
		*notifyspoof = g_key_file_get_integer( keyfile, kMainSec, kNotifySpoofKey, &err );
		if( err == NULL )
			{
			succ = true;
			}//end if
		}//end if
	g_key_file_free( keyfile );

	return succ;
}//end LoadNotifySpoof

void SaveAllConfig( const char file[], const Config* cfg, bool notifyspoof )
{
	char buff[64];
	FILE* fp;
	GKeyFile *keyfile;
	gchar *str;
	gsize len;
	int i;

	keyfile = g_key_file_new();

	g_key_file_set_value( keyfile, kMainSec, kAdapterKey, cfg->adapter );

	g_key_file_set_value( keyfile, kMainSec, kNetmaskKey,
			inet_ntoa( cfg->netmask.ia ) );

	g_key_file_set_integer( keyfile, kMainSec, kBindGatewayKey, cfg->bindgateway );

	g_key_file_set_integer( keyfile, kMainSec, kAutoDetectKey, cfg->autodetect );

	g_key_file_set_integer( keyfile, kMainSec, kKeepProtStatKey, cfg->keepprotstat );

	g_key_file_set_integer( keyfile, kMainSec, kMultipleKey, cfg->multiple );

	g_key_file_set_integer( keyfile, kMainSec, kSpoofRangeSecKey, cfg->spoof_range / 1000 );

	g_key_file_set_integer( keyfile, kMainSec, kReply4GwKey, cfg->reply4gw );

	g_key_file_set_integer( keyfile, kMainSec, kReply4HostsKey, cfg->reply4h );

	g_key_file_set_integer( keyfile, kMainSec, kReply4HostsIntvKey, cfg->reply4hintv );

	g_key_file_set_integer( keyfile, kMainSec, kRemoteCtrlKey, cfg->remotectrl );

	g_key_file_set_integer( keyfile, kMainSec, kRemoteCtrlPortKey, cfg->rc_port );
		
	g_key_file_set_value( keyfile, kMainSec, kRemoteCtrlPswdKey, cfg->rc_pswd );

	g_key_file_set_value( keyfile, kMainSec, kLogFileKey, cfg->logfile );

	sprintf( buff, "%s|%02X:%02X:%02X:%02X:%02X:%02X",
		inet_ntoa( cfg->local.ip.ia ),
		cfg->local.mac.addr[0], cfg->local.mac.addr[1], cfg->local.mac.addr[2],
		cfg->local.mac.addr[3], cfg->local.mac.addr[4], cfg->local.mac.addr[5] );
	g_key_file_set_value( keyfile, kMainSec, kLocalAddrKey, buff );

	sprintf( buff, "%s|%02X:%02X:%02X:%02X:%02X:%02X",
		inet_ntoa( cfg->gateway.ip.ia ),
		cfg->gateway.mac.addr[0], cfg->gateway.mac.addr[1], cfg->gateway.mac.addr[2],
		cfg->gateway.mac.addr[3], cfg->gateway.mac.addr[4], cfg->gateway.mac.addr[5] );
	g_key_file_set_value( keyfile, kMainSec, kGatewayAddrKey, buff );

	g_key_file_set_integer( keyfile, kMainSec, kNotifySpoofKey, notifyspoof );

	for( i = 0; i < cfg->prot_num; ++i )
		{
		len = sprintf( buff, "%02X:%02X:%02X:%02X:%02X:%02X|",
				cfg->protaddr[i].mac.addr[0], cfg->protaddr[i].mac.addr[1], cfg->protaddr[i].mac.addr[2],
				cfg->protaddr[i].mac.addr[3], cfg->protaddr[i].mac.addr[4], cfg->protaddr[i].mac.addr[5] );
		if( cfg->protaddr[i].type & PROT_TYPE_HOST )
			{
			buff[len++] = 'h';
			}//end if
		if( cfg->protaddr[i].type & PROT_TYPE_GATEWAY )
			{
			buff[len++] = 'g';
			}//end if
		buff[len++] = '\0';
		g_key_file_set_value( keyfile, kProtectHostsSec, inet_ntoa( cfg->protaddr[i].ip.ia ), buff );
		}//end for

	str = g_key_file_to_data( keyfile, &len, NULL );
	fp = fopen( file, "w" );
	if( fp != NULL )
		{
		fwrite( str, len, 1, fp );
		fclose( fp );
		}//end if
	g_free( str );

	g_key_file_free( keyfile );
}//end SaveAllConfig

#endif

void CleanupProtAddr( Config *cfg )
{
	delete [] cfg->protaddr;
	cfg->protaddr = NULL;
	cfg->prot_num = 0;
}//end CleanupProtAddr
