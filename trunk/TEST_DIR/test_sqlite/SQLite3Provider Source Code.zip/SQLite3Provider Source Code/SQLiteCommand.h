#pragma once

#include "config.h"

namespace sqlite3provider
{
	class SQLiteCommand
	{
		friend class SQLiteDataReader;
		friend class SQLiteParameter;

	public:
		explicit SQLiteCommand(const SQLiteConnection& connection);
		SQLiteCommand(const SQLiteConnection& connection, const string& commandText);
		SQLiteCommand(const SQLiteCommand& other);
		~SQLiteCommand(void);

	private:
		SQLiteCommand& operator=(const SQLiteCommand& );

	public:
		void setCommandText(const string& commandText);
		SQLiteParameter createParameter(void);
		int executeNonQuery(void);
		int executeScalar(void);
		const SQLiteDataReader executeReader(void);
		void fill(SQLiteDataTable& dataTable);

	private:
		void prepare(void);
		bool step(void);
		void reset(void);
		void finalize(void);

	public:
		const SQLiteConnection& connection;
		
	private:
		struct sqlite3_stmt* _stmt;
		string _commandText;
	};
}