#pragma once

#include "config.h"

namespace sqlite3provider
{
	class SQLiteConnection
	{
		friend class SQLiteException;
		friend class SQLiteCommand;
		friend class SQLiteTransaction;
		friend class SQLiteDataReader;
		friend class SQLiteDataTable;

	public:
		explicit SQLiteConnection(const string& name);
		~SQLiteConnection(void);

	private:
		SQLiteConnection(const SQLiteConnection& );
		SQLiteConnection& operator=(const SQLiteConnection& );

	public:
		void open(void);
		void close(void);

		SQLiteTransaction beginTransaction(void) const;
		void setBusyTimeout(const int millisecond) const;

	private:
		void execute(const string& sql, int (*callback)(void*, int, char**, char**) = NULL, void* argument = NULL) const;
		void isOpened(void) const; 

	public:
		const string name;
		const string version;

	private:
		struct sqlite3* _db;
		mutable bool _inTransaction;
	};
}
