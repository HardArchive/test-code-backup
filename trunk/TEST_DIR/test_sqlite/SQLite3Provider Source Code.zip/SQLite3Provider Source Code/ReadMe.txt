SQLite3������C++��װ��⣬ʹ�÷�������Microsoft.net��Data Provider, ���¸��µ�sqlite3��3.6.3�汾�������Ҫ����sqlite3�İ汾����

http://www.sqlite.org/download.html

�������µ�amalgamation ��ʽԴ�룬����sqlite3.h��sqlite3.c�����ļ������±��뼴�ɡ�

����ʹ�÷����μ�����ʾ����

#include "sqlite3provider.h"

int main() {

    try {

        SQLiteConnection conn("test.db"); 

    cout << conn.version << endl; cout << conn.name << endl; 

    conn.open(); 

    SQLiteTransaction trans = conn.beginTransaction(); 

    //================================================================ 

    SQLiteCommand cmd(conn); cmd.setCommandText("create table IF NOT EXISTS TABLE_TEST( ID integer primary key autoincrement, field1 varchar(10), field2 int, field3 double, field4 BLOB)"); cmd.executeNonQuery(); 

    cmd.setCommandText("insert into TABLE_TEST( field1, field2, field3, field4) values( ?, ?, ?, ? ); "); 

    SQLiteParameter param1(cmd); param1.bind(1, "abc"); 

    SQLiteParameter param2 = cmd.createParameter(); param2.bind(2, 100); 

    SQLiteParameter param3 = cmd.createParameter(); param3.bind(3, 80.2345345); 

    char dt = new char1024; memset(dt, 97, 1024); 

    SQLiteParameter param4(cmd); param4.bind(4, dt, 1024); 

    delete dt; 

    cmd.executeNonQuery(); //cmd.executeScalar(); 

    //================================================================ 

    /SQLiteDataTable table_test(conn, "select from TABLE_TEST"); SQLiteDataTable table = table_test; 

    for (int i = 0; i < table.rows(); i++) {

        cout << "row:" << i << endl; for (int j = 0; j < table.columns(); j++) {

            cout << table.getFieldName(j) << ": " << table.getFieldValue(i, j) << endl; 

        } cout << endl; 

    } 

    //================================================================ 

    SQLiteCommand cmd2(conn, "select from TABLE_TEST"); SQLiteDataReader dr = cmd2.executeReader(); 

    while (dr.read()) {

        for (int i = 0; i < dr.getFieldCount(); i++) {

            if (!dr.isDbNull(i)) {

                cout << dr.getFieldName(i) << "[" << dr.getDataTypeName(i) << "]:"; switch(dr.getFieldDbType(i)) { case sqlite3provider::DT_INTERGER:

                    cout << dr.getInt32(i) << endl; break; 

                case sqlite3provider::DT_FLOAT:

                    cout << dr.getFloat(i) << endl; break; 

                case sqlite3provider::DT_TEXT:

                    cout << dr.getString(i) << endl; break; 

                case sqlite3provider::DT_BLOB:

                    cout << dr.getBLOB(i) << endl; break; 

                } 

    } 

    } cout << endl; 

    } 

    //================================================================ 

    trans.commit(); conn.close(); 

    } catch (SQLiteException& e) {

        cout << e.what() << endl; 

    } 

    cout << "All command has been executed!" << endl; cin.get(); 

} 