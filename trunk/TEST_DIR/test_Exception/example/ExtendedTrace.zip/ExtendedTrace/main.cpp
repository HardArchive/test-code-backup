// main.cpp : Defines the entry point for the console application.
//

#include <windows.h>
#include <tchar.h>
#include <time.h>

#include "ExtendedTrace.h"

void g ( LPTSTR )
{
	STACKTRACE();
}

void f( int, int, int )
{
	FNPARAMTRACE();

	g( NULL );
}

int main( int, char** )
{
	TRACEF( _T("Application started at %d\n"), clock() );

	EXTENDEDTRACEINITIALIZE( NULL );

	SRCLINKTRACE( _T("I'm calling f(...)\n") );

	f( 1, 2, 3);

	EXTENDEDTRACEUNINITIALIZE();

	TRACEF( _T("Application ended at %d\n"), clock() );

	return 0;
}
