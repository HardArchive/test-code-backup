//------------------------------------------------------------------------------
//      Author:	Martin Johannes Isaak Brandl 
//              mjibrandl@googlemail.com
//
// Description: Determines the file version of a specific file.
//
//        Date: 05.05.2010
//
//     License: This file is Copyright � 2010 Martin Johannes Isaak Brandl.
//				All Rights Reserved.
//              This software is released under the Code Project Open License 
//              (CPOL), which may be found here:  
//				http://www.codeproject.com/info/eula.aspx
//------------------------------------------------------------------------------
#include "stdafx.h"

#include "FileVersion.hpp"

#include <Windows.h>
#include <vector>
#include <atlstr.h>

// Look for version.lib
#pragma comment( lib, "version.lib" )

// Default format string when GetFileVersion() is called with 1 argument
const TCHAR FileVersion::kVersionFormat[]	= _T("%i.%i.%i.%i");

FileVersion::FileVersion( const TCHAR * kstrFilePath )
: mbVersionIsValid ( false )
{
	mbVersionIsValid = DetermineFileVersion( kstrFilePath );
}


FileVersion::FileVersion()
: mbVersionIsValid ( false )
{
	TCHAR	strTempBuffer[ MAX_PATH ];
	// Retrieve the fully-qualified path from the current process
	if ( NULL == ::GetModuleFileName( NULL	// Current module
		, strTempBuffer
		, MAX_PATH ) )
		return;	// Can't retrieve path from current process

	mbVersionIsValid = DetermineFileVersion( strTempBuffer );
}

FileVersion::~FileVersion(void)
{
}



bool FileVersion::DetermineFileVersion( const TCHAR* kstrFilePath )
{
	// Precondition
	if ( NULL == kstrFilePath )
		return false; // FilePath is empty, no file to determine version.

	DWORD	dwHandle;

	// Determines whether the operating system can retrieve version information
	// for a specified file.
	DWORD	dwFileVersionInfoSize = 
		GetFileVersionInfoSize( kstrFilePath, &dwHandle );

	if ( NULL == dwFileVersionInfoSize )
		return false;	// Can't retrieve version information size.

	// Allocate space to retrieve version information using vector to prevent
	// memory leaks
	std::vector<BYTE>	pData( dwFileVersionInfoSize );

	// Retrieves version information for the specified file.
	if ( false == GetFileVersionInfo( kstrFilePath
		, dwHandle
		, dwFileVersionInfoSize
		, static_cast<LPVOID>( &pData[0] ) ) )
		return false; // Can't retrieve version information.

	// The memory of ptFileInfo is freed when pData is freed.
	VS_FIXEDFILEINFO *ptFileInfo;
	UINT	uintSize;

	// Retrieves version information from the version-information resource
	if ( false == VerQueryValue( static_cast<LPVOID>( &pData[0] )
		, _T("\\")
		, reinterpret_cast<LPVOID*> ( &ptFileInfo )
		, &uintSize ) )
		return false; // Can't retrieve version information

	// Resolve major, minor, release and build number.
	musMajorVersion		= static_cast<unsigned short>(  
		( ptFileInfo->dwFileVersionMS >> 16 ) &0xffff );

	musMinorVersion		= static_cast<unsigned short>( 
		ptFileInfo->dwFileVersionMS &0xffff );

	musReleaseNumber	= static_cast<unsigned short>( 
		( ptFileInfo->dwFileVersionLS >> 16 ) &0xffff);

	musBuildNumber		= static_cast<unsigned short>( 
		ptFileInfo->dwFileVersionLS & 0xffff );

	return true;
}


bool FileVersion::GetFileVersion( const TCHAR* kstrFileFormat
								 , CString& strFileVersion ) const
{

	// Precondition
	if ( NULL == kstrFileFormat )
		return false; // Null Pointer.

	if ( false == mbVersionIsValid )
		return false; // This version is not valid.

	// Format the string
	strFileVersion.Format( kstrFileFormat
		, musMajorVersion
		, musMinorVersion
		, musReleaseNumber
		, musBuildNumber);

	return true;
}

bool FileVersion::GetFileVersion( CString& strFileVersion ) const
{
	return GetFileVersion( kVersionFormat, strFileVersion );
}


bool FileVersion::IsEqual( const FileVersion & krhs ) const
{
	if ( musMajorVersion != krhs.musMajorVersion )
		return false;

	if ( musMinorVersion != krhs.musMinorVersion )
		return false;

	if ( musReleaseNumber != krhs.musReleaseNumber )
		return false;

	return musBuildNumber == krhs.musBuildNumber;
}


// Comparator: Less then
bool FileVersion::operator<( const FileVersion & krhs ) const
{
	if ( musMajorVersion < krhs.musMajorVersion )
		return true;

	if ( musMajorVersion > krhs.musMajorVersion )
		return false;

	if ( musMinorVersion < krhs.musMinorVersion )
		return true;

	if ( musMinorVersion > krhs.musMinorVersion )
		return false;

	if ( musReleaseNumber < krhs.musReleaseNumber )
		return true;

	if ( musReleaseNumber > krhs.musReleaseNumber )
		return false;

	return musBuildNumber < krhs.musBuildNumber;
}


// Comparator: Greater then
bool FileVersion::operator>( const FileVersion & krhs ) const
{
	if ( true == this->IsEqual( krhs) )
		return false; // Equal file version

	// File version is greater if its not equal and not less then passed 
	// version.
	return ( false == ( this->operator<( krhs ) ) );
}


// Operator: Equal
bool FileVersion::operator==( const FileVersion & krhs ) const
{
	return IsEqual( krhs );
}



