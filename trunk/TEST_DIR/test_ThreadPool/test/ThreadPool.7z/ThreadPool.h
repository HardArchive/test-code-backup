#pragma once
/***************************************************************************************************
* 1�� Class      �� CThreadPool.c
* 2�� Version    �� *.*
* 3�� Description�� 
* 4�� Author     �� QNA (http://www.9cpp.com/)
* 5�� Created    �� 2012-10-17 10:08:32
* 6�� History    �� 
* 7�� Remark     �� �������ڲ�����������vector��һ���Ǵ��浱ǰ���е��̣߳�����һ���Ǵ���ȴ����е��̣߳�
*				    �����m_nMaxThreadCount������������init�̳߳ص�ʱ����һ��PeekMessage(&msg,0,WM_USER,WM_USER,PM_NOREMOVE);��䣬
*				    ��ǿ�ƴ�����Ϣ���С�
*				    Ȼ�����Ǳ�������̵߳���Ϣ�����н�����Ϣ�������̵߳����У�
*				    ��idilʱ���̳߳ػ��Զ��Ƴ���ǰ����vector����ֹ���̣߳��ӵȴ�vector����������е��̣߳�
*				    �����WM_THREADSTART��Ϣ�����ȼ���ȷ�����߳��ܼ�ʹ����
****************************************************************************************************/
#pragma once
#include <iostream>
#include <vector>
#include <windows.h>
using namespace std;

#define WM_THREADSTART    WM_USER+1
#define WM_THREADEND      WM_USER+2
#define WM_THREADADD      WM_USER+3
#define WM_THREADPOOLEND  WM_USER+4
#define WM_THREADPOOLIDIL WM_USER+5



class ThreadPool
{
public:
	typedef DWORD (WINAPI *ThreadFunc)(LPVOID);
	typedef struct _sThread
	{
		HANDLE     m_hThread;  //�߳̾��
		ThreadFunc m_fFunc;    //�߳�ִ�к���ָ��
		void*      m_vParam;
		DWORD      m_dRetval;
	} sThread, *spThread;

	typedef void (*CallBackFunc)(UINT, spThread);
public:
	ThreadPool(void)
	{
		m_iThread = 0;
		m_fFunc = 0;
		m_hThread = 0;
		InitializeCriticalSection(&m_cs);
	}

	~ThreadPool(void)
	{
		PostThreadMessage(m_iThread, WM_THREADPOOLEND, 0, 0);
		WaitForSingleObject(m_hThread, -1);
		CloseHandle(m_hThread);
		LeaveCriticalSection(&m_cs);
		int i;
		for(i = 0; i < m_qRun.size(); i++)
		{
			delete m_qRun[i];
		}
		for(i = 0; i < m_qWait.size(); i++)
		{
			delete m_qWait[i];
		}
	}


	void AddTask(ThreadFunc func, LPVOID lp, bool bImme)
	{
		if(!bImme)
		{
			PostThreadMessage(m_iThread, WM_THREADADD, (WPARAM)func, (LPARAM)lp);
		}
		else
		{
			spThread sTh = new sThread;
			sTh->m_dRetval = 0;
			sTh->m_hThread = 0;
			sTh->m_fFunc = func;
			sTh->m_vParam = lp;
			EnterCriticalSection(&m_cs);
			m_qWait.insert(m_qWait.begin(), sTh);
			LeaveCriticalSection(&m_cs);
		}
		PostThreadMessage(m_iThread, WM_THREADPOOLIDIL, 0, 0);

	}

	void Init(CallBackFunc func, int count/* =10000 */)
	{
		if(func != NULL)  m_fFunc = func;
		if(count > 0)    m_nMaxThreadCount = count;
		m_hEvent = CreateEvent(0, TRUE, FALSE, 0);
		m_hThread = CreateThread(0, 0, Thread, this, 0, &m_iThread);
		WaitForSingleObject(m_hEvent, -1);
		CloseHandle(m_hEvent);
	}

	DWORD WINAPI Thread(LPVOID lp)
	{
		CThreadPool *pThPool = (CThreadPool *)lp;
		DWORD dwCurId = GetCurrentThreadId();
		MSG msg;
		PeekMessage(&msg, 0, WM_USER, WM_USER, PM_NOREMOVE);
		SetEvent(pThPool->m_hEvent);
		while (1)
		{
			Sleep(1);

			if(PeekMessage(&msg, 0, WM_THREADSTART, WM_THREADPOOLIDIL, PM_REMOVE))
			{

				switch (msg.message)
				{
				case WM_THREADPOOLEND:
					{
						return true;
					}
				case WM_THREADSTART:
					{
						spThread sTh = (spThread)msg.wParam;
						sTh->m_hThread = CreateThread(0, 0, sTh->m_fFunc, sTh->m_vParam, 0, 0);
						if(pThPool->m_fFunc)  pThPool->m_fFunc(WM_THREADSTART, sTh);
						break;
					}
				case WM_THREADEND:
					{
						spThread sTh = (spThread)msg.wParam;
						if(pThPool->m_fFunc)  pThPool->m_fFunc(WM_THREADEND, sTh);
						delete sTh;
						CloseHandle(sTh->m_hThread);
						break;
					}
				case WM_THREADADD:
					{
						CThreadPool::spThread sTh = new CThreadPool::sThread;
						sTh->m_dRetval = 0;
						sTh->m_hThread = 0;
						sTh->m_fFunc = (ThreadFunc)msg.wParam;
						sTh->m_vParam = (LPVOID)msg.lParam;
						EnterCriticalSection(&(pThPool->m_cs));
						pThPool->m_qWait.push_back(sTh);
						LeaveCriticalSection(&(pThPool->m_cs));
						break;
					}
				case WM_THREADPOOLIDIL:
					{
						goto IDIL;
					}
				}
			}
			else
			{
IDIL:
				vector<CThreadPool::spThread> &vObj = pThPool->m_qRun;
				for(int i = 0; i < vObj.size(); i++)
				{
					DWORD iExitCode;
					GetExitCodeThread(vObj[i]->m_hThread, &iExitCode);
					if(iExitCode != STILL_ACTIVE)
					{
						vObj[i]->m_dRetval = iExitCode;
						PostThreadMessage(dwCurId, WM_THREADEND, (WPARAM)vObj[i], 0);
						vObj.erase(vObj.begin() + i);
						i--;
					}
				}
				if(vObj.size() < pThPool->m_nMaxThreadCount)
				{
					int nCount = pThPool->m_nMaxThreadCount - vObj.size();
					while(nCount)
					{
						if(pThPool->m_qWait.size() > 0)
						{
							EnterCriticalSection(&(pThPool->m_cs));
							vObj.push_back(pThPool->m_qWait[0]);
							pThPool->m_qWait.erase(pThPool->m_qWait.begin());
							LeaveCriticalSection(&(pThPool->m_cs));
							PostThreadMessage(dwCurId, WM_THREADSTART, (WPARAM)vObj[vObj.size() - 1], 0);
							while(1)
							{
								MSG msgtemp;
								PeekMessage(&msgtemp, 0, WM_THREADSTART, WM_THREADPOOLIDIL, PM_NOREMOVE);
								if(msgtemp.message != WM_THREADSTART)
								{
									PeekMessage(&msgtemp, 0, WM_THREADSTART, WM_THREADPOOLIDIL, PM_REMOVE);
									PostThreadMessage(dwCurId, msgtemp.message, msgtemp.wParam, msgtemp.lParam);
								}
								else
								{
									break;
								}
							}
						}
						else
						{
							break;
						}
						nCount--;
					}
				}

			}
		}
		return 0;
	}

	DWORD GetRunThreadCount()
	{
		return m_qRun.size();
	}

	spThread GetRunThreadItem(int nIndex)
	{
		return m_qRun[nIndex];
	}

	DWORD GetWaitThreadCount()
	{
		return m_qWait.size();
	}

	spThread GetWaitThreadItem(int nIndex)
	{
		return m_qWait[nIndex];
	}


private:
	static DWORD WINAPI Thread(LPVOID);
	DWORD m_iThread;
	HANDLE m_hThread;
	CallBackFunc m_fFunc;
	DWORD m_nMaxThreadCount;
	vector<spThread> m_qRun;   //��ǰ�����߳�

	vector<spThread> m_qWait;  //�ȴ��е��߳�
	HANDLE m_hEvent;
	CRITICAL_SECTION m_cs;
};
