//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Calendar.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDC_YEAREDIT                    101
#define IDD_CALENDAR_DIALOG             102
#define IDC_MONTHSELECT                 102
#define IDC_YEARSELECT                  103
#define IDC_BUTTODAY                    105
#define IDC_CALENDARFRM                 106
#define IDC_CALENDAR                    107
#define ID_TITLEBKCOLOR                 108
#define ID_TITLECOLOR                   109
#define ID_SELCOLOR                     110
#define ID_FORECOLOR                    111
#define IDR_MAINFRAME                   128
#define IDB_BITMAP1                     191
#define IDB_BITMAP2                     192
#define IDB_BITMAP3                     193
#define IDB_BITMAP4                     194
#define IDB_BITMAP5                     195
#define IDB_BITMAP6                     196
#define IDB_BITMAP7                     197
#define IDB_BITMAP8                     198
#define IDB_BITMAP9                     199
#define IDB_BITMAP10                    200
#define IDB_BITMAP11                    201
#define IDB_BITMAP12                    202
#define IDB_BITMAP13                    203
#define IDB_BITMAP14                    204
#define IDB_BITMAP15                    205
#define IDB_BITMAP16                    206
#define IDB_BITMAP17                    207
#define IDB_BITMAP18                    208
#define IDB_BITMAP19                    209
#define IDB_BITMAP20                    210
#define IDB_BITMAP21                    211
#define IDB_BITMAP22                    212
#define IDB_BITMAP23                    213
#define IDB_BITMAP24                    214
#define IDB_BITMAP25                    215
#define IDB_BITMAP26                    216
#define IDB_BITMAP27                    217
#define IDB_BITMAP28                    218
#define IDB_BITMAP29                    219
#define IDB_BITMAP30                    220
#define IDB_BITMAP31                    221
#define IDB_BITMAP32                    222
#define IDB_BITMAP33                    223
#define IDB_BITMAP34                    224
#define IDB_BITMAP35                    225
#define IDB_BITMAP36                    226
#define IDB_BITMAP37                    227
#define IDB_BITMAP38                    228
#define IDB_BITMAP39                    229
#define IDB_BITMAP40                    230
#define IDB_BITMAP41                    231
#define IDB_BITMAP42                    232
#define IDC_BUTTON1                     1000

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        242
#define _APS_NEXT_COMMAND_VALUE         32776
#define _APS_NEXT_CONTROL_VALUE         1029
#define _APS_NEXT_SYMED_VALUE           112
#endif
#endif
