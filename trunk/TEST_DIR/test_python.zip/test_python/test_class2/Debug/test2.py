#Filename test.py 
class TestClass: 
    def __init__(self,name): 
		self.name = name 
	
    def printName(self): 
		print self.name 