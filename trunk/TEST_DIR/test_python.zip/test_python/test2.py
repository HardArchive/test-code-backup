#Filename test.py 
def Hello():
    print "Hello, world!" 