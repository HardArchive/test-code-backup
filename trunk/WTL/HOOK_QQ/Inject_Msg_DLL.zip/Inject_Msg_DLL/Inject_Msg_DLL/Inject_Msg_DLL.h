// Inject_Msg_DLL.h
