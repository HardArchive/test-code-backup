//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by MsgMapper.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDD_MAINDLG                     129
#define IDC_MSGLIST                     1000
#define IDC_EDITCODE                    1001
#define IDC_COPY1                       1002
#define IDC_COPY2                       1003
#define IDC_COPY3                       1004
#define IDC_EDIT1                       1006
#define IDC_CLASSNAME                   1006
#define IDC_BUTTON1                     1007
#define IDC_COPY4                       1007

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        201
#define _APS_NEXT_COMMAND_VALUE         32772
#define _APS_NEXT_CONTROL_VALUE         1008
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
