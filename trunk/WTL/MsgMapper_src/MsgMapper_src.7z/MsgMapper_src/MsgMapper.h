// MsgMapper.h
