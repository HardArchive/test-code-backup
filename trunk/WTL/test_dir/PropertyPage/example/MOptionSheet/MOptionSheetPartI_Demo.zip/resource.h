//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by OptionSheetPartOne.rc
//
#define IDD_ABOUTBOX                    100
#define IDD_OPTIONPAGE_ABOUT            102
#define IDD_OPTIONPAGE_GENERAL          109
#define IDR_MAINFRAME                   128
#define IDD_MAINDLG                     129
#define IDD_MYOPTIONSHEET               132
#define IDC_MYOPTIONSHEET               1000
#define IDC_MYPROPSHEET                 1001
#define IDC_VERSION                     1002
#define IDC_COPYRIGHT                   1008
#define IDC_CHECK                       1008
#define IDC_EDIT                        1009

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        201
#define _APS_NEXT_COMMAND_VALUE         32772
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
