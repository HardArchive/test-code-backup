// AppOptions.h: interface for the CAppOptions class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_APPOPTIONS_H__3A058489_2705_4C4C_B74F_B761681D3538__INCLUDED_)
#define AFX_APPOPTIONS_H__3A058489_2705_4C4C_B74F_B761681D3538__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


struct CGeneralOptions
{
	CString Name;
	bool Enable;
};

struct CAppOptions
{
	CGeneralOptions Default;
	CGeneralOptions Current;

	// Dummies, in real life you should really load or save the options
	void Load() {}
	void Save() {}
};

#endif // !defined(AFX_APPOPTIONS_H__3A058489_2705_4C4C_B74F_B761681D3538__INCLUDED_)
