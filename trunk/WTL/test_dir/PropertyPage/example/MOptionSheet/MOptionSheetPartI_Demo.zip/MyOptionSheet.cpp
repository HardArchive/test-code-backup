// MyOptionSheet.cpp: implementation of the CMyOptionSheet class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "MyOptionSheet.h"

//////////////////////////////////////////////////////////////////////

// See this file to know why to include a .cpp
#include <MOptionSheet.cpp>

//////////////////////////////////////////////////////////////////////

bool CMyOptionSheet::DoInit(bool FirstTime)
{
	if (FirstTime)
	{
		m_PageAbout.Create(this);
		m_PageGeneral.Create(this);
	}

	AddItem(new COptionItem(NULL, &m_PageAbout));
	AddItem(new CMyOptionItem("Default", &m_PageGeneral, &m_pOptions->Default));
	AddItem(new CMyOptionItem("Current", &m_PageGeneral, &m_pOptions->Current));

	return COptionSheet::DoInit(FirstTime);
}

void CMyOptionSheet::SetOptions(CAppOptions *pOptions)
{
	m_pOptions = pOptions;
}

void CMyOptionSheet::OnOK(UINT uCode, int nID, HWND hWndCtl)
{
	COptionSheet::OnOK(uCode, nID, hWndCtl);
	m_pOptions->Save();
}

void CMyOptionSheet::OnApply(UINT uCode, int nID, HWND hWndCtl)
{
	COptionSheet::OnApply(uCode, nID, hWndCtl);
	m_pOptions->Save();
}

void CMyOptionSheet::OnCancel(UINT uCode, int nID, HWND hWndCtl)
{
	COptionSheet::OnCancel(uCode, nID, hWndCtl);
	m_pOptions->Load();	// Reload the saved options
}
