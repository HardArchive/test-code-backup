// OptionPageAbout.h: interface for the COptionPageAbout class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_OPTIONPAGEABOUT_H__EE487897_14E5_4CB1_8298_5CF7A1A30A25__INCLUDED_)
#define AFX_OPTIONPAGEABOUT_H__EE487897_14E5_4CB1_8298_5CF7A1A30A25__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "resource.h"
#include <MOptionPage.h>

class COptionPageAbout : public Mortimer::COptionPageImpl<COptionPageAbout>
{
public:
	enum { IDD = IDD_OPTIONPAGE_ABOUT };

	DECLARE_EMPTY_MSG_MAP()
};

#endif // !defined(AFX_OPTIONPAGEABOUT_H__EE487897_14E5_4CB1_8298_5CF7A1A30A25__INCLUDED_)
