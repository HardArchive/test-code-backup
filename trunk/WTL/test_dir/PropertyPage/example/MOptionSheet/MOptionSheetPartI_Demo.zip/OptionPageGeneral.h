// OptionPageGeneral.h: interface for the COptionPageGeneral class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_OPTIONPAGEGENERAL_H__723F378D_C5CD_4C63_AC4F_2B54CF399118__INCLUDED_)
#define AFX_OPTIONPAGEGENERAL_H__723F378D_C5CD_4C63_AC4F_2B54CF399118__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "resource.h"
#include <MOptionPage.h>
using Mortimer::COptionItem;

#include "AppOptions.h"
#include "MyOptionSheet.h"

class COptionPageGeneral : public Mortimer::COptionPageImpl<COptionPageGeneral>
{
public:
	enum { IDD = IDD_OPTIONPAGE_GENERAL };

	DECLARE_EMPTY_MSG_MAP()

	bool OnSetActive(COptionItem *pItem)
	{
		// cast the Item to our own
		CMyOptionItem *pMyItem = dynamic_cast<CMyOptionItem*>(pItem);
		if (pMyItem)
		{
			// Get the options pointer (void*)
			m_pOptions = (CGeneralOptions*)pMyItem->GetOptions();
			if (m_pOptions)
			{
				// Okay, sets the control contents
				SetDlgItemText(IDC_EDIT, m_pOptions->Name);
				CheckDlgButton(IDC_CHECK, m_pOptions->Enable);
			}
		}
		return true;
	}

	bool OnKillActive(COptionItem *pItem)
	{
		// Do we have options to update ?
		if (m_pOptions)
		{
			// Yes, fetch the values from the controls
			GetDlgItemText(IDC_EDIT, m_pOptions->Name.GetBuffer(100), 100);
			m_pOptions->Name.ReleaseBuffer();
			m_pOptions->Enable = IsDlgButtonChecked(IDC_CHECK);
		}
		return true;
	}

protected:
	CGeneralOptions *m_pOptions;

};

#endif // !defined(AFX_OPTIONPAGEGENERAL_H__723F378D_C5CD_4C63_AC4F_2B54CF399118__INCLUDED_)
