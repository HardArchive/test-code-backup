// PropPageGeneral.h: interface for the CPropPageGeneral class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_PROPPAGEGENERAL_H__311A0255_1A34_4582_94F3_3B307E176CA7__INCLUDED_)
#define AFX_PROPPAGEGENERAL_H__311A0255_1A34_4582_94F3_3B307E176CA7__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "resource.h"
#include <MOptionPage.h>


class CPropPageGeneral : public Mortimer::COptionPageImpl<CPropPageGeneral, Mortimer::CPropPage>
{
public:
	enum { IDD = IDD_OPTIONPAGE_GENERAL };

	DECLARE_EMPTY_MSG_MAP()

	bool OnSetActive(COptionItem *pItem)
	{
		// Sets the control contents
		SetDlgItemText(IDC_EDIT, m_pOptions->Name);
		CheckDlgButton(IDC_CHECK, m_pOptions->Enable);
		return true;
	}

	void OnOK()
	{
		// Retrieve values from the controls
		GetDlgItemText(IDC_EDIT, m_pOptions->Name.GetBuffer(100), 100);
		m_pOptions->Name.ReleaseBuffer();
		m_pOptions->Enable = IsDlgButtonChecked(IDC_CHECK);
	}

	void OnCancel()
	{
		// Do nothing
	}

	CGeneralOptions *m_pOptions;
};

#endif // !defined(AFX_PROPPAGEGENERAL_H__311A0255_1A34_4582_94F3_3B307E176CA7__INCLUDED_)
