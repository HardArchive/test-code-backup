// MyOptionSheet.h: interface for the CMyOptionSheet class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_MYOPTIONSHEET_H__2A170C9D_E3AA_4567_87BD_38D54B0B86AA__INCLUDED_)
#define AFX_MYOPTIONSHEET_H__2A170C9D_E3AA_4567_87BD_38D54B0B86AA__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <MOptionSheet.h>
using Mortimer::COptionItem;
using Mortimer::COptionPage;

#include "AppOptions.h"

//////////////////////////////////////////////////////////////////////


class CMyOptionItem : public COptionItem
{
public:
	CMyOptionItem(LPCTSTR Caption, COptionPage *pPage, void *pOptions) : COptionItem(Caption, pPage), m_pOptions(pOptions) {}

	void SetOptions(void *pOptions) { m_pOptions = pOptions; }
	void *GetOptions() { return m_pOptions; }

protected:
	void *m_pOptions;
};

//////////////////////////////////////////////////////////////////////

#include "OptionPageAbout.h"
#include "OptionPageGeneral.h"

class CMyOptionSheet : public Mortimer::COptionSheet  
{
public:
	bool DoInit(bool FirstTime);

	void OnOK(UINT uCode, int nID, HWND hWndCtl);
	void OnApply(UINT uCode, int nID, HWND hWndCtl);
	void OnCancel(UINT uCode, int nID, HWND hWndCtl);

	void SetOptions(CAppOptions *pOptions);

protected:
	COptionPageAbout m_PageAbout;
	COptionPageGeneral m_PageGeneral;

	CAppOptions *m_pOptions;
};

#endif // !defined(AFX_MYOPTIONSHEET_H__2A170C9D_E3AA_4567_87BD_38D54B0B86AA__INCLUDED_)
