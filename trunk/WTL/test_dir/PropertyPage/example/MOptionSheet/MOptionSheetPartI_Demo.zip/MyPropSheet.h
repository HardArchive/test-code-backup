// MyPropSheet.h: interface for the CMyPropSheet class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_MYPROPSHEET_H__17457933_2640_443A_880D_5E52599033C7__INCLUDED_)
#define AFX_MYPROPSHEET_H__17457933_2640_443A_880D_5E52599033C7__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "OptionPageAbout.h"
#include "PropPageGeneral.h"

class CMyPropSheet : public Mortimer::CPropSheet  
{
public:
	bool DoInit(bool FirstTime)
	{
		if (FirstTime)
		{
			m_PageAbout.Create(this);
			m_PageGeneral.Create(this);
		}

		AddItem(new COptionItem(NULL, &m_PageAbout));
		AddItem(new COptionItem(NULL, &m_PageGeneral));

		// Set the options pointer for the page
		m_PageGeneral.m_pOptions = &m_pOptions->Current;

		return CPropSheet::DoInit(FirstTime);
	}

	void SetOptions(CAppOptions *pOptions)
	{
		m_pOptions = pOptions;
	}

protected:
	COptionPageAbout m_PageAbout;
	CPropPageGeneral m_PageGeneral;

	CAppOptions *m_pOptions;
};

#endif // !defined(AFX_MYPROPSHEET_H__17457933_2640_443A_880D_5E52599033C7__INCLUDED_)
