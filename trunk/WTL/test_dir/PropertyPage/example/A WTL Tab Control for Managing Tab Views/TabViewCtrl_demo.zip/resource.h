//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by TabViewDemo.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDD_TABVIEWDEMO_FORM            129
#define IDR_HTML1                       201
#define IDD_STYLES_DIALOG               201
#define IDR_JPGS1                       202
#define IDB_TABBITMAP                   202
#define IDC_BUTTON1                     1000
#define IDC_BUTTON2                     1001
#define IDC_EDIT1                       1002
#define IDC_EDIT2                       1003
#define IDC_EDIT3                       1004
#define IDC_CHECK1                      1005
#define IDC_RADIO1                      1006
#define IDC_TCS_BUTTONS                 1006
#define IDC_RADIO2                      1007
#define IDC_TCS_FIXEDWIDTH              1007
#define IDAPPLY                         1008
#define IDC_TCS_FLATBUTTONS             1009
#define IDC_TCS_FOCUSNEVER              1010
#define IDC_TCS_FOCUSONBUTTONDOWN       1011
#define IDC_TCS_FORCEICONLEFT           1012
#define IDC_TCS_FORCELABELLEFT          1013
#define IDC_TCS_HOTTRACK                1014
#define IDC_TCS_MULTILINE               1015
#define IDC_TCS_MULTISELECT             1016
#define IDC_TCS_OWNERDRAWFIXED          1017
#define IDC_TCS_RAGGEDRIGHT             1018
#define IDC_TCS_RIGHT                   1019
#define IDC_TCS_RIGHTJUSTIFY            1020
#define IDC_TCS_BOTTOM                  1021
#define IDC_TCS_SCROLLOPPOSITE          1022
#define IDC_TCS_SINGLELINE              1023
#define IDC_TCS_TABS                    1024
#define IDC_TCS_TOOLTIPS                1025
#define IDC_TCS_VERTICAL                1026
#define ID_DEMO_ADDTAB                  32772
#define ID_DEMO_ADDTAB2                 32773
#define ID_DEMO_REMOVETAB               32774
#define ID_DEMO_REMOVEALLTABS           32775
#define ID_DEMO_STYLES                  32780
#define ATL_IDS_IDLEMESSAGE2            57346

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        203
#define _APS_NEXT_COMMAND_VALUE         32772
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
