// XmlTreeView.h : header file
//
// Copyright (C) 2000 Frank Le.
// All rights reserved
//

#if !defined(_XMLTREEVIEW_H_)
#define _XMLTREEVIEW_H_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#import "msxml.dll" named_guids

/////////////////////////////////////////////////////////////////////////////
// CXmlTreeView view

class CXmlTreeView : public CTreeView
{
protected:
	CXmlTreeView();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CXmlTreeView)

// Attributes
public:

// Operations
public:
	BOOL loadXML(const CString& strPathName, const BOOL bOptimizeMemory = FALSE);

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CXmlTreeView)
	public:
	virtual void OnInitialUpdate();
	protected:
	virtual void OnDraw(CDC* pDC);      // overridden to draw this view
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CXmlTreeView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Generated message map functions
protected:
	//{{AFX_MSG(CXmlTreeView)
	afx_msg void OnItemexpanding(NMHDR* pNMHDR, LRESULT* pResult);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

protected:
    BOOL populateNode(MSXML::IXMLDOMElement* node, const HTREEITEM& hItem);
	BOOL populateAttributes(MSXML::IXMLDOMElement *node, const HTREEITEM &hParent);
    HTREEITEM insertItem(MSXML::IXMLDOMElement* node, 
        const CString &nodeName, int nImage, int nSelectedImage, 
        HTREEITEM hParent = TVI_ROOT, HTREEITEM hInsertAfter = TVI_LAST);
    void deleteFirstChild(const HTREEITEM& hItem);
	void deleteAllChildren(const HTREEITEM& hItem);
	int getIconIndex(MSXML::IXMLDOMElement* node);

private:
	CImageList m_theImageList;
	BOOL m_bOptimizeMemory;
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(_XMLTREEVIEW_H_)
