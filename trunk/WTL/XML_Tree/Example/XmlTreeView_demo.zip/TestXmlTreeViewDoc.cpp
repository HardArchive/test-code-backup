// TestXmlTreeViewDoc.cpp : implementation of the CTestXmlTreeViewDoc class
//

#include "stdafx.h"
#include "TestXmlTreeView.h"

#include "TestXmlTreeViewDoc.h"
#include "TestXmlTreeViewView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTestXmlTreeViewDoc

IMPLEMENT_DYNCREATE(CTestXmlTreeViewDoc, CDocument)

BEGIN_MESSAGE_MAP(CTestXmlTreeViewDoc, CDocument)
	//{{AFX_MSG_MAP(CTestXmlTreeViewDoc)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTestXmlTreeViewDoc construction/destruction

CTestXmlTreeViewDoc::CTestXmlTreeViewDoc()
{
	// TODO: add one-time construction code here

}

CTestXmlTreeViewDoc::~CTestXmlTreeViewDoc()
{
}

BOOL CTestXmlTreeViewDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	// TODO: add reinitialization code here
	// (SDI documents will reuse this document)

	return TRUE;
}



/////////////////////////////////////////////////////////////////////////////
// CTestXmlTreeViewDoc serialization

void CTestXmlTreeViewDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO: add storing code here
	}
	else
	{
		// TODO: add loading code here
	}
}

/////////////////////////////////////////////////////////////////////////////
// CTestXmlTreeViewDoc diagnostics

#ifdef _DEBUG
void CTestXmlTreeViewDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CTestXmlTreeViewDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CTestXmlTreeViewDoc commands

BOOL CTestXmlTreeViewDoc::OnOpenDocument(LPCTSTR lpszPathName) 
{
	if (!CDocument::OnOpenDocument(lpszPathName))
		return FALSE;
	
    CTestXmlTreeViewView* pView = CTestXmlTreeViewView::GetView();
    if (pView->loadXML(lpszPathName) == FALSE) {
        return FALSE;
    }
	
	return TRUE;
}
