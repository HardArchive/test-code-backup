// XmlTreeView.cpp : implementation file
//
// Copyright (C) 2000 Frank Le.
// All rights reserved
//

#include "stdafx.h"
#include "XmlTreeView.h"
#include "resource.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// Image indexes.
const int ILI_ROOT = 0;
const int ILI_ELEMENT = 1;
const int ILI_TEXT = 2;
const int ILI_OTHER = 3;
const int ILI_ATTRIBUTE = 4;
const int ILI_COMMENT = 5;

/////////////////////////////////////////////////////////////////////////////
// CXmlTreeView

IMPLEMENT_DYNCREATE(CXmlTreeView, CTreeView)

CXmlTreeView::CXmlTreeView()
{
}

CXmlTreeView::~CXmlTreeView()
{
}


BEGIN_MESSAGE_MAP(CXmlTreeView, CTreeView)
	//{{AFX_MSG_MAP(CXmlTreeView)
	ON_NOTIFY_REFLECT(TVN_ITEMEXPANDING, OnItemexpanding)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CXmlTreeView drawing

void CXmlTreeView::OnDraw(CDC* pDC)
{
	CDocument* pDoc = GetDocument();
	// TODO: add draw code here
}

/////////////////////////////////////////////////////////////////////////////
// CXmlTreeView diagnostics

#ifdef _DEBUG
void CXmlTreeView::AssertValid() const
{
	CTreeView::AssertValid();
}

void CXmlTreeView::Dump(CDumpContext& dc) const
{
	CTreeView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CXmlTreeView message handlers

BOOL CXmlTreeView::PreCreateWindow(CREATESTRUCT& cs) 
{
	cs.style |= TVS_HASLINES | TVS_LINESATROOT | TVS_HASBUTTONS | TVS_SHOWSELALWAYS;
	
	return CTreeView::PreCreateWindow(cs);
}

void CXmlTreeView::OnInitialUpdate() 
{
	CTreeView::OnInitialUpdate();
	
	m_theImageList.Detach();	// For MDI
	m_theImageList.Create(IDB_BITMAP_TREE_ICONS, 16, 4, RGB(255, 255, 255));	
	GetTreeCtrl().SetImageList(&m_theImageList, TVSIL_NORMAL);
}

void CXmlTreeView::OnItemexpanding(NMHDR* pNMHDR, LRESULT* pResult) 
{
	NM_TREEVIEW* pNMTreeView = (NM_TREEVIEW*)pNMHDR;
	HTREEITEM hItem = pNMTreeView->itemNew.hItem;
	MSXML::IXMLDOMElement* node = (MSXML::IXMLDOMElement*)GetTreeCtrl().GetItemData(hItem);
	HRESULT hr;

	*pResult = 0;
	
	// If m_bOptimizeMemory is false then we optimize by not adding and deleting 
	// already added items. The trade-off is memory exhausted!
	
	CWaitCursor waitCursor;     // This could take a while!
	GetTreeCtrl().LockWindowUpdate();
	if (pNMTreeView->action == TVE_EXPAND) {
		if (m_bOptimizeMemory == FALSE) {
			HTREEITEM hChildItem;
			if ((hChildItem = GetTreeCtrl().GetChildItem(hItem)) != NULL) {
				MSXML::IXMLDOMElement* childNode = 
					(MSXML::IXMLDOMElement*)GetTreeCtrl().GetItemData(hChildItem);
				if (childNode == NULL) {
					GetTreeCtrl().DeleteItem(hChildItem);
					MSXML::IXMLDOMNode* firstChild = NULL;
					hr = node->get_firstChild(&firstChild);
					if (SUCCEEDED(hr) && firstChild != NULL) {
						if (populateNode((MSXML::IXMLDOMElement*)firstChild, hItem) == FALSE) {
							*pResult = 1;            
						}
					}
				}
			}
		} else {
			deleteFirstChild(hItem);
			MSXML::IXMLDOMNode* firstChild = NULL;
			hr = node->get_firstChild(&firstChild);
			if (SUCCEEDED(hr) && firstChild != NULL) {
				if (populateNode((MSXML::IXMLDOMElement*)firstChild, hItem) == FALSE) {
					*pResult = 1;            
				}
			}
		}
	} else { // pNMTreeView->action == TVE_COLLAPSE
		if (m_bOptimizeMemory == TRUE) {
			deleteAllChildren(hItem);
			// Set button state.
			if (node->hasChildNodes()) {
				int nImage, nSelectedImage;
				nImage = nSelectedImage = getIconIndex(node);
				HTREEITEM hChildItem = GetTreeCtrl().InsertItem(_T(""), nImage, 
					nSelectedImage, hItem);
				GetTreeCtrl().SetItemData(hChildItem, (DWORD)NULL);
			}
		}
	}
	GetTreeCtrl().UnlockWindowUpdate();
}

BOOL CXmlTreeView::loadXML(const CString &strPathName, const BOOL bOptimizeMemory /*= FALSE*/)
{
	MSXML::IXMLDOMDocument* document = NULL;
	MSXML::IXMLDOMParseError* parseError = NULL;
	MSXML::IXMLDOMElement* element = NULL;	

	GetTreeCtrl().DeleteAllItems();

	HRESULT hr;
	hr = CoInitialize(NULL);
	if (FAILED(hr)) {
		return FALSE;
	}

	hr = CoCreateInstance(MSXML::CLSID_DOMDocument, NULL, 
		CLSCTX_INPROC_SERVER | CLSCTX_LOCAL_SERVER, 
		MSXML::IID_IXMLDOMDocument, (LPVOID*)&document);
	if (!document) {
		return FALSE;
	}

	BSTR bstr = NULL;
	document->put_async(VARIANT_FALSE);
	bstr = strPathName.AllocSysString();
	VARIANT_BOOL varOkay = document->load(bstr);
	SysFreeString(bstr);
	
	BSTR nodeName;
	HTREEITEM hItem;	
	if (varOkay) {
		hr = document->get_documentElement(&element);
		if (FAILED(hr) || element == NULL) {
			MessageBox(_T("Empty document!"), _T("Error Loading XML"), MB_ICONWARNING);
			return FALSE;
		}
		element->get_nodeName(&nodeName);
		hItem = insertItem(element, CString(nodeName), ILI_ROOT, ILI_ROOT);	
		// Optional expand the root initially.
		GetTreeCtrl().Expand(hItem, TVE_EXPAND);
		GetTreeCtrl().Select(hItem, TVGN_CARET);
	} else {
		long line, linePos;
		BSTR reason = NULL;
		
		document->get_parseError(&parseError);
		parseError->get_errorCode(&hr);
		parseError->get_line(&line);
		parseError->get_linepos(&linePos);
		parseError->get_reason(&reason);
		
		CString strMsg;
		strMsg.Format(_T("Error 0x%.8X on line %d, position %d\r\nReason: %s"), 
			hr, line, linePos, CString(reason));
		MessageBox(strMsg, _T("Error Loading XML"), MB_ICONWARNING);
				
		SysFreeString(reason);
		return FALSE;
	}

	// Must initialize here.
	m_bOptimizeMemory = bOptimizeMemory;
	
	return TRUE;
}

// This function populates all siblings of the [in] node.
//
BOOL CXmlTreeView::populateNode(MSXML::IXMLDOMElement *node, const HTREEITEM &hParent)
{
	HRESULT hr = S_OK;
	BSTR nodeType, nodeName;
	HTREEITEM hItem;

	node->get_nodeTypeString(&nodeType);
	if (!wcscmp(nodeType, L"element")) {
		node->get_nodeName(&nodeName);
		hItem = insertItem(node, CString(nodeName), ILI_ELEMENT, ILI_ELEMENT, hParent);
		populateAttributes(node, hItem);
	} else if(!wcscmp(nodeType, L"text")) {
		node->get_text(&nodeName);
		hItem = insertItem(node, CString(nodeName), ILI_TEXT, ILI_TEXT, hParent);	
	} else if(!wcscmp(nodeType, L"comment")) {
		node->get_nodeName(&nodeName);
		hItem = insertItem(node, CString(nodeName), ILI_COMMENT, ILI_COMMENT, hParent);	
	} else {    // Handle more data types here if needed.
		node->get_nodeName(&nodeName);
		hItem = insertItem(node, CString(nodeName), ILI_OTHER, ILI_OTHER, hParent);	
	}
	
	MSXML::IXMLDOMNode* nextSibling = NULL;
	hr = node->get_nextSibling(&nextSibling);
	if (SUCCEEDED(hr) && nextSibling != NULL) {
		populateNode((MSXML::IXMLDOMElement*)nextSibling, hParent);
	}

	return TRUE;
}

BOOL CXmlTreeView::populateAttributes(MSXML::IXMLDOMElement *node, const HTREEITEM &hParent)
{
	HRESULT hr = S_OK;
	BSTR nodeName;
	HTREEITEM hItem;

	MSXML::IXMLDOMNamedNodeMap* namedNodeMap = NULL;
	hr = node->get_attributes(&namedNodeMap);
	if (SUCCEEDED(hr) && namedNodeMap != NULL) {
		long listLength;
		hr = namedNodeMap->get_length(&listLength);
		for(long i = 0; i < listLength; i++) {
			MSXML::IXMLDOMNode* listItem = NULL;
			hr = namedNodeMap->get_item(i, &listItem);
			listItem->get_nodeName(&nodeName);
			hItem = insertItem((MSXML::IXMLDOMElement*)listItem, 
				CString(nodeName), ILI_ATTRIBUTE, ILI_ATTRIBUTE, hParent);	
		}
	}

	return TRUE;
}

HTREEITEM CXmlTreeView::insertItem(MSXML::IXMLDOMElement *node, 
	const CString &nodeName, int nImage, int nSelectedImage, 
	HTREEITEM hParent /*= TVI_ROOT*/, HTREEITEM hInsertAfter /*= TVI_LAST*/)
{
	HTREEITEM hItem = GetTreeCtrl().InsertItem(nodeName, nImage, 
		nSelectedImage, hParent, hInsertAfter);	
	GetTreeCtrl().SetItemData(hItem, (DWORD)node);

	// Set button state.
	if (node->hasChildNodes()) {
		HTREEITEM hChildItem = GetTreeCtrl().InsertItem(_T(""), nImage, 
			nSelectedImage, hItem);
		GetTreeCtrl().SetItemData(hChildItem, (DWORD)NULL);
	}

	return hItem;
}

void CXmlTreeView::deleteFirstChild(const HTREEITEM &hItem)
{
	HTREEITEM hChildItem;
	if ((hChildItem = GetTreeCtrl().GetChildItem(hItem)) != NULL) {
		GetTreeCtrl().DeleteItem(hChildItem);
	}
}

void CXmlTreeView::deleteAllChildren(const HTREEITEM &hItem)
{
	HTREEITEM hChildItem;
	if ((hChildItem = GetTreeCtrl().GetChildItem(hItem)) == NULL) {
		return;
	}

	do {
		HTREEITEM hNextItem = GetTreeCtrl().GetNextSiblingItem(hChildItem);
		GetTreeCtrl().DeleteItem(hChildItem);
		hChildItem = hNextItem;
	} while (hChildItem != NULL);
}

int CXmlTreeView::getIconIndex(MSXML::IXMLDOMElement *node)
{
	BSTR nodeType;

	node->get_nodeTypeString(&nodeType);
	if (!wcscmp(nodeType, L"element")) {
		return ILI_ELEMENT;
	} else if(!wcscmp(nodeType, L"attribute")) {
		return ILI_ATTRIBUTE;
	} else if(!wcscmp(nodeType, L"text")) {
		return ILI_TEXT;
	} else if(!wcscmp(nodeType, L"comment")) {
		return ILI_COMMENT;
	}

	return ILI_OTHER;
}
