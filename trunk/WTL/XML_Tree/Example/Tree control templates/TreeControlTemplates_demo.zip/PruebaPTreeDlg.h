// PruebaPTreeDlg.h : header file
//

#if !defined(AFX_PRUEBAPTREEDLG_H__8FF80297_D67E_421C_8938_35095D0CB446__INCLUDED_)
#define AFX_PRUEBAPTREEDLG_H__8FF80297_D67E_421C_8938_35095D0CB446__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "TCExpand.h"
#include "TCPersist.h"
#include "TCIterator.h"

/////////////////////////////////////////////////////////////////////////////
// CPruebaPTreeDlg dialog

class CPruebaPTreeDlg : public CDialog
{
// Construction
public:
	CPruebaPTreeDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CPruebaPTreeDlg)
	enum { IDD = IDD_PRUEBAPTREE_DIALOG };
	CListBox	mc_lbItems;
	//}}AFX_DATA
	TTCIterator<TTCPersist<TTCExpand<CTreeCtrl> > >	mc_tcTree;

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPruebaPTreeDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

	void PopulateTree();

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CPruebaPTreeDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnBtCollapse();
	afx_msg void OnBtExpand();
	afx_msg void OnBtReload();
	afx_msg void OnBtIterateDeep();
	afx_msg void OnBtIterateWidth();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PRUEBAPTREEDLG_H__8FF80297_D67E_421C_8938_35095D0CB446__INCLUDED_)
