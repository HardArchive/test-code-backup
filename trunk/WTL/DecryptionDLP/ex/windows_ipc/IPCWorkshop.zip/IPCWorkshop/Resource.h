//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by IPCWorkshop.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_IPCWORKSHOP_DIALOG          102
#define IDR_MAINFRAME                   128
#define IDC_IPC_HEADING                 1000
#define IDC_GB_PROCESS                  1001
#define IDC_RADIO_SERVER                1002
#define IDC_RADIO_CLIENT                1003
#define IDC_RADIO_LOCAL                 1004
#define IDC_RADIO_INTRANET              1005
#define IDC_RADIO_INTERNET              1006
#define IDC_GB_COMMUNICATION            1007
#define IDC_SETTINGS                    1008
#define IDC_GB_DATA                     1009
#define IDC_STATIC_EMPID                1010
#define IDC_STATIC_NAME                 1011
#define IDC_STATIC_ADDRESS              1012
#define IDC_STATIC_PHONE                1013
#define IDC_STATIC_DOB                  1014
#define IDC_EMPID                       1015
#define IDC_NAME                        1016
#define IDC_ADDRESS                     1017
#define IDC_PHONE                       1018
#define IDC_DOB                         1019
#define IDC_STATIC_COMMMEDIUM           1020
#define IDC_COMBO_IPCMECHANISMS         1021
#define IDC_SEND                        1022
#define IDC_READ                        1023
#define IDC_SERVER                      1024
#define IDC_STATIC_SERVER               1025
#define IDC_IPADDRESS                   1026
#define IDC_CONNECT                     1027

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        131
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1029
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
