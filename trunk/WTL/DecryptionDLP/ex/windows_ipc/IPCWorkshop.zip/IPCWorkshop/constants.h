#ifndef __CONSTANTS_H__
#define __CONSTANTS_H__

#define		CLIPBOARD		"Clipboard"
#define		FILEMAPPING		"FileMapping"
#define		MAILSLOTS		"Mailslots"
#define		NAMEDPIPES		"NamedPipes"
#define		SOCKETS			"Sockets"
#define		FILEMAPNAME		"Filemap_EmpData"
#define		MAILSLOTNAME	"Mailslot_EmpData"
#define		PIPENAME		"Pipe_EmpData"
#define		MAILSLOTCONTROL	2	
#define		PIPECONTROL		3	
#define		SOCKETCONTROL	4	

#endif //__CONSTANTS_H__