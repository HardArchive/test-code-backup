#pragma

#define _WIN32_WINNT 0x0400

#include <windows.h>
#include <iostream>
#include <string>
#include <list>
