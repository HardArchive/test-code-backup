
// stdafx.h : include file for standard system include files,
// or project specific include files that are used frequently,
// but are changed infrequently

#pragma once

#define _WIN32_WINNT _WIN32_WINNT_WINXP
//#define _WIN32_WINNT _WIN32_WINNT_WIN7

#define _USE_MFC
#define _RIBBONS_SUPPORT
#define _DETECT_MEMORY_LEAK

#include "../../../Common/Src/GeneralHelper.h"

