#pragma once

	/***********************************
		** MsXML �汾 **

		MsXML6.0 -- USES_MSXML60
		MsXML4.0 -- USES_MSXML40
		MsXML3.0 -- USES_MSXML30
		MsXML2.0 -- (Ĭ��ֵ, ���ض���)
	***********************************/

//#define USES_MSXML40