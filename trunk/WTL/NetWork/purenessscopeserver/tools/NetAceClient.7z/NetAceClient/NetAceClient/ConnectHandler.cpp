#include "ConnectHandler.h"

Mutex_Allocator _connecthandle_mb_allocator;
CConnectHandler::CConnectHandler(void)
{
	m_szError[0] = '\0';
}

CConnectHandler::~CConnectHandler(void)
{
}

int CConnectHandler::open(void*)
{
	int nRet = ACE_Svc_Handler<ACE_SOCK_STREAM, ACE_MT_SYNCH>::open();
	if(nRet != 0)
	{
		OUR_DEBUG((LM_ERROR, "[CConnectHandler::open]ACE_Svc_Handler<ACE_SOCK_STREAM, ACE_MT_SYNCH>::open() error [%d].\n", nRet));
		sprintf_safe(m_szError, MAX_BUFF_500, "[CConnectHandler::open]ACE_Svc_Handler<ACE_SOCK_STREAM, ACE_MT_SYNCH>::open() error [%d].", nRet);
		return -1;
	}

	//��������Ϊ������ģʽ
	if (this->peer().enable(ACE_NONBLOCK) == -1)
	{
		OUR_DEBUG((LM_ERROR, "[CConnectHandler::open]this->peer().enable  = ACE_NONBLOCK error.\n"));
		sprintf_safe(m_szError, MAX_BUFF_500, "[CConnectHandler::open]this->peer().enable  = ACE_NONBLOCK error.");
		return -1;
	}

	//���Զ�����ӵ�ַ�Ͷ˿�
	if(this->peer().get_remote_addr(m_addrRemote) == -1)
	{
		OUR_DEBUG((LM_ERROR, "[CConnectHandler::open]this->peer().get_remote_addr error.\n"));
		sprintf_safe(m_szError, MAX_BUFF_500, "[CConnectHandler::open]this->peer().get_remote_addr error.");
		return -1;
	}

	OUR_DEBUG((LM_INFO, "[CConnectHandler::open] Connection to [%s:%d]\n",m_addrRemote.get_host_addr(), m_addrRemote.get_port_number()));

	m_atvConnect      = ACE_OS::gettimeofday();
	m_atvInput        = ACE_OS::gettimeofday();
	m_atvOutput       = ACE_OS::gettimeofday();

	m_u4AllRecvCount  = 0;
	m_u4AllSendCount  = 0;
	m_u4AllRecvSize   = 0;
	m_u4AllSendSize   = 0;
	m_u1ConnectState  = CONNECT_OPEN;
	m_u2SendQueueMax  = MAX_BUFF_1000;

	//���ý��ջ���صĴ�С
	int nTecvBuffSize = MAX_MSG_SOCKETBUFF;
	ACE_OS::setsockopt(this->get_handle(), SOL_SOCKET, SO_RCVBUF, (char* )&nTecvBuffSize, sizeof(nTecvBuffSize));
	ACE_OS::setsockopt(this->get_handle(), SOL_SOCKET, SO_SNDBUF, (char* )&nTecvBuffSize, sizeof(nTecvBuffSize));

	return 0;
}

int CConnectHandler::handle_input(ACE_HANDLE fd)
{
	ACE_Time_Value nowait(ACE_Time_Value::zero);

	m_atvInput       = ACE_OS::gettimeofday();
	m_u1ConnectState = CONNECT_RECVGEGIN;

	if(fd == ACE_INVALID_HANDLE)
	{
		OUR_DEBUG((LM_ERROR, "[CConnectHandler::handle_input]fd == ACE_INVALID_HANDLE .\n"));
		sprintf_safe(m_szError, MAX_BUFF_500, "[CConnectHandler::handle_input]fd == ACE_INVALID_HANDLE .");
		m_u1ConnectState = CONNECT_RECVERROR;
		return -1;
	}

	int nCurrRecvSize =  m_RecvPacket.GetPacketSize() - m_RecvPacket.GetWriteLen();
	if(nCurrRecvSize <= 0)
	{
		m_RecvPacket.AddBuff(10 * MAX_BUFF_1024);
		nCurrRecvSize =  m_RecvPacket.GetPacketSize() - m_RecvPacket.GetWriteLen();
	}

	int nDataLen = this->peer().recv(m_RecvPacket.WritePtr(), nCurrRecvSize, MSG_NOSIGNAL, &nowait);
	if(nDataLen <= 0)
	{
		uint32 u4Error = (uint32)errno;
		if(u4Error != 10054)
		{
			OUR_DEBUG((LM_ERROR, "[CConnectHandler::handle_input] recv data is error nDataLen = [%d] errno = [%d].\n", nDataLen, u4Error));
			sprintf_safe(m_szError, MAX_BUFF_500, "[CConnectHandler::handle_input] recv data is error[%d].\n", nDataLen);
			m_u1ConnectState = CONNECT_RECVERROR;
		}
		return -1;
	}

	m_RecvPacket.WritePtr(nDataLen);
	m_u4AllRecvSize += nDataLen;

	bool blState = true;
	while(true == blState)
	{
		blState = CheckMessage();
	}

	m_u1ConnectState = CONNECT_RECVGEND;

	return 0;
}

int CConnectHandler::handle_close(ACE_HANDLE h, ACE_Reactor_Mask mask)
{
	if (mask == ACE_Event_Handler::WRITE_MASK)
	{
		return 0;
	}

	msg_queue()->deactivate();
	shutdown();

	OUR_DEBUG((LM_DEBUG,"[CConnectHandler::handle_close] Connection close [%s:%d] finish ok...\n", m_addrRemote.get_host_addr(), m_addrRemote.get_port_number()));	

	delete this;
	return 0;
}

bool CConnectHandler::SendMessage(IBuffPacket* pBuffPacket)
{
	if(NULL == pBuffPacket)
	{
		OUR_DEBUG((LM_DEBUG,"[CConnectHandler::SendMessage] pBuffPacket is NULL.\n"));	
		return false;
	}

	CBuffPacket* pReturnBuffPacket = new CBuffPacket();	
	if(NULL == pReturnBuffPacket)
	{
		OUR_DEBUG((LM_DEBUG,"[CConnectHandler::SendMessage] pReturnBuffPacket is NULL.\n"));	
		return false;
	}

	//������
	uint32 u4PacketLen = pBuffPacket->GetPacketLen();
	(*pReturnBuffPacket) << u4PacketLen;
	pReturnBuffPacket->WriteStream(pBuffPacket->ReadPtr(), u4PacketLen);

	if(pReturnBuffPacket->GetPacketLen() <= 0 || false == PutSendPacket(pReturnBuffPacket))
	{	
		if(NULL != pReturnBuffPacket)
		{
			delete pReturnBuffPacket;
			pReturnBuffPacket = NULL;
		}
		return false;
	}
	else
	{
		return true;
	}
}

bool CConnectHandler::PutSendPacket(IBuffPacket* pBuffPacket)
{
	m_ThreadLock.acquire();
	if(NULL == pBuffPacket)
	{
		OUR_DEBUG ((LM_ERROR,"[CConnectHandler::PutSendPacket] pBuffPacket is NULL!\n"));
		m_ThreadLock.release();
		return false;
	}

	//ACE_Time_Value     nowait(ACE_Time_Value::zero);
	ACE_Time_Value     nowait(5);
	while(pBuffPacket->GetPacketLen() - pBuffPacket->GetReadLen() > 0)
	{
		//��������
		char* pData = pBuffPacket->ReadPtr();
		if(NULL == pData)
		{
			OUR_DEBUG((LM_ERROR, "[CConnectHandler::handle_output] pData is NULL.\n"));
			delete pBuffPacket;
			pBuffPacket = NULL;
			m_u1ConnectState = CONNECT_SENDEND;
			m_ThreadLock.release();
			return false;
		}

		int nCurrSendSize = (int)(pBuffPacket->GetPacketLen() - pBuffPacket->GetReadLen());
		if(nCurrSendSize <= 0)
		{
			OUR_DEBUG((LM_ERROR, "[CConnectHandler::handle_output] nCurrSendSize error is %d.\n", nCurrSendSize));
			delete pBuffPacket;
			pBuffPacket = NULL;
			m_u1ConnectState = CONNECT_SENDEND;
			m_ThreadLock.release();
			return false;
		}

		//��������
		int nDataLen = this->peer().send(pData, nCurrSendSize, &nowait);
		int nErr = ACE_OS::last_error();
		if(nDataLen <= 0)
		{
			if(nErr == EWOULDBLOCK)
			{
				OUR_DEBUG((LM_ERROR, "[CConnectHandler::handle_output] senderror = %d.\n", nErr));
				sprintf_safe(m_szError, MAX_BUFF_500, "[CConnectHandler::handle_output] senderror = %d.\n", nErr);
				m_u1ConnectState = CONNECT_SENDEND;
			}

			OUR_DEBUG((LM_ERROR, "[CConnectHandler::handle_output] error = %d.\n", errno));
			delete pBuffPacket;
			pBuffPacket = NULL;
			m_u1ConnectState = CONNECT_SENDERROR;
			m_ThreadLock.release();
			return false;
		}
		else if(nDataLen >= nCurrSendSize)   //�����ݰ�ȫ��������ϣ���ա�
		{
			//OUR_DEBUG((LM_ERROR, "[CConnectHandler::handle_output] ConnectID = %d, send (%d) OK.\n", GetConnectID(), msg_queue()->is_empty()));
			m_u4AllSendCount += pBuffPacket->GetPacketCount();
			m_u4AllSendSize  += pBuffPacket->GetPacketLen();
			delete pBuffPacket;
			pBuffPacket = NULL;
			m_u1ConnectState = CONNECT_SENDEND;
			m_ThreadLock.release();
			return true;
		}
		else
		{
			pBuffPacket->ReadPtr(nDataLen);
			m_u4AllSendSize  += nDataLen;
			//OUR_DEBUG((LM_ERROR, "[CConnectHandler::handle_output] ConnectID = %d, sendlen = %d.\n", GetConnectID(), nDataLen));
			m_u1ConnectState = CONNECT_SENDEND;
		}
	}

	m_ThreadLock.release();
	return true;
}

CMessage* CConnectHandler::SetMessage(IBuffPacket* pBuffPacket)
{
	if(NULL == pBuffPacket)
	{
		OUR_DEBUG((LM_ERROR, "[CConnectHandler::SetMessage] pBuffPacket is NULL.\n"));
		return false;
	}

	//�����µ�Message����
	CMessage* pMessage = new CMessage();
	if(NULL == pMessage)
	{
		//д����հ�����
		OUR_DEBUG((LM_ERROR, "[CConnectHandler::SetMessage] pMessage is NULL.\n"));
		return NULL;
	}

	//�����µ�_MessageBase
	_MessageBase* pMessageBase = new _MessageBase();
	if(NULL == pMessageBase)
	{
		//д����հ�����
		OUR_DEBUG((LM_ERROR, "[CConnectHandler::SetMessage] _MessageBase is NULL.\n"));
		return NULL;
	}

	//��ʼ��װ����
	pMessageBase->m_u4ConnectID = 0;
	pMessageBase->m_u2Cmd       = 0;
	pMessageBase->m_u4MsgTime   = (uint32)ACE_OS::gettimeofday().sec();

	pMessage->SetMessageBase(pMessageBase);

	//�����ܵ����ݻ������CMessage����
	if(false == pMessage->SetRecvPacket(pBuffPacket))
	{
		//д����հ�����
		OUR_DEBUG((LM_ERROR, "[CConnectHandler::SetMessage] pMessage->SetRecvPacket is fail.\n"));
		delete pMessage;
		return NULL;
	}

	return pMessage;
}

bool CConnectHandler::CheckMessage()
{
	int nPacketLen = m_RecvPacket.GetPacketLen();
	if(nPacketLen > 2)
	{
		//�����ݽ��룬���õ�����
		uint32 u4Packetlen = 0;

		u4Packetlen = m_RecvPacket.GetHeadLen();

		if(u4Packetlen > m_RecvPacket.GetWriteLen())
		{
			//�������ݿ�û�д��꣬��Ҫ����������ݡ�
			return false;
		}

		m_RecvPacket >> u4Packetlen;

		//�������и��������һ������Buff
		CBuffPacket* pBuffPacket = new CBuffPacket();
		if(NULL == pBuffPacket)
		{
			//�������հ�����
			OUR_DEBUG((LM_ERROR, "[CConnectHandler::CheckMessage] u2Packetlen[%d]�� m_RecvPacket.GetWriteLen()[%d] pBuffPacket is NULL.\n", u4Packetlen, m_RecvPacket.GetWriteLen()));
			m_RecvPacket.RollBack(m_RecvPacket.GetWriteLen());
			return false;
		}

		if(false == pBuffPacket->WriteStream(m_RecvPacket.GetData(), u4Packetlen + sizeof(uint32)))  //����Ҫ���ϰ����ܳ���4���ֽ�
		{
			//д����հ�����
			OUR_DEBUG((LM_ERROR, "[CConnectHandler::CheckMessage] u2Packetlen[%d]�� m_RecvPacket.GetWriteLen()[%d] ppBuffPacket->WriteStream error.\n", u4Packetlen, m_RecvPacket.GetWriteLen()));
			m_RecvPacket.RollBack(m_RecvPacket.GetWriteLen());
			return false;
		}

		m_RecvPacket.RollBack(u4Packetlen + sizeof(uint32));

		//����Message����
		//������Buff������Ϣ����
		CMessage* pMessage = SetMessage(pBuffPacket);
		if(NULL != pMessage)
		{
			//�����ӵ�IP�Ͷ˿�д����Ϣ��
			pMessage->SetMessageInfo(m_addrRemote.get_host_addr(), (int)m_addrRemote.get_port_number());
			//��Ҫ��������Ϣ������Ϣ�����߳�
			if(false == App_MessageService::instance()->PutMessage(pMessage))
			{
				OUR_DEBUG((LM_ERROR, "[CConnectHandler::CheckMessage] App_MessageService::instance()->PutMessage Error.\n"));
				delete pMessage;
				return false;
			}
			m_u4AllRecvCount++;
		}

		return true;
	}
	else
	{
		return false;
	}
}

