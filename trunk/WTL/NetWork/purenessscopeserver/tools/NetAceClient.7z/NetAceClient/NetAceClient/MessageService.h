#ifndef _MESSAGESERVICE_H
#define _MESSAGESERVICE_H

#include "define.h"
#include "ace/Task.h"
#include "ace/Synch.h"
#include "ace/Malloc_T.h"
#include "ace/Singleton.h"
#include "ace/Process_Mutex.h"
#include "ace/Date_Time.h"
#include "ace/Reactor.h"

#include "Message.h"
#include "ThreadInfo.h"
#include "MessageManager.h"
#include "LogManager.h"
#include "BuffPacket.h"

class CMessageService : public ACE_Task<ACE_MT_SYNCH>
{
public:
	CMessageService(void);
	~CMessageService(void);

	virtual int open(void* args = 0);
	virtual int svc (void);
	virtual int close (u_long);

	virtual int handle_timeout(const ACE_Time_Value &tv, const void *arg);

	void Init(uint32 u4ThreadCount = MAX_MSG_THREADCOUNT, uint32 u4MaxQueue = MAX_MSG_THREADQUEUE, uint32 u4LowMask = MAX_MSG_MASK, uint32 u4HighMask = MAX_MSG_MASK);

	bool Start();

	bool PutMessage(CMessage* pMessage);

private:
	bool StartTimer();
	bool KillTimer();
	bool IsRun();
	bool ProcessMessage(CMessage* pMessage, uint32 u4ThreadID);

private:
	ACE_Thread_Mutex     m_RunMutex;           //�߳�������
	ACE_RW_Thread_Mutex  m_rwThreadLock;       //�̶߳�д������
	uint32               m_u4ThreadCount;      //�������߳�����
	uint32               m_u4ThreadNo;         //��ǰ�߳�ID
	uint32               m_u4MaxQueue;         //�߳��������Ϣ�������
	uint32               m_u4TimerID;          //��ʱ������
	bool                 m_blRun;              //�߳��Ƿ�������
	uint32               m_u4HighMask;
	uint32               m_u4LowMask;
	uint16               m_u2ThreadTimeOut;  
	uint16               m_u2ThreadTimeCheck;
	uint16               m_u2PacketTimeOut;    //�������ݰ���ʱ�ж���ֵ

	CThreadInfo          m_ThreadInfo;
};

typedef ACE_Singleton<CMessageService,ACE_Null_Mutex> App_MessageService; 
#endif
