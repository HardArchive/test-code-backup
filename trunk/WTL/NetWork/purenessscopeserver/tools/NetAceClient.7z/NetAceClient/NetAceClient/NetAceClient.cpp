// NetAceClient.cpp : �������̨Ӧ�ó������ڵ㡣
//

#include "stdafx.h"

#include "ace/Select_Reactor.h"

#include "ClientConnect.h"
#include "Command_Base.h"

int _tmain(int argc, _TCHAR* argv[])
{
	CClientConnect client;
	if(client.Connect("192.168.1.8", 10077) == false)
	{
		getchar();
	}

	if(false == client.Start())
	{
		getchar();
	}

	CCommand_Base* pCommand_Base = new CCommand_Base();
	App_MessageManager::instance()->AddClientCommand(RETURN_COMMAND_BASE, pCommand_Base);

	CBuffPacket* pBuffPacket = new CBuffPacket();

	char szName[20]      = {'\0'};
	uint16 u2CommandID = 0x1000;
	VCHARS_STR strName;

	sprintf_s(szName, 20, "freeeyes");

	strName.u1Len = (uint8)strlen(szName);
	strName.text  = (const char*)szName;

	(*pBuffPacket) << u2CommandID;
	(*pBuffPacket) << strName;

	ACE_Time_Value tvSleep(0, 10);
	for(int i = 0; i < 1000000; i++)
	{
		client.SendPacket(pBuffPacket);
		ACE_OS::sleep(tvSleep);
	}

	delete pBuffPacket;

	OUR_DEBUG((LM_INFO, "Send OK!\n"));

	getchar();

	return 0;
}

