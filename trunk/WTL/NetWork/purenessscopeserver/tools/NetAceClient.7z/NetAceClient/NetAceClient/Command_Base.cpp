#include "StdAfx.h"
#include "Command_Base.h"

CCommand_Base::CCommand_Base(void)
{
}

CCommand_Base::~CCommand_Base(void)
{
}

int CCommand_Base::DoMessage(IMessage* pMessage, bool& bDeleteFlag)
{
	if(pMessage == NULL)
	{
		OUR_DEBUG((LM_ERROR, "[CBaseCommand::DoMessage] pMessage is NULL.\n"));
		return -1;
	}

	//OUR_DEBUG((LM_INFO, "[CBaseCommand::DoMessage] GetMessage pMessage.GetWriteLen() = %d\n", pMessage->GetRecvPacket()->GetWriteLen()));

	uint16     u2CommandID = 0;
	VCHARS_STR strsName;
	VCHARS_STR strsPass;
	string     strName;
	string     strPass;

	(*pMessage->GetRecvPacket()) >> u2CommandID;
	(*pMessage->GetRecvPacket()) >> strsName;
	(*pMessage->GetRecvPacket()) >> strsPass;
	strName.assign(strsName.text, strsName.u1Len);
	strPass.assign(strsPass.text, strsPass.u1Len);

	//OUR_DEBUG((LM_INFO, "[CCommand_Base::DoMessage] strsName = %s strsPass = %s.\n", strName.c_str(), strPass.c_str()));
	AppLogManager::instance()->WriteLog(LOG_SYSTEM, "strsName = %s strsPass = %s.", strName.c_str(), strPass.c_str());

	return 0;
}

void CCommand_Base::SetLogManager(ILogManager* pLogManager)
{
	m_pLogManager = pLogManager;
}
