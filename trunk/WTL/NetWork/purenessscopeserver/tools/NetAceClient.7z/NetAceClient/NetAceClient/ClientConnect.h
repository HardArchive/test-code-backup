#pragma once

#include "ace/Task.h"
#include "ace/Synch.h"
#include "ace/Connector.h"
#include "ace/SOCK_Connector.h"
#include "ace/Synch_Options.h"

#include "ConnectHandler.h"

typedef ACE_Connector<CConnectHandler, ACE_SOCK_CONNECTOR> ConnectConnector;

class CClientConnect : public ACE_Task<ACE_MT_SYNCH>
{
public:
	CClientConnect(void);
	~CClientConnect(void);

	virtual int open(void* args = 0);
	virtual int svc (void);

	bool Connect(const char* szIP, int nPort);
	bool SendPacket(IBuffPacket* pPacket);

	bool Start();

private:
	ConnectConnector m_ConnectConnector;
	CConnectHandler* m_pConnectHandler;
};
