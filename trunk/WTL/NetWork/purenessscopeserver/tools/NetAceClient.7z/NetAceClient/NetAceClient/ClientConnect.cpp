#include "ClientConnect.h"

CClientConnect::CClientConnect(void)
{
}

CClientConnect::~CClientConnect(void)
{
}

bool CClientConnect::Connect(const char* szIP, int nPort)
{
	ACE_INET_Addr ConnectAddr;

	int nErr = ConnectAddr.set(nPort, szIP);
	if(nErr != 0)
	{
		OUR_DEBUG((LM_INFO, "[CClientConnect::Connect](%d)set_address error.\n", errno));
		return false;
	}

	m_pConnectHandler = new CConnectHandler();

	ACE_Time_Value tv(10);
	ACE_Synch_Options* pSynOption  = new ACE_Synch_Options(ACE_Synch_Options::USE_TIMEOUT, tv);

	if(NULL == pSynOption)
	{
		OUR_DEBUG((LM_ERROR, "[CClientConnect::Connect][%d] pServerConnect->GetOption() is NULL.\n"));
		return false;
	}

	int nRet = m_ConnectConnector.connect(m_pConnectHandler, ConnectAddr, *pSynOption);
	if(nRet != 0)
	{
		OUR_DEBUG((LM_ERROR, "[CServerConnectPool::ConnectToServer](%s:%d)connect error[%d].\n", szIP, nPort, errno));
		return false;
	}

	return true;
}

int CClientConnect::open(void* args)
{
	int nThreadCount = 1;
	if(activate(THR_NEW_LWP | THR_DETACHED | THR_SUSPENDED, nThreadCount) == -1)
	{
		OUR_DEBUG((LM_ERROR, "[CMessageService::open] activate error ThreadCount = [%d].", nThreadCount));
		return -1;
	}

	resume();
	return 0;
}

int CClientConnect::svc(void)
{
	ACE_Reactor::instance()->run_reactor_event_loop();
	return 0;
}

bool CClientConnect::Start()
{
	//��ʼ����־ϵͳ�߳�
	CFileLogger* pFileLogger = new CFileLogger();
	if(NULL == pFileLogger)
	{
		OUR_DEBUG((LM_INFO, "[CClientConnect::Start]pFileLogger new is NULL.\n"));
		return false;
	}

	pFileLogger->Init();
	AppLogManager::instance()->Init();
	if(0 != AppLogManager::instance()->RegisterLog(pFileLogger))
	{
		OUR_DEBUG((LM_INFO, "[CClientConnect::Start]AppLogManager::instance()->RegisterLog error.\n"));
		return false;
	}
	else
	{
		OUR_DEBUG((LM_INFO, "[CClientConnect::Start]AppLogManager is OK.\n"));
	}

	//������־�����߳�
	if(0 != AppLogManager::instance()->Start())
	{
		AppLogManager::instance()->WriteLog(LOG_SYSTEM, "[CClientConnect::Start]AppLogManager is ERROR.");
	}
	else
	{
		AppLogManager::instance()->WriteLog(LOG_SYSTEM, "[CClientConnect::Start]AppLogManager is OK.");
	}

	//��ʼ����Ϣ�̲߳���
	App_MessageService::instance()->Init();

	//��ʼ��Ϣ�����߳�
	if(false == App_MessageService::instance()->Start())
	{
		OUR_DEBUG((LM_INFO, "[CClientConnect::Start]AppLogManager::instance()->RegisterLog error.\n"));
		return false;
	}

	if(0 != open())
	{
		return false;
	}
	else
	{
		return true;
	}
}

bool CClientConnect::SendPacket(IBuffPacket* pPacket)
{
	if(NULL != m_pConnectHandler)
	{
		return m_pConnectHandler->SendMessage(pPacket);
	}
	else
	{
		return false;
	}
}
