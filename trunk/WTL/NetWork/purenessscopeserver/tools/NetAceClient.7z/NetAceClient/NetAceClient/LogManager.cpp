// LogManager.h
// Log�Ĺ����࣬����Log��־�Ķ��������
// һ��ʼ�������Ϊһ��DLL����ʵ�֣����ǿ���һ�£����Ƿ��ڿ������ʵ�ֱȽϺá�
// add by freeeyes
// 2009-04-04

#include "LogManager.h"

Mutex_Allocator _log_service_mb_allocator; 

CLogManager::CLogManager(void)
{
	m_blRun         = false;
	m_nThreadCount  = 1;
	m_nQueueMax     = MAX_MSG_THREADQUEUE;
}

CLogManager::~CLogManager(void)
{
}

int CLogManager::open(void *args)
{
	if(activate(THR_NEW_LWP | THR_DETACHED, m_nThreadCount) == -1)
	{
		m_blRun = false;
		OUR_DEBUG((LM_ERROR,"[%D|%t] %p\n","[CLogManager::open] activate is error[%d].", errno));
		return -1;
	}

	m_blRun = true;
	return 0;
}

int CLogManager::svc(void)
{
	OUR_DEBUG((LM_INFO,"[CLogManager::svc] svc run.\n"));
	ACE_Message_Block* mb = NULL;
	ACE_Time_Value     xtime;
	while(m_blRun)
	{
		int msgcount = (int)msg_queue()->message_count();

		mb = NULL;
		xtime=ACE_OS::gettimeofday()+ACE_Time_Value(0, MAX_MSG_PUTTIMEOUT);
		if(getq(mb, &xtime) == -1)
		{
			continue;
		}

		if (mb == NULL)
		{
			continue;
		}

		ACE_TString* pstrLogText = *((ACE_TString**)mb->base());
		if (!pstrLogText)
		{
			OUR_DEBUG((LM_ERROR,"[CLogManager::svc] CLogManager mb log == NULL!\n"));
			mb->release();
			continue;
		}

		ProcessLog(mb->msg_type(), pstrLogText);
		mb->release();
		//OUR_DEBUG((LM_ERROR,"[CLogManager::svc] delete pstrLogText BEGIN!\n"));
		delete pstrLogText;
		//OUR_DEBUG((LM_ERROR,"[CLogManager::svc] delete pstrLogText END!\n"));

	}
	OUR_DEBUG((LM_INFO,"[CLogManager::svc] CLogManager::svc finish!\n"));
	return 0;
}

int CLogManager::close(u_long)
{
	m_blRun = false;
	return 0;
}

void CLogManager::Init(int nThreadCount, int nQueueMax)
{
	m_nThreadCount = nThreadCount;
	m_nQueueMax    = nQueueMax;
}

int CLogManager::Start()
{
	if(m_blRun == true)
	{
		return 0;
	}
	else
	{
		return open();
	}
	
}

int CLogManager::Stop()
{
	m_blRun = false;
	return 0;
}

bool CLogManager::IsRun()
{
	return m_blRun;
}

int CLogManager::PutLog(int nLogType, ACE_TString *pLogText)
{
	ACE_Message_Block* mb = NULL;

	ACE_NEW_MALLOC_NORETURN (mb,
		ACE_static_cast
		(	ACE_Message_Block*,
		_log_service_mb_allocator.malloc (sizeof (ACE_Message_Block))
		),
		ACE_Message_Block
		(	sizeof(ACE_TString *), // size
		nLogType,
		0,
		0,
		&_log_service_mb_allocator, // allocator_strategy
		0, // locking strategy
		ACE_DEFAULT_MESSAGE_BLOCK_PRIORITY, // priority
		ACE_Time_Value::zero,
		ACE_Time_Value::max_time,
		&_log_service_mb_allocator,
		&_log_service_mb_allocator
		)
		);		

	if(mb)
	{
		ACE_TString** loadin = (ACE_TString **)mb->base();
		*loadin = pLogText;

		int msgcount = (int)msg_queue()->message_count();
		if (msgcount >= m_nQueueMax) 
		{
			OUR_DEBUG((LM_INFO,"[CLogManager::PutLog] CLogManager queue is full!\n"));
			mb->release();
			return 1;
		}
		ACE_Time_Value xtime;
		xtime = ACE_OS::gettimeofday()+ACE_Time_Value(0, MAX_MSG_PUTTIMEOUT);
		if(this->putq(mb, &xtime) == -1)
		{
			OUR_DEBUG((LM_ERROR,"[CLogManager::PutLog] CLogManager putq error!\n"));
			mb->release();
			return -1;
		}
		return 0;
	}

	OUR_DEBUG((LM_ERROR,"[CLogManager::PutLog] CLogManager new ACE_Message_Block error!\n"));	
	return -1;
}

int CLogManager::RegisterLog(CServerLogger* pServerLogger)
{
	if(pServerLogger == NULL)
	{
		return -1;
	}

	int nLogTypeCount = pServerLogger->GetLogTypeCount();

	for(int i = 0; i < nLogTypeCount; i++)
	{
		int nLogType = pServerLogger->GetLogType(i);
		if(nLogType <= 0)
		{
			continue;
		}

		m_mapServerLogger.AddMapData(nLogType, pServerLogger);
	}

	return 0;
}

int CLogManager::UnRegisterLog(CServerLogger* pServerLogger)
{
	CServerLogger* pTempServerLogger = NULL;
	vector<int>    vecDel;
	int            i = 0;

	int nLogTypeCount = m_mapServerLogger.GetSize();
	for(i = 0; i < nLogTypeCount; i++)
	{
		pTempServerLogger = m_mapServerLogger.GetMapData(i);
		if(pTempServerLogger == pServerLogger)
		{
			int nLogType = m_mapServerLogger.GetMapDataKey(i);
			vecDel.push_back(nLogType);
		}
	}

	for(i = 0; i < (int)vecDel.size(); i++)
	{
		m_mapServerLogger.DelMapData(vecDel[i]);
	}

	return 0;
}

int CLogManager::ProcessLog(int nLogType, ACE_TString* pLogText)
{
	CServerLogger* pServerLogger = NULL;

	pServerLogger = m_mapServerLogger.SearchMapData(nLogType);
	if(NULL == pServerLogger)
	{
		return -1;
	}

	m_Logger_Mutex.acquire();
	pServerLogger->DoLog(nLogType, pLogText);
	m_Logger_Mutex.release();
	return 0;
}

//*****************************************************************************

int CLogManager::WriteLog(int nLogType, char* fmt, ...)
{
	int  nRet = 0;
	char szTemp[MAX_BUFF_1024*5] = {'\0'};
	va_list ap;
	va_start(ap, fmt);
	ACE_OS::vsnprintf(szTemp,sizeof(szTemp)-1,fmt, ap);
	va_end(ap);
	ACE_TString* pstrLog= new ACE_TString(szTemp,ACE_OS::strlen(szTemp));
	if (pstrLog)
	{

		if (IsRun()) 
		{
			nRet = PutLog(nLogType, pstrLog);
			if (nRet) 
			{
				delete pstrLog;
				pstrLog = NULL;
			}
		} 
		else 
		{
			delete pstrLog;
			pstrLog = NULL;
		}
	}
	else 
	{
		nRet = -1;
	}
	return nRet;
}

int CLogManager::WriteLog(int nLogType, int nIndex, char* szLofText)
{
	int  nRet = 0;
	char szTemp[MAX_BUFF_1024*5] = {'\0'};
	ACE_TString* pstrLog= new ACE_TString(szTemp,ACE_OS::strlen(szLofText));
	if (pstrLog)
	{

		if (IsRun()) 
		{
			nRet = PutLog(nLogType, pstrLog);
			if (nRet) 
			{
				delete pstrLog;
				pstrLog = NULL;
			}
		} 
		else 
		{
			delete pstrLog;
			pstrLog = NULL;
		}
	}
	else 
	{
		nRet = -1;
	}
	return nRet;
}
