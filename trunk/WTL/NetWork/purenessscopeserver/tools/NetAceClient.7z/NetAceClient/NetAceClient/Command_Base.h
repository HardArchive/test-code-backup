#pragma once

#include "LogManager.h"
#include "ClientCommand.h"
#include <string>

using namespace std;

class CCommand_Base : public CClientCommand
{
public:
	CCommand_Base(void);
	~CCommand_Base(void);

	int DoMessage(IMessage* pMessage, bool& bDeleteFlag);
	void SetLogManager(ILogManager* pLogManager);

private:
	ILogManager*     m_pLogManager;
};
