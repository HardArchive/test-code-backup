#ifndef _PROSERVERMANAGER_H
#define _PROSERVERMANAGER_H

#include "define.h"
#include "MainConfig.h"
#include "ProConnectAccept.h"
#include "AceProactorManager.h"
#include "MessageService.h"
#include "ProServerConnectManager.h"
#include "SigHandle.h"
#include "LoadModule.h"
#include "LogManager.h"
#include "FileLogger.h"
#include "IObject/IObject.h"
#include "BuffPacketManager.h"
#include "TimerManager.h"

class CProServerManager
{
public:
	CProServerManager(void);
	~CProServerManager(void);

	bool Init();
	bool Start();
	bool Close();

private:
	CProConnectAcceptManager m_ConnectAcceptorManager;
};

typedef ACE_Singleton<CProServerManager, ACE_Null_Mutex> App_ProServerManager;
#endif
