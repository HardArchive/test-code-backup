#include "PostServerService.h"

Mutex_Allocator _msg_postservice_mb_allocator; 

CPostServerService::CPostServerService(void)
{
	m_u4ThreadNo    = 0;
	m_u4ThreadCount = MAX_MSG_THREADCOUNT;
	m_u4MaxQueue    = MAX_MSG_THREADQUEUE;
	m_u4TimerID     = 0;
	m_blRun         = false;
	m_u4HighMask    = 0;
	m_u4LowMask     = 0;
	m_u4PutTimeOut  = MAX_MSG_PUTTIMEOUT;
	m_u4MsgCurrID   = 0;

	uint16 u2ThreadTimeOut = App_MainConfig::instance()->GetPostThreadTimuOut();
	if(u2ThreadTimeOut <= 0)
	{
		m_u2ThreadTimeOut = MAX_MSG_THREADTIMEOUT;
	}
	else
	{
		m_u2ThreadTimeOut = u2ThreadTimeOut;
	}

	uint16 u2ThreadTimeCheck = App_MainConfig::instance()->GetPostThreadTimeCheck();
	if(u2ThreadTimeOut <= 0)
	{
		m_u2ThreadTimeCheck = MAX_MSG_TIMEDELAYTIME;
	}
	else
	{
		m_u2ThreadTimeCheck = u2ThreadTimeCheck;
	}
}

CPostServerService::~CPostServerService(void)
{
	PostMapClear();
}

void CPostServerService::Init(uint32 u4ThreadCount, uint32 u4MaxQueue, uint32 u4LowMask, uint32 u4HighMask)
{
	m_u4ThreadCount = u4ThreadCount;
	m_u4MaxQueue    = u4MaxQueue;
	m_u4HighMask    = u4HighMask;
	m_u4LowMask     = u4LowMask;
}

bool CPostServerService::StartTimer()
{
	OUR_DEBUG((LM_ERROR, "CPostServerService::StartTimer()-->begin....\n"));

	App_TimerManager::instance()->schedule(this, NULL, ACE_Time_Value(MAX_MSG_STARTTIME), ACE_Time_Value(m_u2ThreadTimeCheck));
	if(-1 == m_u4TimerID)
	{
		OUR_DEBUG((LM_ERROR, "CPostServerService::StartTimer()--> Start thread time error.\n"));
		return false;
	}
	else
	{
		OUR_DEBUG((LM_ERROR, "CPostServerService::StartTimer()--> Start thread time OK.\n"));
		return true;
	}
}

bool CPostServerService::KillTimer()
{
	if(m_u4TimerID > 0)
	{
		App_TimerManager::instance()->cancel(m_u4TimerID);
		m_u4TimerID = 0;
	}
	return true;
}

bool CPostServerService::IsRun()
{
	ACE_Guard<ACE_Thread_Mutex> guard(m_RunMutex);

	return m_blRun;
}

bool CPostServerService::Start()
{
	if(false == StartTimer())
	{
		return false;
	}

	if(0 != open())
	{
		return false;
	}

	return true;
}

bool CPostServerService::PutPostRecvMessage(uint32 u4MsgID, IBuffPacket* pBuffPacket)
{
	//�õ�������м��������Ϣ
	IPostMessage* pPostMessage = PostMapPop(u4MsgID);

	int nMsgType = 1;  //����

	if(NULL == pPostMessage)
	{
		OUR_DEBUG((LM_ERROR,"[CPostServerService::PutMessage] Get pPostMessage NULL = [%d].\n", u4MsgID));
		return false;
	}

	if(false == pPostMessage->SetRecvPacket(pBuffPacket))
	{
		OUR_DEBUG((LM_ERROR,"[CPostServerService::PutMessage] Get SetRecvPacket fail = [%d].\n", u4MsgID));
		return false;
	}

	ACE_Message_Block* mb = NULL;

	ACE_NEW_MALLOC_NORETURN(mb, 
		ACE_static_cast(ACE_Message_Block*, _msg_postservice_mb_allocator.malloc(sizeof(ACE_Message_Block))),
		ACE_Message_Block(sizeof(CMessage*), // size
		nMsgType, // type
		0,
		0,
		&_msg_postservice_mb_allocator, // allocator_strategy
		0, // locking strategy
		ACE_DEFAULT_MESSAGE_BLOCK_PRIORITY, // priority
		ACE_Time_Value::zero,
		ACE_Time_Value::max_time,
		&_msg_postservice_mb_allocator,
		&_msg_postservice_mb_allocator
		));

	if(NULL != mb)
	{
		IPostMessage** ppMessage = (IPostMessage **)mb->base();
		*ppMessage = pPostMessage;

		//�ж϶����Ƿ����Ѿ����
		int nQueueCount = (int)msg_queue()->message_count();
		if(nQueueCount >= (int)m_u4MaxQueue)
		{
			OUR_DEBUG((LM_ERROR,"[CPostServerService::PutMessage] Queue is Full nQueueCount = [%d].\n", nQueueCount));
			mb->release();
			return false;
		}

		ACE_Time_Value xtime = ACE_OS::gettimeofday() + ACE_Time_Value(0, MAX_MSG_PUTTIMEOUT);
		if(this->putq(mb, &xtime) == -1)
		{
			OUR_DEBUG((LM_ERROR,"[CPostServerService::PutMessage] Queue putq  error nQueueCount = [%d] errno = [%d].\n", nQueueCount, errno));
			mb->release();
			return false;
		}
	}
	else
	{
		OUR_DEBUG((LM_ERROR,"[CPostServerService::PutMessage] mb new error.\n"));
		return false;
	}

	return true;
}

bool CPostServerService::PutPostSendMessage(IPostMessage* pPostMessage)
{
	int nMsgType = 0;       //����

	ACE_Message_Block* mb = NULL;

	ACE_NEW_MALLOC_NORETURN(mb, 
		ACE_static_cast(ACE_Message_Block*, _msg_postservice_mb_allocator.malloc(sizeof(ACE_Message_Block))),
		ACE_Message_Block(sizeof(CMessage*), // size
		nMsgType, // type
		0,
		0,
		&_msg_postservice_mb_allocator, // allocator_strategy
		0, // locking strategy
		ACE_DEFAULT_MESSAGE_BLOCK_PRIORITY, // priority
		ACE_Time_Value::zero,
		ACE_Time_Value::max_time,
		&_msg_postservice_mb_allocator,
		&_msg_postservice_mb_allocator
		));

	if(NULL != mb)
	{
		IPostMessage** ppMessage = (IPostMessage **)mb->base();
		*ppMessage = pPostMessage;

		//�ж϶����Ƿ����Ѿ����
		int nQueueCount = (int)msg_queue()->message_count();
		if(nQueueCount >= (int)m_u4MaxQueue)
		{
			OUR_DEBUG((LM_ERROR,"[CPostServerService::PutMessage] Queue is Full nQueueCount = [%d].\n", nQueueCount));
			mb->release();
			return false;
		}

		ACE_Time_Value xtime = ACE_OS::gettimeofday() + ACE_Time_Value(0, MAX_MSG_PUTTIMEOUT);
		if(this->putq(mb, &xtime) == -1)
		{
			OUR_DEBUG((LM_ERROR,"[CPostServerService::PutMessage] Queue putq  error nQueueCount = [%d] errno = [%d].\n", nQueueCount, errno));
			mb->release();
			return false;
		}
	}
	else
	{
		OUR_DEBUG((LM_ERROR,"[CPostServerService::PutMessage] mb new error.\n"));
		return false;
	}

	return true;
}

int CPostServerService::open(void* args)
{
	m_blRun = true;
	msg_queue()->high_water_mark(m_u4HighMask);
	msg_queue()->low_water_mark(m_u4LowMask);

	OUR_DEBUG((LM_INFO,"[CPostServerService::open] m_u4HighMask = [%d] m_u4LowMask = [%d]\n", m_u4HighMask, m_u4LowMask));
	if(activate(THR_NEW_LWP | THR_DETACHED | THR_SUSPENDED, m_u4ThreadCount) == -1)
	{
		OUR_DEBUG((LM_ERROR, "[CPostServerService::open] activate error ThreadCount = [%d].", m_u4ThreadCount));
		m_blRun = false;
		return -1;
	}

	resume();

	//�����߳���Ϣ
	for(uint32 i = 0; i < m_u4ThreadCount; i++)
	{
		m_ThreadInfo.AddThreadInfo(i);
	}

	return 0;
}

int CPostServerService::svc(void)
{
	uint32 u4threadCurNo = 0;
	ACE_Message_Block* mb = NULL;
	ACE_Time_Value xtime;

	m_rwThreadLock.acquire_write();
	u4threadCurNo = m_u4ThreadNo;
	m_u4ThreadNo++;

	m_rwThreadLock.release();
	OUR_DEBUG((LM_INFO,"[CPostServerService::svc] CurrthreadNo=[%d] ...\n", u4threadCurNo));

	//��ȡ�̵߳�ϵͳID
	_ThreadInfo* pThreadInfo = m_ThreadInfo.GetThreadInfo(u4threadCurNo);
	if(NULL == pThreadInfo)
	{
		OUR_DEBUG((LM_ERROR,"[CMessageService::svc] pThreadInfo[%d] is not find.\n", u4threadCurNo));
		return true;
	}

	if(pThreadInfo->m_u4ThreadIndex == 0)
	{
		pThreadInfo->m_u4ThreadIndex = ACE_OS::thr_self();
	}

	ACE_OS::sleep(1);

	while(IsRun())
	{
		mb = NULL;
		xtime = ACE_OS::gettimeofday() + ACE_Time_Value(0, MAX_MSG_PUTTIMEOUT);
		if(getq(mb, &xtime) == -1)
		{
			//OUR_DEBUG((LM_ERROR,"[CMessageService::PutMessage] getq error errno = [%d].\n", errno));
			continue;
		}
		if (mb == NULL)
		{
			continue;
		}
		IPostMessage* msg = *((IPostMessage**)mb->base());
		if (! msg)
		{
			OUR_DEBUG((LM_ERROR,"[CPostServerService::svc] mb msg == NULL CurrthreadNo=[%d]!\n", u4threadCurNo));
			mb->release();
			continue;
		}

		//���������Ϣ�ı�־λ�ж���ʲô������0Ϊ���ͣ�1Ϊ����
		pThreadInfo->m_u4State = THREAD_RUNBEGIN;
		if(mb->msg_type() == 0)
		{
			//���ͣ����͸��м��������ͬʱ��¼�߳���Ϣ��
			pThreadInfo->m_u4SendPacketCount++;
			pThreadInfo->m_u2CommandID = msg->GetCommandID();
			int nMsgID = GetPostMsgID();
			PostMapInsert(nMsgID, msg);
			App_ServerConnectManager::instance()->SetSendMessage(msg->GetServerID(), msg->GetSendPacket(), nMsgID);
			
		}

		if(mb->msg_type() == 1)
		{
			//���գ����յ��ظ���ɾ������ͬʱ��¼�߳���Ϣ��
			pThreadInfo->m_u4RecvPacketCount++;
			pThreadInfo->m_u2CommandID = msg->GetCommandID();
			msg->CallBack();
			delete msg;
			
		}

		pThreadInfo->m_u4State = THREAD_RUNEND;

		//delete msg;
		mb->release();
	}

	OUR_DEBUG((LM_INFO,"[CPostServerService::svc] svc finish!\n"));
	return 0;
}

int CPostServerService::close(u_long)
{
	m_blRun = false;
	OUR_DEBUG((LM_INFO,"[CPostServerService::close] close().\n"));
	return 0;
}

int CPostServerService::handle_timeout(const ACE_Time_Value &tv, const void *arg)
{
	//��������߳��Լ�
	for(uint32 i = 0; i < m_u4ThreadCount; i++)
	{
		_ThreadInfo* pThreadInfo = m_ThreadInfo.GetThreadInfo(i);
		if(NULL != pThreadInfo)
		{
			ACE_Time_Value tvNow(ACE_OS::gettimeofday());
			ACE_Date_Time dt(pThreadInfo->m_tvUpdateTime);
			//��ʼ�鿴�߳��Ƿ�ʱ
			if(pThreadInfo->m_u4State == THREAD_RUNBEGIN && tvNow.sec() - pThreadInfo->m_tvUpdateTime.sec() > m_u2ThreadTimeOut)
			{
				AppLogManager::instance()->WriteLog(LOG_SYSTEM_POSTTHREAD, "[CPostServerService::handle_timeout] pThreadInfo = [%d] State = [%d] Time = [%04d-%02d-%02d %02d:%02d:%02d] RecvPacketCount = %d, SendpacketCount = %d, LastCommand = 0x%x TimeOut > 30[%d].", 
																		   pThreadInfo->m_u4ThreadID, 
																		   pThreadInfo->m_u4State, 
																		   dt.year(), dt.month(), dt.day(), dt.hour(), dt.minute(), dt.second(), 
																		   pThreadInfo->m_u4RecvPacketCount,
																		   pThreadInfo->m_u4SendPacketCount,
																		   pThreadInfo->m_u2CommandID,
																		   tvNow.sec() - pThreadInfo->m_tvUpdateTime.sec());

				//���������̣߳�������Ӧ���߳�
				ACE_OS::thr_kill(pThreadInfo->m_u4ThreadIndex, SIGALRM);
				AppLogManager::instance()->WriteLog(LOG_SYSTEM_POSTTHREAD, "[CPostServerService::handle_timeout]  pThreadInfo = [%d] ThreadID = [%d] Thread is reset.", pThreadInfo->m_u4ThreadID, pThreadInfo->m_u4ThreadIndex);
			}
			else
			{
				AppLogManager::instance()->WriteLog(LOG_SYSTEM_POSTTHREAD, "[CPostServerService::handle_timeout] pThreadInfo = [%d] State = [%d] Time = [%04d-%02d-%02d %02d:%02d:%02d] RecvPacketCount = %d, SendpacketCount = %d, LastCommand = 0x%x.", 
																		   pThreadInfo->m_u4ThreadID, 
																		   pThreadInfo->m_u4State, 
																		   dt.year(), dt.month(), dt.day(), dt.hour(), dt.minute(), dt.second(), 
																		   pThreadInfo->m_u4RecvPacketCount,
																		   pThreadInfo->m_u4SendPacketCount,
																		   pThreadInfo->m_u2CommandID);
			}
		}
		else
		{
			OUR_DEBUG((LM_INFO,"[CPostServerService::handle_timeout] pThreadInfo = [%d] Not find.\n", i));
		}
	}

	return 0;
}

bool CPostServerService::PostMapClear()
{
	mapPostMessage::iterator b = m_mapPostMessage.begin();
	mapPostMessage::iterator e = m_mapPostMessage.end();

	for(b; b != e; b++)
	{
		IPostMessage* pPostMessage = (IPostMessage* )b->second;
		if(NULL != pPostMessage)
		{
			delete pPostMessage;
		}
	}

	return true;
}

bool CPostServerService::PostMapInsert(uint32 u4MsgID, IPostMessage* pMessage)
{
	mapPostMessage::iterator f = m_mapPostMessage.find(u4MsgID);

	if(f != m_mapPostMessage.end())
	{
		OUR_DEBUG((LM_INFO,"[CPostServerService::PostMapInsert] u4MsgID = [%d] is find.\n", u4MsgID));
		return false;
	}
	else
	{
		m_mapPostMessage.insert(mapPostMessage::value_type(u4MsgID, pMessage));
		return true;
	}
}

IPostMessage* CPostServerService::PostMapPop(uint32 u4MsgID)
{
	mapPostMessage::iterator f = m_mapPostMessage.find(u4MsgID);

	int nSize = (int)m_mapPostMessage.size();

	if(f == m_mapPostMessage.end())
	{
		OUR_DEBUG((LM_INFO,"[CPostServerService::PostMapInsert] u4MsgID = [%d] not find.\n", u4MsgID));
		return NULL;
	}
	else
	{
		IPostMessage* pPostMessage = (IPostMessage* )f->second;
		return pPostMessage;
	}
}

uint32 CPostServerService::GetPostMsgID()
{
	if(m_u4MsgCurrID >= MAX_POSTMESSAGE_SIZE)
	{
		m_u4MsgCurrID = 1;
	}
	else
	{
		m_u4MsgCurrID++;
	}

	return m_u4MsgCurrID;
}
