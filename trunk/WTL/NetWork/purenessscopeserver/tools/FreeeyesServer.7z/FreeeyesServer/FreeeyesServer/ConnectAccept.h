#ifndef _CONNECTACCEPT_H
#define _CONNECTACCEPT_H

#include "ConnectHandler.h"

#include <vector>

using namespace std;

typedef ACE_Acceptor<CConnectHandler, ACE_SOCK_ACCEPTOR> ConnectAcceptor;
typedef ACE_Singleton<ConnectAcceptor, ACE_Null_Mutex> App_ClientAcceptor;

class CConnectAcceptorManager
{
public:
	CConnectAcceptorManager(void);
	~CConnectAcceptorManager(void);

	bool InitConnectAcceptor(int nCount);
	void Close();
	int GetCount();
	ConnectAcceptor* GetConnectAcceptor(int nIndex);
	const char* GetError();

private:
	typedef vector<ConnectAcceptor*> vecConnectAcceptor;
	vecConnectAcceptor m_vecConnectAcceptor;
	int                m_nAcceptorCount;
	char               m_szError[MAX_BUFF_500];
};



#endif
