#include "ProServerConnectPool.h"

CProServerConnectPool::CProServerConnectPool(void)
{
	m_u4ServerConnectCount = 0;
}

CProServerConnectPool::~CProServerConnectPool(void)
{
	Close();
}

bool CProServerConnectPool::AddServerConnect(uint32 u4Index, ACE_Proactor* pProactor, _ServerConnectInfo* pServerConnectInfo)
{
	mapServerConnect::iterator f = m_mapServerConnect.find(u4Index);
	if(f != m_mapServerConnect.end())
	{
		OUR_DEBUG((LM_ERROR, "[CProServerConnectPool::AddServerConnect] u4Index = [%d] is exist.\n", u4Index));
		return false;
	}

	CProServerConnect* pServerConnect = new CProServerConnect();
	if(NULL == pServerConnect)
	{
		OUR_DEBUG((LM_ERROR, "[CProServerConnectPool::AddServerConnect] u4Index = [%d] new pServerConnect error.\n", u4Index));
		return false;
	}

	if(false == pServerConnect->Init(pProactor, pServerConnectInfo))
	{
		OUR_DEBUG((LM_ERROR, "[CProServerConnectPool::AddServerConnect] u4Index = [%d] pServerConnect->Init error.\n", u4Index));
		return false;
	}

	m_mapServerConnect.insert(mapServerConnect::value_type(u4Index, pServerConnect));

	return true;
}

CProServerConnect* CProServerConnectPool::GetServerConnect(uint32 u4Index)
{
	mapServerConnect::iterator f = m_mapServerConnect.find(u4Index);
	if(f != m_mapServerConnect.end())
	{
		return (CProServerConnect* )f->second;
	}
	else
	{
		return NULL;
	}
}

void CProServerConnectPool::Close()
{
	mapServerConnect::iterator b = m_mapServerConnect.begin();
	mapServerConnect::iterator e = m_mapServerConnect.end();

	for(b; b != e; b++)
	{
		CProServerConnect* pServerConnect = (CProServerConnect* )b->second;
		if(NULL != pServerConnect)
		{
			delete pServerConnect;
			pServerConnect = NULL;
		}
	}

	m_mapServerConnect.clear();
}

uint32 CProServerConnectPool::GetConnectCount()
{
	return m_u4ServerConnectCount;
}

bool CProServerConnectPool::ConnectServer(CProServerConnect* pServerConnect)
{
	//��ʼ���ӷ�����
	if(NULL == pServerConnect)
	{
		OUR_DEBUG((LM_ERROR, "[CProServerConnectPool::ConnectToServer] pServerConnect->GetRemoteAddr() is NULL.\n"));
		return false;
	}

	_ServerConnectInfo* pServerConnectInfo = pServerConnect->GetServerConnectInfo();

	if(NULL == pServerConnectInfo)
	{
		OUR_DEBUG((LM_ERROR, "[CProServerConnectPool::ConnectToServer] pServerConnectInfo is NULL.\n"));
		return false;
	}

	ACE_INET_Addr*      pAddrRemote;

	pAddrRemote = pServerConnect->GetRemoteAddr();

	if(NULL == pAddrRemote)
	{
		OUR_DEBUG((LM_ERROR, "[CProServerConnectPool::ConnectToServer] pServerConnect->GetRemoteAddr() is NULL.\n"));
		return false;
	}

	m_ConnectorFactory.SetHandle(pServerConnect);
	m_ConnectorFactory.open();
	int nRet = m_ConnectorFactory.connect(*pAddrRemote);
	if(nRet != 0)
	{
		OUR_DEBUG((LM_ERROR, "[CProServerConnectPool::ConnectToServer](%s:%d)connect error[%d].\n", pServerConnectInfo->m_strServerIP.c_str(), pServerConnectInfo->m_u4ServerPort, errno));
		return false;
	}

	return true;
}

bool CProServerConnectPool::Init(ACE_Proactor* pProactor, _ServerConnectInfo* pServerConnectInfo)
{
	if(NULL == pProactor)
	{
		OUR_DEBUG((LM_ERROR, "[CProServerConnectPool::Init] pReactor is NULL.\n"));
		return false;
	}

	if(NULL == pServerConnectInfo)
	{
		OUR_DEBUG((LM_ERROR, "[CProServerConnectPool::Init] pServerConnectInfo is NULL.\n"));
		return false;
	}

	int nThreadCount = 0;
	for(uint32 i = 0; i < pServerConnectInfo->m_u4MaxConn; i++)
	{
		//�����µ�pServerConnectInfo
		if(false == AddServerConnect(i, pProactor, pServerConnectInfo))
		{
			return false;
		}

		CProServerConnect* pServerConnect = GetServerConnect(i);
		if(NULL == pServerConnect)
		{
			OUR_DEBUG((LM_ERROR, "[CProServerConnectPool::Init] Can't find [%d] pServerConnect.\n", i));
			return false;
		}

		if(false == ConnectServer(pServerConnect))
		{
			OUR_DEBUG((LM_ERROR, "[CProServerConnectPool::Init] ConnectToServer m_u4ServerID = %d, [%d] is fail.\n", pServerConnectInfo->m_u4ServerID, i));
			return false;
		}
		else
		{
			OUR_DEBUG((LM_ERROR, "[CProServerConnectPool::Init] ConnectToServer m_u4ServerID = %d, [%d] is OK.\n", pServerConnectInfo->m_u4ServerID, i));
		}

		nThreadCount++;
		m_u4ServerConnectCount = nThreadCount;
		m_RandomNumber.SetRange(0, m_u4ServerConnectCount - 1);
	}
	return true;
}

int CProServerConnectPool::GetRandomServerConnectID()
{
	return m_RandomNumber.GetRandom();
}
