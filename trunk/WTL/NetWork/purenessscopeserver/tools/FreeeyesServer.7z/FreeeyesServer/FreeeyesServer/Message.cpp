// BuffPacket.h
// ������Ϣ���࣬���ڽ���Ϣ�ַ�����Ҫ����������
// ѧϰ�Ǳ�Ҫ�ģ�������Ҫ�������ҵ�ʵ������ƣ�������ǣ���Ҫ����սʤ����
// add by freeeyes
// 2009-01-10

#include "Message.h"

CMessage::CMessage(void)
{
	m_pRecvPacket   = NULL;
	m_pSendPacket   = NULL;
	m_pMessageBase  = NULL;
	m_szError[0]    = '\0';
	m_szClientIP[0] = '\0';
	m_nClientPort   = 0;
}

CMessage::~CMessage(void)
{
	Close();
}

const char* CMessage::GetError()
{
	return m_szError;
}

void CMessage::SetMessageBase(_MessageBase* pMessageBase)
{
	if(NULL != m_pMessageBase)
	{
		delete m_pMessageBase;
		m_pMessageBase = NULL;
	}

	m_pMessageBase = pMessageBase;
}

bool CMessage::SetMessageInfo(const char* szClientIP, int nClientPort)
{
	sprintf_safe(m_szClientIP, MAX_BUFF_20, "%s", szClientIP);
	m_nClientPort = nClientPort;

	return true;
}

char* CMessage::GetClientIP()
{
	return m_szClientIP;
}

int CMessage::GetClientPort()
{
	return m_nClientPort;
}


bool CMessage::SetRecvPacket(IBuffPacket* pRecvPacket)
{
	if(NULL == pRecvPacket)
	{
		sprintf_safe(m_szError, MAX_BUFF_500, "[CMessage::SetRecvPacket]Set RecvPacket is NULL");
		return false;
	}

	if(NULL != m_pRecvPacket)
	{
		delete m_pRecvPacket;
		m_pRecvPacket = NULL;
	}
	
	m_pRecvPacket = pRecvPacket;
	return true;
}

bool CMessage::SetSendPacket(IBuffPacket* pSendPacket)
{
	if(NULL == pSendPacket)
	{
		sprintf_safe(m_szError, MAX_BUFF_500, "[CMessage::SetSendPacket]Set pSendPacket is NULL");
		return false;
	}

	if(NULL != m_pSendPacket)
	{
		delete m_pSendPacket;
		m_pSendPacket = NULL;
	}

	m_pSendPacket = pSendPacket;

	return true;
}

_MessageBase* CMessage::GetMessageBase()
{
	return m_pMessageBase;
}

IBuffPacket* CMessage::GetRecvPacket()
{
	return m_pRecvPacket;
}

IBuffPacket* CMessage::GetSendPacket()
{
	return m_pSendPacket;
}

void CMessage::Close()
{
	if(NULL != m_pMessageBase)
	{
		delete m_pMessageBase;
		m_pMessageBase = NULL;
	}

	if(NULL != m_pRecvPacket)
	{
		delete m_pRecvPacket;
		m_pRecvPacket = NULL;
	}

	if(NULL != m_pSendPacket)
	{
		delete m_pSendPacket;
		m_pSendPacket = NULL;
	}
}

