#ifndef _PROSERVERCONNECT_H
#define _PROSERVERCONNECT_H

#include "define.h"
#include "ace/Synch.h"
#include "ace/Synch_Traits.h"
#include "ace/Singleton.h"
#include "ace/Condition_T.h"
#include "ace/SOCK_Stream.h"
#include "ace/Svc_Handler.h"
#include "ace/Connector.h" 
#include "ace/Asynch_Connector.h"
#include "ace/Asynch_IO.h"
#include "ace/Proactor.h"
#include "ace/Mutex.h" 
#include "ace/Thread_Mutex.h"

#include "LogManager.h"
#include "BuffPacket.h"
#include "Message.h"
#include <deque>

using namespace std;

class CProServerConnect : public ACE_Service_Handler
{
public:
	CProServerConnect(void);
	~CProServerConnect(void);

	bool Init(ACE_Proactor* pProactor, _ServerConnectInfo* pServerConnectInfo);

	//��д�̳з���
	virtual void open(ACE_HANDLE h, ACE_Message_Block&);                                 //�û�����һ������
	virtual void handle_read_stream(const ACE_Asynch_Read_Stream::Result &result);
	virtual void handle_write_stream(const ACE_Asynch_Write_Stream::Result &result);
	virtual void addresses (const ACE_INET_Addr &remote_address, const ACE_INET_Addr &local_address);

	bool GetConnectState();
	void SetConnectTime();
	void SetUpdateTime();
	ACE_INET_Addr* GetRemoteAddr();
	ACE_Synch_Options* GetOption();
	void Close();
	bool SendMessage(IBuffPacket* pBuffPacket, uint32 u4MsgID);
	_ServerConnectInfo* GetServerConnectInfo(); 

private:
	bool CheckMessage();
	uint32 GetConnectID();
	bool PutSendPacket(IBuffPacket* pBuffPacket);             //���м��������������

	void SetMessageID(uint32 u4MsgID);
	uint32 GetMessageID();

private:
	char                               m_szError[MAX_BUFF_500];
	_ServerConnectInfo*                m_pServerConnectInfo;
	ACE_Proactor*                      m_pProactor; 
	ACE_Time_Value                     m_tvConnectTime;
	ACE_Time_Value                     m_tvUpdateTime;
	ACE_Time_Value                     m_atvInput;
	ACE_Time_Value                     m_atvOutput;
	ACE_INET_Addr*                     m_pAddrRemote;
	ACE_Synch_Options*                 m_pSynOption;
	bool                               m_blConnect;
	CBuffPacket                        m_RecvPacket;

	uint8                              m_u1ConnectState;               //��ǰ����״̬
	uint32                             m_u4AllRecvCount;               //��ǰ���ӽ������ݰ��ĸ���
	uint32                             m_u4AllSendCount;               //��ǰ���ӷ������ݰ��ĸ���
	uint32                             m_u4AllRecvSize;                //��ǰ���ӽ����ֽ�����
	uint32                             m_u4AllSendSize;                //��ǰ���ӷ����ֽ�����

	ACE_Thread_Mutex                   m_ThreadReadLock;

	typedef deque<uint32>  dqMessageID;
	dqMessageID                       m_dqMessageID;

	ACE_Asynch_Read_Stream  m_reader;
	ACE_Asynch_Write_Stream m_writer;
	ACE_Message_Block*      m_mbRecv;
};

class CAsynchConnector : public ACE_Asynch_Connector<CProServerConnect>
{
public:
	CAsynchConnector();
	~CAsynchConnector();

	void SetHandle(CProServerConnect* pProServerConnect);

private:
	virtual CProServerConnect* make_handler (void);
	CProServerConnect* Gethandle();

private:
	CProServerConnect* m_pProServerConnect;
};


typedef CAsynchConnector ProConnectorFactory;
#endif
