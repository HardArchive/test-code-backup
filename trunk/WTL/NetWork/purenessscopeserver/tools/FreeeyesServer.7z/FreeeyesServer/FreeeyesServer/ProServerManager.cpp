#include "ProServerManager.h"

CProServerManager::CProServerManager(void)
{
}

CProServerManager::~CProServerManager(void)
{
}

bool CProServerManager::Init()
{
	int nServerPortCount    = App_MainConfig::instance()->GetServerPortCount();
	int nUDPServerPortCount = App_MainConfig::instance()->GetUDPServerPortCount();
	int nReactorCount       = App_MainConfig::instance()->GetReactorCount();

	bool blState = false;

	//��ʼ��������
	if(!m_ConnectAcceptorManager.InitConnectAcceptor(nServerPortCount))
	{
		OUR_DEBUG((LM_INFO, "[CProServerManager::Init]%s.\n", m_ConnectAcceptorManager.GetError()));
		return false;
	}

	//��ʼ����Ӧ��
	for(int i = 0 ; i < nReactorCount + 1; i++)
	{
		OUR_DEBUG((LM_INFO, "[CProServerManager::Init()]... i=[%d].\n",i));
		if(i == 0)
		{
			//�������ֲ���ϵͳ�汾��ʹ�ò�ͬ�ķ�Ӧ��
#ifdef WIN32
			blState = App_ProactorManager::instance()->AddNewProactor(REACTOR_CLIENTDEFINE, Proactor_WIN32, 0);
			OUR_DEBUG((LM_INFO, "[CProServerManager::Init]AddNewProactor REACTOR_CLIENTDEFINE = Proactor_WIN32.\n"));
#else
			blState = App_ProactorManager::instance()->AddNewProactor(REACTOR_CLIENTDEFINE, Proactor_POSIX, 0);
			OUR_DEBUG((LM_INFO, "[CProServerManager::Init]AddNewProactor REACTOR_CLIENTDEFINE = Proactor_POSIX.\n"));	
#endif		
			if(!blState)
			{
				OUR_DEBUG((LM_INFO, "[CProServerManager::Init]AddNewReactor REACTOR_CLIENTDEFINE Error.\n"));
				return false;
			}
		}
		else
		{
#ifdef WIN32
			blState = App_ProactorManager::instance()->AddNewProactor(i, Proactor_WIN32, 1);
			OUR_DEBUG((LM_INFO, "[CProServerManager::Init]AddNewReactor REACTOR_CLIENTDEFINE = Proactor_WIN32.\n"));
#else
			blState = App_ProactorManager::instance()->AddNewProactor(i, Proactor_POSIX, 1);
			OUR_DEBUG((LM_INFO, "[CProServerManager::Init]AddNewReactor REACTOR_CLIENTDEFINE = Proactor_POSIX.\n"));
#endif
			if(!blState)
			{
				OUR_DEBUG((LM_INFO, "[CProServerManager::Init]AddNewReactor [%d] Error.\n", i));
				return false;
			}
		}
	}

	//��ʼ����־ϵͳ�߳�
	CFileLogger* pFileLogger = new CFileLogger();
	if(NULL == pFileLogger)
	{
		OUR_DEBUG((LM_INFO, "[CProServerManager::Init]pFileLogger new is NULL.\n"));
		return false;
	}

	pFileLogger->Init();
	AppLogManager::instance()->Init();
	if(0 != AppLogManager::instance()->RegisterLog(pFileLogger))
	{
		OUR_DEBUG((LM_INFO, "[CProServerManager::Init]AppLogManager::instance()->RegisterLog error.\n"));
		return false;
	}
	else
	{
		OUR_DEBUG((LM_INFO, "[CProServerManager::Init]AppLogManager is OK.\n"));
	}

	//��ʼ�����������������߳�
	App_ProServerConnectManager::instance()->Init();

	//��ʼ����Ϣ�����߳�
	App_MessageService::instance()->Init(App_MainConfig::instance()->GetThreadCount(), App_MainConfig::instance()->GetMsgMaxQueue(), App_MainConfig::instance()->GetMgsHighMark(), App_MainConfig::instance()->GetMsgLowMark());

	//��ʼ���м��������Ϣ�����߳�
	App_PostServerService::instance()->Init(App_MainConfig::instance()->GetPostThreadCount(), App_MainConfig::instance()->GetPostMsgMaxQueue(), App_MainConfig::instance()->GetPostMgsHighMark(), App_MainConfig::instance()->GetPostMsgLowMark());

	//��ʼ��UDP�����߳�
	//App_UDPMessageService::instance()->Init(App_MainConfig::instance()->GetUDPThreadCount(), App_MainConfig::instance()->GetUDPMsgMaxQueue(), App_MainConfig::instance()->GetUDPMgsHighMark(), App_MainConfig::instance()->GetUDPMsgLowMark());

	//��ʼ����DLL�Ķ���ӿ�
	App_ServerObject::instance()->SetMessageManager((IMessageManager* )App_MessageManager::instance());
	App_ServerObject::instance()->SetLogManager((ILogManager*  )AppLogManager::instance());
	App_ServerObject::instance()->SetConnectManager((IConnectManager* )App_ProConnectManager::instance());
	App_ServerObject::instance()->SetPacketManager((IPacketManager* )App_BuffPacketManager::instance());

	if(App_ProServerConnectManager::instance()->GetServerCount() > 0)
	{
		//ע����Ӧ���м����������
		App_ServerObject::instance()->SetPostManager((IPostManager* )App_PostServerService::instance());
	}

	//if(App_MainConfig::instance()->GetUDPServerPortCount() > 0)
	//{
	//	//ע�����UDP�ķ���
	//	App_ServerObject::instance()->SetUDPConnectManager(App_UDPConnectManager::instance());
	//	App_ServerObject::instance()->SetUDPMessageManager(App_UDPMessageManager::instance());
	//}

	//��ʼ��ģ�����
	blState = App_ModuleLoader::instance()->LoadModule(App_MainConfig::instance()->GetModulePath(), App_MainConfig::instance()->GetModuleString());
	if(false == blState)
	{
		return false;
	}

	return true;
}

bool CProServerManager::Start()
{
	//ע���ź���
	if(0 != App_SigHandler::instance()->RegisterSignal(App_ReactorManager::instance()->GetAce_Reactor(REACTOR_CLIENTDEFINE)))
	{
		return false;
	}

	//����TCP����
	int nServerPortCount = App_MainConfig::instance()->GetServerPortCount();
	bool blState = false;

	for(int i = 0 ; i < nServerPortCount; i++)
	{
		ACE_INET_Addr listenAddr;

		_ServerInfo* pServerInfo = App_MainConfig::instance()->GetServerPort(i);
		if(NULL == pServerInfo)
		{
			OUR_DEBUG((LM_INFO, "[CProServerManager::Start]pServerInfo [%d] is NULL.\n", i));
			return false;
		}

		int nErr = listenAddr.set(pServerInfo->m_nPort, pServerInfo->m_szServerIP);
		if(nErr != 0)
		{
			OUR_DEBUG((LM_INFO, "[CProServerManager::Start](%d)set_address error[%d].\n", i, errno));
			return false;
		}

		//�õ�������
		ProConnectAcceptor* pConnectAcceptor = m_ConnectAcceptorManager.GetConnectAcceptor(i);

		if(NULL == pConnectAcceptor)
		{
			OUR_DEBUG((LM_INFO, "[CProServerManager::Start]pConnectAcceptor[%d] is NULL.\n", i));
			return false;
		}

		ACE_Proactor* pProactor = App_ProactorManager::instance()->GetAce_Proactor(REACTOR_CLIENTDEFINE);
		if(NULL == pProactor)
		{
			OUR_DEBUG((LM_INFO, "[CProServerManager::Start]App_ProactorManager::instance()->GetAce_Proactor(REACTOR_CLIENTDEFINE) is NULL.\n", i));
			return false;
		}

		int nRet = pConnectAcceptor->open(listenAddr, 0, 1, ACE_DEFAULT_ASYNCH_BACKLOG, 1, pProactor);
		if(-1 == nRet)
		{
			OUR_DEBUG((LM_INFO, "[CProServerManager::Start] pConnectAcceptor->open[%d] is error.\n", i));
			OUR_DEBUG((LM_INFO, "[CProServerManager::Start] Listen from [%s:%d] error(%d).\n",listenAddr.get_host_addr(), listenAddr.get_port_number(), errno));
			return false;
		}
		OUR_DEBUG((LM_INFO, "[CProServerManager::Start] Listen from [%s:%d] OK.\n", listenAddr.get_host_addr(), listenAddr.get_port_number()));
	}

	//������־�����߳�
	if(0 != AppLogManager::instance()->Start())
	{
		AppLogManager::instance()->WriteLog(LOG_SYSTEM, "[CProServerManager::Init]AppLogManager is ERROR.");
	}
	else
	{
		AppLogManager::instance()->WriteLog(LOG_SYSTEM, "[CProServerManager::Init]AppLogManager is OK.");
	}

	//�������������������̣߳�������м����������������ش����̡߳�
	if(App_ProServerConnectManager::instance()->GetServerCount() > 0)
	{
		if(!App_ProServerConnectManager::instance()->Start(App_ProactorManager::instance()->GetAce_Proactor(REACTOR_CLIENTDEFINE)))
		{
			OUR_DEBUG((LM_INFO, "[CProServerManager::Start]App_ServerConnectManager::instance()->Start is error.\n"));
			return false;
		}

		//�����м�������̳߳�
		if(!App_PostServerService::instance()->Start())
		{
			OUR_DEBUG((LM_INFO, "[CProServerManager::Start]App_PostServerService::instance()->Start is error.\n"));
			return false;
		}
	}

	//������ʱ��
	if(false == App_TimerManager::instance()->Start())
	{
		OUR_DEBUG((LM_INFO, "[CProServerManager::Start]App_TimerManager::instance()->Start() is error.\n"));
		return false;
	}

	////����UDP�������������UDP����������������̡߳�
	//if(App_MainConfig::instance()->GetUDPServerPortCount() > 0)
	//{
	//	for(int i = 0; i < (int)App_MainConfig::instance()->GetUDPServerPortCount(); i++)
	//	{
	//		_ServerInfo* pServerInfo = App_MainConfig::instance()->GetUDPServerPort(i);
	//		if(NULL == pServerInfo)
	//		{
	//			OUR_DEBUG((LM_INFO, "[CProServerManager::Start]UDP(%d) pServerInfo is NULL.\n", i));
	//			return false;
	//		}

	//		CUDPConnectHandler* pUDPConnectHandler = new CUDPConnectHandler();
	//		if(NULL == pUDPConnectHandler)
	//		{
	//			OUR_DEBUG((LM_INFO, "[CProServerManager::Start]UDP(%d) pUDPConnectHandler is NULL.\n", i));
	//			return false;
	//		}

	//		//����UDP��Ӧ�ķ�Ӧ��
	//		pUDPConnectHandler->reactor(App_ReactorManager::instance()->GetAce_Reactor(REACTOR_UDPDEFINE));

	//		//����UDP����
	//		if(0 != pUDPConnectHandler->open(pServerInfo->m_szServerIP, pServerInfo->m_nPort))
	//		{
	//			OUR_DEBUG((LM_INFO, "[CProServerManager::Start]UDP(%d) pUDPConnectHandler start error.\n", i));
	//			return false;
	//		}

	//		//����UDP������
	//		if(false == App_UDPConnectManager::instance()->AddConnect(pUDPConnectHandler))
	//		{
	//			OUR_DEBUG((LM_INFO, "[CProServerManager::Start]UDP(%d) App_UDPConnectManager add error.\n", i));
	//			return false;
	//		}
	//	}

	//	//���������Ϣ�����߳�
	//	if(false == App_UDPMessageService::instance()->Start())
	//	{
	//		OUR_DEBUG((LM_INFO, "[CProServerManager::Start] App_UDPMessageService::instance()->Start() is error.\n"));
	//		return false;
	//	}
	//}


	//������������Reactor���������ԭʼ��Reactor����Ϊԭʼ�Ļ�����̣߳������������һ�¡�
	if(!App_ProactorManager::instance()->StartProactor())
	{
		OUR_DEBUG((LM_INFO, "[CProServerManager::Start]App_ProactorManager::instance()->StartProactor is error.\n"));
		return false;
	}

	//��ʼ��Ϣ�����߳�
	App_MessageService::instance()->Start();

	////��ʼ�������ӷ��Ͷ�ʱ��
	App_ProConnectManager::instance()->StartTimer();

	//���������Ӧ��
	OUR_DEBUG((LM_INFO, "[CProServerManager::Start]App_ProactorManager::instance()->StartProactorDefault begin....\n"));
	if(!App_ProactorManager::instance()->StartProactorDefault())
	{
		OUR_DEBUG((LM_INFO, "[CProServerManager::Start]App_ProactorManager::instance()->StartProactorDefault is error.\n"));
		return false;
	}

	return true;
}

bool CProServerManager::Close()
{
	return true;
}
