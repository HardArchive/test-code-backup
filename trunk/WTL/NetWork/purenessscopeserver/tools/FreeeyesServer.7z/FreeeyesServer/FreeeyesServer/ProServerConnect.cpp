#include "ProServerConnect.h"
#include "PostServerService.h"

CProServerConnect::CProServerConnect(void)
{
}

CProServerConnect::~CProServerConnect(void)
{
}

bool CProServerConnect::Init(ACE_Proactor* pProactor, _ServerConnectInfo* pServerConnectInfo)
{
	if(NULL == pProactor)
	{
		OUR_DEBUG((LM_ERROR, "[CProServerConnect::Init] pProactor is NULL.\n"));
		return false;
	}

	if(NULL == pServerConnectInfo)
	{
		OUR_DEBUG((LM_ERROR, "[CProServerConnect::Init] pServerConnectInfo is NULL.\n"));
		return false;
	}

	m_pServerConnectInfo = pServerConnectInfo;
	m_pProactor          = pProactor;


	m_pAddrRemote = new ACE_INET_Addr();
	if(NULL == m_pAddrRemote)
	{
		OUR_DEBUG((LM_ERROR, "[CProServerConnect::Init] m_pAddrRemote is NULL.\n"));
		return false;
	}

	ACE_Time_Value tv = ACE_Time_Value(m_pServerConnectInfo->m_u4TimeOut);
	m_pSynOption = new ACE_Synch_Options(ACE_Synch_Options::USE_TIMEOUT, tv);
	if(NULL == m_pSynOption)
	{
		OUR_DEBUG((LM_ERROR, "[CProServerConnect::Init] m_pSynOption is NULL.\n"));
		return false;
	}

	int nErr = m_pAddrRemote->set(pServerConnectInfo->m_u4ServerPort, pServerConnectInfo->m_strServerIP.c_str());
	if(nErr != 0)
	{
		OUR_DEBUG((LM_ERROR, "[CProServerConnect::Init](%s:%d)set_address error[%d].\n", pServerConnectInfo->m_strServerIP.c_str(), pServerConnectInfo->m_u4ServerPort, errno));
		return false;
	}

	return true;
}

bool CProServerConnect::GetConnectState()
{
	return m_blConnect;
}

_ServerConnectInfo* CProServerConnect::GetServerConnectInfo()
{
	return m_pServerConnectInfo;
}

void CProServerConnect::SetConnectTime()
{
	m_tvConnectTime = ACE_OS::gettimeofday();
}

void CProServerConnect::SetUpdateTime()
{
	m_tvUpdateTime  = ACE_OS::gettimeofday();
}

ACE_INET_Addr* CProServerConnect::GetRemoteAddr()
{
	return m_pAddrRemote;
}

ACE_Synch_Options* CProServerConnect::GetOption()
{
	return m_pSynOption;
}

void CProServerConnect::Close()
{
	m_u1ConnectState = CONNECT_CLOSEBEGIN;
	OUR_DEBUG ((LM_DEBUG,"[CProServerConnect::handle_write_stream]Connectid=[%d] begin(%d)...\n",GetConnectID(), errno));

#ifdef WIN32
		ACE_OS::shutdown(this->handle(), SD_BOTH);
#else
    ACE_OS::shutdown(this->handle(), SHUT_RDWR);
#endif		

	AppLogManager::instance()->WriteLog(LOG_SYSTEM_CONNECT, "Close Connection from [%s:%d] RecvSize = %d, RecvCount = %d, SendSize = %d, SendCount = %d.",m_pAddrRemote->get_host_addr(), m_pAddrRemote->get_port_number(), m_u4AllRecvSize, m_u4AllRecvCount, m_u4AllSendSize, m_u4AllSendCount);

	OUR_DEBUG((LM_DEBUG,"[CProServerConnect::handle_write_stream] Connectid=[%d] finish ok...\n", GetConnectID()));	

	m_blConnect = false;

	m_u1ConnectState = CONNECT_CLOSEEND;
}

void CProServerConnect::addresses (const ACE_INET_Addr &remote_address, const ACE_INET_Addr &local_address)
{
	(*m_pAddrRemote) = remote_address;
}

void CProServerConnect::open(ACE_HANDLE h, ACE_Message_Block&)
{
	this->handle(h);
	if(this->m_reader.open(*this, h) == -1||this->m_writer.open(*this, h) == -1)
	{
		OUR_DEBUG((LM_DEBUG,"[CProConnectHandle::open] m_reader or m_reader == 0.\n"));	
		delete this;
		return;
	}

	if(NULL == m_pProactor)
	{
		OUR_DEBUG((LM_ERROR, "[CProServerConnect::open] pProactor is NULL.\n"));
		return;
	}

	if(NULL != m_pAddrRemote)
	{
		AppLogManager::instance()->WriteLog(LOG_SYSTEM_CONNECT, "Connection to [%s:%d].",m_pAddrRemote->get_host_addr(), m_pAddrRemote->get_port_number());
	}

	ACE_NEW_NORETURN(m_mbRecv, ACE_Message_Block(MAX_BUFF_1024));
	if(this->m_reader.read(*m_mbRecv, m_mbRecv->space())!=0)
	{
		OUR_DEBUG((LM_DEBUG,"[CProConnectHandle::open] m_reader or m_reader == 0.\n"));	
		delete this;
		return;
	}

	m_u1ConnectState = CONNECT_OPEN;

	return;
}

void CProServerConnect::handle_read_stream(const ACE_Asynch_Read_Stream::Result &result)
{
	if(!result.success() || result.bytes_transferred()==0)
	{
		//���ӶϿ�
		m_u1ConnectState = CONNECT_CLOSEBEGIN;
		OUR_DEBUG ((LM_DEBUG,"[CProServerConnect::handle_read_stream]Connectid=[%d] begin(%d)...\n",GetConnectID(), errno));

		ACE_Message_Block& mb = result.message_block();
		mb.release();

#ifdef WIN32
		ACE_OS::shutdown(this->handle(), SD_BOTH);
#else
    ACE_OS::shutdown(this->handle(), SHUT_RDWR);
#endif		
		if(this->handle()!=ACE_INVALID_HANDLE)
		{
			ACE_OS::closesocket(this->handle());
		}

		AppLogManager::instance()->WriteLog(LOG_SYSTEM_CONNECT, "Close Connection to [%s:%d] RecvSize = %d, RecvCount = %d, SendSize = %d, SendCount = %d.",m_pAddrRemote->get_host_addr(), m_pAddrRemote->get_port_number(), m_u4AllRecvSize, m_u4AllRecvCount, m_u4AllSendSize, m_u4AllSendCount);

		OUR_DEBUG((LM_DEBUG,"[CProServerConnect::handle_read_stream] Connectid=[%d] finish ok...\n", GetConnectID()));	

		m_u1ConnectState = CONNECT_CLOSEEND;

		return;
	}

	m_ThreadReadLock.acquire();
	ACE_Message_Block& mb = result.message_block();

	m_atvInput = ACE_OS::gettimeofday();
	m_u1ConnectState = CONNECT_RECVGEGIN;

	m_RecvPacket.WriteStream(mb.rd_ptr(), (uint32)result.bytes_transferred());

	m_u4AllRecvSize += (uint32)result.bytes_transferred();

	bool blState = true;
	while(true == blState)
	{
		blState = CheckMessage();
	}
	m_ThreadReadLock.release();

	m_mbRecv->release();

	ACE_NEW_NORETURN(m_mbRecv, ACE_Message_Block(MAX_BUFF_1024));

	if(this->m_reader.read(*m_mbRecv, m_mbRecv->space()) != 0)
	{
		OUR_DEBUG((LM_DEBUG,"[CProConnectHandle::handle_read_stream] m_reader or m_reader == 0.\n"));	
		delete this;
		return;
	}

	m_u1ConnectState = CONNECT_RECVGEND;
}

void CProServerConnect::handle_write_stream(const ACE_Asynch_Write_Stream::Result &result)
{
	m_u4AllSendSize += (uint32)result.bytes_transferred();
	if(!result.success() || result.bytes_transferred()==0)
	{
		//���ӶϿ�
		m_u1ConnectState = CONNECT_CLOSEBEGIN;
		OUR_DEBUG ((LM_DEBUG,"[CProServerConnect::handle_write_stream]Connectid=[%d] begin(%d)...\n",GetConnectID(), errno));

#ifdef WIN32
		ACE_OS::shutdown(this->handle(), SD_BOTH);
#else
    ACE_OS::shutdown(this->handle(), SHUT_RDWR);
#endif		

		AppLogManager::instance()->WriteLog(LOG_SYSTEM_CONNECT, "Close Connection from [%s:%d] RecvSize = %d, RecvCount = %d, SendSize = %d, SendCount = %d.",m_pAddrRemote->get_host_addr(), m_pAddrRemote->get_port_number(), m_u4AllRecvSize, m_u4AllRecvCount, m_u4AllSendSize, m_u4AllSendCount);

		OUR_DEBUG((LM_DEBUG,"[CProServerConnect::handle_write_stream] Connectid=[%d] finish ok...\n", GetConnectID()));	

		m_u1ConnectState = CONNECT_CLOSEEND;

		return;
	}

	result.message_block().release();
}

bool CProServerConnect::CheckMessage()
{
	int nPacketLen = m_RecvPacket.GetPacketLen();
	if(nPacketLen > 2)
	{
		//�����ݽ��룬���õ�����
		uint32 u4Packetlen = 0;

		u4Packetlen = m_RecvPacket.GetHeadLen();

		if(u4Packetlen > m_RecvPacket.GetWriteLen())
		{
			//�������ݿ�û�д��꣬��Ҫ����������ݡ�
			OUR_DEBUG((LM_ERROR, "[CProServerConnect::CheckMessage] ConnectID = %d, u2Packetlen[%d] > m_RecvPacket.GetWriteLen()[%d].\n", GetConnectID(), u4Packetlen, m_RecvPacket.GetWriteLen()));
			//m_RecvPacket.RollBack(m_RecvPacket.GetWriteLen());
			return false;
		}

		m_RecvPacket >> u4Packetlen;

		//�������и��������һ������Buff
		CBuffPacket* pBuffPacket = new CBuffPacket();
		if(NULL == pBuffPacket)
		{
			//�������հ�����
			OUR_DEBUG((LM_ERROR, "[CProServerConnect::CheckMessage] ConnectID = %d, u2Packetlen[%d]�� m_RecvPacket.GetWriteLen()[%d] pBuffPacket is NULL.\n", GetConnectID(), u4Packetlen, m_RecvPacket.GetWriteLen()));
			m_RecvPacket.RollBack(m_RecvPacket.GetWriteLen());
			return false;
		}

		if(false == pBuffPacket->WriteStream(m_RecvPacket.GetData(), u4Packetlen + sizeof(uint32)))  //����Ҫ���ϰ����ܳ���4���ֽ�
		{
			//д����հ�����
			OUR_DEBUG((LM_ERROR, "[CProServerConnect::CheckMessage] ConnectID = %d, u2Packetlen[%d]�� m_RecvPacket.GetWriteLen()[%d] ppBuffPacket->WriteStream error.\n", GetConnectID(), u4Packetlen, m_RecvPacket.GetWriteLen()));
			m_RecvPacket.RollBack(m_RecvPacket.GetWriteLen());
			return false;
		}

		m_RecvPacket.RollBack(u4Packetlen + sizeof(uint32));

		if(NULL != pBuffPacket)
		{
			//��Ҫ��������Ϣ������Ϣ�����߳�
			if(false == App_PostServerService::instance()->PutPostRecvMessage(GetMessageID(), pBuffPacket))
			{
				OUR_DEBUG((LM_ERROR, "[CProServerConnect::CheckMessage] App_MessageService::instance()->PutMessage Error.\n"));
				delete pBuffPacket;
				return false;
			}
			m_u4AllRecvCount++;
		}

		return true;
	}
	else
	{
		return false;
	}
}

bool CProServerConnect::SendMessage(IBuffPacket* pBuffPacket, uint32 u4MsgID)
{
	if(NULL == pBuffPacket)
	{
		OUR_DEBUG((LM_DEBUG,"[CProServerConnect::SendMessage] Connectid=[%d] pBuffPacket is NULL.\n", GetConnectID()));	
		return false;
	}

	CBuffPacket* pReturnBuffPacket = new CBuffPacket();	
	if(NULL == pBuffPacket)
	{
		OUR_DEBUG((LM_DEBUG,"[CProServerConnect::SendMessage] Connectid=[%d] pReturnBuffPacket is NULL.\n", GetConnectID()));	
		return false;
	}

	//������
	uint16 u2PacketLen = pBuffPacket->GetPacketLen();
	(*pReturnBuffPacket) << u2PacketLen;
	pReturnBuffPacket->WriteStream(pBuffPacket->ReadPtr(), u2PacketLen);

	if(pReturnBuffPacket->GetPacketLen() <= 0 || false == PutSendPacket(pReturnBuffPacket))
	{	
		delete pReturnBuffPacket;
		pReturnBuffPacket = NULL;
		return false;
	}
	else
	{
		SetMessageID(u4MsgID);   //��¼��ǰ��MsgID�����ص�ʱ�����ID��������PostServerService
		return true;
	}
}

bool CProServerConnect::PutSendPacket(IBuffPacket* pBuffPacket)
{
	if(NULL == pBuffPacket)
	{
		OUR_DEBUG ((LM_ERROR,"[CProServerConnect::PutSendPacket] Connectid=%d pBuffPacket is NULL!\n", GetConnectID()));
		return true;
	}
	
	CBuffPacket* pSendbulkPacket = new CBuffPacket();
	if(NULL == pSendbulkPacket)
	{
		OUR_DEBUG ((LM_ERROR,"[CProServerConnect::PutSendPacket] Connectid=%d pSendbulkPacket is NULL!\n", GetConnectID()));
		return true;
	}

	pSendbulkPacket->WriteStream(pBuffPacket->GetData(), pBuffPacket->GetPacketLen());
	pSendbulkPacket->SetPacketCount(1);

	m_atvOutput       = ACE_OS::gettimeofday();

	//�첽���ͷ���
	ACE_Message_Block* mb = new ACE_Message_Block(pSendbulkPacket->GetPacketLen()); 
	if(NULL != mb)
	{
		ACE_OS::memcpy(mb->wr_ptr(), pSendbulkPacket->GetData(), pSendbulkPacket->GetPacketLen());
		mb->wr_ptr(pSendbulkPacket->GetPacketLen());
		if(-1 == m_writer.write(*mb, mb->length()))
		{
			OUR_DEBUG ((LM_ERROR,"[CProServerConnect::PutSendPacket] Connectid=%d m_writer.write error!\n", GetConnectID()));
		}
		else
		{
			m_u4AllSendCount += pSendbulkPacket->GetPacketCount();
		}
	}
	else
	{
		OUR_DEBUG ((LM_ERROR,"[CProServerConnect::PutSendPacket] Connectid=%d mb is NULL!\n", GetConnectID()));
	}

	return true;
}

uint32 CProServerConnect::GetConnectID()
{
	if(NULL == m_pServerConnectInfo)
	{
		return 0;
	}
	else
	{
		return m_pServerConnectInfo->m_u4ServerID;
	}	
}

void CProServerConnect::SetMessageID(uint32 u4MsgID)
{
	m_dqMessageID.push_back(u4MsgID);
}

uint32 CProServerConnect::GetMessageID()
{
	if((int)m_dqMessageID.size() > 0)
	{
		uint32 u4MsgID = (uint32)m_dqMessageID[0];
		m_dqMessageID.pop_front();
		return u4MsgID;
	}
	else
	{
		return 0;
	}
}

CAsynchConnector::CAsynchConnector()
{
	m_pProServerConnect = NULL;
}

CAsynchConnector::~CAsynchConnector()
{

}

void CAsynchConnector::SetHandle(CProServerConnect* pProServerConnect)
{
	m_pProServerConnect = pProServerConnect;
}

CProServerConnect* CAsynchConnector::Gethandle()
{
	return m_pProServerConnect;
}

CProServerConnect* CAsynchConnector::make_handler (void)
{
	return m_pProServerConnect;
}

