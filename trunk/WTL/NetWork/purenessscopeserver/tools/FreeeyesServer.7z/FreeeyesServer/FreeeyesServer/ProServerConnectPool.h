#ifndef _PROSERVERCONNECTPOOL_H
#define _PROSERVERCONNECTPOOL_H

#include "ProServerConnect.h"
#include "RandomNumber.h"

#include <map>

using namespace std;

class CProServerConnectPool
{
public:
	CProServerConnectPool(void);
	~CProServerConnectPool(void);

	bool Init(ACE_Proactor* pProactor, _ServerConnectInfo* pServerConnectInfo);
	bool ConnectServer(CProServerConnect* pServerConnect);
	void Close();
	CProServerConnect* GetServerConnect(uint32 u4Index);
	int  GetRandomServerConnectID();

private:
	bool AddServerConnect(uint32 u4Index, ACE_Proactor* pProactor, _ServerConnectInfo* pServerConnectInfo);
	uint32 GetConnectCount();

private:
	typedef map<uint32, CProServerConnect*> mapServerConnect;
	mapServerConnect    m_mapServerConnect;
	uint32              m_u4ServerConnectCount;
	ProConnectorFactory m_ConnectorFactory;
	CRandomNumber       m_RandomNumber;
};
#endif
