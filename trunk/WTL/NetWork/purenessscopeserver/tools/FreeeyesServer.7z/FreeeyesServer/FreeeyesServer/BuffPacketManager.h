#ifndef _BUFFPACKETMAGER_H
#define _BUFFPACKETMAGER_H

#include "define.h"
#include "IObject/IPacketManager.h"
#include "BuffPacket.h"

class CBuffPacketManager : public IPacketManager
{
public:
	CBuffPacketManager(void);
	~CBuffPacketManager(void);

	IBuffPacket* CreateBuffPacket();
	bool DeleteBuffPacket(IBuffPacket* pBuffPacket);
};

typedef ACE_Singleton<CBuffPacketManager, ACE_Null_Mutex> App_BuffPacketManager; 
#endif
