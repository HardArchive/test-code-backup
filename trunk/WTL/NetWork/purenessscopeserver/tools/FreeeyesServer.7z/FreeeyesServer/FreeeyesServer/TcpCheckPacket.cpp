#include "TcpCheckPacket.h"

CTcpCheckPacket::CTcpCheckPacket(void)
{
}

CTcpCheckPacket::~CTcpCheckPacket(void)
{
}

IBuffPacket* CTcpCheckPacket::CheckData(IBuffPacket* pRecvPacket, uint32 u4ConnectID, uint32& u4PacketLen)
{
	if(NULL == pRecvPacket)
	{
		OUR_DEBUG((LM_ERROR, "[CTcpCheckPacket::CheckData] ConnectID = %d, pRecvPacket is NULL.\n", u4ConnectID));
		return false;
	}

	if(*(char* )pRecvPacket->GetData() != 11)
	{
		pRecvPacket->GetData();
	}

	int nPacketLen = pRecvPacket->GetPacketLen();
	if(nPacketLen > 2)
	{
		//�����ݽ��룬���õ�����
		uint32 u4Packetlen = 0;

		u4Packetlen = pRecvPacket->GetHeadLen();

		if(u4Packetlen >= MAX_PACKET_SIZE)
		{
			OUR_DEBUG((LM_ERROR, "[CTcpCheckPacket::CheckData] ConnectID = %d, pRecvPacket is more %d.\n", u4ConnectID, MAX_PACKET_SIZE));
			pRecvPacket->RollBack(pRecvPacket->GetWriteLen());
			return false;
		}

		if(u4Packetlen > pRecvPacket->GetWriteLen())
		{
			//�������ݿ�û�д��꣬��Ҫ����������ݡ�
			//OUR_DEBUG((LM_ERROR, "[CProConnectHandle::CheckMessage] ConnectID = %d, u2Packetlen[%d] > m_RecvPacket.GetWriteLen()[%d].\n", GetConnectID(), u4Packetlen, m_RecvPacket.GetWriteLen()));
			//m_RecvPacket.RollBack(m_RecvPacket.GetWriteLen());
			return NULL;
		}

		(*pRecvPacket) >> u4PacketLen;

		//�������и��������һ������Buff
		CBuffPacket* pBuffPacket = new CBuffPacket();
		if(NULL == pBuffPacket)
		{
			//�������հ�����
			OUR_DEBUG((LM_ERROR, "[CTcpCheckPacket::CheckData] ConnectID = %d, u2Packetlen[%d]�� m_RecvPacket.GetWriteLen()[%d] pBuffPacket is NULL.\n", u4ConnectID, u4Packetlen, pRecvPacket->GetWriteLen()));
			pRecvPacket->RollBack(pRecvPacket->GetWriteLen());
			return NULL;
		}

		pBuffPacket->WriteStream(pRecvPacket->GetData(), u4PacketLen + sizeof(uint32));

		pBuffPacket->GetPacketLen();

		return (IBuffPacket* )pBuffPacket;
	}
	else
	{
		return NULL;
	}
}
