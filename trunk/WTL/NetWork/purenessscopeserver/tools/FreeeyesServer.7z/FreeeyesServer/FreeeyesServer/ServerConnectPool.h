#ifndef _SERVERCONNECTPOOL_H
#define _SERVERCONNECTPOOL_H

#include "ServerConnect.h"
#include "RandomNumber.h"
#include <map>

using namespace std;

class CServerConnectPool
{
public:
	CServerConnectPool(void);
	~CServerConnectPool(void);

	bool Init(ACE_Reactor* pReactor, _ServerConnectInfo* pServerConnectInfo);
	bool ConnectServer(CServerConnect* pServerConnect);
	void Close();
	CServerConnect* GetServerConnect(uint32 u4Index);
	int  GetRandomServerConnectID();

private:
	bool AddServerConnect(uint32 u4Index, ACE_Reactor* pReactor, _ServerConnectInfo* pServerConnectInfo);
	uint32 GetConnectCount();

private:
	typedef map<uint32, CServerConnect*> mapServerConnect;
	mapServerConnect m_mapServerConnect;
	uint32           m_u4ServerConnectCount;
	ConnectorFactory m_ConnectorFactory;
	CRandomNumber    m_RandomNumber;

};
#endif
