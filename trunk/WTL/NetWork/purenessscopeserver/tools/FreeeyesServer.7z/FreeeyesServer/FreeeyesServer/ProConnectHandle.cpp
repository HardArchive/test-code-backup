#include "ProConnectHandle.h"

Mutex_Allocator _proconnecthandle_mb_allocator; 
CProConnectHandle::CProConnectHandle(void)
{
	m_szError[0]      = '\0';
	m_u4ConnectID     = 0;
	m_nTimerID        = 0;
	m_u2SendCount     = 0;
	m_u4AllRecvCount  = 0;
	m_u4AllSendCount  = 0;
	m_u4AllRecvSize   = 0;
	m_u4AllSendSize   = 0;
	m_u4SendThresHold = MAX_MSG_SNEDTHRESHOLD;
	m_u4SendCheckTime = MAX_MSG_SENDCHECKTIME;
	m_u2SendQueueMax  = MAX_MSG_SENDPACKET;
	m_u1ConnectState  = CONNECT_INIT;
	m_u1SendBuffState = CONNECT_SENDNON;
	m_pTCClose        = NULL;
	m_u2SendAliveTime = MAX_MSG_SENDALIVETIME;
	m_u1IsClosing     = HANDLE_ISCLOSE_NO;
}

CProConnectHandle::~CProConnectHandle(void)
{
	if(NULL != m_pTCClose)
	{
		delete m_pTCClose;
		m_pTCClose = NULL;
	}

	if(this->handle()!=ACE_INVALID_HANDLE)
	{
		ACE_OS::closesocket(this->handle());
	}

	m_reader.cancel();
	m_writer.cancel();
}

const char* CProConnectHandle::GetError()
{
	return m_szError;
}

bool CProConnectHandle::Close()
{
	//�ӷ�Ӧ��ע���¼�
	//close();
	return true;
}

void CProConnectHandle::SetConnectID(uint32 u4ConnectID)
{
	m_u4ConnectID = u4ConnectID;
}

uint32 CProConnectHandle::GetConnectID()
{
	return m_u4ConnectID;
}

void CProConnectHandle::addresses (const ACE_INET_Addr &remote_address, const ACE_INET_Addr &local_address)
{
	m_addrRemote = remote_address;
}

void CProConnectHandle::open(ACE_HANDLE h, ACE_Message_Block&)
{
	ACE_Time_Value tvOpenBegin(ACE_OS::gettimeofday());
	this->handle(h);
	if(this->m_reader.open(*this, h, 0, App_ProactorManager::instance()->GetAce_Proactor(REACTOR_CLIENTDEFINE)) == -1 || 
	   this->m_writer.open(*this, h, 0, App_ProactorManager::instance()->GetAce_Proactor(REACTOR_CLIENTDEFINE)) == -1)
	{
		OUR_DEBUG((LM_DEBUG,"[CProConnectHandle::open] m_reader or m_reader == 0.\n"));	
		delete this;
		return;
	}

	OUR_DEBUG((LM_INFO, "[CProConnectHandle::open] Connection from [%s:%d]\n",m_addrRemote.get_host_addr(), m_addrRemote.get_port_number()));

	m_atvConnect      = ACE_OS::gettimeofday();
	m_atvInput        = ACE_OS::gettimeofday();
	m_atvOutput       = ACE_OS::gettimeofday();
	m_atvSendAlive    = ACE_OS::gettimeofday();

	m_u4AllRecvCount  = 0;
	m_u4AllSendCount  = 0;
	m_u4AllRecvSize   = 0;
	m_u4AllSendSize   = 0;

	//���û�ü�����Ϣ������
	m_Encrypt.SetKey(App_MainConfig::instance()->GetEncryptPass());	

	//��������ӷ������ӿ�
	if(false == App_ProConnectManager::instance()->AddConnect(this))
	{
		OUR_DEBUG((LM_ERROR, "%s.\n", App_ProConnectManager::instance()->GetError()));
		sprintf_safe(m_szError, MAX_BUFF_500, "%s", App_ProConnectManager::instance()->GetError());
		return;
	}

	//���ý��ջ���صĴ�С
	uint32 u4RecvAddBuff = App_MainConfig::instance()->GetRecvBuffSize() - MAX_BUFF_1024;
	if(u4RecvAddBuff > 0)
	{
		m_RecvPacket.AddBuff(u4RecvAddBuff);
	}

	m_u4SendThresHold = App_MainConfig::instance()->GetSendThresHold();
	m_u4SendCheckTime = App_MainConfig::instance()->GetSendCheckTime();
	m_u2SendQueueMax  = App_MainConfig::instance()->GetSendQueueMax();
	m_u2SendAliveTime = App_MainConfig::instance()->GetSendAliveTime();

	//�������������
	CBuffPacket* pBuffPacket = new CBuffPacket();
	if(NULL == pBuffPacket)
	{
		OUR_DEBUG((LM_ERROR, "[CProConnectHandle::open] New AlivePacket is NULL.\n"));
		return;
	}

	(*pBuffPacket) << (uint16)COMMAND_RETURN_ALIVE;
	(*pBuffPacket) << (uint32)ACE_OS::gettimeofday().sec();

	//�����ǿ����������Ƿ�Ҫ���ܣ�������ķ���Ҳ�Ǻ�ϵͳ����һ�¡�
	if(App_MainConfig::instance()->GetEncryptOutFlag() == 0)
	{
		//������
		uint32 u4PacketLen = pBuffPacket->GetPacketLen();
		m_AlivePacket << u4PacketLen;
		m_AlivePacket.WriteStream(pBuffPacket->ReadPtr(), u4PacketLen);
		delete pBuffPacket;
	}
	else
	{
		//����
		uint32 u4PacketLen = pBuffPacket->GetPacketLen();
		uint32 u4SrcLen = u4PacketLen + (int)sizeof(uint32);
		uint32 u4DesLen = 0;

		if(u4SrcLen % 8 == 0)
		{
			u4DesLen = u4SrcLen;
		}
		else
		{
			u4DesLen = u4SrcLen / 8 * 8 + 8;
		}

		char* pSrcBuff = new char[u4SrcLen];
		char* pDesBuff = new char[u4DesLen];

		if(NULL == pSrcBuff || NULL == pDesBuff)
		{
			OUR_DEBUG((LM_DEBUG,"[CConnectHandler::SendMessage] Connectid=[%d] pDesBuff or pDesBuff is NULL.\n", GetConnectID()));	
			delete pBuffPacket;
			return;
		}

		ACE_OS::memcpy(pSrcBuff, &u4PacketLen, (int)sizeof(uint32));
		ACE_OS::memcpy(&pSrcBuff[(int)sizeof(uint32)], pBuffPacket->ReadPtr(), u4PacketLen);

		m_Encrypt.DoEncrypt(true, pSrcBuff, u4SrcLen, pDesBuff, u4DesLen);

		m_AlivePacket << u4DesLen;
		m_AlivePacket.WriteStream(pDesBuff, u4DesLen);

		delete pBuffPacket;
		delete[] pSrcBuff;
		delete[] pDesBuff;
	}

	ACE_Time_Value tvOpenEnd(ACE_OS::gettimeofday());
	ACE_Time_Value tvOpen(tvOpenEnd - tvOpenBegin);

	AppLogManager::instance()->WriteLog(LOG_SYSTEM_CONNECT, "Connection from [%s:%d] DisposeTime = %d.",m_addrRemote.get_host_addr(), m_addrRemote.get_port_number(), tvOpen.msec());

	ACE_Message_Block* pmb = NULL;
	ACE_NEW_NORETURN(pmb, ACE_Message_Block(MAX_BUFF_1024));
	if(this->m_reader.read(*pmb, pmb->space())!=0)
	{
		OUR_DEBUG((LM_DEBUG,"[CProConnectHandle::open] m_reader or m_reader == 0.\n"));	
		delete this;
		return;
	}

	ACE_Sig_Action writeAction((ACE_SignalHandler)SIG_IGN);
	writeAction.register_action(SIGPIPE, 0);

	m_u1ConnectState = CONNECT_OPEN;

}

void CProConnectHandle::handle_read_stream(const ACE_Asynch_Read_Stream::Result &result)
{
	ACE_Guard<ACE_Thread_Mutex> WGuard(m_ThreadReadLock);
	ACE_Message_Block& mb = result.message_block();
	uint32 u4PacketLen = (uint32)result.bytes_transferred();
	if(!result.success() || result.bytes_transferred()==0)
	{
		//���ӶϿ�
		m_u1ConnectState = CONNECT_CLOSEBEGIN;
		OUR_DEBUG ((LM_DEBUG,"[CConnectHandler::handle_read_stream]Connectid=[%d] begin(%d)...\n",GetConnectID(), errno));

		bool bState = App_ProConnectManager::instance()->CloseConnect(GetConnectID());
		if(bState == false)
		{
			OUR_DEBUG ((LM_DEBUG,"[CConnectHandler::handle_read_stream]Connectid=[%d] CloseConnect error[%s]. \n", GetConnectID(), App_ProConnectManager::instance()->GetError()));
			return;
		}

		mb.release();
#ifdef WIN32
		ACE_OS::shutdown(this->handle(), SD_BOTH);
#else
    ACE_OS::shutdown(this->handle(), SHUT_RDWR);
#endif			
		TimeClose();

		AppLogManager::instance()->WriteLog(LOG_SYSTEM_CONNECT, "Close Connection from [%s:%d] RecvSize = %d, RecvCount = %d, SendSize = %d, SendCount = %d.",m_addrRemote.get_host_addr(), m_addrRemote.get_port_number(), m_u4AllRecvSize, m_u4AllRecvCount, m_u4AllSendSize, m_u4AllSendCount);

		OUR_DEBUG((LM_DEBUG, "[CConnectHandler::handle_read_stream] Connectid=[%d] finish ok...\n", GetConnectID()));

		return;
	}

	m_atvInput = ACE_OS::gettimeofday();
	m_u1ConnectState = CONNECT_RECVGEGIN;

	//OUR_DEBUG((LM_DEBUG, "[CConnectHandler::handle_read_stream] Connectid=[%d] Get Data.\n", GetConnectID()));
	m_RecvPacket.WriteStream(mb.rd_ptr(), u4PacketLen);

	m_u4AllRecvSize += u4PacketLen;

	bool blState = true;
	while(true == blState)
	{
		blState = CheckMessage();
	}

	mb.release();

	ACE_Message_Block* pmb = NULL;
	ACE_NEW_NORETURN(pmb, ACE_Message_Block(MAX_BUFF_1024));

	if(this->m_reader.read(*pmb, pmb->space()) != 0)
	{
		OUR_DEBUG((LM_DEBUG,"[CProConnectHandle::handle_read_stream] m_reader or m_reader == 0.\n"));	
		delete this;
		return;
	}

	m_u1ConnectState = CONNECT_RECVGEND;

	return;
}

void CProConnectHandle::handle_write_stream(const ACE_Asynch_Write_Stream::Result &result)
{
	m_u4AllSendSize += (uint32)result.bytes_transferred();
	if(!result.success() || result.bytes_transferred()==0)
	{
		//���ӶϿ�
		m_u1ConnectState = CONNECT_CLOSEBEGIN;
		OUR_DEBUG ((LM_DEBUG,"[CConnectHandler::handle_write_stream] Connectid=[%d] begin(%d)...\n",GetConnectID(), errno));

		bool bState = App_ProConnectManager::instance()->CloseConnect(GetConnectID());
		if(bState == false)
		{
			OUR_DEBUG ((LM_DEBUG,"[CConnectHandler::handle_write_stream]Connectid=[%d] CloseConnect error[%s]. \n", GetConnectID(), App_ProConnectManager::instance()->GetError()));
			return;
		}

#ifdef WIN32
		ACE_OS::shutdown(this->handle(), SD_BOTH);
#else
    ACE_OS::shutdown(this->handle(), SHUT_RDWR);
#endif
		TimeClose();

		AppLogManager::instance()->WriteLog(LOG_SYSTEM_CONNECT, "Close Connection from [%s:%d] RecvSize = %d, RecvCount = %d, SendSize = %d, SendCount = %d.",m_addrRemote.get_host_addr(), m_addrRemote.get_port_number(), m_u4AllRecvSize, m_u4AllRecvCount, m_u4AllSendSize, m_u4AllSendCount);

		OUR_DEBUG((LM_DEBUG,"[CConnectHandler::handle_write_stream] Connectid=[%d] finish ok...\n", GetConnectID()));	

		return;
	}

	result.message_block().release();
}

//��ʱ��
int CProConnectHandle::handle_timeout(const ACE_Time_Value &tv, const void *arg)
{
	_TimerCheckID* pTimerCheckID = (_TimerCheckID*)arg;
	if(NULL == pTimerCheckID)
	{
		return 0;
	}

	if(pTimerCheckID->m_u2TimerCheckID == PARM_HANDLE_CLOSE)
	{
		m_u1ConnectState = CONNECT_CLOSEEND;
		delete this;
		return 0;
	}

	return 0;
}

uint8 CProConnectHandle::GetConnectState()
{
	return m_u1ConnectState;
}

uint8 CProConnectHandle::GetSendBuffState()
{
	return m_u1SendBuffState;
}

uint8 CProConnectHandle::GetIsClosing()
{
	return m_u1IsClosing;
}

bool CProConnectHandle::SendMessage(IBuffPacket* pBuffPacket)
{
	if(NULL == pBuffPacket)
	{
		OUR_DEBUG((LM_DEBUG,"[CProConnectHandle::SendMessage] Connectid=[%d] pBuffPacket is NULL.\n", GetConnectID()));	
		return false;
	}

	CBuffPacket* pReturnBuffPacket = new CBuffPacket();	
	if(NULL == pReturnBuffPacket)
	{
		OUR_DEBUG((LM_DEBUG,"[CProConnectHandle::SendMessage] Connectid=[%d] pReturnBuffPacket is NULL.\n", GetConnectID()));	
		return false;
	}

	//�������Ӽ����㷨
	if(App_MainConfig::instance()->GetEncryptOutFlag() == 0)
	{
		//������
		uint32 u4PacketLen = pBuffPacket->GetPacketLen();
		(*pReturnBuffPacket) << u4PacketLen;
		pReturnBuffPacket->WriteStream(pBuffPacket->ReadPtr(), u4PacketLen);
	}
	else
	{
		//����
		uint32 u4PacketLen = pBuffPacket->GetPacketLen();
		uint32 u4SrcLen = u4PacketLen + (int)sizeof(uint32);
		uint32 u4DesLen = 0;

		if(u4SrcLen % 8 == 0)
		{
			u4DesLen = u4SrcLen;
		}
		else
		{
			u4DesLen = u4SrcLen / 8 * 8 + 8;
		}

		char* pSrcBuff = new char[u4SrcLen];
		char* pDesBuff = new char[u4DesLen];

		if(NULL == pSrcBuff || NULL == pDesBuff)
		{
			OUR_DEBUG((LM_DEBUG,"[CProConnectHandle::SendMessage] Connectid=[%d] pDesBuff or pDesBuff is NULL.\n", GetConnectID()));	
			delete pReturnBuffPacket;
			return false;
		}

		ACE_OS::memcpy(pSrcBuff, &u4PacketLen, (int)sizeof(uint32));
		ACE_OS::memcpy(&pSrcBuff[(int)sizeof(uint32)], pBuffPacket->ReadPtr(), u4PacketLen);

		m_Encrypt.DoEncrypt(true, pSrcBuff, u4SrcLen, pDesBuff, u4DesLen);

		(*pReturnBuffPacket) << u4DesLen;
		pReturnBuffPacket->WriteStream(pDesBuff, u4DesLen);

		delete[] pSrcBuff;
		delete[] pDesBuff;
	}

	if(pReturnBuffPacket->GetPacketLen() <= 0 || false == PutSendPacket(pReturnBuffPacket))
	{	
		if(NULL != pReturnBuffPacket)
		{
			delete pReturnBuffPacket;
			pReturnBuffPacket = NULL;
		}
		return false;
	}
	else
	{
		return true;
	}
}

bool CProConnectHandle::PutSendPacket(IBuffPacket* pBuffPacket)
{
	//��ʼ�����������͵�Ԫ
	m_ThreadWriteLock.acquire();
	if(NULL == pBuffPacket)
	{
		OUR_DEBUG ((LM_ERROR,"[CProConnectHandle::PutSendPacket] Connectid=%d pBuffPacket is NULL!\n", GetConnectID()));
		m_ThreadWriteLock.release();
		return false;
	}

	m_SendPacket.WriteStream(pBuffPacket->GetData(), pBuffPacket->GetPacketLen());
	delete pBuffPacket;
	pBuffPacket = NULL;
	m_u2SendCount++;

	if(m_u2SendCount < m_u4SendThresHold)    //����ﵽ��ֵ��������
	{
		m_u1SendBuffState = CONNECT_SENDBUFF;
		m_SendPacket.SetPacketCount(m_u2SendCount);
		m_ThreadWriteLock.release();

		return true;
	}
	else
	{
		m_SendPacket.SetPacketCount(m_u2SendCount);
		CBuffPacket* pSendbulkPacket = new CBuffPacket();
		if(NULL == pSendbulkPacket)
		{
			OUR_DEBUG ((LM_ERROR,"[CProConnectHandle::PutSendPacket] Connectid=%d pSendbulkPacket is NULL!\n", GetConnectID()));
			return true;
		}

		pSendbulkPacket->WriteStream(m_SendPacket.GetData(), m_SendPacket.GetPacketLen());
		pSendbulkPacket->SetPacketCount(m_SendPacket.GetPacketCount());
		m_SendPacket.SetPacketCount(0);
		m_SendPacket.RollBack(m_SendPacket.GetPacketLen());
		//OUR_DEBUG ((LM_INFO,"[CProConnectHandle::PutSendPacket] Connectid=%d m_SendPacket.GetPacketCount() = %d AllCount = %d.\n", GetConnectID(), pSendbulkPacket->GetPacketCount(), m_u4AllSendCount));
		m_u2SendCount     = 0;
		m_atvOutput       = ACE_OS::gettimeofday();
		m_u1SendBuffState = CONNECT_SENDNON;
		m_ThreadWriteLock.release();

		//�첽���ͷ���
		ACE_Message_Block* mb = new ACE_Message_Block(pSendbulkPacket->GetPacketLen()); 
		if(NULL != mb)
		{
			ACE_OS::memcpy(mb->wr_ptr(), pSendbulkPacket->GetData(), pSendbulkPacket->GetPacketLen());
			mb->wr_ptr(pSendbulkPacket->GetPacketLen());
			if(-1 == m_writer.write(*mb, mb->length()))
			{
				OUR_DEBUG ((LM_ERROR,"[CConnectHandler::PutSendPacket] Connectid=%d m_writer.write error!\n", GetConnectID()));
			}
			else
			{
				m_u4AllSendCount += pSendbulkPacket->GetPacketCount();
			}
		}
		else
		{
			OUR_DEBUG ((LM_ERROR,"[CConnectHandler::PutSendPacket] Connectid=%d mb is NULL!\n", GetConnectID()));
		}

		delete pSendbulkPacket;
		return true;
	}
}

bool CProConnectHandle::CheckSendPacket()
{
	ACE_Time_Value tvNow(ACE_OS::gettimeofday() - m_atvOutput);
	if(tvNow.msec() < m_u4SendCheckTime)
	{
		return true;
	}

	m_ThreadWriteLock.acquire();
	//����ﵽ���������ʱ�䣬��������������
	ACE_Time_Value tvAliveNow = ACE_OS::gettimeofday();
	ACE_Time_Value tvInterval(tvAliveNow - m_atvSendAlive);
	if(tvInterval.sec() >= m_u2SendAliveTime)
	{
		//����ﵽ�����������������������������
		m_SendPacket.WriteStream(m_AlivePacket.GetData(), m_AlivePacket.GetPacketLen());
		m_u2SendCount++;
		m_atvSendAlive = tvAliveNow;
	}

	if(m_u2SendCount == 0)
	{
		m_ThreadWriteLock.release();
		return true;
	}

	CBuffPacket* pSendbulkPacket = new CBuffPacket();

	if(NULL == pSendbulkPacket)
	{
		OUR_DEBUG ((LM_ERROR,"[CProConnectHandle::CheckSendPacket] Connectid=%d pSendbulkPacket is NULL!\n", GetConnectID()));
		m_ThreadWriteLock.release();
		return true;
	}

	pSendbulkPacket->WriteStream(m_SendPacket.GetData(), m_SendPacket.GetPacketLen());
	pSendbulkPacket->SetPacketCount(m_SendPacket.GetPacketCount());
	m_SendPacket.RollBack(m_SendPacket.GetPacketLen());
	m_SendPacket.SetPacketCount(0);
	//OUR_DEBUG ((LM_INFO,"[CProConnectHandle::CheckSendPacket] Connectid=%d m_SendPacket.GetPacketCount() = %d AllCount = %d.\n", GetConnectID(), pSendbulkPacket->GetPacketCount(), m_u4AllSendCount));
	m_u2SendCount     = 0;
	m_atvOutput       = ACE_OS::gettimeofday();
	m_u1SendBuffState = CONNECT_SENDNON;
	m_ThreadWriteLock.release();

	//�첽���ͷ���
	ACE_Message_Block* mb = new ACE_Message_Block(pSendbulkPacket->GetPacketLen()); 
	if(NULL != mb)
	{
		ACE_OS::memcpy(mb->wr_ptr(), pSendbulkPacket->GetData(), pSendbulkPacket->GetPacketLen());
		mb->wr_ptr(pSendbulkPacket->GetPacketLen());
		if(-1 == m_writer.write(*mb,  mb->length()))
		{
			OUR_DEBUG ((LM_ERROR,"[CConnectHandler::PutSendPacket] Connectid=%d m_writer.write error!\n", GetConnectID()));
		}
		else
		{
			m_u4AllSendCount += pSendbulkPacket->GetPacketCount();
		}
	}
	else
	{
		OUR_DEBUG ((LM_ERROR,"[CConnectHandler::PutSendPacket] Connectid=%d mb is NULL!\n", GetConnectID()));
	}

	delete pSendbulkPacket;
	return true;
}

void CProConnectHandle::TimeClose()
{
	if(NULL == m_pTCClose)
	{
		m_pTCClose = new _TimerCheckID();
		if(NULL == m_pTCClose)
		{
			OUR_DEBUG((LM_ERROR, "CProConnectHandle::StartTimer() m_pTCCountCheck is NULL.\n"));
			return;
		}

		m_pTCClose->m_u2TimerCheckID = PARM_HANDLE_CLOSE;
	}

	if(m_nTimerID == 0)
	{
		m_nTimerID = App_ProactorManager::instance()->GetAce_Proactor(REACTOR_CLIENTDEFINE)->schedule_timer(*this, m_pTCClose, ACE_Time_Value(CONNECT_CLOSE_TIME));
	}
}

bool CProConnectHandle::CheckMessage()
{
	CBuffPacket* pOrcPacket  = NULL;
	uint32       u4PacketLen = 0;

	pOrcPacket = (CBuffPacket* )m_TcpCheckPacket.CheckData(&m_RecvPacket, GetConnectID(), u4PacketLen);
	if(NULL == pOrcPacket)
	{
		return false;
	}

	m_RecvPacket.RollBack(pOrcPacket->GetPacketLen());

	CBuffPacket* pBuffPacket = new CBuffPacket();
	if(NULL == pBuffPacket)
	{
		//�������հ�����
		OUR_DEBUG((LM_ERROR, "[CProConnectHandle::CheckMessage] ConnectID = %d, u2Packetlen[%d]�� m_RecvPacket.GetWriteLen()[%d] pBuffPacket is NULL.\n", GetConnectID(), u4PacketLen, m_RecvPacket.GetWriteLen()));
		m_RecvPacket.RollBack(m_RecvPacket.GetWriteLen());
		delete pOrcPacket;
		pOrcPacket = NULL;
		return false;
	}

	//�������ӽ����㷨�ж�
	if(0 == App_MainConfig::instance()->GetEncryptFlag())
	{
		if(false == pBuffPacket->WriteStream(pOrcPacket->GetData(), pOrcPacket->GetPacketLen()))  //����Ҫ���ϰ����ܳ���4���ֽ�
		{
			//д����հ�����
			OUR_DEBUG((LM_ERROR, "[CProConnectHandle::CheckMessage] ConnectID = %d, u2Packetlen[%d]�� m_RecvPacket.GetWriteLen()[%d] ppBuffPacket->WriteStream error.\n", GetConnectID(), u4PacketLen, m_RecvPacket.GetWriteLen()));
			m_RecvPacket.RollBack(m_RecvPacket.GetWriteLen());
			delete pOrcPacket;
			pOrcPacket = NULL;
			return false;
		}
		else
		{
			delete pOrcPacket;
			pOrcPacket = NULL;
		}
	}
	else
	{
		//��������
		char* pSrc = new char[u4PacketLen + sizeof(uint32) + 1];   //��������
		pSrc[u4PacketLen + sizeof(uint32)] = '\0';
		char* pDes = new char[u4PacketLen + sizeof(uint32) + 1];   //��������
		pSrc[0] = '\0';

		int nDesLen = pOrcPacket->GetPacketLen(); 
		ACE_OS::memcpy(pSrc, pOrcPacket->GetData() + sizeof(uint32), pOrcPacket->GetPacketLen() - sizeof(uint32));
		if(false == Decrypt(pSrc, u4PacketLen, pDes, nDesLen))
		{
			OUR_DEBUG((LM_ERROR, "[CProConnectHandle::CheckMessage] ConnectID = %d, u2Packetlen[%d]�� m_RecvPacket.GetWriteLen()[%d]  Decrypt Error.\n", GetConnectID(), u4PacketLen, m_RecvPacket.GetWriteLen()));
			m_RecvPacket.RollBack(m_RecvPacket.GetWriteLen());
			delete[] pSrc;
			delete[] pDes;
			delete pOrcPacket;
			pOrcPacket = NULL;
			return false;
		}

		//��ý����ַ����ĳ���
		ACE_OS::memcpy(&nDesLen, pDes, 4);

		//(*pBuffPacket) << (uint32)nDesLen;
		if(false == pBuffPacket->WriteStream(pDes, nDesLen + sizeof(uint32)))
		{
			//д����հ�����
			OUR_DEBUG((LM_ERROR, "[CProConnectHandle::CheckMessage] ConnectID = %d, u2Packetlen[%d]�� m_RecvPacket.GetWriteLen()[%d] ppBuffPacket->WriteStream error.\n", GetConnectID(), u4PacketLen, m_RecvPacket.GetWriteLen()));
			m_RecvPacket.RollBack(m_RecvPacket.GetWriteLen());
			delete[] pSrc;
			delete[] pDes;
			delete pOrcPacket;
			pOrcPacket = NULL;
			return false;
		}

		delete[] pSrc;
		delete[] pDes;
		delete pOrcPacket;
		pOrcPacket = NULL;
	}

	//������Buff������Ϣ����
	CMessage* pMessage = SetMessage(pBuffPacket);
	if(NULL != pMessage)
	{
		//�����ӵ�IP�Ͷ˿�д����Ϣ��
		pMessage->SetMessageInfo(m_addrRemote.get_host_addr(), (int)m_addrRemote.get_port_number());
		//��Ҫ��������Ϣ������Ϣ�����߳�
		if(false == App_MessageService::instance()->PutMessage(pMessage))
		{
			OUR_DEBUG((LM_ERROR, "[CProConnectHandle::CheckMessage] App_MessageService::instance()->PutMessage Error.\n"));
			delete pMessage;
			return false;
		}
		m_u4AllRecvCount++;
	}

	return true;

	/*int nPacketLen = m_RecvPacket.GetPacketLen();
	if(nPacketLen > 2)
	{
		//�����ݽ��룬���õ�����
		uint32 u4Packetlen = 0;

		u4Packetlen = m_RecvPacket.GetHeadLen();

		if(u4Packetlen > m_RecvPacket.GetWriteLen())
		{
			//�������ݿ�û�д��꣬��Ҫ����������ݡ�
			//OUR_DEBUG((LM_ERROR, "[CProConnectHandle::CheckMessage] ConnectID = %d, u2Packetlen[%d] > m_RecvPacket.GetWriteLen()[%d].\n", GetConnectID(), u4Packetlen, m_RecvPacket.GetWriteLen()));
			//m_RecvPacket.RollBack(m_RecvPacket.GetWriteLen());
			return false;
		}

		m_RecvPacket >> u4Packetlen;

		//�������и��������һ������Buff
		CBuffPacket* pBuffPacket = new CBuffPacket();
		if(NULL == pBuffPacket)
		{
			//�������հ�����
			OUR_DEBUG((LM_ERROR, "[CProConnectHandle::CheckMessage] ConnectID = %d, u2Packetlen[%d]�� m_RecvPacket.GetWriteLen()[%d] pBuffPacket is NULL.\n", GetConnectID(), u4Packetlen, m_RecvPacket.GetWriteLen()));
			m_RecvPacket.RollBack(m_RecvPacket.GetWriteLen());
			return false;
		}

		//�������ӽ����㷨�ж�
		if(0 == App_MainConfig::instance()->GetEncryptFlag())
		{
			if(false == pBuffPacket->WriteStream(m_RecvPacket.GetData(), u4Packetlen + sizeof(uint32)))  //����Ҫ���ϰ����ܳ���4���ֽ�
			{
				//д����հ�����
				OUR_DEBUG((LM_ERROR, "[CProConnectHandle::CheckMessage] ConnectID = %d, u2Packetlen[%d]�� m_RecvPacket.GetWriteLen()[%d] ppBuffPacket->WriteStream error.\n", GetConnectID(), u4Packetlen, m_RecvPacket.GetWriteLen()));
				m_RecvPacket.RollBack(m_RecvPacket.GetWriteLen());
				return false;
			}
		}
		else
		{
			//��������
			char* pSrc = new char[u4Packetlen + sizeof(uint32) + 1];   //��������
			pSrc[u4Packetlen + sizeof(uint32)] = '\0';
			char* pDes = new char[u4Packetlen + sizeof(uint32) + 1];   //��������
			pSrc[0] = '\0';

			int nDesLen = u4Packetlen + sizeof(uint32); 
			ACE_OS::memcpy(pSrc, m_RecvPacket.GetData() + sizeof(uint32), u4Packetlen);
			if(false == Decrypt(pSrc, u4Packetlen, pDes, nDesLen))
			{
				OUR_DEBUG((LM_ERROR, "[CProConnectHandle::CheckMessage] ConnectID = %d, u2Packetlen[%d]�� m_RecvPacket.GetWriteLen()[%d]  Decrypt Error.\n", GetConnectID(), u4Packetlen, m_RecvPacket.GetWriteLen()));
				m_RecvPacket.RollBack(m_RecvPacket.GetWriteLen());
				delete[] pSrc;
				delete[] pDes;
				return false;
			}

			//��ý����ַ����ĳ���
			ACE_OS::memcpy(&nDesLen, pDes, 4);

			//(*pBuffPacket) << (uint32)nDesLen;
			if(false == pBuffPacket->WriteStream(pDes, nDesLen + sizeof(uint32)))
			{
				//д����հ�����
				OUR_DEBUG((LM_ERROR, "[CProConnectHandle::CheckMessage] ConnectID = %d, u2Packetlen[%d]�� m_RecvPacket.GetWriteLen()[%d] ppBuffPacket->WriteStream error.\n", GetConnectID(), u4Packetlen, m_RecvPacket.GetWriteLen()));
				m_RecvPacket.RollBack(m_RecvPacket.GetWriteLen());
				delete[] pSrc;
				delete[] pDes;
				return false;
			}

			delete[] pSrc;
			delete[] pDes;
		}

		m_RecvPacket.RollBack(u4Packetlen + sizeof(uint32));

		//������Buff������Ϣ����
		CMessage* pMessage = SetMessage(pBuffPacket);
		if(NULL != pMessage)
		{
			//�����ӵ�IP�Ͷ˿�д����Ϣ��
			pMessage->SetMessageInfo(m_addrRemote.get_host_addr(), (int)m_addrRemote.get_port_number());
			//��Ҫ��������Ϣ������Ϣ�����߳�
			if(false == App_MessageService::instance()->PutMessage(pMessage))
			{
				OUR_DEBUG((LM_ERROR, "[CProConnectHandle::CheckMessage] App_MessageService::instance()->PutMessage Error.\n"));
				delete pMessage;
				return false;
			}
			m_u4AllRecvCount++;
		}

		return true;
	}
	else
	{
		return false;
	}
	*/
}

bool CProConnectHandle::Decrypt(const char* szSrc, int nSrcLen, char* szDes, int& nDecLen)
{
	bool blFlag = m_Encrypt.DoEncrypt(false, szSrc, nSrcLen, szDes, nDecLen);

	return blFlag;
}

CMessage* CProConnectHandle::SetMessage(IBuffPacket* pBuffPacket)
{
	if(NULL == pBuffPacket)
	{
		OUR_DEBUG((LM_ERROR, "[CProConnectHandle::SetMessage] ConnectID = %d, pBuffPacket is NULL.\n", GetConnectID()));
		return false;
	}

	//�����µ�Message����
	CMessage* pMessage = new CMessage();
	if(NULL == pMessage)
	{
		//д����հ�����
		OUR_DEBUG((LM_ERROR, "[CProConnectHandle::SetMessage] ConnectID = %d, pMessage is NULL.\n", GetConnectID()));
		return NULL;
	}

	//�����µ�_MessageBase
	_MessageBase* pMessageBase = new _MessageBase();
	if(NULL == pMessageBase)
	{
		//д����հ�����
		OUR_DEBUG((LM_ERROR, "[CProConnectHandle::SetMessage] ConnectID = %d, _MessageBase is NULL.\n", GetConnectID()));
		return NULL;
	}

	//��ʼ��װ����
	pMessageBase->m_u4ConnectID = GetConnectID();
	pMessageBase->m_u2Cmd       = 0;
	pMessageBase->m_u4MsgTime   = (uint32)ACE_OS::gettimeofday().sec();

	pMessage->SetMessageBase(pMessageBase);

	//�����ܵ����ݻ������CMessage����
	if(false == pMessage->SetRecvPacket(pBuffPacket))
	{
		//д����հ�����
		OUR_DEBUG((LM_ERROR, "[CProConnectHandle::SetMessage] ConnectID = %d, pMessage->SetRecvPacket is fail.\n", GetConnectID()));
		delete pMessage;
		return NULL;
	}

	return pMessage;
}

bool CProConnectHandle::CheckConnectAlive(uint16 u2QueuePacketCount)
{
	//�����Ǽ�������Ƿ��Ѿ��ҵ��Ĳ��ԡ�
	ACE_Time_Value tvNow(ACE_OS::gettimeofday());
	ACE_Time_Value tvInterval(tvNow - m_atvOutput);
	if(u2QueuePacketCount >= MAX_MSG_SENDALCOUNT && tvInterval.sec() >= MAX_MSG_SENDALIVETIME)
	{
		AppLogManager::instance()->WriteLog(LOG_SYSTEM_CONNECT, "Connectioned [%s:%d] is no alive.",m_addrRemote.get_host_addr(), m_addrRemote.get_port_number());
		m_u1IsClosing = HANDLE_ISCLOSE_YES;
	}

	return true;
}

//***************************************************************************
CProConnectManager::CProConnectManager(void)
{
	m_u4TimeCheckID      = 0;
	m_u4ConnectCurrID    = 0;
	m_szError[0]         = '\0';

	m_pTCTimeSendCheck   = NULL;
	m_tvCheckConnect     = ACE_OS::gettimeofday();
}

CProConnectManager::~CProConnectManager(void)
{
	CloseAll();
}

void CProConnectManager::CloseAll()
{
	KillTimer();
	mapConnectManager::iterator b = m_mapConnectManager.begin();
	mapConnectManager::iterator e = m_mapConnectManager.end();

	for(b; b != e; b++)
	{
		CProConnectHandle* pConnectHandler = (CProConnectHandle* )b->second;
		if(pConnectHandler != NULL)
		{
			pConnectHandler->Close();
		}
	}

	m_mapConnectManager.clear();
}

bool CProConnectManager::Close(uint32 u4ConnectID)
{
	mapConnectManager::iterator f = m_mapConnectManager.find(u4ConnectID);

	if(f != m_mapConnectManager.end())
	{
		CProConnectHandle* pConnectHandler = (CProConnectHandle* )f->second;
		if(pConnectHandler != NULL)
		{
			pConnectHandler->Close();
		}

		return true;
	}
	else
	{
		sprintf_safe(m_szError, MAX_BUFF_500, "[CProConnectManager::Close] ConnectID[%d] is not find.", u4ConnectID);
		return true;
	}
}

bool CProConnectManager::CloseConnect(uint32 u4ConnectID)
{
	m_ThreadWriteLock.acquire();
	mapConnectManager::iterator f = m_mapConnectManager.find(u4ConnectID);

	if(f != m_mapConnectManager.end())
	{
		m_mapConnectManager.erase(f);
		m_ThreadWriteLock.release();
		return true;
	}
	else
	{
		sprintf_safe(m_szError, MAX_BUFF_500, "[CProConnectManager::CloseConnect] ConnectID[%d] is not find.", u4ConnectID);
		m_ThreadWriteLock.release();
		return true;
	}
}

bool CProConnectManager::AddConnect(CProConnectHandle* pConnectHandler)
{
	if(pConnectHandler == NULL)
	{
		sprintf_safe(m_szError, MAX_BUFF_500, "[CProConnectManager::AddConnect] pConnectHandler is NULL.");
		return false;		
	}

	m_ThreadWriteLock.acquire();
	mapConnectManager::iterator f = m_mapConnectManager.find(m_u4ConnectCurrID);
	if(f != m_mapConnectManager.end())
	{
		sprintf_safe(m_szError, MAX_BUFF_500, "[CProConnectManager::AddConnect] ConnectID[%d] is exist.", m_u4ConnectCurrID);
		m_ThreadWriteLock.release();
		return false;
	}
	
	pConnectHandler->SetConnectID(m_u4ConnectCurrID);
	//����map
	m_mapConnectManager.insert(mapConnectManager::value_type(m_u4ConnectCurrID, pConnectHandler));
	m_u4ConnectCurrID++;
	m_ThreadWriteLock.release();

	return true;
}

bool CProConnectManager::SendMessage(uint32 u4ConnectID, IBuffPacket* pBuffPacket)
{
	if(NULL == pBuffPacket)
	{
		sprintf_safe(m_szError, MAX_BUFF_500, "[CProConnectManager::SendMessage] ConnectID[%d] pBuffPacket is NULL.", u4ConnectID);
		return false;
	}

	mapConnectManager::iterator f = m_mapConnectManager.find(u4ConnectID);

	if(f != m_mapConnectManager.end())
	{
		CProConnectHandle* pConnectHandler = (CProConnectHandle* )f->second;

		if(NULL != pConnectHandler)
		{
			return pConnectHandler->SendMessage(pBuffPacket);
		}
		else
		{
			sprintf_safe(m_szError, MAX_BUFF_500, "[CProConnectManager::SendMessage] ConnectID[%d] is not find.", u4ConnectID);
			return true;
		}
	}
	else
	{
		sprintf_safe(m_szError, MAX_BUFF_500, "[CProConnectManager::SendMessage] ConnectID[%d] is not find.", u4ConnectID);
		return true;
	}
}

const char* CProConnectManager::GetError()
{
	return m_szError;
}

bool CProConnectManager::StartTimer()
{
	//���ⶨʱ���ظ�����
	KillTimer();
	OUR_DEBUG((LM_ERROR, "CProConnectManager::StartTimer()-->begin....\n"));

	m_pTCTimeSendCheck = new _TimerCheckID();
	if(NULL == m_pTCTimeSendCheck)
	{
		OUR_DEBUG((LM_ERROR, "CProConnectManager::StartTimer() m_pTCTimeSendCheck is NULL.\n"));
		return false;
	}

	m_pTCTimeSendCheck->m_u2TimerCheckID = PARM_CONNECTHANDLE_CHECK;
	uint32 u4Temp = App_MainConfig::instance()->GetSendCheckTime() * MAX_BUFF_1000;
	m_u4TimeCheckID = App_TimerManager::instance()->schedule(this, (void *)m_pTCTimeSendCheck, ACE_Time_Value(0, u4Temp), ACE_Time_Value(0, u4Temp));
	if(-1 == m_u4TimeCheckID)
	{
		OUR_DEBUG((LM_ERROR, "CProConnectManager::StartTimer()--> Start thread m_u4TimeCheckID error.\n"));
		return false;
	}
	else
	{
		OUR_DEBUG((LM_ERROR, "CProConnectManager::StartTimer()--> Start thread time OK.\n"));
		return true;
	}
}

bool CProConnectManager::KillTimer()
{
	if(m_u4TimeCheckID > 0)
	{
		App_TimerManager::instance()->cancel(m_u4TimeCheckID);
		m_u4TimeCheckID = 0;
	}

	if(NULL != m_pTCTimeSendCheck)
	{
		delete m_pTCTimeSendCheck;
		m_pTCTimeSendCheck = NULL;
	}

	return true;
}

int CProConnectManager::handle_timeout(const ACE_Time_Value &tv, const void *arg)
{
	_TimerCheckID* pTimerCheckID = (_TimerCheckID*)arg;
	if(NULL == pTimerCheckID)
	{
		return 0;
	}

	vecConnectManager vecConnect;

	//��ʱ��ⷢ�ͣ����ｫ��ʱ��¼������Ϣ�������У�����һ����ʱ��
	if(pTimerCheckID->m_u2TimerCheckID == PARM_CONNECTHANDLE_CHECK)
	{
		m_ThreadWriteLock.acquire();
		if(m_mapConnectManager.size() == 0)
		{
			m_ThreadWriteLock.release();
		}
		else
		{
			mapConnectManager::iterator b = m_mapConnectManager.begin();
			mapConnectManager::iterator e = m_mapConnectManager.end();

			for(b; b != e; b++)
			{
				CProConnectHandle* pConnectHandler = (CProConnectHandle* )b->second;
				if(pConnectHandler != NULL)
				{
					uint8 u1ConnectState = pConnectHandler->GetConnectState();
					if(u1ConnectState != CONNECT_CLOSEEND && u1ConnectState != CONNECT_SENDBEGIN)
					{
						if(HANDLE_ISCLOSE_YES == pConnectHandler->GetIsClosing())
						{
							vecConnect.push_back(pConnectHandler->GetConnectID());
						}
						else
						{
							pConnectHandler->CheckSendPacket();
						}
					}
				}
			}
			m_ThreadWriteLock.release();

			for(int i = 0; i < (int)vecConnect.size(); i++)
			{
				Close(vecConnect[i]);
			}
		}

		//�ж��Ƿ�Ӧ�ü�¼������־
		ACE_Time_Value tvNow = ACE_OS::gettimeofday();
		ACE_Time_Value tvInterval(tvNow - m_tvCheckConnect);
		if(tvInterval.sec() >= MAX_MSG_HANDLETIME)
		{
			AppLogManager::instance()->WriteLog(LOG_SYSTEM_CONNECT, "[CProConnectManager]CurrConnectCount = %d.", GetCount());
			m_tvCheckConnect = tvNow;
		}

		return 0;

	}

	return 0;
}

int CProConnectManager::GetCount()
{
	return (int)m_mapConnectManager.size(); 
}
