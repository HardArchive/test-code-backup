#include "BuffPacketManager.h"

CBuffPacketManager::CBuffPacketManager(void)
{

}

CBuffPacketManager::~CBuffPacketManager(void)
{

}

IBuffPacket* CBuffPacketManager::CreateBuffPacket()
{
	IBuffPacket* pBuffPacket = new CBuffPacket();
	return pBuffPacket;
}

bool CBuffPacketManager::DeleteBuffPacket(IBuffPacket* pBuffPacket)
{
	if(NULL != pBuffPacket)
	{
		delete pBuffPacket;
		pBuffPacket = NULL;
		return true;
	}
	else
	{
		return false;
	}
	
}
