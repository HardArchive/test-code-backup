#include "ServerConnectPool.h"

CServerConnectPool::CServerConnectPool(void)
{
	m_u4ServerConnectCount = 0;
}

CServerConnectPool::~CServerConnectPool(void)
{
	Close();
}

bool CServerConnectPool::AddServerConnect(uint32 u4Index, ACE_Reactor* pReactor, _ServerConnectInfo* pServerConnectInfo)
{
	mapServerConnect::iterator f = m_mapServerConnect.find(u4Index);
	if(f != m_mapServerConnect.end())
	{
		OUR_DEBUG((LM_ERROR, "[CServerConnectPool::AddServerConnect] u4Index = [%d] is exist.\n", u4Index));
		return false;
	}

	CServerConnect* pServerConnect = new CServerConnect();
	if(NULL == pServerConnect)
	{
		OUR_DEBUG((LM_ERROR, "[CServerConnectPool::AddServerConnect] u4Index = [%d] new pServerConnect error.\n", u4Index));
		return false;
	}

	if(false == pServerConnect->Init(pReactor, pServerConnectInfo))
	{
		OUR_DEBUG((LM_ERROR, "[CServerConnectPool::AddServerConnect] u4Index = [%d] pServerConnect->Init error.\n", u4Index));
		return false;
	}

	m_mapServerConnect.insert(mapServerConnect::value_type(u4Index, pServerConnect));

	return true;
}

CServerConnect* CServerConnectPool::GetServerConnect(uint32 u4Index)
{
	mapServerConnect::iterator f = m_mapServerConnect.find(u4Index);
	if(f != m_mapServerConnect.end())
	{
		return (CServerConnect* )f->second;
	}
	else
	{
		return NULL;
	}
}

void CServerConnectPool::Close()
{
	mapServerConnect::iterator b = m_mapServerConnect.begin();
	mapServerConnect::iterator e = m_mapServerConnect.end();

	for(b; b != e; b++)
	{
		CServerConnect* pServerConnect = (CServerConnect* )b->second;
		if(NULL != pServerConnect)
		{
			delete pServerConnect;
			pServerConnect = NULL;
		}
	}

	m_mapServerConnect.clear();
}

uint32 CServerConnectPool::GetConnectCount()
{
	return m_u4ServerConnectCount;
}

bool CServerConnectPool::ConnectServer(CServerConnect* pServerConnect)
{
	//��ʼ���ӷ�����
	if(NULL == pServerConnect)
	{
		OUR_DEBUG((LM_ERROR, "[CServerConnectPool::ConnectToServer] pServerConnect->GetRemoteAddr() is NULL.\n"));
		return false;
	}

	_ServerConnectInfo* pServerConnectInfo = pServerConnect->GetServerConnectInfo();

	if(NULL == pServerConnectInfo)
	{
		OUR_DEBUG((LM_ERROR, "[CServerConnectPool::ConnectToServer] pServerConnectInfo is NULL.\n"));
		return false;
	}

	ACE_INET_Addr*      pAddrRemote;
	ACE_Synch_Options*  pSynOption;

	pAddrRemote = pServerConnect->GetRemoteAddr();
	pSynOption  = pServerConnect->GetOption();

	if(NULL == pAddrRemote)
	{
		OUR_DEBUG((LM_ERROR, "[CServerConnectPool::ConnectToServer] pServerConnect->GetRemoteAddr() is NULL.\n"));
		return false;
	}

	if(NULL == pSynOption)
	{
		OUR_DEBUG((LM_ERROR, "[CServerConnectPool::ConnectToServer][%s:%d] pServerConnect->GetOption() is NULL.\n", pAddrRemote->get_host_addr(), pAddrRemote->get_port_number()));
		return false;
	}

	int nRet = m_ConnectorFactory.connect(pServerConnect, *pAddrRemote, *pSynOption);
	if(nRet != 0)
	{
		OUR_DEBUG((LM_ERROR, "[CServerConnectPool::ConnectToServer](%s:%d)connect error[%d].\n", pServerConnectInfo->m_strServerIP.c_str(), pServerConnectInfo->m_u4ServerPort, errno));
		return false;
	}

	return true;
}

bool CServerConnectPool::Init(ACE_Reactor* pReactor, _ServerConnectInfo* pServerConnectInfo)
{
	if(NULL == pReactor)
	{
		OUR_DEBUG((LM_ERROR, "[CServerConnectPool::Init] pReactor is NULL.\n"));
		return false;
	}

	if(NULL == pServerConnectInfo)
	{
		OUR_DEBUG((LM_ERROR, "[CServerConnectPool::Init] pServerConnectInfo is NULL.\n"));
		return false;
	}

	int nThreadCount = 0;
	for(uint32 i = 0; i < pServerConnectInfo->m_u4MaxConn; i++)
	{
		//�����µ�pServerConnectInfo
		if(false == AddServerConnect(i, pReactor, pServerConnectInfo))
		{
			return false;
		}

		CServerConnect* pServerConnect = GetServerConnect(i);
		if(NULL == pServerConnect)
		{
			OUR_DEBUG((LM_ERROR, "[CServerConnectPool::Init] Can't find [%d] pServerConnect.\n", i));
			return false;
		}

		if(false == ConnectServer(pServerConnect))
		{
			OUR_DEBUG((LM_ERROR, "[CServerConnectPool::Init] ConnectToServer m_u4ServerID = %d, [%d] is fail.\n", pServerConnectInfo->m_u4ServerID, i));
			return false;
		}
		else
		{
			OUR_DEBUG((LM_ERROR, "[CServerConnectPool::Init] ConnectToServer m_u4ServerID = %d, [%d] is OK.\n", pServerConnectInfo->m_u4ServerID, i));
		}

		nThreadCount++;
		m_u4ServerConnectCount = nThreadCount;
		m_RandomNumber.SetRange(0, m_u4ServerConnectCount - 1);
	}
	return true;
}

int CServerConnectPool::GetRandomServerConnectID()
{
	return m_RandomNumber.GetRandom();
}
