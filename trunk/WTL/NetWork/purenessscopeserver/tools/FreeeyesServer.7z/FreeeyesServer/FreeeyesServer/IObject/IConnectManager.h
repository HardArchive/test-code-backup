#ifndef _ICONNECTMANAGER_H
#define _ICONNECTMANAGER_H

#include "IBuffPacket.h"

class IConnectManager
{
public:
	virtual ~IConnectManager() {};
	virtual bool SendMessage(uint32 u4ConnectID, IBuffPacket* pBuffPacket) = 0;
	virtual bool Close(uint32 u4ConnectID)                                 = 0;
	virtual int  GetCount()                                                = 0;
};

#endif
