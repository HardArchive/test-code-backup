#ifndef _IPOSTMANAGER_H
#define _IPOSTMANAGER_H

#include "IMessage.h"

class IPostManager
{
public:
	virtual ~IPostManager() {};
	virtual bool PutPostSendMessage(IPostMessage* pPostMessage) = 0;
};

#endif
