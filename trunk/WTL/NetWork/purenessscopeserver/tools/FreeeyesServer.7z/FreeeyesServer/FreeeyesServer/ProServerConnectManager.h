#ifndef _PROSERVERCONNECTMANAGER_H
#define _PROSERVERCONNECTMANAGER_H

#include "ProServerConnectPool.h"
#include "AppConfig.h"

class CProServerConnectManager
{
public:
	CProServerConnectManager(void);
	~CProServerConnectManager(void);

	bool Init();
	void Close();
	void ClosePool();
	void Display();
	bool Start(ACE_Proactor* pProactor);
	bool SetSendMessage(uint32 u4ServerID, IBuffPacket* pBuffPacket, uint32 u4MsgID);   //��ĳһ��ָ�����м������������������
	int  GetServerCount();

private:
	bool ReadConfig(); 
	bool AddServerConnectInfo(_ServerConnectInfo* pServerConnectInfo);           //��Ӧ�����ļ���ӳ���
	bool AddServerConnectPool(uint32 u4ServerID);                                //��Ӧ�����ļ��Ľṹ��
	CProServerConnectPool* GetProServerConnectPool(uint32 u4ServerID);

private:
	typedef map<uint32, _ServerConnectInfo*>    mapServerConnectInfo;
	typedef map<uint32, CProServerConnectPool*> mapServerConnectPool;
	char                 m_szConfigName[MAX_BUFF_200];
	CAppConfig           m_AppConfig;
	mapServerConnectInfo m_mapServerConnectInfo;
	mapServerConnectPool m_mapServerConnectPool;
	int                  m_nServerCount;
};

typedef ACE_Singleton<CProServerConnectManager, ACE_Null_Mutex> App_ProServerConnectManager;
#endif
