#ifndef _SERVERCONNECT_H
#define _SERVERCONNECT_H

#include "define.h"
#include "ace/Synch.h"
#include "ace/Synch_Traits.h"
#include "ace/Singleton.h"
#include "ace/Condition_T.h"
#include "ace/SOCK_Stream.h"
#include "ace/Svc_Handler.h"
#include "ace/Connector.h" 
#include "ace/SOCK_Connector.h" 
#include "ace/Reactor.h"
#include "ace/Mutex.h" 
#include "ace/Thread_Mutex.h"
#include "ace/Reactor_Notification_Strategy.h"
#include "BuffPacket.h"
#include "Message.h"
#include <deque>

using namespace std;

class CServerConnect : public ACE_Svc_Handler<ACE_SOCK_STREAM, ACE_NULL_SYNCH>
{
public:
	CServerConnect(void);
	~CServerConnect(void);

	bool Init(ACE_Reactor* pReactor, _ServerConnectInfo* pServerConnectInfo);

	virtual int open (void*);
	virtual int handle_input(ACE_HANDLE fd = ACE_INVALID_HANDLE);
	virtual int handle_output(ACE_HANDLE fd = ACE_INVALID_HANDLE);
	virtual int handle_close(ACE_HANDLE h, ACE_Reactor_Mask mask);

	bool GetConnectState();
	void SetConnectTime();
	void SetUpdateTime();
	ACE_INET_Addr* GetRemoteAddr();
	ACE_Synch_Options* GetOption();
	void Close();
	bool SendMessage(IBuffPacket* pBuffPacket, uint32 u4MsgID);
	_ServerConnectInfo* GetServerConnectInfo(); 
	
private:
	bool CheckMessage();
	uint32 GetConnectID();
	bool PutSendPacket(IBuffPacket* pBuffPacket);             //���м��������������

	void SetMessageID(uint32 u4MsgID);
	uint32 GetMessageID();

private:
	char                               m_szError[MAX_BUFF_500];
	_ServerConnectInfo*                m_pServerConnectInfo;
	ACE_Reactor*                       m_pReactor; 
	ACE_Reactor_Notification_Strategy* m_pNotifier;
	ACE_Time_Value                     m_tvConnectTime;
	ACE_Time_Value                     m_tvUpdateTime;
	ACE_Time_Value                     m_atvInput;
	ACE_Time_Value                     m_atvOutput;
	ACE_INET_Addr*                     m_pAddrRemote;
	ACE_Synch_Options*                 m_pSynOption;
	bool                               m_blConnect;
	CBuffPacket                        m_RecvPacket;

	uint8                              m_u1ConnectState;               //��ǰ����״̬
	uint32                             m_u4AllRecvCount;               //��ǰ���ӽ������ݰ��ĸ���
	uint32                             m_u4AllSendCount;               //��ǰ���ӷ������ݰ��ĸ���
	uint32                             m_u4AllRecvSize;                //��ǰ���ӽ����ֽ�����
	uint32                             m_u4AllSendSize;                //��ǰ���ӷ����ֽ�����

	typedef deque<uint32>  dqMessageID;
	dqMessageID                       m_dqMessageID;
};

typedef ACE_Connector<CServerConnect, ACE_SOCK_CONNECTOR> ConnectorFactory;

#endif
