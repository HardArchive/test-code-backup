#ifndef _TCPCHECKPACKET_H
#define _TCPCHECKPACKET_H

#include "BuffPacket.h"
#include "IObject/ICheckPacket.h"

class CTcpCheckPacket : public ICheckPacket
{
public:
	CTcpCheckPacket(void);
	~CTcpCheckPacket(void);

	IBuffPacket* CheckData(IBuffPacket* pRecvPacket, uint32 u4ConnectID, uint32& u4PacketLen);
};
#endif
