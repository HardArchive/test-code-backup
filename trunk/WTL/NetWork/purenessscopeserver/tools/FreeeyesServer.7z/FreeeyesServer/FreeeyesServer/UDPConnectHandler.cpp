#include "UDPConnectHandler.h"

CUDPConnectHandler::CUDPConnectHandler(void)
{
	m_u4ConnectID = 0;
}

CUDPConnectHandler::~CUDPConnectHandler(void)
{
}

ACE_HANDLE CUDPConnectHandler::get_handle(void) const
{
	return m_updDgram.get_handle();
}

int CUDPConnectHandler::open(const char* szIP, int nPort)
{
	m_AddrLocal.set(nPort, szIP);
	if(-1 == m_updDgram.open(m_AddrLocal, 1))
	{
		char szAddr[512]   = {'\0'};
		m_AddrLocal.addr_to_string(szAddr, 512);
		OUR_DEBUG((LM_ERROR, "[CUDPConnect::open] Addr[%s] is bind error(%d).\n", szAddr, errno));
		return -1;
	}

	if(-1 == this->reactor()->register_handler(this, ACE_Event_Handler::READ_MASK))
	{
		char szAddr[512]   = {'\0'};
		m_AddrLocal.addr_to_string(szAddr, 512);
		OUR_DEBUG((LM_ERROR, "[CUDPConnect::open] Addr[%s] is register_handler error(%d).\n", szAddr, errno));
		return -1;
	}
	else
	{
		m_atvConnect = ACE_OS::gettimeofday();
		m_atvInput   = ACE_OS::gettimeofday();
		return 0;
	}
}

void CUDPConnectHandler::SetConnectID(uint32 u4ConnectID)
{
	m_u4ConnectID = u4ConnectID;
}

uint32 CUDPConnectHandler::GetConnectID()
{
	return m_u4ConnectID;
}

const char* CUDPConnectHandler::GetError()
{
	return m_szError;
}

bool CUDPConnectHandler::Close()
{
	return true;
}

bool CUDPConnectHandler::Decrypt(const char* szSrc, int nSrcLen, char* szDes, int& nDecLen)
{
	bool blFlag = m_Encrypt.DoEncrypt(false, szSrc, nSrcLen, szDes, nDecLen);

	return blFlag;
}

CMessage* CUDPConnectHandler::SetMessage(IBuffPacket* pBuffPacket)
{
	if(NULL == pBuffPacket)
	{
		OUR_DEBUG((LM_ERROR, "[CConnectHandler::SetMessage] ConnectID = %d, pBuffPacket is NULL.\n", GetConnectID()));
		return false;
	}

	//�����µ�Message����
	CMessage* pMessage = new CMessage();
	if(NULL == pMessage)
	{
		//д����հ�����
		OUR_DEBUG((LM_ERROR, "[CConnectHandler::SetMessage] ConnectID = %d, pMessage is NULL.\n", GetConnectID()));
		return NULL;
	}

	//�����µ�_MessageBase
	_MessageBase* pMessageBase = new _MessageBase();
	if(NULL == pMessageBase)
	{
		//д����հ�����
		OUR_DEBUG((LM_ERROR, "[CConnectHandler::SetMessage] ConnectID = %d, _MessageBase is NULL.\n", GetConnectID()));
		return NULL;
	}

	//��ʼ��װ����
	pMessageBase->m_u4ConnectID = GetConnectID();
	pMessageBase->m_u2Cmd       = 0;
	pMessageBase->m_u4MsgTime   = (uint32)ACE_OS::gettimeofday().sec();

	pMessage->SetMessageBase(pMessageBase);

	//�����ܵ����ݻ������CMessage����
	if(false == pMessage->SetRecvPacket(pBuffPacket))
	{
		//д����հ�����
		OUR_DEBUG((LM_ERROR, "[CConnectHandler::SetMessage] ConnectID = %d, pMessage->SetRecvPacket is fail.\n", GetConnectID()));
		delete pMessage;
		return NULL;
	}

	return pMessage;
}

bool CUDPConnectHandler::CheckMessage(ACE_INET_Addr& remoteAddr)
{
	int nPacketLen = m_RecvPacket.GetPacketLen();
	if(nPacketLen > 2)
	{
		//�����ݽ��룬���õ�����
		uint32 u4Packetlen = 0;

		u4Packetlen = m_RecvPacket.GetHeadLen();

		if(u4Packetlen > m_RecvPacket.GetWriteLen())
		{
			//�������ݿ�û�д��꣬��Ҫ����������ݡ�
			OUR_DEBUG((LM_ERROR, "[CConnectHandler::CheckMessage] ConnectID = %d, u2Packetlen[%d] > m_RecvPacket.GetWriteLen()[%d].\n", GetConnectID(), u4Packetlen, m_RecvPacket.GetWriteLen()));
			//m_RecvPacket.RollBack(m_RecvPacket.GetWriteLen());
			return false;
		}

		m_RecvPacket >> u4Packetlen;

		//�������и��������һ������Buff
		CBuffPacket* pBuffPacket = new CBuffPacket();
		if(NULL == pBuffPacket)
		{
			//�������հ�����
			OUR_DEBUG((LM_ERROR, "[CConnectHandler::CheckMessage] ConnectID = %d, u2Packetlen[%d]�� m_RecvPacket.GetWriteLen()[%d] pBuffPacket is NULL.\n", GetConnectID(), u4Packetlen, m_RecvPacket.GetWriteLen()));
			m_RecvPacket.RollBack(m_RecvPacket.GetWriteLen());
			return false;
		}

		//�������ӽ����㷨�ж�
		if(0 == App_MainConfig::instance()->GetUDPEncryptFlag())
		{
			if(false == pBuffPacket->WriteStream(m_RecvPacket.GetData(), u4Packetlen + sizeof(uint32)))  //����Ҫ���ϰ����ܳ���4���ֽ�
			{
				//д����հ�����
				OUR_DEBUG((LM_ERROR, "[CConnectHandler::CheckMessage] ConnectID = %d, u2Packetlen[%d]�� m_RecvPacket.GetWriteLen()[%d] ppBuffPacket->WriteStream error.\n", GetConnectID(), u4Packetlen, m_RecvPacket.GetWriteLen()));
				m_RecvPacket.RollBack(m_RecvPacket.GetWriteLen());
				return false;
			}
		}
		else
		{
			//��������
			char* pSrc = new char[u4Packetlen + sizeof(uint32) + 1];   //��������
			pSrc[u4Packetlen + sizeof(uint32)] = '\0';
			char* pDes = new char[u4Packetlen + sizeof(uint32) + 1];   //��������
			pSrc[0] = '\0';

			int nDesLen = u4Packetlen + sizeof(uint32); 
			ACE_OS::memcpy(pSrc, m_RecvPacket.GetData() + sizeof(uint32), u4Packetlen);
			if(false == Decrypt(pSrc, u4Packetlen, pDes, nDesLen))
			{
				OUR_DEBUG((LM_ERROR, "[CConnectHandler::CheckMessage] ConnectID = %d, u2Packetlen[%d]�� m_RecvPacket.GetWriteLen()[%d]  Decrypt Error.\n", GetConnectID(), u4Packetlen, m_RecvPacket.GetWriteLen()));
				m_RecvPacket.RollBack(m_RecvPacket.GetWriteLen());
				delete[] pSrc;
				delete[] pDes;
				return false;
			}

			//��ý����ַ����ĳ���
			ACE_OS::memcpy(&nDesLen, pDes, 4);

			//(*pBuffPacket) << (uint32)nDesLen;
			if(false == pBuffPacket->WriteStream(pDes, nDesLen + sizeof(uint32)))
			{
				//д����հ�����
				OUR_DEBUG((LM_ERROR, "[CConnectHandler::CheckMessage] ConnectID = %d, u2Packetlen[%d]�� m_RecvPacket.GetWriteLen()[%d] ppBuffPacket->WriteStream error.\n", GetConnectID(), u4Packetlen, m_RecvPacket.GetWriteLen()));
				m_RecvPacket.RollBack(m_RecvPacket.GetWriteLen());
				delete[] pSrc;
				delete[] pDes;
				return false;
			}

			delete[] pSrc;
			delete[] pDes;
		}

		m_RecvPacket.RollBack(u4Packetlen + sizeof(uint32));

		//������Buff������Ϣ����
		CMessage* pMessage = SetMessage(pBuffPacket);
		if(NULL != pMessage)
		{
			//�����ӵ�IP�Ͷ˿�д����Ϣ��
			pMessage->SetMessageInfo(remoteAddr.get_host_addr(), (int)remoteAddr.get_port_number());
			//��Ҫ��������Ϣ������Ϣ�����߳�
			if(false == App_UDPMessageService::instance()->PutMessage(pMessage))
			{
				OUR_DEBUG((LM_ERROR, "[CConnectHandler::CheckMessage] App_MessageService::instance()->PutMessage Error.\n"));
				delete pMessage;
				return false;
			}
		}

		return true;
	}
	else
	{
		return false;
	}
}

int CUDPConnectHandler::handle_signal (int signum, siginfo_t* siginfo, ucontext_t* context)
{
	return ACE_Event_Handler::handle_signal (signum, siginfo, context);
}

int CUDPConnectHandler::handle_input(ACE_HANDLE fd)
{
	//UDP�����ݽ�����������û����ӵģ����Ժ�TCP����Щ��ͬ
	ACE_INET_Addr remoteAddr;

	m_atvInput = ACE_OS::gettimeofday();

	if(fd == ACE_INVALID_HANDLE)
	{
		OUR_DEBUG((LM_ERROR, "[CConnectHandler::handle_input]fd == ACE_INVALID_HANDLE .\n"));
		sprintf_safe(m_szError, MAX_BUFF_500, "[CConnectHandler::handle_input]fd == ACE_INVALID_HANDLE .");
		return -1;
	}

	OUR_DEBUG((LM_ERROR, "[CUDPConnectHandler::handle_input]m_RecvPacket.GetPacketSize() = %d m_RecvPacket.GetWriteLen() = %d.\n", m_RecvPacket.GetPacketSize(), m_RecvPacket.GetWriteLen()));
	int nDataLen = m_updDgram.recv(m_RecvPacket.WritePtr(), m_RecvPacket.GetPacketSize() - m_RecvPacket.GetWriteLen(), remoteAddr);
	if(nDataLen <= 0)
	{
		OUR_DEBUG((LM_ERROR, "[CUDPConnectHandler::handle_input] ConnectID = %d, recv data is error nDataLen = [%d] errno = [%d].\n", GetConnectID(), nDataLen, errno));
		sprintf_safe(m_szError, MAX_BUFF_500, "[CConnectHandler::handle_input] ConnectID = %d, recv data is error[%d].\n", GetConnectID(), nDataLen);
		return -1;
	}
	OUR_DEBUG((LM_ERROR, "[CUDPConnectHandler::handle_input] ConnectID = %d, nDataLen =%d.\n", GetConnectID(), nDataLen));
	m_RecvPacket.WritePtr(nDataLen);

	bool blState = true;
	while(true == blState)
	{
		blState = CheckMessage(remoteAddr);
	}

	return 0;

	return 0;
}

int CUDPConnectHandler::handle_close(ACE_HANDLE handle, ACE_Reactor_Mask close_mask)
{
	if(close_mask == ACE_Event_Handler::WRITE_MASK)
	{
		return 0;
	}

	close_mask = ACE_Event_Handler::ALL_EVENTS_MASK | ACE_Event_Handler::DONT_CALL;
	this->reactor()->remove_handler(this, close_mask);
	m_updDgram.close();
	delete this;
	return 0;
}

bool CUDPConnectHandler::SendMessage(IBuffPacket* pBuffPacket, const char* szIP, int nPort)
{
	//UDP�Ƿ��������ӵģ�������ʱ���ÿ��Ƕ��з��͵����⡣
	ACE_INET_Addr remoteAddr;
	remoteAddr.set(nPort, szIP);
	int nSendLen = (int)m_updDgram.send(pBuffPacket->ReadPtr(), pBuffPacket->GetWriteLen(), remoteAddr);
	if((uint32)nSendLen != pBuffPacket->GetWriteLen())
	{
		OUR_DEBUG((LM_ERROR, "[CUDPConnectHandler::SendMessage] Addr[%s:%d] error(%d).\n", szIP, nPort, errno));
		return false;
	}
	else
	{
		return true;
	}
}

//**********************************************************************

CUDPConnectManager::CUDPConnectManager()
{
	m_u4ConnectCurrID = 0;
	m_szError[0]      = '\0';
}

CUDPConnectManager::~CUDPConnectManager()
{
	CloseAll();
}

void CUDPConnectManager::CloseAll()
{
	mapConnectManager::iterator b = m_mapConnectManager.begin();
	mapConnectManager::iterator e = m_mapConnectManager.end();

	for(b; b != e; b++)
	{
		CUDPConnectHandler* pConnectHandler = (CUDPConnectHandler* )b->second;
		if(pConnectHandler != NULL)
		{
			pConnectHandler->Close();
		}
	}

	m_mapConnectManager.clear();
}

bool CUDPConnectManager::CloseConnect(uint32 u4ConnectID)
{
	mapConnectManager::iterator f = m_mapConnectManager.find(u4ConnectID);

	if(f != m_mapConnectManager.end())
	{
		CUDPConnectHandler* pConnectHandler = (CUDPConnectHandler* )f->second;
		if(pConnectHandler != NULL)
		{
			pConnectHandler->Close();
		}

		m_mapConnectManager.erase(f);

		return true;
	}
	else
	{
		sprintf_safe(m_szError, MAX_BUFF_500, "[CUDPConnectManager::CloseConnect] ConnectID[%d] is not find.", u4ConnectID);
		return true;
	}
}

bool CUDPConnectManager::AddConnect(CUDPConnectHandler* pConnectHandler)
{
	if(pConnectHandler == NULL)
	{
		sprintf_safe(m_szError, MAX_BUFF_500, "[CUDPConnectManager::AddConnect] pConnectHandler is NULL.");
		return false;		
	}

	mapConnectManager::iterator f = m_mapConnectManager.find(m_u4ConnectCurrID);
	if(f != m_mapConnectManager.end())
	{
		sprintf_safe(m_szError, MAX_BUFF_500, "[CUDPConnectManager::AddConnect] ConnectID[%d] is exist.", m_u4ConnectCurrID);
		return false;
	}

	pConnectHandler->SetConnectID(m_u4ConnectCurrID);
	//����map
	m_mapConnectManager.insert(mapConnectManager::value_type(m_u4ConnectCurrID, pConnectHandler));
	m_u4ConnectCurrID++;

	return true;
}

bool CUDPConnectManager::SendMessage(uint32 u4ConnectID, IBuffPacket* pBuffPacket, const char* szIP, int nPort)
{
	if(NULL == pBuffPacket)
	{
		sprintf_safe(m_szError, MAX_BUFF_500, "[CUDPConnectManager::SendMessage] ConnectID[%d] pBuffPacket is NULL.", u4ConnectID);
		return false;
	}

	mapConnectManager::iterator f = m_mapConnectManager.find(u4ConnectID);

	if(f != m_mapConnectManager.end())
	{
		CUDPConnectHandler* pConnectHandler = (CUDPConnectHandler* )f->second;

		if(NULL != pConnectHandler)
		{
			return pConnectHandler->SendMessage(pBuffPacket, szIP, nPort);
		}
		else
		{
			sprintf_safe(m_szError, MAX_BUFF_500, "[CUDPConnectManager::SendMessage] ConnectID[%d] is not find.", u4ConnectID);
			return true;
		}
	}
	else
	{
		sprintf_safe(m_szError, MAX_BUFF_500, "[CUDPConnectManager::SendMessage] ConnectID[%d] is not find.", u4ConnectID);
		return true;
	}
}

const char* CUDPConnectManager::GetError()
{
	return m_szError;
}
