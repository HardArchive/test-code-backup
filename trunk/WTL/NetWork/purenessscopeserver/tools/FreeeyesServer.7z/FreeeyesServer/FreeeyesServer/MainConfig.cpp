#include "MainConfig.h"

CMainConfig::CMainConfig(void)
{
	m_szError[0] = '\0';

	m_u4MsgHighMark         = 0;
	m_u4MsgLowMark          = 0;
	m_u4MsgThreadCount      = 0;
	m_u4MsgMaxQueue         = 0;
	m_nEncryptFlag          = 0;
	m_nEncryptOutFlag       = 0;
	m_u4ReactorCount        = 0;
	m_u4SendThresHold       = 0;
	m_u4SendCheckTime       = 0;
	m_u4RecvBuffSize        = 0;
	m_u2ThreadTimuOut       = 0;
	m_u2ThreadTimeCheck     = 0;
	m_u2PostThreadTimuOut   = 0;
	m_u2PostThreadTimeCheck = 0;
	m_u2UDPThreadTimuOut    = 0;
	m_u2UDPThreadTimeCheck  = 0;
	m_u2PacketTimeOut       = 0;
	m_u2SendAliveTime       = 0;

	m_u4UDPMsgHighMark      = 0;
	m_u4UDPMsgLowMark       = 0;
	m_u4UDPMsgThreadCount   = 0;
	m_u4UDPMsgMaxQueue      = 0;
	m_nUDPEncryptFlag       = 0;

	m_szServerName[0]       = '\0';
	m_szModulePath[0]       = '\0';
	m_szResourceName[0]     = '\0';
	m_szEncryptPass[0]      = '\0';
	m_szUDPEncryptPass[0]   = '\0';
}

CMainConfig::~CMainConfig(void)
{
	m_vecServerInfo.clear();
	m_vecUDPServerInfo.clear();
}

const char* CMainConfig::GetError()
{
	return m_szError;
}

bool CMainConfig::Init(const char* szConfigPath)
{
	OUR_DEBUG((LM_INFO, "[CMainConfig::Init]Filename = %s.\n", szConfigPath));
	if(!m_AppConfig.ReadConfig(szConfigPath))
	{
		sprintf_safe(m_szError, MAX_BUFF_500, "%s", m_AppConfig.GetError());
		return false;
	}

	ACE_TString strValue;

	//��÷�Ӧ������
	m_AppConfig.GetValue("ReactorCount", strValue, "\\REACTOR");
	m_u4ReactorCount = ACE_OS::atoi((char*)strValue.c_str());

	m_AppConfig.GetValue("ServerID", strValue, "\\SERVER");
	m_nServerID = ACE_OS::atoi((char*)strValue.c_str());

	m_AppConfig.GetValue("ServerName", strValue, "\\SERVER");
	sprintf_safe(m_szServerName, MAX_BUFF_20, "%s", strValue.c_str());

	m_AppConfig.GetValue("ListenPortCount", strValue, "\\SERVER");
	int nServerCount = ACE_OS::atoi((char*)strValue.c_str());

	//��ü����˿���Ϣ
	char szName1[MAX_BUFF_20] = {'\0'};
	char szName2[MAX_BUFF_20] = {'\0'};
	_ServerInfo serverinfo;

	m_vecServerInfo.clear();
	for(int i = 0; i < nServerCount; i++)
	{
		sprintf_safe(szName1, MAX_BUFF_20, "ServerIP%d", i);
		sprintf_safe(szName2, MAX_BUFF_20, "ServerPort%d", i);
		m_AppConfig.GetValue(szName1, strValue, "\\SERVER");
		sprintf_safe(serverinfo.m_szServerIP, MAX_BUFF_20, "%s", strValue.c_str());

		m_AppConfig.GetValue(szName2, strValue, "\\SERVER");
		serverinfo.m_nPort = ACE_OS::atoi((char*)strValue.c_str());

		m_vecServerInfo.push_back(serverinfo);
	}

	//��ʼ�����Ϣ�����̲߳���
	m_AppConfig.GetValue("Msg_High_mark", strValue, "\\SERVER");
	m_u4MsgHighMark = (uint32)ACE_OS::atoi((char*)strValue.c_str());
	m_AppConfig.GetValue("Msg_Low_mark", strValue, "\\SERVER");
	m_u4MsgLowMark = (uint32)ACE_OS::atoi((char*)strValue.c_str());
	m_AppConfig.GetValue("Msg_Thread", strValue, "\\SERVER");
	m_u4MsgThreadCount = (uint32)ACE_OS::atoi((char*)strValue.c_str());
	m_AppConfig.GetValue("Msg_MaxQueue", strValue, "\\SERVER");
	m_u4MsgMaxQueue = (uint32)ACE_OS::atoi((char*)strValue.c_str());

	//��ʼ���UDP��������ز���
	m_AppConfig.GetValue("ListenPortCount", strValue, "\\UDPSERVER");
	int nUDPServerCount = ACE_OS::atoi((char*)strValue.c_str());

	m_vecUDPServerInfo.clear();
	for(int i = 0; i < nUDPServerCount; i++)
	{
		sprintf_safe(szName1, MAX_BUFF_20, "ServerIP%d", i);
		sprintf_safe(szName2, MAX_BUFF_20, "ServerPort%d", i);
		m_AppConfig.GetValue(szName1, strValue, "\\UDPSERVER");
		sprintf_safe(serverinfo.m_szServerIP, MAX_BUFF_20, "%s", strValue.c_str());

		m_AppConfig.GetValue(szName2, strValue, "\\UDPSERVER");
		serverinfo.m_nPort = ACE_OS::atoi((char*)strValue.c_str());

		m_vecUDPServerInfo.push_back(serverinfo);
	}

	m_AppConfig.GetValue("Msg_High_mark", strValue, "\\UDPSERVER");
	m_u4UDPMsgHighMark = (uint32)ACE_OS::atoi((char*)strValue.c_str());
	m_AppConfig.GetValue("Msg_Low_mark", strValue, "\\UDPSERVER");
	m_u4UDPMsgLowMark = (uint32)ACE_OS::atoi((char*)strValue.c_str());
	m_AppConfig.GetValue("Msg_Thread", strValue, "\\UDPSERVER");
	m_u4UDPMsgThreadCount = (uint32)ACE_OS::atoi((char*)strValue.c_str());
	m_AppConfig.GetValue("Msg_MaxQueue", strValue, "\\UDPSERVER");
	m_u4UDPMsgMaxQueue = (uint32)ACE_OS::atoi((char*)strValue.c_str());

	m_AppConfig.GetValue("EncryptFlag", strValue, "\\UDPSERVER");
	m_nUDPEncryptFlag = (int)ACE_OS::atoi((char*)strValue.c_str());
	m_AppConfig.GetValue("EncryptPass", strValue, "\\UDPSERVER");
	sprintf_safe(m_szUDPEncryptPass, MAX_BUFF_9, "%s", strValue.c_str());
	m_AppConfig.GetValue("ThreadTimeout", strValue, "\\UDPSERVER");
	m_u2UDPThreadTimuOut = (uint16)ACE_OS::atoi((char*)strValue.c_str());
	m_AppConfig.GetValue("ThreadTimeCheck", strValue, "\\UDPSERVER");
	m_u2UDPThreadTimeCheck = (uint16)ACE_OS::atoi((char*)strValue.c_str());

	//��ʼ��ü���ģ�����
	m_AppConfig.GetValue("ModulePath", strValue, "\\SERVER");
	sprintf_safe(m_szModulePath, MAX_BUFF_200, "%s", strValue.c_str());
	m_AppConfig.GetValue("ModuleString", strValue, "\\SERVER");
	sprintf_safe(m_szResourceName, MAX_BUFF_200, "%s", strValue.c_str());

	//��ʼ��ü���ģʽ����
	m_AppConfig.GetValue("EncryptFlag", strValue, "\\SERVER");
	m_nEncryptFlag = (int)ACE_OS::atoi((char*)strValue.c_str());
	m_AppConfig.GetValue("EncryptPass", strValue, "\\SERVER");
	sprintf_safe(m_szEncryptPass, MAX_BUFF_9, "%s", strValue.c_str());
	m_AppConfig.GetValue("EncryptOutFlag", strValue, "\\SERVER");
	m_nEncryptOutFlag = (int)ACE_OS::atoi((char*)strValue.c_str());

	//��ʼ��÷��ͺͽ��ܷ�ֵ
	m_AppConfig.GetValue("SendThresHold", strValue, "\\SERVER");
	m_u4SendThresHold = (int)ACE_OS::atoi((char*)strValue.c_str());
	m_AppConfig.GetValue("SendCheckTime", strValue, "\\SERVER");
	m_u4SendCheckTime = (int)ACE_OS::atoi((char*)strValue.c_str());
	m_AppConfig.GetValue("RecvBuffSize", strValue, "\\SERVER");
	m_u4RecvBuffSize = (int)ACE_OS::atoi((char*)strValue.c_str());
	m_AppConfig.GetValue("SendQueueMax", strValue, "\\SERVER");
	m_u2SendQueueMax = (uint16)ACE_OS::atoi((char*)strValue.c_str());
	m_AppConfig.GetValue("ThreadTimeout", strValue, "\\SERVER");
	m_u2ThreadTimuOut = (uint16)ACE_OS::atoi((char*)strValue.c_str());
	m_AppConfig.GetValue("ThreadTimeCheck", strValue, "\\SERVER");
	m_u2ThreadTimeCheck = (uint16)ACE_OS::atoi((char*)strValue.c_str());
	m_AppConfig.GetValue("DisposeTimeout", strValue, "\\SERVER");
	m_u2PacketTimeOut = (uint16)ACE_OS::atoi((char*)strValue.c_str());
	m_AppConfig.GetValue("SendAliveTime", strValue, "\\SERVER");
	m_u2SendAliveTime = (uint16)ACE_OS::atoi((char*)strValue.c_str());

	//��ʼ����м��������ز���
	m_AppConfig.GetValue("Msg_High_mark", strValue, "\\POSTSERVER");
	m_u4PostMsgHighMark = (uint32)ACE_OS::atoi((char*)strValue.c_str());
	m_AppConfig.GetValue("Msg_Low_mark", strValue, "\\POSTSERVER");
	m_u4PostMsgLowMark = (uint32)ACE_OS::atoi((char*)strValue.c_str());
	m_AppConfig.GetValue("Msg_Thread", strValue, "\\POSTSERVER");
	m_u4PostMsgThreadCount = (uint32)ACE_OS::atoi((char*)strValue.c_str());
	m_AppConfig.GetValue("Msg_MaxQueue", strValue, "\\POSTSERVER");
	m_u4PostMsgMaxQueue = (uint32)ACE_OS::atoi((char*)strValue.c_str());
	m_AppConfig.GetValue("ThreadTimeout", strValue, "\\POSTSERVER");
	m_u2PostThreadTimuOut = (uint16)ACE_OS::atoi((char*)strValue.c_str());
	m_AppConfig.GetValue("ThreadTimeCheck", strValue, "\\POSTSERVER");
	m_u2PostThreadTimeCheck = (uint16)ACE_OS::atoi((char*)strValue.c_str());

	return true;
}

void CMainConfig::Display()
{
	OUR_DEBUG((LM_INFO, "[CMainConfig::Display]m_nServerID = %d.\n", m_nServerID));
	OUR_DEBUG((LM_INFO, "[CMainConfig::Display]m_szServerName = %s.\n", m_szServerName));

	for(int i = 0; i < (int)m_vecServerInfo.size(); i++)
	{
		OUR_DEBUG((LM_INFO, "[CMainConfig::Display]ServerIP%d = %s.\n", i, m_vecServerInfo[i].m_szServerIP));
		OUR_DEBUG((LM_INFO, "[CMainConfig::Display]ServerPort%d = %d.\n", i, m_vecServerInfo[i].m_nPort));
	}

	OUR_DEBUG((LM_INFO, "[CMainConfig::Display]m_u4MsgHighMark = %d.\n", m_u4MsgHighMark));
	OUR_DEBUG((LM_INFO, "[CMainConfig::Display]m_u4MsgLowMark = %d.\n", m_u4MsgLowMark));
	OUR_DEBUG((LM_INFO, "[CMainConfig::Display]m_u4MsgThreadCount = %d.\n", m_u4MsgThreadCount));
	OUR_DEBUG((LM_INFO, "[CMainConfig::Display]m_u4MsgMaxQueue = %d.\n", m_u4MsgMaxQueue));
	OUR_DEBUG((LM_INFO, "[CMainConfig::Display]m_szModulePath = %s.\n", m_szModulePath));
	OUR_DEBUG((LM_INFO, "[CMainConfig::Display]m_szResourceName = %s.\n", m_szResourceName));
	OUR_DEBUG((LM_INFO, "[CMainConfig::Display]m_nEncryptFlag = %d.\n", m_nEncryptFlag));
	OUR_DEBUG((LM_INFO, "[CMainConfig::Display]m_szEncryptPass = %s.\n", m_szEncryptPass));
	OUR_DEBUG((LM_INFO, "[CMainConfig::Display]m_nEncryptOutFlag = %d.\n", m_nEncryptOutFlag));
	OUR_DEBUG((LM_INFO, "[CMainConfig::Display]m_u4SendThresHold = %d.\n", m_u4SendThresHold));
	OUR_DEBUG((LM_INFO, "[CMainConfig::Display]m_u4SendCheckTime = %d.\n", m_u4SendCheckTime));
	OUR_DEBUG((LM_INFO, "[CMainConfig::Display]m_u4RecvBuffSize = %d.\n", m_u4RecvBuffSize));
	OUR_DEBUG((LM_INFO, "[CMainConfig::Display]m_u2SendQueueMax = %d.\n", m_u2SendQueueMax));
	OUR_DEBUG((LM_INFO, "[CMainConfig::Display]m_u2ThreadTimuOut = %d.\n", m_u2ThreadTimuOut));
	OUR_DEBUG((LM_INFO, "[CMainConfig::Display]m_u2ThreadTimeCheck = %d.\n", m_u2ThreadTimeCheck));
	OUR_DEBUG((LM_INFO, "[CMainConfig::Display]m_u4PostMsgHighMark = %d.\n", m_u4PostMsgHighMark));
	OUR_DEBUG((LM_INFO, "[CMainConfig::Display]m_u4PostMsgLowMark = %d.\n", m_u4PostMsgLowMark));
	OUR_DEBUG((LM_INFO, "[CMainConfig::Display]m_u4PostMsgThreadCount = %d.\n", m_u4PostMsgThreadCount));
	OUR_DEBUG((LM_INFO, "[CMainConfig::Display]m_u4PostMsgMaxQueue = %d.\n", m_u4PostMsgMaxQueue));
	OUR_DEBUG((LM_INFO, "[CMainConfig::Display]m_u2PostThreadTimuOut = %d.\n", m_u2PostThreadTimuOut));
	OUR_DEBUG((LM_INFO, "[CMainConfig::Display]m_u2PostThreadTimeCheck = %d.\n", m_u2PostThreadTimeCheck));
	OUR_DEBUG((LM_INFO, "[CMainConfig::Display]m_u2PacketTimeOut = %d.\n", m_u2PacketTimeOut));
	OUR_DEBUG((LM_INFO, "[CMainConfig::Display]m_u2SendAliveTime = %d.\n", m_u2SendAliveTime));

	for(int i = 0; i < (int)m_vecUDPServerInfo.size(); i++)
	{
		OUR_DEBUG((LM_INFO, "[CMainConfig::Display]ServerIP%d = %s.\n", i, m_vecUDPServerInfo[i].m_szServerIP));
		OUR_DEBUG((LM_INFO, "[CMainConfig::Display]ServerPort%d = %d.\n", i, m_vecUDPServerInfo[i].m_nPort));
	}

	OUR_DEBUG((LM_INFO, "[CMainConfig::Display]m_u4UDPMsgHighMark = %d.\n", m_u4UDPMsgHighMark));
	OUR_DEBUG((LM_INFO, "[CMainConfig::Display]m_u4UDPMsgLowMark = %d.\n", m_u4UDPMsgLowMark));
	OUR_DEBUG((LM_INFO, "[CMainConfig::Display]m_u4UDPMsgThreadCount = %d.\n", m_u4UDPMsgThreadCount));
	OUR_DEBUG((LM_INFO, "[CMainConfig::Display]m_u4UDPMsgMaxQueue = %d.\n", m_u4UDPMsgMaxQueue));
	OUR_DEBUG((LM_INFO, "[CMainConfig::Display]m_nUDPEncryptFlag = %d.\n", m_nUDPEncryptFlag));
	OUR_DEBUG((LM_INFO, "[CMainConfig::Display]m_szUDPEncryptPass = %s.\n", m_szUDPEncryptPass));
	OUR_DEBUG((LM_INFO, "[CMainConfig::Display]m_u2UDPThreadTimuOut = %d.\n", m_u2UDPThreadTimuOut));
	OUR_DEBUG((LM_INFO, "[CMainConfig::Display]m_u2UDPThreadTimeCheck = %d.\n", m_u2UDPThreadTimeCheck));
}

const char* CMainConfig::GetServerName()
{
	return m_szServerName;
}

uint16 CMainConfig::GetServerID()
{
	return (uint16)m_nServerID;
}

uint16 CMainConfig::GetServerPortCount()
{
	return (uint16)m_vecServerInfo.size();
}

_ServerInfo* CMainConfig::GetServerPort(int nIndex)
{
	if(nIndex > (uint16)m_vecServerInfo.size())
	{
		return NULL;
	}

	return &m_vecServerInfo[nIndex];
}

uint32 CMainConfig::GetMgsHighMark()
{
	return m_u4MsgHighMark;
}

uint32 CMainConfig::GetMsgLowMark()
{
	return m_u4MsgLowMark;
}

uint32 CMainConfig::GetThreadCount()
{
	return m_u4MsgThreadCount;
}

uint32 CMainConfig::GetMsgMaxQueue()
{
	return m_u4MsgMaxQueue;
}

const char* CMainConfig::GetModulePath()
{
	return m_szModulePath;
}

const char* CMainConfig::GetModuleString()
{
	return m_szResourceName;
}

int CMainConfig::GetEncryptFlag()
{
	return m_nEncryptFlag;
}

const char* CMainConfig::GetEncryptPass() 
{
	return m_szEncryptPass;
}

int CMainConfig::GetEncryptOutFlag()
{
	return m_nEncryptOutFlag;
}

uint32 CMainConfig::GetPostMgsHighMark()
{
	return m_u4PostMsgHighMark;
}

uint32 CMainConfig::GetPostMsgLowMark()
{
	return m_u4PostMsgLowMark;
}

uint32 CMainConfig::GetPostThreadCount()
{
	return m_u4PostMsgThreadCount;
}

uint32 CMainConfig::GetPostMsgMaxQueue()
{
	return m_u4PostMsgMaxQueue;
}

uint32 CMainConfig::GetUDPMgsHighMark()
{
	return m_u4UDPMsgHighMark;
}

uint32 CMainConfig::GetUDPMsgLowMark()
{
	return m_u4UDPMsgLowMark;
}

uint32 CMainConfig::GetUDPThreadCount()
{
	return m_u4UDPMsgThreadCount;
}

uint32 CMainConfig::GetUDPMsgMaxQueue()
{
	return m_u4UDPMsgMaxQueue;
}

uint32 CMainConfig::GetReactorCount()
{
	return m_u4ReactorCount;
}

int CMainConfig::GetUDPEncryptFlag()
{
	return m_nUDPEncryptFlag;
}

const char* CMainConfig::GetUDPEncryptPass()
{
	return m_szUDPEncryptPass;
}

uint16 CMainConfig::GetUDPServerPortCount()
{
	return (uint16)m_vecUDPServerInfo.size();
}

_ServerInfo* CMainConfig::GetUDPServerPort(int nIndex)
{
	if(nIndex > (uint16)m_vecUDPServerInfo.size())
	{
		return NULL;
	}

	return &m_vecUDPServerInfo[nIndex];
}

uint32 CMainConfig::GetSendThresHold()
{
	return m_u4SendThresHold;
}

uint32 CMainConfig::GetSendCheckTime()
{
	return m_u4SendCheckTime;
}

uint32 CMainConfig::GetRecvBuffSize()
{
	return m_u4RecvBuffSize;
}

uint16 CMainConfig::GetSendQueueMax()
{
	return m_u2SendQueueMax;
}

uint16 CMainConfig::GetThreadTimuOut()
{
	return m_u2ThreadTimuOut;
}

uint16 CMainConfig::GetThreadTimeCheck()
{
	return m_u2ThreadTimeCheck;
}

uint16 CMainConfig::GetPostThreadTimuOut()
{
	return m_u2PostThreadTimuOut;
}

uint16 CMainConfig::GetPostThreadTimeCheck()
{
	return m_u2PostThreadTimeCheck;
}

uint16 CMainConfig::GetUDPThreadTimuOut()
{
	return m_u2UDPThreadTimuOut;
}

uint16 CMainConfig::GetUDPThreadTimeCheck()
{
	return m_u2UDPThreadTimeCheck;
}

uint16 CMainConfig::GetPacketTimeOut()
{
	return m_u2PacketTimeOut;
}

uint16 CMainConfig::GetSendAliveTime()
{
	return m_u2SendAliveTime;
};

