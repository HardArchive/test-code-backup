#ifndef _UDPMESSAGEMANAGER_H
#define _UDPMESSAGEMANAGER_H

#include "IObject/IUDPMessageManager.h"
#include "IObject/IMessage.h"
#include <map>

using namespace std;

class CUDPMessageManager : public IUDPMessageManager
{
public:
	CUDPMessageManager(void);
	~CUDPMessageManager(void);

	bool DoMessage(IMessage* pMessage, uint32& u4Len, uint16& u2CommandID);
	void Close();

	bool AddClientCommand(uint16 u2CommandID, CClientCommand* pClientCommand);
	bool DelClientCommand(uint16 u2CommandID);

private:
	CClientCommand* GetClientCommand(uint16 u2CommandID);

private:
	typedef map<uint16, CClientCommand*> mapClientCommand;
	mapClientCommand m_mapClientCommand;
};

typedef ACE_Singleton<CUDPMessageManager, ACE_Null_Mutex> App_UDPMessageManager; 
#endif
