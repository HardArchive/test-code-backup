#ifndef _SERVERCONNECTMANAGER_H
#define _SERVERCONNECTMANAGER_H

#include "ServerConnectPool.h"
#include "AppConfig.h"
#include <map>

using namespace std;

class CServerConnectManager : public ACE_Event_Handler
{
public:
	CServerConnectManager(void);
	~CServerConnectManager(void);

	bool Init();
	void Close();
	void ClosePool();
	void Display();
	bool Start(ACE_Reactor* pReactor);
	bool SetSendMessage(uint32 u4ServerID, IBuffPacket* pBuffPacket, uint32 u4MsgID);   //��ĳһ��ָ�����м������������������
	int  GetServerCount();

private:
	bool ReadConfig(); 
	bool AddServerConnectInfo(_ServerConnectInfo* pServerConnectInfo);           //��Ӧ�����ļ���ӳ���
	bool AddServerConnectPool(uint32 u4ServerID);                                //��Ӧ�����ļ��Ľṹ��
	CServerConnectPool* GetCServerConnectPool(uint32 u4ServerID);
	
private:
	typedef map<uint32, _ServerConnectInfo*> mapServerConnectInfo;
	typedef map<uint32, CServerConnectPool*> mapServerConnectPool;
	char                 m_szConfigName[MAX_BUFF_200];
	CAppConfig           m_AppConfig;
	mapServerConnectInfo m_mapServerConnectInfo;
	mapServerConnectPool m_mapServerConnectPool;
	int                  m_nServerCount;
};

typedef ACE_Singleton<CServerConnectManager, ACE_Null_Mutex> App_ServerConnectManager;
#endif
