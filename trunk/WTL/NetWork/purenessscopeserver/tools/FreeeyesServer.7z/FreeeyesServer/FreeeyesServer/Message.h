#ifndef _MESSAGE_H
#define _MESSAGE_H

#include "BuffPacket.h"
#include "IObject/IMessage.h"

class CMessage : public IMessage
{
public:
	CMessage(void);
	~CMessage(void);

	void Close();

	void SetMessageBase(_MessageBase* pMessageBase);
	bool SetRecvPacket(IBuffPacket* pRecvPacket);
	bool SetSendPacket(IBuffPacket* pSendPacket);
	bool SetMessageInfo(const char* szClientIP, int nClientPort);

	_MessageBase* GetMessageBase();
	IBuffPacket*  GetRecvPacket();
	IBuffPacket*  GetSendPacket();

	char* GetClientIP();
	int   GetClientPort();

	const char* GetError();

private:
	IBuffPacket*  m_pRecvPacket;
	IBuffPacket*  m_pSendPacket;
	char          m_szError[MAX_BUFF_500];
	_MessageBase* m_pMessageBase;

	char          m_szClientIP[MAX_BUFF_20];
	int           m_nClientPort;
};

#endif
