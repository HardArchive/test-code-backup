// MessageService.h
// ������Ϣ������Ϣ���ɸ�������߼�������ȥִ��
// ���쵽�˹���ͼ��ݣ��о��¹���ĺ����ɣ�������д���������˼��
// add by freeeyes
// 2009-01-29

#include "MessageManager.h"

CMessageManager::CMessageManager(void)
{
}

CMessageManager::~CMessageManager(void)
{
	Close();
}

bool CMessageManager::DoMessage(IMessage* pMessage, uint32& u4Len, uint16& u2CommandID)
{
	if(NULL == pMessage)
	{
		OUR_DEBUG((LM_ERROR, "[CMessageManager::DoMessage] pMessage is NULL.\n"));
		return false;
	}

	//�Ÿ���Ҫ�̳е�ClientCommand��ȥ����
	bool bDeleteFlag = true;         //���ݰ��Ƿ������ɾ��
	//OUR_DEBUG((LM_ERROR, "[CMessageManager::DoMessage]u2Len = %d u2CommandID = %d pMessage = 0x%08x.\n",u4Len, u2CommandID, (int)pMessage));

	CClientCommand* pClientCommand = GetClientCommand(u2CommandID);
	if(pClientCommand != NULL)
	{
		pClientCommand->DoMessage(pMessage, bDeleteFlag);
	}

	if(true == bDeleteFlag)
	{
		if(NULL != pMessage)
		{
			delete pMessage;
			pMessage = NULL;
		}
	}

	return true;
}

CClientCommand* CMessageManager::GetClientCommand(uint16 u2CommandID)
{
	mapClientCommand::iterator f = m_mapClientCommand.find(u2CommandID);
	if(f != m_mapClientCommand.end())
	{
		CClientCommand* pClientCommand = (CClientCommand* )f->second;
		return pClientCommand;
	}

	//OUR_DEBUG((LM_ERROR, "[CMessageManager::GetClientCommand] u2CommandID = %d 0x%08x Add OK.\n", u2CommandID, &m_mapClientCommand));
	return NULL;
}

bool CMessageManager::AddClientCommand(uint16 u2CommandID, CClientCommand* pClientCommand)
{
	if(NULL == pClientCommand)
	{
		OUR_DEBUG((LM_ERROR, "[CMessageManager::AddClientCommand] u2CommandID = %d pClientCommand is NULL.\n", u2CommandID));
		return false;
	}

	mapClientCommand::iterator f = m_mapClientCommand.find(u2CommandID);
	if(f != m_mapClientCommand.end())
	{
		OUR_DEBUG((LM_ERROR, "[CMessageManager::AddClientCommand] u2CommandID = %d is exist.\n", u2CommandID));
		return false;
	}

	m_mapClientCommand.insert(mapClientCommand::value_type(u2CommandID, pClientCommand));
	OUR_DEBUG((LM_ERROR, "[CMessageManager::AddClientCommand] u2CommandID = %d Add OK***.\n", u2CommandID));
	return true;
}

bool CMessageManager::DelClientCommand(uint16 u2CommandID)
{
	mapClientCommand::iterator f = m_mapClientCommand.find(u2CommandID);
	if(f != m_mapClientCommand.end())
	{
		m_mapClientCommand.erase(f);
		OUR_DEBUG((LM_ERROR, "[CMessageManager::DelClientCommand] u2CommandID = %d Del OK.\n", u2CommandID));
		return true;
	}
	else
	{
		OUR_DEBUG((LM_ERROR, "[CMessageManager::DelClientCommand] u2CommandID = %d is not exist.\n", u2CommandID));
		return false;
	}
}

void CMessageManager::Close()
{
	mapClientCommand::iterator b = m_mapClientCommand.begin();
	mapClientCommand::iterator e = m_mapClientCommand.end();

	for(b; b != e; b++)
	{
		 CClientCommand* pClientCommand = (CClientCommand* )b->second;
		 if(NULL != pClientCommand)
		 {
			 delete pClientCommand;
			 pClientCommand = NULL;
		 }
	}

	m_mapClientCommand.clear();
}

