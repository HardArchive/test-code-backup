#include "ServerConnect.h"
#include "PostServerService.h"

Mutex_Allocator _connectServer_mb_allocator; 
CServerConnect::CServerConnect(void)
{
	m_pNotifier          = new ACE_Reactor_Notification_Strategy(0, this, ACE_Event_Handler::WRITE_MASK);
	m_pServerConnectInfo = NULL;
	m_pReactor           = NULL;
	m_pAddrRemote        = NULL;
	m_pSynOption         = NULL;
	m_tvConnectTime      = ACE_Time_Value(ACE_Time_Value::zero);
	m_tvUpdateTime       = ACE_Time_Value(ACE_Time_Value::zero);
	m_blConnect          = false; 
	m_szError[0]         = '\0';
	m_u1ConnectState     = CONNECT_INIT;

	m_u4AllRecvCount  = 0;
	m_u4AllSendCount  = 0;
	m_u4AllRecvSize   = 0;
	m_u4AllSendSize   = 0;
}

CServerConnect::~CServerConnect(void)
{
	m_dqMessageID.clear();
}

bool CServerConnect::Init(ACE_Reactor* pReactor, _ServerConnectInfo* pServerConnectInfo)
{
	if(NULL == pReactor)
	{
		OUR_DEBUG((LM_ERROR, "[CServerConnect::Init] pReactor is NULL.\n"));
		return false;
	}

	if(NULL == pServerConnectInfo)
	{
		OUR_DEBUG((LM_ERROR, "[CServerConnect::Init] pServerConnectInfo is NULL.\n"));
		return false;
	}

	m_pServerConnectInfo = pServerConnectInfo;
	m_pReactor           = pReactor;


	m_pAddrRemote = new ACE_INET_Addr();
	if(NULL == m_pAddrRemote)
	{
		OUR_DEBUG((LM_ERROR, "[CServerConnect::Init] m_pAddrRemote is NULL.\n"));
		return false;
	}

	ACE_Time_Value tv = ACE_Time_Value(m_pServerConnectInfo->m_u4TimeOut);
	m_pSynOption = new ACE_Synch_Options(ACE_Synch_Options::USE_TIMEOUT, tv);
	if(NULL == m_pSynOption)
	{
		OUR_DEBUG((LM_ERROR, "[CServerConnect::Init] m_pSynOption is NULL.\n"));
		return false;
	}

	int nErr = m_pAddrRemote->set(pServerConnectInfo->m_u4ServerPort, pServerConnectInfo->m_strServerIP.c_str());
	if(nErr != 0)
	{
		OUR_DEBUG((LM_ERROR, "[CServerConnect::Init](%s:%d)set_address error[%d].\n", pServerConnectInfo->m_strServerIP.c_str(), pServerConnectInfo->m_u4ServerPort, errno));
		return false;
	}

	return true;
}

bool CServerConnect::GetConnectState()
{
	return m_blConnect;
}

_ServerConnectInfo* CServerConnect::GetServerConnectInfo()
{
	return m_pServerConnectInfo;
}

void CServerConnect::SetConnectTime()
{
	m_tvConnectTime = ACE_OS::gettimeofday();
}

void CServerConnect::SetUpdateTime()
{
	m_tvUpdateTime  = ACE_OS::gettimeofday();
}

ACE_INET_Addr* CServerConnect::GetRemoteAddr()
{
	return m_pAddrRemote;
}

ACE_Synch_Options* CServerConnect::GetOption()
{
	return m_pSynOption;
}

void CServerConnect::Close()
{
	this->peer().close();
	m_blConnect = false;
}

int CServerConnect::open(void*)
{
	if(NULL == m_pReactor)
	{
		OUR_DEBUG((LM_ERROR, "[CServerConnect::open] pReactor is NULL.\n"));
		return -1;
	}

	if(m_pReactor->register_handler(this,ACE_Event_Handler::READ_MASK) == -1)
	{
		OUR_DEBUG((LM_ERROR, "[CServerConnect::open] m_pReactor->register_handler error.\n"));
		return -1;
	}

	if(NULL == m_pNotifier)
	{
		OUR_DEBUG((LM_ERROR, "[CServerConnect::open] m_pNotifier is NULL.\n"));
		return -1;
	}

	m_pNotifier->reactor(m_pReactor);
	msg_queue()->notification_strategy(m_pNotifier);
	m_blConnect = true;

	if(NULL != m_pAddrRemote)
	{
		AppLogManager::instance()->WriteLog(LOG_SYSTEM_CONNECT, "Connection from [%s:%d].",m_pAddrRemote->get_host_addr(), m_pAddrRemote->get_port_number());
	}
	
	m_u1ConnectState = CONNECT_OPEN;

	return 0;
}

int CServerConnect::handle_input(ACE_HANDLE fd)
{
	ACE_Time_Value nowait(ACE_Time_Value::zero);
	m_atvInput = ACE_OS::gettimeofday();

	m_u1ConnectState = CONNECT_RECVGEGIN;

	if(fd == ACE_INVALID_HANDLE)
	{
		OUR_DEBUG((LM_ERROR, "[CServerConnect::handle_input]fd == ACE_INVALID_HANDLE .\n"));
		sprintf_safe(m_szError, MAX_BUFF_500, "[CServerConnect::handle_input]fd == ACE_INVALID_HANDLE .");
		return -1;
	}

	OUR_DEBUG((LM_ERROR, "[CServerConnect::handle_input]m_RecvPacket.GetPacketSize() = %d m_RecvPacket.GetWriteLen() = %d.\n", m_RecvPacket.GetPacketSize(), m_RecvPacket.GetWriteLen()));
	int nDataLen = this->peer().recv(m_RecvPacket.WritePtr(), m_RecvPacket.GetPacketSize() - m_RecvPacket.GetWriteLen(), MSG_NOSIGNAL, &nowait);
	if(nDataLen <= 0)
	{
		OUR_DEBUG((LM_ERROR, "[CServerConnect::handle_input] ConnectID = %d, recv data is error nDataLen = [%d] errno = [%d].\n", GetConnectID(), nDataLen, errno));
		sprintf_safe(m_szError, MAX_BUFF_500, "[CServerConnect::handle_input] ConnectID = %d, recv data is error[%d].\n", GetConnectID(), nDataLen);
		return -1;
	}
	OUR_DEBUG((LM_ERROR, "[CServerConnect::handle_input] ConnectID = %d, nDataLen =%d.\n", GetConnectID(), nDataLen));
	m_RecvPacket.WritePtr(nDataLen);

	bool blState = true;
	while(true == blState)
	{
		blState = CheckMessage();
	}

	m_u1ConnectState = CONNECT_RECVGEND;

	return 0;
}

int CServerConnect::handle_output(ACE_HANDLE fd)
{
	ACE_Time_Value     nowait(ACE_Time_Value::zero);
	ACE_Time_Value     tvsend(0, MAX_MSG_PUTTIMEOUT);
	ACE_Message_Block* mb         = NULL;
	CBuffPacket*       sendpacket = NULL;

	m_u1ConnectState = CONNECT_SENDBEGIN;

	while(-1 != getq(mb, &nowait))
	{
		if(NULL == mb)
		{
			return 0;
		}

		sendpacket = *((CBuffPacket**)mb->base());

		if(sendpacket == NULL)
		{
			mb->release();
			m_u1ConnectState = CONNECT_SENDEND;
			return 0;
		}

		if(get_handle() == ACE_INVALID_HANDLE)
		{
			OUR_DEBUG((LM_ERROR, "[CServerConnect::handle_output] ConnectID = %d, get_handle() == ACE_INVALID_HANDLE.\n", GetConnectID()));
			sprintf_safe(m_szError, MAX_BUFF_500, "[CServerConnect::handle_output] ConnectID = %d, get_handle() == ACE_INVALID_HANDLE.\n", GetConnectID());
			delete sendpacket;
			sendpacket = NULL;
			m_u1ConnectState = CONNECT_SENDEND;
			mb->release();
			return -1;
		}

		//��������
		char* pData = sendpacket->ReadPtr();
		if(NULL == pData)
		{
			OUR_DEBUG((LM_ERROR, "[CServerConnect::handle_output] ConnectID = %d, pData is NULL.\n", GetConnectID()));
			delete sendpacket;
			sendpacket = NULL;
			mb->release();
			m_u1ConnectState = CONNECT_SENDEND;
			return -1;
		}


		int nCurrSendSize = (int)(sendpacket->GetPacketLen() - sendpacket->GetReadLen());
		if(nCurrSendSize <= 0)
		{
			OUR_DEBUG((LM_ERROR, "[CConnectHandler::handle_output] ConnectID = %d, nCurrSendSize error is %d.\n", GetConnectID(), nCurrSendSize));
			delete sendpacket;
			sendpacket = NULL;
			mb->release();
			m_u1ConnectState = CONNECT_SENDEND;
			return 0;
		}

		int nDataLen = this->peer().send(pData, nCurrSendSize, &nowait);
		int nErr = ACE_OS::last_error();
		if(nDataLen <= 0)
		{
			if(nErr == EWOULDBLOCK)
			{
				ungetq(mb);
				OUR_DEBUG((LM_ERROR, "[CServerConnect::handle_output] ConnectID = %d, senderror = %d.\n", GetConnectID(), nErr));
				sprintf_safe(m_szError, MAX_BUFF_500, "[CServerConnect::handle_output] ConnectID = %d, senderror = %d.\n", GetConnectID(), nErr);
				m_u1ConnectState = CONNECT_SENDEND;
				return 0;
			}
			delete sendpacket;
			sendpacket = NULL;
			mb->release();
			return -1;
		}
		else if(nDataLen >= nCurrSendSize)
		{
			OUR_DEBUG((LM_ERROR, "[CServerConnect::handle_output] ConnectID = %d, send OK.\n", GetConnectID()));
			delete sendpacket;
			sendpacket = NULL;
			mb->release();
			m_u1ConnectState = CONNECT_SENDEND;
			return 0;
		}
		else
		{
			sendpacket->ReadPtr(nDataLen);
			ungetq(mb);
			OUR_DEBUG((LM_ERROR, "[CServerConnect::handle_output] ConnectID = %d, sendlen = %d.\n", GetConnectID(), nDataLen));
			m_u1ConnectState = CONNECT_SENDEND;
			return 0;
		}
	}

	m_u1ConnectState = CONNECT_SENDEND;
	return 0;
}

int CServerConnect::handle_close(ACE_HANDLE h, ACE_Reactor_Mask mask)
{
	m_u1ConnectState = CONNECT_CLOSEBEGIN;
	if (mask == ACE_Event_Handler::WRITE_MASK)
	{
		return 0;
	}

	if(NULL == m_pServerConnectInfo)
	{
		OUR_DEBUG ((LM_DEBUG,"[CServerConnect::handle_close]m_pServerConnectInfo is NULL ...\n"));
		return 0;
	}

	OUR_DEBUG ((LM_DEBUG,"[CServerConnect::handle_close]Connectid=[%d] begin...\n", m_pServerConnectInfo->m_u4ServerID));

	if(closing_ != 0)   //�Ѿ��ر�
	{
		return 0;
	}
	else
	{
		closing_ = 1;
	}

	msg_queue()->deactivate();
	shutdown();
	m_RecvPacket.RollBack(m_RecvPacket.GetPacketLen());

	OUR_DEBUG((LM_DEBUG,"[CServerConnect::handle_close] Connectid=[%d] finish ok...\n", m_pServerConnectInfo->m_u4ServerID));

	if(NULL != m_pAddrRemote)
	{
		AppLogManager::instance()->WriteLog(LOG_SYSTEM_POSTCONNECT, "Close Connection from [%s:%d] RecvSize = %d, RecvCount = %d, SendSize = %d, SendCount = %d.",m_pAddrRemote->get_host_addr(), m_pAddrRemote->get_port_number(), m_u4AllRecvSize, m_u4AllRecvCount, m_u4AllSendSize, m_u4AllSendCount);
	}

	m_u1ConnectState = CONNECT_CLOSEEND;

	return 0;
}

bool CServerConnect::CheckMessage()
{
	int nPacketLen = m_RecvPacket.GetPacketLen();
	if(nPacketLen > 2)
	{
		//�����ݽ��룬���õ�����
		uint32 u4Packetlen = 0;

		u4Packetlen = m_RecvPacket.GetHeadLen();

		if(u4Packetlen > m_RecvPacket.GetWriteLen())
		{
			//�������ݿ�û�д��꣬��Ҫ����������ݡ�
			OUR_DEBUG((LM_ERROR, "[CServerConnect::CheckMessage] ConnectID = %d, u2Packetlen[%d] > m_RecvPacket.GetWriteLen()[%d].\n", GetConnectID(), u4Packetlen, m_RecvPacket.GetWriteLen()));
			//m_RecvPacket.RollBack(m_RecvPacket.GetWriteLen());
			return false;
		}

		m_RecvPacket >> u4Packetlen;

		//�������и��������һ������Buff
		CBuffPacket* pBuffPacket = new CBuffPacket();
		if(NULL == pBuffPacket)
		{
			//�������հ�����
			OUR_DEBUG((LM_ERROR, "[CServerConnect::CheckMessage] ConnectID = %d, u2Packetlen[%d]�� m_RecvPacket.GetWriteLen()[%d] pBuffPacket is NULL.\n", GetConnectID(), u4Packetlen, m_RecvPacket.GetWriteLen()));
			m_RecvPacket.RollBack(m_RecvPacket.GetWriteLen());
			return false;
		}

		if(false == pBuffPacket->WriteStream(m_RecvPacket.GetData(), u4Packetlen + sizeof(uint32)))  //����Ҫ���ϰ����ܳ���4���ֽ�
		{
			//д����հ�����
			OUR_DEBUG((LM_ERROR, "[CServerConnect::CheckMessage] ConnectID = %d, u2Packetlen[%d]�� m_RecvPacket.GetWriteLen()[%d] ppBuffPacket->WriteStream error.\n", GetConnectID(), u4Packetlen, m_RecvPacket.GetWriteLen()));
			m_RecvPacket.RollBack(m_RecvPacket.GetWriteLen());
			return false;
		}

		m_RecvPacket.RollBack(u4Packetlen + sizeof(uint32));

		if(NULL != pBuffPacket)
		{
			//��Ҫ��������Ϣ������Ϣ�����߳�
			if(false == App_PostServerService::instance()->PutPostRecvMessage(GetMessageID(), pBuffPacket))
			{
				OUR_DEBUG((LM_ERROR, "[CServerConnect::CheckMessage] App_MessageService::instance()->PutMessage Error.\n"));
				delete pBuffPacket;
				return false;
			}
			m_u4AllRecvCount++;
		}

		return true;
	}
	else
	{
		return false;
	}
}

bool CServerConnect::SendMessage(IBuffPacket* pBuffPacket, uint32 u4MsgID)
{
	if(NULL == pBuffPacket)
	{
		OUR_DEBUG((LM_DEBUG,"[CServerConnect::SendMessage] Connectid=[%d] pBuffPacket is NULL.\n", GetConnectID()));	
		return false;
	}

	CBuffPacket* pReturnBuffPacket = new CBuffPacket();	
	if(NULL == pBuffPacket)
	{
		OUR_DEBUG((LM_DEBUG,"[CServerConnect::SendMessage] Connectid=[%d] pReturnBuffPacket is NULL.\n", GetConnectID()));	
		return false;
	}

	//������
	uint16 u2PacketLen = pBuffPacket->GetPacketLen();
	(*pReturnBuffPacket) << u2PacketLen;
	pReturnBuffPacket->WriteStream(pBuffPacket->ReadPtr(), u2PacketLen);

	if(pReturnBuffPacket->GetPacketLen() <= 0 || false == PutSendPacket(pReturnBuffPacket))
	{	
		delete pReturnBuffPacket;
		pReturnBuffPacket = NULL;
		return false;
	}
	else
	{
		SetMessageID(u4MsgID);   //��¼��ǰ��MsgID�����ص�ʱ�����ID��������PostServerService
		return true;
	}
}

bool CServerConnect::PutSendPacket(IBuffPacket* pBuffPacket)
{
	ACE_Message_Block* mb = NULL;
	ACE_NEW_MALLOC_NORETURN (mb,
		ACE_static_cast
		(ACE_Message_Block*, _connectServer_mb_allocator.malloc(sizeof(ACE_Message_Block))),
		ACE_Message_Block
		(sizeof(CBuffPacket *), // size
		ACE_Message_Block::MB_DATA, // type
		0,
		0,
		&_connectServer_mb_allocator, // allocator_strategy
		0, // locking strategy
		ACE_DEFAULT_MESSAGE_BLOCK_PRIORITY, // priority
		ACE_Time_Value::zero,
		ACE_Time_Value::max_time,
		&_connectServer_mb_allocator,
		&_connectServer_mb_allocator)
		);

	if(NULL != mb)
	{
		IBuffPacket** loadin = (IBuffPacket **)mb->base();
		*loadin = pBuffPacket;

		//�жϷ��Ͷ����е������Ƿ��������
		int nSendMessageCount = (int)msg_queue()->message_count();
		if(MAX_MSG_SENDPACKET < nSendMessageCount)
		{
			OUR_DEBUG ((LM_ERROR,"[CServerConnect::PutSendPacket] Connectid=%d Send queue is more than MAX_MSG_SENDPACKET!\n", GetConnectID()));
			mb->release();
			return false;
		}

		//���뷢�Ͷ���
		ACE_Time_Value tvSend;
		int nOutputOff = msg_queue()->is_empty();
		tvSend = ACE_OS::gettimeofday() + ACE_Time_Value(0, MAX_MSG_PUTTIMEOUT);
		int nRet = this->putq(mb, &tvSend); 
		if(nRet == -1)
		{
			OUR_DEBUG ((LM_ERROR,"[CServerConnect::PutSendPacket] Connectid=%d Send putq is error!\n", GetConnectID()));
			mb->release();
			return false;
		}

		OUR_DEBUG ((LM_ERROR,"[CServerConnect::PutSendPacket] Connectid=%d Count = %d nRet = %d!\n", GetConnectID(), nSendMessageCount, nRet));

		if(nOutputOff == 1)
		{
			this->reactor()->register_handler(this, ACE_Event_Handler::WRITE_MASK);
		}

		return true;
	}

	return true;
}

uint32 CServerConnect::GetConnectID()
{
	if(NULL == m_pServerConnectInfo)
	{
		return 0;
	}
	else
	{
		return m_pServerConnectInfo->m_u4ServerID;
	}	
}

void CServerConnect::SetMessageID(uint32 u4MsgID)
{
	m_dqMessageID.push_back(u4MsgID);
}

uint32 CServerConnect::GetMessageID()
{
	if((int)m_dqMessageID.size() > 0)
	{
		uint32 u4MsgID = (uint32)m_dqMessageID[0];
		m_dqMessageID.pop_front();
		return u4MsgID;
	}
	else
	{
		return 0;
	}
}
