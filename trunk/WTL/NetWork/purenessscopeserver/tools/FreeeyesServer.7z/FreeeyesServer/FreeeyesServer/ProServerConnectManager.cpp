#include "ProServerConnectManager.h"

CProServerConnectManager::CProServerConnectManager(void)
{
	m_nServerCount    = 0;
	m_szConfigName[0] = '\0';
}

CProServerConnectManager::~CProServerConnectManager(void)
{
	Close();
	ClosePool();
}

int CProServerConnectManager::GetServerCount()
{
	return m_nServerCount;
}


bool CProServerConnectManager::Init()
{
	//��ȡ�����ļ�
	if(false == ReadConfig())
	{
		return false;
	}

	Display();
	OUR_DEBUG((LM_INFO, "[CProServerConnectManager::Init] OK.\n"));
	return true;
}

bool CProServerConnectManager::Start(ACE_Proactor* pProactor)
{
	mapServerConnectInfo::iterator b = m_mapServerConnectInfo.begin();
	mapServerConnectInfo::iterator e = m_mapServerConnectInfo.end();

	for(b; b!= e; b++)
	{
		_ServerConnectInfo* pServerConnectInfo = (_ServerConnectInfo* )b->second;
		if(NULL != pServerConnectInfo)
		{
			CProServerConnectPool* pServerConnectPool = GetProServerConnectPool(pServerConnectInfo->m_u4ServerID);
			if(false == pServerConnectPool->Init(pProactor, pServerConnectInfo))
			{
				return false;
			}
			else
			{
				OUR_DEBUG((LM_INFO, "[CProServerConnectManager::Start](%d) pServerConnectPool->Init(MAX conn = %d) OK.\n", pServerConnectInfo->m_u4ServerID, pServerConnectInfo->m_u4MaxConn));
			}
		}
	}

	return true;
}

void CProServerConnectManager::Display()
{
	mapServerConnectInfo::iterator b = m_mapServerConnectInfo.begin();
	mapServerConnectInfo::iterator e = m_mapServerConnectInfo.end();

	for(b; b != e; b++)
	{
		_ServerConnectInfo* pServerConnectInfo = (_ServerConnectInfo* )b->second;
		if(NULL != pServerConnectInfo)
		{
			OUR_DEBUG((LM_INFO, "[CProServerConnectManager::Display](%d) pServerConnectInfo->m_u4ServerID = %d.\n", pServerConnectInfo->m_u4ServerID, pServerConnectInfo->m_u4ServerID));
			OUR_DEBUG((LM_INFO, "[CProServerConnectManager::Display](%d) pServerConnectInfo->m_strServerName = %s.\n", pServerConnectInfo->m_u4ServerID, pServerConnectInfo->m_strServerName.c_str()));
			OUR_DEBUG((LM_INFO, "[CProServerConnectManager::Display](%d) pServerConnectInfo->m_strServerIP = %s.\n", pServerConnectInfo->m_u4ServerID, pServerConnectInfo->m_strServerIP.c_str()));
			OUR_DEBUG((LM_INFO, "[CProServerConnectManager::Display](%d) pServerConnectInfo->m_u4ServerPort = %d.\n", pServerConnectInfo->m_u4ServerID, pServerConnectInfo->m_u4ServerPort));
			OUR_DEBUG((LM_INFO, "[CProServerConnectManager::Display](%d) pServerConnectInfo->m_u4MaxConn = %d.\n", pServerConnectInfo->m_u4ServerID, pServerConnectInfo->m_u4MaxConn));
			OUR_DEBUG((LM_INFO, "[CProServerConnectManager::Display](%d) pServerConnectInfo->m_u4TimeOut = %d.\n", pServerConnectInfo->m_u4ServerID, pServerConnectInfo->m_u4TimeOut));
		}
	}
}

void CProServerConnectManager::Close()
{
	mapServerConnectInfo::iterator b = m_mapServerConnectInfo.begin();
	mapServerConnectInfo::iterator e = m_mapServerConnectInfo.end();

	for(b; b != e; b++)
	{
		_ServerConnectInfo* pServerConnectInfo = (_ServerConnectInfo* )b->second;
		if(NULL != pServerConnectInfo)
		{
			delete pServerConnectInfo;
			pServerConnectInfo = NULL;
		}
	}

	m_mapServerConnectInfo.clear();
}

void CProServerConnectManager::ClosePool()
{
	mapServerConnectPool::iterator b = m_mapServerConnectPool.begin();
	mapServerConnectPool::iterator e = m_mapServerConnectPool.end();

	for(b; b != e; b++)
	{
		CProServerConnectPool* pServerConnectPool = (CProServerConnectPool* )b->second;
		if(NULL != pServerConnectPool)
		{
			delete pServerConnectPool;
			pServerConnectPool = NULL;
		}
	}

	m_mapServerConnectPool.clear();
}

bool CProServerConnectManager::AddServerConnectInfo(_ServerConnectInfo* pServerConnectInfo)
{
	if(NULL == pServerConnectInfo)
	{
		OUR_DEBUG((LM_ERROR, "[CProServerConnectManager::AddServerConnectInfo] pServerConnectInfo is NULL.\n"));
		return false;
	}

	mapServerConnectInfo::iterator f = m_mapServerConnectInfo.find(pServerConnectInfo->m_u4ServerID);
	if(f != m_mapServerConnectInfo.end())
	{
		OUR_DEBUG((LM_ERROR, "[CProServerConnectManager::AddServerConnectInfo] pServerConnectInfo[%d] is exist.\n", pServerConnectInfo->m_u4ServerID));
		return false;
	}

	m_mapServerConnectInfo.insert(mapServerConnectInfo::value_type(pServerConnectInfo->m_u4ServerID, pServerConnectInfo));
	return true;
}

bool CProServerConnectManager::AddServerConnectPool(uint32 u4ServerID)
{
	CProServerConnectPool* pServerConnectPool = new CProServerConnectPool();
	if(NULL == pServerConnectPool)
	{
		OUR_DEBUG((LM_ERROR, "[CProServerConnectManager::AddServerConnectPool] pServerConnectInfo is NULL.\n"));
		return false;
	}

	mapServerConnectPool::iterator f = m_mapServerConnectPool.find(u4ServerID);
	if(f != m_mapServerConnectPool.end())
	{
		OUR_DEBUG((LM_ERROR, "[CProServerConnectManager::AddServerConnectPool] pServerConnectInfo[%d] is exist.\n", u4ServerID));
		return false;
	}

	m_mapServerConnectPool.insert(mapServerConnectPool::value_type(u4ServerID, pServerConnectPool));
	return true;
}

CProServerConnectPool* CProServerConnectManager::GetProServerConnectPool(uint32 u4ServerID)
{
	mapServerConnectPool::iterator f = m_mapServerConnectPool.find(u4ServerID);
	if(f != m_mapServerConnectPool.end())
	{
		return (CProServerConnectPool* )f->second;
	}
	else
	{
		return NULL;
	}
}

bool CProServerConnectManager::ReadConfig()
{
	Close();

	sprintf_safe(m_szConfigName, MAX_BUFF_200, "%s", SERVER_CONNECT_FILE);
	OUR_DEBUG((LM_ERROR, "[CProServerConnectManager::ReadConfig] Filename = %s.\n", m_szConfigName));

	if(!m_AppConfig.ReadConfig(m_szConfigName))
	{
		OUR_DEBUG((LM_ERROR, "[CProServerConnectManager::ReadConfig] Read filename = %s is error.\n", m_szConfigName));
		return false;
	}

	ACE_TString strValue;

	m_AppConfig.GetValue("ServerCount", strValue, "\\SERVERCOUNT");
	m_nServerCount = ACE_OS::atoi((char*)strValue.c_str());

	char szConfigName[MAX_BUFF_200] = {'\0'};

	//��ʼ���ӵ���Ӧ��Map��
	for(int i = 0; i < m_nServerCount; i++)
	{
		sprintf_safe(m_szConfigName, MAX_BUFF_200, "\\SERVER%d", i + 1);

		_ServerConnectInfo* pServerConnectInfo = new _ServerConnectInfo();

		m_AppConfig.GetValue("ServerID", strValue, m_szConfigName);
		pServerConnectInfo->m_u4ServerID = (uint32)ACE_OS::atoi((char*)strValue.c_str());

		m_AppConfig.GetValue("ServerName", strValue, m_szConfigName);
		pServerConnectInfo->m_strServerName = strValue;

		m_AppConfig.GetValue("ServerIP", strValue, m_szConfigName);
		pServerConnectInfo->m_strServerIP = strValue;

		m_AppConfig.GetValue("ServerPort", strValue, m_szConfigName);
		pServerConnectInfo->m_u4ServerPort = (uint32)ACE_OS::atoi((char*)strValue.c_str());

		m_AppConfig.GetValue("MaxConn", strValue, m_szConfigName);
		pServerConnectInfo->m_u4MaxConn = (uint32)ACE_OS::atoi((char*)strValue.c_str());

		m_AppConfig.GetValue("TimeOut", strValue, m_szConfigName);
		pServerConnectInfo->m_u4TimeOut = (uint32)ACE_OS::atoi((char*)strValue.c_str());

		if(false == AddServerConnectInfo(pServerConnectInfo))
		{
			delete pServerConnectInfo;
			return false;
		}

		if(false == AddServerConnectPool(pServerConnectInfo->m_u4ServerID))
		{
			return false;
		}
	}

	return true;
}

bool CProServerConnectManager::SetSendMessage(uint32 u4ServerID, IBuffPacket* pBuffPacket, uint32 u4MsgID)
{
	if(NULL == pBuffPacket)
	{
		OUR_DEBUG((LM_ERROR, "[CProServerConnectManager::SetSendMessage] Send packet is NULL u4ServerID = %d.\n", u4ServerID));
		return false;
	}

	CProServerConnectPool* pServerConnectPool = GetProServerConnectPool(u4ServerID);
	if(NULL == pServerConnectPool)
	{
		OUR_DEBUG((LM_ERROR, "[CProServerConnectManager::SetSendMessage] pServerConnectPool is NULL u4ServerID = %d.\n", u4ServerID));
		return false;
	}

	//�����������Ļ������һ�����ӡ�
	int nServerConnectID = pServerConnectPool->GetRandomServerConnectID();
	CProServerConnect* pServerConnect = pServerConnectPool->GetServerConnect(nServerConnectID);
	if(NULL == pServerConnect)
	{
		OUR_DEBUG((LM_ERROR, "[CProServerConnectManager::SetSendMessage] pServerConnect is NULL u4ServerID = %d.\n", u4ServerID));
		return false;
	}

	if(pServerConnect->GetConnectState() == false)
	{
		//��Ҫ���½�������
		if(false == pServerConnectPool->ConnectServer(pServerConnect))
		{
			OUR_DEBUG((LM_ERROR, "[CProServerConnectManager::SetSendMessage] pServerConnectPool ConnectServer is fail u4ServerID = %d.\n", u4ServerID));
			return false;
		}
	}

	//�������ݰ�
	if(false == pServerConnect->SendMessage(pBuffPacket, u4MsgID))
	{
		OUR_DEBUG((LM_ERROR, "[CProServerConnectManager::SetSendMessage] pServerConnect->PutSendPacket fail u4ServerID = %d.\n", u4ServerID));
		return false;
	}

	return true;
}
