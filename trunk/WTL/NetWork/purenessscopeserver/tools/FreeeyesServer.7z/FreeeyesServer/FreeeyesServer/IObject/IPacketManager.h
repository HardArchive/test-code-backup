#ifndef _IPACKETMANAGER_H
#define _IPACKETMANAGER_H

#include "IBuffPacket.h"

class IPacketManager
{
public:
	virtual ~IPacketManager() {};

	virtual IBuffPacket* CreateBuffPacket()                 = 0;
	virtual bool DeleteBuffPacket(IBuffPacket* pBuffPacket) = 0;
};

#endif
