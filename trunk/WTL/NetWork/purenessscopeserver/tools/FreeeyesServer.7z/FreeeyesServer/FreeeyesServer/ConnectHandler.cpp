#include "ConnectHandler.h"

Mutex_Allocator _connecthandle_mb_allocator; 
CConnectHandler::CConnectHandler(void)
{
	m_szError[0]      = '\0';
	m_u4ConnectID     = 0;
	m_nTimerID        = 0;
	m_u2SendCount     = 0;
	m_u4AllRecvCount  = 0;
	m_u4AllSendCount  = 0;
	m_u4AllRecvSize   = 0;
	m_u4AllSendSize   = 0;
	m_u4SendThresHold = MAX_MSG_SNEDTHRESHOLD;
	m_u4SendCheckTime = MAX_MSG_SENDCHECKTIME;
	m_u2SendQueueMax  = MAX_MSG_SENDPACKET;
	m_u1ConnectState  = CONNECT_INIT;
	m_u1SendBuffState = CONNECT_SENDNON;
	m_pTCClose        = NULL;
	m_u2SendAliveTime = MAX_MSG_SENDALIVETIME;
	m_u1IsClosing     = HANDLE_ISCLOSE_NO;

}

CConnectHandler::~CConnectHandler(void)
{
	if(NULL != m_pTCClose)
	{
		delete m_pTCClose;
		m_pTCClose = NULL;
	}
}

const char* CConnectHandler::GetError()
{
	return m_szError;
}

bool CConnectHandler::Close()
{
	//�ӷ�Ӧ��ע���¼�
	this->reactor()->remove_handler(this, ACE_Event_Handler::WRITE_MASK);
	close();
	return true;
}

void CConnectHandler::SetConnectID(uint32 u4ConnectID)
{
	m_u4ConnectID = u4ConnectID;
}

uint32 CConnectHandler::GetConnectID()
{
	return m_u4ConnectID;
}

int CConnectHandler::open(void*)
{
	int nRet = ACE_Svc_Handler<ACE_SOCK_STREAM, ACE_MT_SYNCH>::open();
	if(nRet != 0)
	{
		OUR_DEBUG((LM_ERROR, "[CConnectHandler::open]ACE_Svc_Handler<ACE_SOCK_STREAM, ACE_MT_SYNCH>::open() error [%d].\n", nRet));
		sprintf_safe(m_szError, MAX_BUFF_500, "[CConnectHandler::open]ACE_Svc_Handler<ACE_SOCK_STREAM, ACE_MT_SYNCH>::open() error [%d].", nRet);
		return -1;
	}

	//��������Ϊ������ģʽ
	if (this->peer().enable(ACE_NONBLOCK) == -1)
	{
		OUR_DEBUG((LM_ERROR, "[CConnectHandler::open]this->peer().enable  = ACE_NONBLOCK error.\n"));
		sprintf_safe(m_szError, MAX_BUFF_500, "[CConnectHandler::open]this->peer().enable  = ACE_NONBLOCK error.");
		return -1;
	}

	//���Զ�����ӵ�ַ�Ͷ˿�
	if(this->peer().get_remote_addr(m_addrRemote) == -1)
	{
		OUR_DEBUG((LM_ERROR, "[CConnectHandler::open]this->peer().get_remote_addr error.\n"));
		sprintf_safe(m_szError, MAX_BUFF_500, "[CConnectHandler::open]this->peer().get_remote_addr error.");
		return -1;
	}

	OUR_DEBUG((LM_INFO, "[CConnectHandler::open] Connection from [%s:%d]\n",m_addrRemote.get_host_addr(), m_addrRemote.get_port_number()));
	
	m_atvConnect      = ACE_OS::gettimeofday();
	m_atvInput        = ACE_OS::gettimeofday();
	m_atvOutput       = ACE_OS::gettimeofday();
	m_atvSendAlive    = ACE_OS::gettimeofday();

	m_u4AllRecvCount  = 0;
	m_u4AllSendCount  = 0;
	m_u4AllRecvSize   = 0;
	m_u4AllSendSize   = 0;

	//���û�ü�����Ϣ������
	m_Encrypt.SetKey(App_MainConfig::instance()->GetEncryptPass());

	//��������ӷ������ӿ�
	if(false == App_ConnectManager::instance()->AddConnect(this))
	{
		OUR_DEBUG((LM_ERROR, "%s.\n", App_ConnectManager::instance()->GetError()));
		sprintf_safe(m_szError, MAX_BUFF_500, "%s", App_ConnectManager::instance()->GetError());
		return -1;
	}

	//���ý��ջ���صĴ�С
	uint32 u4RecvAddBuff = App_MainConfig::instance()->GetRecvBuffSize() - MAX_BUFF_1024;
	if(u4RecvAddBuff > 0)
	{
		m_RecvPacket.AddBuff(u4RecvAddBuff);
	}

	//���ý��ջ���صĴ�С
	//int nTecvBuffSize = MAX_MSG_SOCKETBUFF;
	//ACE_OS::setsockopt(this->get_handle(), SOL_SOCKET, SO_RCVBUF, (char* )&nTecvBuffSize, sizeof(nTecvBuffSize));
	//ACE_OS::setsockopt(this->get_handle(), SOL_SOCKET, SO_SNDBUF, (char* )&nTecvBuffSize, sizeof(nTecvBuffSize));
	//int nOverTime = MAX_MSG_SENDTIMEOUT;
	//ACE_OS::setsockopt(this->get_handle(), SOL_SOCKET, SO_SNDTIMEO, (char* )&nOverTime, sizeof(nOverTime));

	m_u4SendThresHold = App_MainConfig::instance()->GetSendThresHold();
	m_u4SendCheckTime = App_MainConfig::instance()->GetSendCheckTime();
	m_u2SendQueueMax  = App_MainConfig::instance()->GetSendQueueMax();
	m_u2SendAliveTime = App_MainConfig::instance()->GetSendAliveTime();

	//�������������
	CBuffPacket* pBuffPacket = new CBuffPacket();
	if(NULL == pBuffPacket)
	{
		OUR_DEBUG((LM_ERROR, "[CConnectHandler::CConnectHandler] New AlivePacket is NULL.\n"));
		return -1;
	}

	(*pBuffPacket) << (uint16)COMMAND_RETURN_ALIVE;
	(*pBuffPacket) << (uint32)ACE_OS::gettimeofday().sec();

	//�����ǿ����������Ƿ�Ҫ���ܣ�������ķ���Ҳ�Ǻ�ϵͳ����һ�¡�
	if(App_MainConfig::instance()->GetEncryptOutFlag() == 0)
	{
		//������
		uint32 u4PacketLen = pBuffPacket->GetPacketLen();
		m_AlivePacket << u4PacketLen;
		m_AlivePacket.WriteStream(pBuffPacket->ReadPtr(), u4PacketLen);
		delete pBuffPacket;
	}
	else
	{
		//����
		uint32 u4PacketLen = pBuffPacket->GetPacketLen();
		uint32 u4SrcLen = u4PacketLen + (int)sizeof(uint32);
		uint32 u4DesLen = 0;

		if(u4SrcLen % 8 == 0)
		{
			u4DesLen = u4SrcLen;
		}
		else
		{
			u4DesLen = u4SrcLen / 8 * 8 + 8;
		}

		char* pSrcBuff = new char[u4SrcLen];
		char* pDesBuff = new char[u4DesLen];

		if(NULL == pSrcBuff || NULL == pDesBuff)
		{
			delete pBuffPacket;
			return -1;
		}

		ACE_OS::memcpy(pSrcBuff, &u4PacketLen, (int)sizeof(uint32));
		ACE_OS::memcpy(&pSrcBuff[(int)sizeof(uint32)], pBuffPacket->ReadPtr(), u4PacketLen);

		m_Encrypt.DoEncrypt(true, pSrcBuff, u4SrcLen, pDesBuff, u4DesLen);

		m_AlivePacket << u4DesLen;
		m_AlivePacket.WriteStream(pDesBuff, u4DesLen);

		delete pBuffPacket;
		delete[] pSrcBuff;
		delete[] pDesBuff;
	}

	AppLogManager::instance()->WriteLog(LOG_SYSTEM_CONNECT, "Connection from [%s:%d].",m_addrRemote.get_host_addr(), m_addrRemote.get_port_number());

	m_u1ConnectState = CONNECT_OPEN;

	return nRet;
}

//��ʱ��
int CConnectHandler::handle_timeout(const ACE_Time_Value &tv, const void *arg)
{
	_TimerCheckID* pTimerCheckID = (_TimerCheckID*)arg;
	if(NULL == pTimerCheckID)
	{
		return 0;
	}

	if(pTimerCheckID->m_u2TimerCheckID == PARM_HANDLE_CLOSE)
	{
		m_u1ConnectState = CONNECT_CLOSEEND;
		delete this;
		return 0;
	}

	return 0;
}

//��������
int CConnectHandler::handle_input(ACE_HANDLE fd)
{
	ACE_Time_Value nowait(ACE_Time_Value::zero);

	m_atvInput = ACE_OS::gettimeofday();
	m_u1ConnectState = CONNECT_RECVGEGIN;

	if(fd == ACE_INVALID_HANDLE)
	{
		OUR_DEBUG((LM_ERROR, "[CConnectHandler::handle_input]fd == ACE_INVALID_HANDLE .\n"));
		sprintf_safe(m_szError, MAX_BUFF_500, "[CConnectHandler::handle_input]fd == ACE_INVALID_HANDLE .");
		m_u1ConnectState = CONNECT_RECVERROR;
		return -1;
	}

	//OUR_DEBUG((LM_ERROR, "[CConnectHandler::handle_input]m_RecvPacket.GetPacketSize() = %d m_RecvPacket.GetWriteLen() = %d.\n", m_RecvPacket.GetPacketSize(), m_RecvPacket.GetWriteLen()));
	int nCurrRecvSize =  m_RecvPacket.GetPacketSize() - m_RecvPacket.GetWriteLen();
	int nDataLen = this->peer().recv(m_RecvPacket.WritePtr(), nCurrRecvSize, MSG_NOSIGNAL, &nowait);
	if(nDataLen <= 0)
	{
		uint32 u4Error = (uint32)errno;
		if(u4Error != 10054)
		{
			OUR_DEBUG((LM_ERROR, "[CConnectHandler::handle_input] ConnectID = %d, recv data is error nDataLen = [%d] errno = [%d].\n", GetConnectID(), nDataLen, u4Error));
			sprintf_safe(m_szError, MAX_BUFF_500, "[CConnectHandler::handle_input] ConnectID = %d, recv data is error[%d].\n", GetConnectID(), nDataLen);
			m_u1ConnectState = CONNECT_RECVERROR;
		}
		return -1;
	}
	//OUR_DEBUG((LM_ERROR, "[CConnectHandler::handle_input] ConnectID = %d, nDataLen =%d.\n", GetConnectID(), nDataLen));
	m_RecvPacket.WritePtr(nDataLen);
	m_u4AllRecvSize += nDataLen;

	bool blState = true;
	while(true == blState)
	{
		blState = CheckMessage();
	}

	m_u1ConnectState = CONNECT_RECVGEND;
	return 0;
}

//��������
int CConnectHandler::handle_output(ACE_HANDLE fd)
{
	ACE_Time_Value     nowait(ACE_Time_Value::zero);
	ACE_Time_Value     tvsend(0, MAX_MSG_PUTTIMEOUT);
	ACE_Message_Block* mb         = NULL;
	CBuffPacket*       sendpacket = NULL;
	m_u1ConnectState = CONNECT_SENDBEGIN;

	if(-1 != getq(mb, &nowait))
	{
		//OUR_DEBUG((LM_ERROR, "[CConnectHandler::handle_output] ConnectID = %d, count = %d.\n", GetConnectID(), this->msg_queue()->message_count()));
		if(NULL == mb)
		{
			OUR_DEBUG((LM_ERROR, "[CConnectHandler::handle_output] ConnectID = %d, NULL == mb.\n", GetConnectID()));
			m_u1ConnectState = CONNECT_SENDEND;
			return -1;
		}

		sendpacket = *((CBuffPacket**)mb->base());

		if(sendpacket == NULL)
		{
			OUR_DEBUG((LM_ERROR, "[CConnectHandler::handle_output] ConnectID = %d, NULL == sendpacket.\n", GetConnectID()));
			mb->release();
			m_u1ConnectState = CONNECT_SENDEND;
			return 0;
		}

		if(get_handle() == ACE_INVALID_HANDLE)
		{
			OUR_DEBUG((LM_ERROR, "[CConnectHandler::handle_output] ConnectID = %d, get_handle() == ACE_INVALID_HANDLE.\n", GetConnectID()));
			sprintf_safe(m_szError, MAX_BUFF_500, "[CConnectHandler::handle_output] ConnectID = %d, get_handle() == ACE_INVALID_HANDLE.\n", GetConnectID());
			delete sendpacket;
			sendpacket = NULL;
			mb->release();
			m_u1ConnectState = CONNECT_SENDERROR;
			return -1;
		}

		//��������
		char* pData = sendpacket->ReadPtr();
		if(NULL == pData)
		{
			OUR_DEBUG((LM_ERROR, "[CConnectHandler::handle_output] ConnectID = %d, pData is NULL.\n", GetConnectID()));
			delete sendpacket;
			sendpacket = NULL;
			mb->release();
			m_u1ConnectState = CONNECT_SENDEND;
			return 0;
		}

		int nCurrSendSize = (int)(sendpacket->GetPacketLen() - sendpacket->GetReadLen());
		if(nCurrSendSize <= 0)
		{
			OUR_DEBUG((LM_ERROR, "[CConnectHandler::handle_output] ConnectID = %d, nCurrSendSize error is %d.\n", GetConnectID(), nCurrSendSize));
			delete sendpacket;
			sendpacket = NULL;
			mb->release();
			m_u1ConnectState = CONNECT_SENDEND;
			return 0;
		}

		int nDataLen = this->peer().send(pData, nCurrSendSize, &nowait);
		int nErr = ACE_OS::last_error();
		if(nDataLen <= 0)
		{
			if(nErr == EWOULDBLOCK)
			{
				ungetq(mb);
				OUR_DEBUG((LM_ERROR, "[CConnectHandler::handle_output] ConnectID = %d, senderror = %d.\n", GetConnectID(), nErr));
				sprintf_safe(m_szError, MAX_BUFF_500, "[CConnectHandler::handle_output] ConnectID = %d, senderror = %d.\n", GetConnectID(), nErr);
				m_u1ConnectState = CONNECT_SENDEND;
				return 0;
			}

			if(nErr == 10054)
			{
				//��������Ѿ�ʧЧ����Ͽ���
				m_u1IsClosing = HANDLE_ISCLOSE_YES;
			}

			OUR_DEBUG((LM_ERROR, "[CConnectHandler::handle_output] ConnectID = %d, error = %d.\n", GetConnectID(), errno));
			delete sendpacket;
			sendpacket = NULL;
			mb->release();
			m_u1ConnectState = CONNECT_SENDERROR;
			return -1;
		}
		else if(nDataLen >= nCurrSendSize)   //�����ݰ�ȫ��������ϣ���ա�
		{
			//OUR_DEBUG((LM_ERROR, "[CConnectHandler::handle_output] ConnectID = %d, send (%d) OK.\n", GetConnectID(), msg_queue()->is_empty()));
			m_u4AllSendCount += sendpacket->GetPacketCount();
			m_u4AllSendSize  += sendpacket->GetPacketLen();
			delete sendpacket;
			sendpacket = NULL;
			mb->release();
			m_u1ConnectState = CONNECT_SENDEND;
			return (msg_queue()->is_empty() ? -1 : 0);
		}
		else
		{
			sendpacket->ReadPtr(nDataLen);
			ungetq(mb);
			m_u4AllSendSize  += nDataLen;
			//OUR_DEBUG((LM_ERROR, "[CConnectHandler::handle_output] ConnectID = %d, sendlen = %d.\n", GetConnectID(), nDataLen));
			m_u1ConnectState = CONNECT_SENDEND;
			return 0;
		}
	}
	else
	{
		m_u1ConnectState = CONNECT_SENDEND;
		return (msg_queue()->is_empty() ? -1 : 0);
	}
}

//�ر�����
int CConnectHandler::handle_close(ACE_HANDLE h, ACE_Reactor_Mask mask)
{
	if (mask == ACE_Event_Handler::WRITE_MASK)
	{
		return 0;
	}

	m_u1ConnectState = CONNECT_CLOSEBEGIN;
	OUR_DEBUG ((LM_DEBUG,"[CConnectHandler::handle_close]Connectid=[%d] begin(%d)...\n",GetConnectID(), errno));

	bool bState = App_ConnectManager::instance()->CloseConnect(GetConnectID());
	if(bState == false)
	{
		OUR_DEBUG ((LM_DEBUG,"[CConnectHandler::handle_close]Connectid=[%d] CloseConnect error[%s]. \n", GetConnectID(), App_ConnectManager::instance()->GetError()));
		return -1;
	}

	if(closing_ != 0)   //�Ѿ��ر�
	{
		return 0;
	}
	else
	{
		closing_ = 1;
	}

	msg_queue()->deactivate();
	shutdown();
	TimeClose();

	AppLogManager::instance()->WriteLog(LOG_SYSTEM_CONNECT, "Close Connection from [%s:%d] RecvSize = %d, RecvCount = %d, SendSize = %d, SendCount = %d.",m_addrRemote.get_host_addr(), m_addrRemote.get_port_number(), m_u4AllRecvSize, m_u4AllRecvCount, m_u4AllSendSize, m_u4AllSendCount);

	OUR_DEBUG((LM_DEBUG,"[CConnectHandler::handle_close] Connectid=[%d] finish ok...\n", GetConnectID()));	

	return 0;
}

uint8 CConnectHandler::GetConnectState()
{
	return m_u1ConnectState;
}

uint8 CConnectHandler::GetSendBuffState()
{
	return m_u1SendBuffState;
}

uint8 CConnectHandler::GetIsClosing()
{
	return m_u1IsClosing;
}

bool CConnectHandler::SendMessage(IBuffPacket* pBuffPacket)
{
	if(NULL == pBuffPacket)
	{
		OUR_DEBUG((LM_DEBUG,"[CConnectHandler::SendMessage] Connectid=[%d] pBuffPacket is NULL.\n", GetConnectID()));	
		return false;
	}

	CBuffPacket* pReturnBuffPacket = new CBuffPacket();	
	if(NULL == pReturnBuffPacket)
	{
		OUR_DEBUG((LM_DEBUG,"[CConnectHandler::SendMessage] Connectid=[%d] pReturnBuffPacket is NULL.\n", GetConnectID()));	
		return false;
	}

	//�������Ӽ����㷨
	if(App_MainConfig::instance()->GetEncryptOutFlag() == 0)
	{
		//������
		uint32 u4PacketLen = pBuffPacket->GetPacketLen();
		(*pReturnBuffPacket) << u4PacketLen;
		pReturnBuffPacket->WriteStream(pBuffPacket->ReadPtr(), u4PacketLen);
	}
	else
	{
		//����
		uint32 u4PacketLen = pBuffPacket->GetPacketLen();
		uint32 u4SrcLen = u4PacketLen + (int)sizeof(uint32);
		uint32 u4DesLen = 0;

		if(u4SrcLen % 8 == 0)
		{
			u4DesLen = u4SrcLen;
		}
		else
		{
			u4DesLen = u4SrcLen / 8 * 8 + 8;
		}

		char* pSrcBuff = new char[u4SrcLen];
		char* pDesBuff = new char[u4DesLen];

		if(NULL == pSrcBuff || NULL == pDesBuff)
		{
			OUR_DEBUG((LM_DEBUG,"[CConnectHandler::SendMessage] Connectid=[%d] pDesBuff or pDesBuff is NULL.\n", GetConnectID()));	
			delete pReturnBuffPacket;
			return false;
		}

		ACE_OS::memcpy(pSrcBuff, &u4PacketLen, (int)sizeof(uint32));
		ACE_OS::memcpy(&pSrcBuff[(int)sizeof(uint32)], pBuffPacket->ReadPtr(), u4PacketLen);

		m_Encrypt.DoEncrypt(true, pSrcBuff, u4SrcLen, pDesBuff, u4DesLen);

		(*pReturnBuffPacket) << u4DesLen;
		pReturnBuffPacket->WriteStream(pDesBuff, u4DesLen);

		delete[] pSrcBuff;
		delete[] pDesBuff;
	}

	if(pReturnBuffPacket->GetPacketLen() <= 0 || false == PutSendPacket(pReturnBuffPacket))
	{	
		if(NULL != pReturnBuffPacket)
		{
			delete pReturnBuffPacket;
			pReturnBuffPacket = NULL;
		}
		return false;
	}
	else
	{
		return true;
	}
}

bool CConnectHandler::PutSendPacket(IBuffPacket* pBuffPacket)
{
	//��ʼ�����������͵�Ԫ
	m_ThreadLock.Lock();
	if(NULL == pBuffPacket)
	{
		OUR_DEBUG ((LM_ERROR,"[CConnectHandler::PutSendPacket] Connectid=%d pBuffPacket is NULL!\n", GetConnectID()));
		m_ThreadLock.UnLock();
		return false;
	}

	m_SendPacket.WriteStream(pBuffPacket->GetData(), pBuffPacket->GetPacketLen());
	delete pBuffPacket;
	pBuffPacket = NULL;
	m_u2SendCount++;
	
	if(m_u2SendCount < m_u4SendThresHold)    //����ﵽ��ֵ��������
	{
		m_u1SendBuffState = CONNECT_SENDBUFF;
		m_SendPacket.SetPacketCount(m_u2SendCount);
		m_ThreadLock.UnLock();
		return true;
	}
	else
	{
		m_SendPacket.SetPacketCount(m_u2SendCount);
		CBuffPacket* pSendbulkPacket = new CBuffPacket();
		if(NULL == pSendbulkPacket)
		{
			OUR_DEBUG ((LM_ERROR,"[CConnectHandler::PutSendPacket] Connectid=%d pSendbulkPacket is NULL!\n", GetConnectID()));
			return true;
		}

		pSendbulkPacket->WriteStream(m_SendPacket.GetData(), m_SendPacket.GetPacketLen());
		pSendbulkPacket->SetPacketCount(m_SendPacket.GetPacketCount());
		m_SendPacket.SetPacketCount(0);
		m_SendPacket.RollBack(m_SendPacket.GetPacketLen());
		//OUR_DEBUG ((LM_INFO,"[CConnectHandler::PutSendPacket] Connectid=%d m_SendPacket.GetPacketCount() = %d AllCount = %d.\n", GetConnectID(), pSendbulkPacket->GetPacketCount(), m_u4AllSendCount));
		m_u2SendCount     = 0;
		m_atvOutput       = ACE_OS::gettimeofday();
		m_u1SendBuffState = CONNECT_SENDNON;
		m_ThreadLock.UnLock();

		ACE_Message_Block* mb = NULL;
		ACE_NEW_MALLOC_NORETURN (mb,
			ACE_static_cast
			(ACE_Message_Block*, _connecthandle_mb_allocator.malloc(sizeof(ACE_Message_Block))),
			ACE_Message_Block
			(sizeof(CBuffPacket *), // size
			ACE_Message_Block::MB_DATA, // type
			0,
			0,
			&_connecthandle_mb_allocator, // allocator_strategy
			0, // locking strategy
			ACE_DEFAULT_MESSAGE_BLOCK_PRIORITY, // priority
			ACE_Time_Value::zero,
			ACE_Time_Value::max_time,
			&_connecthandle_mb_allocator,
			&_connecthandle_mb_allocator)
			);

		if(NULL != mb)
		{
			IBuffPacket** loadin = (IBuffPacket **)mb->base();
			*loadin = pSendbulkPacket;

			//�жϷ��Ͷ����е������Ƿ��������
			int nSendMessageCount = (int)msg_queue()->message_count();
			if(m_u2SendQueueMax < nSendMessageCount)
			{
				OUR_DEBUG ((LM_ERROR,"[CConnectHandler::PutSendPacket] Connectid=%d Send queue is more than MAX_MSG_SENDPACKET!\n", GetConnectID()));
				delete pSendbulkPacket;
				mb->release();
				//��Ϊ���ݰ��Ѿ���ɾ�������Է���ture����Χ��ɾ�����ݰ���
				return true;
			}

			//���뷢�Ͷ���
			ACE_Time_Value tvSend;
			int nOutputOff = msg_queue()->is_empty();
			tvSend = ACE_OS::gettimeofday() + ACE_Time_Value(0, MAX_MSG_PUTTIMEOUT);
			//tvSend   = ACE_Time_Value::zero;
			int nRet = this->putq(mb, &tvSend); 
			if(nRet == -1)
			{
				OUR_DEBUG ((LM_ERROR,"[CConnectHandler::PutSendPacket] Connectid=%d Send putq is error!\n", GetConnectID()));
				delete pSendbulkPacket;
				mb->release();
				//��Ϊ���ݰ��Ѿ���ɾ�������Է���ture����Χ��ɾ�����ݰ���
				return true;
			}

			CheckConnectAlive(nRet);

			if(nOutputOff)
			{
				this->reactor()->register_handler(this, ACE_Event_Handler::WRITE_MASK);
			}

			return true;
		}
		else
		{
			OUR_DEBUG ((LM_ERROR,"[CConnectHandler::PutSendPacket] Connectid=%d mb is NULL!\n", GetConnectID()));
			return true;
		}
	}
}

bool CConnectHandler::CheckSendPacket()
{
	ACE_Time_Value tvNow(ACE_OS::gettimeofday() - m_atvOutput);
	if(tvNow.msec() < m_u4SendCheckTime)
	{
		return true;
	}

	m_ThreadLock.Lock();
	//����ﵽ���������ʱ�䣬��������������
	ACE_Time_Value tvAliveNow = ACE_OS::gettimeofday();
	ACE_Time_Value tvInterval(tvAliveNow - m_atvSendAlive);
	if(tvInterval.sec() >= m_u2SendAliveTime)
	{
		//����ﵽ�����������������������������
		m_SendPacket.WriteStream(m_AlivePacket.GetData(), m_AlivePacket.GetPacketLen());
		m_u2SendCount++;
		m_atvSendAlive = tvAliveNow;
	}

	if(m_u2SendCount == 0)
	{
		m_ThreadLock.UnLock();
		return true;
	}

	CBuffPacket* pSendbulkPacket = new CBuffPacket();

	if(NULL == pSendbulkPacket)
	{
		OUR_DEBUG ((LM_ERROR,"[CConnectHandler::CheckSendPacket] Connectid=%d pSendbulkPacket is NULL!\n", GetConnectID()));
		m_ThreadLock.UnLock();
		return true;
	}

	pSendbulkPacket->WriteStream(m_SendPacket.GetData(), m_SendPacket.GetPacketLen());
	pSendbulkPacket->SetPacketCount(m_SendPacket.GetPacketCount());
	m_SendPacket.RollBack(m_SendPacket.GetPacketLen());
	m_SendPacket.SetPacketCount(0);
	//OUR_DEBUG ((LM_INFO,"[CConnectHandler::CheckSendPacket] Connectid=%d m_SendPacket.GetPacketCount() = %d AllCount = %d.\n", GetConnectID(), pSendbulkPacket->GetPacketCount(), m_u4AllSendCount));
	m_u2SendCount     = 0;
	m_atvOutput       = ACE_OS::gettimeofday();
	m_u1SendBuffState = CONNECT_SENDNON;
	m_ThreadLock.UnLock();

	ACE_Message_Block* mb = NULL;
	ACE_NEW_MALLOC_NORETURN (mb,
		ACE_static_cast
		(ACE_Message_Block*, _connecthandle_mb_allocator.malloc(sizeof(ACE_Message_Block))),
		ACE_Message_Block
		(sizeof(CBuffPacket *), // size
		ACE_Message_Block::MB_DATA, // type
		0,
		0,
		&_connecthandle_mb_allocator, // allocator_strategy
		0, // locking strategy
		ACE_DEFAULT_MESSAGE_BLOCK_PRIORITY, // priority
		ACE_Time_Value::zero,
		ACE_Time_Value::max_time,
		&_connecthandle_mb_allocator,
		&_connecthandle_mb_allocator)
		);

	if(NULL != mb)
	{
		IBuffPacket** loadin = (IBuffPacket **)mb->base();
		*loadin = pSendbulkPacket;

		//�жϷ��Ͷ����е������Ƿ��������
		int nSendMessageCount = (int)msg_queue()->message_count();
		if(MAX_MSG_SENDPACKET < nSendMessageCount)
		{
			OUR_DEBUG ((LM_ERROR,"[CConnectHandler::CheckSendPacket] Connectid=%d Send queue is more than MAX_MSG_SENDPACKET!\n", GetConnectID()));
			mb->release();
			delete pSendbulkPacket;
			//��Ϊ���ݰ��Ѿ���ɾ�������Է���ture����Χ��ɾ�����ݰ���
			return true;
		}

		//���뷢�Ͷ���
		ACE_Time_Value tvSend;
		int nOutputOff = msg_queue()->is_empty();
		tvSend = ACE_OS::gettimeofday() + ACE_Time_Value(0, MAX_MSG_PUTTIMEOUT);
		//tvSend   = ACE_Time_Value::zero;
		int nRet = this->putq(mb, &tvSend); 
		if(nRet == -1)
		{
			OUR_DEBUG ((LM_ERROR,"[CConnectHandler::CheckSendPacket] Connectid=%d Send putq is error!\n", GetConnectID()));
			mb->release();
			delete pSendbulkPacket;
			//��Ϊ���ݰ��Ѿ���ɾ�������Է���ture����Χ��ɾ�����ݰ���
			return true;
		}

		CheckConnectAlive(nRet);

		if(nOutputOff)
		{
			this->reactor()->register_handler(this, ACE_Event_Handler::WRITE_MASK);
		}

		return true;
	}
	else
	{
		OUR_DEBUG ((LM_ERROR,"[CConnectHandler::CheckSendPacket] Connectid=%d mb is NULL!\n", GetConnectID()));
		return true;
	}
}

void CConnectHandler::TimeClose()
{
	if(NULL == m_pTCClose)
	{
		m_pTCClose = new _TimerCheckID();
		if(NULL == m_pTCClose)
		{
			OUR_DEBUG((LM_ERROR, "CConnectHandler::StartTimer() m_pTCCountCheck is NULL.\n"));
			return;
		}

		m_pTCClose->m_u2TimerCheckID = PARM_HANDLE_CLOSE;
	}

	if(m_nTimerID == 0)
	{
		m_nTimerID = App_ReactorManager::instance()->GetAce_Reactor(REACTOR_CLIENTDEFINE)->schedule_timer(this, m_pTCClose, ACE_Time_Value(CONNECT_CLOSE_TIME));
	}
}

bool CConnectHandler::CheckMessage()
{
	int nPacketLen = m_RecvPacket.GetPacketLen();
	if(nPacketLen > 2)
	{
		//�����ݽ��룬���õ�����
		uint32 u4Packetlen = 0;

		u4Packetlen = m_RecvPacket.GetHeadLen();

		if(u4Packetlen > m_RecvPacket.GetWriteLen())
		{
			//�������ݿ�û�д��꣬��Ҫ����������ݡ�
			//OUR_DEBUG((LM_ERROR, "[CConnectHandler::CheckMessage] ConnectID = %d, u2Packetlen[%d] > m_RecvPacket.GetWriteLen()[%d].\n", GetConnectID(), u4Packetlen, m_RecvPacket.GetWriteLen()));
			//m_RecvPacket.RollBack(m_RecvPacket.GetWriteLen());
			return false;
		}

		m_RecvPacket >> u4Packetlen;

		//�������и��������һ������Buff
		CBuffPacket* pBuffPacket = new CBuffPacket();
		if(NULL == pBuffPacket)
		{
			//�������հ�����
			OUR_DEBUG((LM_ERROR, "[CConnectHandler::CheckMessage] ConnectID = %d, u2Packetlen[%d]�� m_RecvPacket.GetWriteLen()[%d] pBuffPacket is NULL.\n", GetConnectID(), u4Packetlen, m_RecvPacket.GetWriteLen()));
			m_RecvPacket.RollBack(m_RecvPacket.GetWriteLen());
			return false;
		}

		//�������ӽ����㷨�ж�
		if(0 == App_MainConfig::instance()->GetEncryptFlag())
		{
			if(false == pBuffPacket->WriteStream(m_RecvPacket.GetData(), u4Packetlen + sizeof(uint32)))  //����Ҫ���ϰ����ܳ���4���ֽ�
			{
				//д����հ�����
				OUR_DEBUG((LM_ERROR, "[CConnectHandler::CheckMessage] ConnectID = %d, u2Packetlen[%d]�� m_RecvPacket.GetWriteLen()[%d] ppBuffPacket->WriteStream error.\n", GetConnectID(), u4Packetlen, m_RecvPacket.GetWriteLen()));
				m_RecvPacket.RollBack(m_RecvPacket.GetWriteLen());
				return false;
			}
		}
		else
		{
			//��������
			char* pSrc = new char[u4Packetlen + sizeof(uint32) + 1];   //��������
			pSrc[u4Packetlen + sizeof(uint32)] = '\0';
			char* pDes = new char[u4Packetlen + sizeof(uint32) + 1];   //��������
			pSrc[0] = '\0';

			int nDesLen = u4Packetlen + sizeof(uint32); 
			ACE_OS::memcpy(pSrc, m_RecvPacket.GetData() + sizeof(uint32), u4Packetlen);
			if(false == Decrypt(pSrc, u4Packetlen, pDes, nDesLen))
			{
				OUR_DEBUG((LM_ERROR, "[CConnectHandler::CheckMessage] ConnectID = %d, u2Packetlen[%d]�� m_RecvPacket.GetWriteLen()[%d]  Decrypt Error.\n", GetConnectID(), u4Packetlen, m_RecvPacket.GetWriteLen()));
				m_RecvPacket.RollBack(m_RecvPacket.GetWriteLen());
				delete[] pSrc;
				delete[] pDes;
				return false;
			}

			//��ý����ַ����ĳ���
			ACE_OS::memcpy(&nDesLen, pDes, 4);

			//(*pBuffPacket) << (uint32)nDesLen;
			if(false == pBuffPacket->WriteStream(pDes, nDesLen + sizeof(uint32)))
			{
				//д����հ�����
				OUR_DEBUG((LM_ERROR, "[CConnectHandler::CheckMessage] ConnectID = %d, u2Packetlen[%d]�� m_RecvPacket.GetWriteLen()[%d] ppBuffPacket->WriteStream error.\n", GetConnectID(), u4Packetlen, m_RecvPacket.GetWriteLen()));
				m_RecvPacket.RollBack(m_RecvPacket.GetWriteLen());
				delete[] pSrc;
				delete[] pDes;
				return false;
			}

			delete[] pSrc;
			delete[] pDes;
		}

		m_RecvPacket.RollBack(u4Packetlen + sizeof(uint32));

		//������Buff������Ϣ����
		CMessage* pMessage = SetMessage(pBuffPacket);
		if(NULL != pMessage)
		{
			//�����ӵ�IP�Ͷ˿�д����Ϣ��
			pMessage->SetMessageInfo(m_addrRemote.get_host_addr(), (int)m_addrRemote.get_port_number());
			//��Ҫ��������Ϣ������Ϣ�����߳�
			if(false == App_MessageService::instance()->PutMessage(pMessage))
			{
				OUR_DEBUG((LM_ERROR, "[CConnectHandler::CheckMessage] App_MessageService::instance()->PutMessage Error.\n"));
				delete pMessage;
				return false;
			}
			m_u4AllRecvCount++;
		}

		return true;
	}
	else
	{
		return false;
	}
}

bool CConnectHandler::Decrypt(const char* szSrc, int nSrcLen, char* szDes, int& nDecLen)
{
	bool blFlag = m_Encrypt.DoEncrypt(false, szSrc, nSrcLen, szDes, nDecLen);

	return blFlag;
}

CMessage* CConnectHandler::SetMessage(IBuffPacket* pBuffPacket)
{
	if(NULL == pBuffPacket)
	{
		OUR_DEBUG((LM_ERROR, "[CConnectHandler::SetMessage] ConnectID = %d, pBuffPacket is NULL.\n", GetConnectID()));
		return false;
	}

	//�����µ�Message����
	CMessage* pMessage = new CMessage();
	if(NULL == pMessage)
	{
		//д����հ�����
		OUR_DEBUG((LM_ERROR, "[CConnectHandler::SetMessage] ConnectID = %d, pMessage is NULL.\n", GetConnectID()));
		return NULL;
	}

	//�����µ�_MessageBase
	_MessageBase* pMessageBase = new _MessageBase();
	if(NULL == pMessageBase)
	{
		//д����հ�����
		OUR_DEBUG((LM_ERROR, "[CConnectHandler::SetMessage] ConnectID = %d, _MessageBase is NULL.\n", GetConnectID()));
		return NULL;
	}

	//��ʼ��װ����
	pMessageBase->m_u4ConnectID = GetConnectID();
	pMessageBase->m_u2Cmd       = 0;
	pMessageBase->m_u4MsgTime   = (uint32)ACE_OS::gettimeofday().sec();

	pMessage->SetMessageBase(pMessageBase);

	//�����ܵ����ݻ������CMessage����
	if(false == pMessage->SetRecvPacket(pBuffPacket))
	{
		//д����հ�����
		OUR_DEBUG((LM_ERROR, "[CConnectHandler::SetMessage] ConnectID = %d, pMessage->SetRecvPacket is fail.\n", GetConnectID()));
		delete pMessage;
		return NULL;
	}

	return pMessage;
}

bool CConnectHandler::CheckConnectAlive(uint16 u2QueuePacketCount)
{
	//�����Ǽ�������Ƿ��Ѿ��ҵ��Ĳ��ԡ�
	ACE_Time_Value tvNow(ACE_OS::gettimeofday());
	ACE_Time_Value tvInterval(tvNow - m_atvOutput);
	if(u2QueuePacketCount >= MAX_MSG_SENDALCOUNT && tvInterval.sec() >= MAX_MSG_SENDALIVETIME)
	{
		AppLogManager::instance()->WriteLog(LOG_SYSTEM_CONNECT, "Connectioned [%s:%d] is no alive.",m_addrRemote.get_host_addr(), m_addrRemote.get_port_number());
		m_u1IsClosing = HANDLE_ISCLOSE_YES;
	}

	return true;
}

//***************************************************************************
CConnectManager::CConnectManager(void)
{
	m_u4TimeCheckID      = 0;
	m_u4ConnectCurrID    = 0;
	m_szError[0]         = '\0';

	m_pTCTimeSendCheck   = NULL;
	m_tvCheckConnect     = ACE_OS::gettimeofday();
}

CConnectManager::~CConnectManager(void)
{
	CloseAll();
}

void CConnectManager::CloseAll()
{
	KillTimer();
	mapConnectManager::iterator b = m_mapConnectManager.begin();
	mapConnectManager::iterator e = m_mapConnectManager.end();

	for(b; b != e; b++)
	{
		CConnectHandler* pConnectHandler = (CConnectHandler* )b->second;
		if(pConnectHandler != NULL)
		{
			pConnectHandler->Close();
		}
	}

	m_mapConnectManager.clear();
}

bool CConnectManager::Close(uint32 u4ConnectID)
{
	mapConnectManager::iterator f = m_mapConnectManager.find(u4ConnectID);

	if(f != m_mapConnectManager.end())
	{
		CConnectHandler* pConnectHandler = (CConnectHandler* )f->second;
		if(pConnectHandler != NULL)
		{
			pConnectHandler->Close();
		}

		return true;
	}
	else
	{
		sprintf_safe(m_szError, MAX_BUFF_500, "[CConnectManager::Close] ConnectID[%d] is not find.", u4ConnectID);
		return true;
	}
}

bool CConnectManager::CloseConnect(uint32 u4ConnectID)
{
	m_ThreadLock.Lock();
	mapConnectManager::iterator f = m_mapConnectManager.find(u4ConnectID);

	if(f != m_mapConnectManager.end())
	{
		m_mapConnectManager.erase(f);
		m_ThreadLock.UnLock();
		return true;
	}
	else
	{
		sprintf_safe(m_szError, MAX_BUFF_500, "[CConnectManager::CloseConnect] ConnectID[%d] is not find.", u4ConnectID);
		m_ThreadLock.UnLock();
		return true;
	}
}

bool CConnectManager::AddConnect(CConnectHandler* pConnectHandler)
{
	if(pConnectHandler == NULL)
	{
		sprintf_safe(m_szError, MAX_BUFF_500, "[CConnectManager::AddConnect] pConnectHandler is NULL.");
		return false;		
	}
	
	mapConnectManager::iterator f = m_mapConnectManager.find(m_u4ConnectCurrID);
	if(f != m_mapConnectManager.end())
	{
		sprintf_safe(m_szError, MAX_BUFF_500, "[CConnectManager::AddConnect] ConnectID[%d] is exist.", m_u4ConnectCurrID);
		return false;
	}

	pConnectHandler->SetConnectID(m_u4ConnectCurrID);
	//����map
	m_mapConnectManager.insert(mapConnectManager::value_type(m_u4ConnectCurrID, pConnectHandler));
	m_u4ConnectCurrID++;

	return true;
}

bool CConnectManager::SendMessage(uint32 u4ConnectID, IBuffPacket* pBuffPacket)
{
	if(NULL == pBuffPacket)
	{
		sprintf_safe(m_szError, MAX_BUFF_500, "[CConnectManager::SendMessage] ConnectID[%d] pBuffPacket is NULL.", u4ConnectID);
		return false;
	}

	mapConnectManager::iterator f = m_mapConnectManager.find(u4ConnectID);

	if(f != m_mapConnectManager.end())
	{
		CConnectHandler* pConnectHandler = (CConnectHandler* )f->second;

		if(NULL != pConnectHandler)
		{
			return pConnectHandler->SendMessage(pBuffPacket);
		}
		else
		{
			sprintf_safe(m_szError, MAX_BUFF_500, "[CConnectManager::SendMessage] ConnectID[%d] is not find.", u4ConnectID);
			return true;
		}
	}
	else
	{
		sprintf_safe(m_szError, MAX_BUFF_500, "[CConnectManager::SendMessage] ConnectID[%d] is not find.", u4ConnectID);
		return true;
	}
}

const char* CConnectManager::GetError()
{
	return m_szError;
}

bool CConnectManager::StartTimer()
{
	//���ⶨʱ���ظ�����
	KillTimer();
	OUR_DEBUG((LM_ERROR, "CConnectManager::StartTimer()-->begin....\n"));
	//�õ��ڶ���Reactor
	ACE_Reactor* pReactor = App_ReactorManager::instance()->GetAce_Reactor(REACTOR_POSTDEFINE);
	if(NULL == pReactor)
	{
		OUR_DEBUG((LM_ERROR, "CConnectManager::StartTimer() -->GetAce_Reactor(REACTOR_POSTDEFINE) is NULL.\n"));
		return false;
	}

	m_pTCTimeSendCheck = new _TimerCheckID();
	if(NULL == m_pTCTimeSendCheck)
	{
		OUR_DEBUG((LM_ERROR, "CConnectManager::StartTimer() m_pTCTimeSendCheck is NULL.\n"));
		return false;
	}

	m_pTCTimeSendCheck->m_u2TimerCheckID = PARM_CONNECTHANDLE_CHECK;
	uint32 u4Temp = App_MainConfig::instance()->GetSendCheckTime();
	m_u4TimeCheckID = pReactor->schedule_timer(this, (const void *)m_pTCTimeSendCheck, ACE_Time_Value(0, u4Temp*MAX_BUFF_1000), ACE_Time_Value(0, u4Temp*MAX_BUFF_1000));
	if(-1 == m_u4TimeCheckID)
	{
		OUR_DEBUG((LM_ERROR, "CConnectManager::StartTimer()--> Start thread m_u4TimeCheckID error.\n"));
		return false;
	}
	else
	{
		OUR_DEBUG((LM_ERROR, "CConnectManager::StartTimer()--> Start thread time OK.\n"));
		return true;
	}
}

bool CConnectManager::KillTimer()
{
	if(m_u4TimeCheckID > 0)
	{
		App_ReactorManager::instance()->GetAce_Reactor(REACTOR_POSTDEFINE)->cancel_timer(m_u4TimeCheckID);
		m_u4TimeCheckID = 0;
	}

	if(NULL != m_pTCTimeSendCheck)
	{
		delete m_pTCTimeSendCheck;
		m_pTCTimeSendCheck = NULL;
	}

	return true;
}

int CConnectManager::handle_timeout(const ACE_Time_Value &tv, const void *arg)
{
	_TimerCheckID* pTimerCheckID = (_TimerCheckID*)arg;
	if(NULL == pTimerCheckID)
	{
		return 0;
	}

	vecConnectManager vecConnect;

	//��ʱ��ⷢ�ͣ����ｫ��ʱ��¼������Ϣ�������У�����һ����ʱ��
	if(pTimerCheckID->m_u2TimerCheckID == PARM_CONNECTHANDLE_CHECK)
	{
		m_ThreadLock.Lock();
		if(m_mapConnectManager.size() == 0)
		{
			m_ThreadLock.UnLock();
		}
		else
		{
			mapConnectManager::iterator b = m_mapConnectManager.begin();
			mapConnectManager::iterator e = m_mapConnectManager.end();

			for(b; b != e; b++)
			{
				CConnectHandler* pConnectHandler = (CConnectHandler* )b->second;
				if(pConnectHandler != NULL)
				{
					uint8 u1ConnectState = pConnectHandler->GetConnectState();
					if(u1ConnectState != CONNECT_CLOSEEND && u1ConnectState != CONNECT_SENDBEGIN)
					{
						if(HANDLE_ISCLOSE_YES == pConnectHandler->GetIsClosing())
						{
							vecConnect.push_back(pConnectHandler->GetConnectID());
						}
						else
						{
							pConnectHandler->CheckSendPacket();
						}
					}
				}
			}
			m_ThreadLock.UnLock();

			for(int i = 0; i < (int)vecConnect.size(); i++)
			{
				Close(vecConnect[i]);
			}
		}

		//�ж��Ƿ�Ӧ�ü�¼������־
		ACE_Time_Value tvNow = ACE_OS::gettimeofday();
		ACE_Time_Value tvInterval(tvNow - m_tvCheckConnect);
		if(tvInterval.sec() >= MAX_MSG_HANDLETIME)
		{
			AppLogManager::instance()->WriteLog(LOG_SYSTEM_CONNECT, "[CConnectManager]CurrConnectCount = %d.", GetCount());
			m_tvCheckConnect = tvNow;
		}

		return 0;

	}

	return 0;
}

int CConnectManager::GetCount()
{
	return (int)m_mapConnectManager.size(); 
}
