#ifndef _UDPCONNECTHANDLER_H
#define _UDPCONNECTHANDLER_H

#include "define.h"
#include "ace/Event_Handler.h"
#include "ace/INET_Addr.h"
#include "ace/Reactor.h"
#include "ace/SOCK_Dgram.h"
#include "MainConfig.h"
#include "BuffPacket.h"
#include "AceReactorManager.h"
#include "UDPServerService.h"
#include "Encrypt.h"
#include "IObject/IUDPConnectManager.h"

#include <map>

using namespace std;

class CUDPConnectHandler : public ACE_Event_Handler
{
public:
	CUDPConnectHandler(void);
	~CUDPConnectHandler(void);

	int open(const char* szIP, int nPort);

	virtual ACE_HANDLE get_handle(void) const;
	virtual int handle_input(ACE_HANDLE fd = ACE_INVALID_HANDLE);
	virtual int handle_close(ACE_HANDLE handle, ACE_Reactor_Mask close_mask);
	virtual int handle_signal (int signum, siginfo_t* siginfo, ucontext_t* context);

	void   SetConnectID(uint32 u4ConnectID);
	uint32 GetConnectID();

	bool SendMessage(IBuffPacket* pBuffPacket, const char* szIP, int nPort);

	const char* GetError();

	bool Close();

private:
	bool CheckMessage(ACE_INET_Addr& remoteAddr);                             //�������յ�����
	CMessage* SetMessage(IBuffPacket* pBuffPacket);                           //�����ݻ������CMessage������
	bool Decrypt(const char* szSrc, int nSrcLen, char* szDes, int& nDecLen);  //���ݰ�������Ϊ

private:
	char           m_szError[MAX_BUFF_500];
	ACE_SOCK_Dgram m_updDgram;
	ACE_INET_Addr  m_AddrLocal;
	uint32         m_u4ConnectID;

	ACE_Time_Value m_atvConnect;
	ACE_Time_Value m_atvInput;
	ACE_Time_Value m_atvOutput;

	CBuffPacket    m_RecvPacket;
	CEncrypt       m_Encrypt;
};

//���������Ѿ�����������
class CUDPConnectManager : public IUDPConnectManager
{
public:
	CUDPConnectManager(void);
	~CUDPConnectManager(void);

	void CloseAll();
	bool CloseConnect(uint32 u4ConnectID);
	bool AddConnect(CUDPConnectHandler* pConnectHandler);
	bool SendMessage(uint32 u4ConnectID, IBuffPacket* pBuffPacket, const char* szIP, int nPort);

	const char* GetError();

private:
	typedef map<uint32, CUDPConnectHandler*> mapConnectManager;
	mapConnectManager m_mapConnectManager;
	char              m_szError[MAX_BUFF_500];
	uint32            m_u4ConnectCurrID;

};

typedef ACE_Singleton<CUDPConnectManager,ACE_Null_Mutex> App_UDPConnectManager; 
#endif
