// Base.cpp : ���� DLL Ӧ�ó������ڵ㡣
//

#include "BaseCommand.h"
#include "../FreeeyesServer/IObject/IObject.h"

static char *g_szDesc      = "Base";       //ģ�����������
static char *g_szName      = "Base";       //ģ�������
static char *g_szModuleKey = "Base";       //ģ���Key

#ifdef WIN32
#if defined DLL_EXPORT
	#define DECLDIR __declspec(dllexport)
#else
	#define DECLDIR __declspec(dllimport)
#endif
#else
  #define DECLDIR
#endif

extern "C"
{
	DECLDIR int LoadModuleData(CServerObject* pServerObject);
	DECLDIR int UnLoadModuleData();
	DECLDIR const char* GetDesc();
	DECLDIR const char* GetName();
	DECLDIR const char* GetModuleKey();
}

static CBaseCommand g_BaseCommand;
CServerObject*      g_pServerObject = NULL;

int LoadModuleData(CServerObject* pServerObject)
{
	g_pServerObject = pServerObject;
	OUR_DEBUG((LM_INFO, "[Base LoadModuleData] Begin.\n"));
	if(g_pServerObject != NULL)
	{
		ILogManager* pLogManager = g_pServerObject->GetLogManager();
		if(NULL != pLogManager)
		{
			g_BaseCommand.SetLogManager(pLogManager);
		}
		else
		{
			OUR_DEBUG((LM_INFO, "[Base LoadModuleData] pLogManager = NULL.\n"));
		}

		IConnectManager* pConnectManager = g_pServerObject->GetConnectManager();
		if(NULL != pConnectManager)
		{
			g_BaseCommand.SetConnectManager(pConnectManager);
		}
		else
		{
			OUR_DEBUG((LM_INFO, "[Base LoadModuleData] pConnectManager = NULL.\n"));
		}	

		IPacketManager* pPacketManager = g_pServerObject->GetPacketManager();
		if(NULL != pPacketManager)
		{
			g_BaseCommand.SetBuffPacketmanager(pPacketManager);
		}
		else
		{
			OUR_DEBUG((LM_INFO, "[Base LoadModuleData] pPacketManager = NULL.\n"));
		}			

		IPostManager* pPostManager = g_pServerObject->GetPostManager();
		if(NULL != pPostManager)
		{
			g_BaseCommand.SetPostManager(pPostManager);
		}
		else
		{
			OUR_DEBUG((LM_INFO, "[Base LoadModuleData] pPostManager = NULL.\n"));
		}			

		IMessageManager* pMessageManager = g_pServerObject->GetMessageManager();
		if(NULL != pMessageManager)
		{
			pMessageManager->AddClientCommand(COMMAND_BASE, &g_BaseCommand);
		}
		else
		{
			OUR_DEBUG((LM_INFO, "[Base LoadModuleData] pMessageManager = NULL.\n"));
		}				

	}
	OUR_DEBUG((LM_INFO, "[Base LoadModuleData] End.\n"));

	return 0;
}

int UnLoadModuleData()
{
	OUR_DEBUG((LM_INFO, "[Base UnLoadModuleData] Begin.\n"));
	if(g_pServerObject != NULL)
	{
		IMessageManager* pMessageManager = g_pServerObject->GetMessageManager();
		if(NULL != pMessageManager)
		{
			pMessageManager->DelClientCommand(COMMAND_BASE);
			pMessageManager = NULL;
		}
	}
	OUR_DEBUG((LM_INFO, "[Base UnLoadModuleData] End.\n"));
	return 0;
}

const char* GetDesc()
{
	return g_szDesc;
}

const char* GetName()
{
	return g_szName;
}

const char* GetModuleKey()
{
	return g_szModuleKey;
}

