#pragma once

#include "../FreeeyesServer/BuffPacket.h"
#include "../FreeeyesServer/ClientCommand.h"
#include "../FreeeyesServer/IObject/ILogManager.h"
#include "../FreeeyesServer/IObject/IConnectManager.h"
#include "../FreeeyesServer/IObject/IPacketManager.h"
#include "../FreeeyesServer/IObject/IPostManager.h"

#include <string>

using namespace std;

//����һ���м������������
class CPostTest : public IPostMessage
{
public:
	CPostTest();
	~CPostTest();

	void CallBefore();
    void CallBack();
};

class CBaseCommand : public CClientCommand
{
public:
	CBaseCommand(void);
	~CBaseCommand(void);

	int DoMessage(IMessage* pMessage, bool& bDeleteFlag);
	void SetLogManager(ILogManager* pLogManager);
	void SetConnectManager(IConnectManager* pConnectManager);
	void SetBuffPacketmanager(IPacketManager* pPacketManager);
	void SetPostManager(IPostManager* pPostManager);

private:
	ILogManager*     m_pLogManager;
	IConnectManager* m_pConnectManager;
	IPacketManager*  m_pPacketManager;
	IPostManager*    m_pPostManager;
};
