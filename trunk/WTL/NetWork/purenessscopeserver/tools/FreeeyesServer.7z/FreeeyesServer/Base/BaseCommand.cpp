#include "BaseCommand.h"

CBaseCommand::CBaseCommand(void)
{
	m_pLogManager     = NULL;
	m_pConnectManager = NULL;
	m_pPacketManager  = NULL;
}

CBaseCommand::~CBaseCommand(void)
{
}

void CBaseCommand::SetLogManager(ILogManager* pLogManager)
{
	m_pLogManager = pLogManager;
}

void CBaseCommand::SetConnectManager(IConnectManager* pConnectManager)
{
	m_pConnectManager = pConnectManager;
}

void CBaseCommand::SetBuffPacketmanager(IPacketManager* pPacketManager)
{
	m_pPacketManager = pPacketManager;
}

void CBaseCommand::SetPostManager(IPostManager* pPostManager)
{
	m_pPostManager = pPostManager;
}

int CBaseCommand::DoMessage(IMessage* pMessage, bool& bDeleteFlag)
{
	if(pMessage == NULL)
	{
		OUR_DEBUG((LM_ERROR, "[CBaseCommand::DoMessage] pMessage is NULL.\n"));
		return -1;
	}

	uint16     u2CommandID = 0;
	VCHARS_STR strsName;
	string     strName;
	(*pMessage->GetRecvPacket()) >> u2CommandID;
	(*pMessage->GetRecvPacket()) >> strsName;
	strName.assign(strsName.text, strsName.u1Len);

	
	if(NULL != m_pLogManager)
	{
		m_pLogManager->WriteLog(LOG_SYSTEM,  "[CBaseCommand::DoMessage] Get CommandID = %d", u2CommandID);
	}
	else
	{
		OUR_DEBUG((LM_INFO, "[CBaseCommand::DoMessage] m_pLogManager = NULL"));
	}

	//if(NULL == m_pPacketManager)
	//{
	//	OUR_DEBUG((LM_ERROR, "[CBaseCommand::DoMessage] m_pPacketManager is NULL.\n"));
	//	return -1;
	//}

	//�������м��������������


	IBuffPacket* pResponsesPacket = m_pPacketManager->CreateBuffPacket();

	VCHARS_STR strsPass;
	uint16 u2PostCommandID = 0xe102;
	string strUserName     = "aaaac";
	string strUserPass     = "aaa";

	strsName.text = strUserName.c_str();
	strsName.u1Len = (uint8)strUserName.length();

	strsPass.text = strUserPass.c_str();
	strsPass.u1Len = (uint8)strUserPass.length();

	(*pResponsesPacket) << u2PostCommandID;
	(*pResponsesPacket) << strsName;
	(*pResponsesPacket) << strsPass;

	if(NULL != m_pConnectManager)
	{
		m_pConnectManager->SendMessage(pMessage->GetMessageBase()->m_u4ConnectID, pResponsesPacket);
	}
	else
	{
		OUR_DEBUG((LM_INFO, "[CBaseCommand::DoMessage] m_pConnectManager = NULL"));
	}

	m_pPacketManager->DeleteBuffPacket(pResponsesPacket);

	//ACE_Time_Value tvStop(0, 1000);
	//ACE_OS::sleep(tvStop);

	//m_pConnectManager->Close(pMessage->GetMessageBase()->m_u4ConnectID);

	//CPostTest* pPostTest = new CPostTest();
	//if(NULL == pPostTest)
	//{
	//	OUR_DEBUG((LM_ERROR, "[CBaseCommand::DoMessage] pPostTest is NULL.\n"));
	//	return 0;
	//}

	//pPostTest->SetServerID(1);
	//pPostTest->SetSendPacket(pResponsesPacket);

	//if(NULL == m_pPostManager)
	//{
	//	OUR_DEBUG((LM_ERROR, "[CBaseCommand::DoMessage] m_pPostManager is NULL.\n"));
	//	return 0;
	//}

	//m_pPostManager->PutPostSendMessage(pPostTest);

	return 0;
}

CPostTest::CPostTest()
{

}

CPostTest::~CPostTest()
{

}

void CPostTest::CallBefore()
{
	OUR_DEBUG((LM_ERROR, "[CPostTest::CallBefore] Begin.\n"));
}

void CPostTest::CallBack()
{
	OUR_DEBUG((LM_ERROR, "[CPostTest::CallBefore] End.\n"));
}

