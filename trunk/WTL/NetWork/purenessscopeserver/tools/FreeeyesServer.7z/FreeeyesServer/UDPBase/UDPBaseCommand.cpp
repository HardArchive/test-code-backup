#include "UDPBaseCommand.h"

CUDPBaseCommand::CUDPBaseCommand(void)
{
}

CUDPBaseCommand::~CUDPBaseCommand(void)
{
}

void CUDPBaseCommand::SetLogManager(ILogManager* pLogManager)
{
	m_pLogManager = pLogManager;
}

void CUDPBaseCommand::SetConnectManager(IConnectManager* pConnectManager)
{
	m_pConnectManager = pConnectManager;
}

void CUDPBaseCommand::SetBuffPacketmanager(IPacketManager* pPacketManager)
{
	m_pPacketManager = pPacketManager;
}

int CUDPBaseCommand::DoMessage(IMessage* pMessage, bool& bDeleteFlag)
{
	if(pMessage == NULL)
	{
		OUR_DEBUG((LM_ERROR, "[CUDPBaseCommand::DoMessage] pMessage is NULL.\n"));
		return -1;
	}

	OUR_DEBUG((LM_INFO, "[CUDPBaseCommand::DoMessage] GetMessage pMessage.GetWriteLen() = %d\n", pMessage->GetRecvPacket()->GetWriteLen()));

	uint16     u2CommandID = 0;
	VCHARS_STR strsName;
	string     strName;
	(*pMessage->GetRecvPacket()) >> u2CommandID;
	(*pMessage->GetRecvPacket()) >> strsName;
	strName.assign(strsName.text, strsName.u1Len);

	OUR_DEBUG((LM_INFO, "[CUDPBaseCommand::DoMessage] CommandID = %d Name = %s\n", u2CommandID, strName.c_str()));
	if(NULL != m_pLogManager)
	{
		m_pLogManager->WriteLog(LOG_SYSTEM,  "[CUDPBaseCommand::DoMessage] Get CommandID = %d", u2CommandID);
	}

	if(NULL == m_pPacketManager)
	{
		OUR_DEBUG((LM_ERROR, "[CUDPBaseCommand::DoMessage] m_pPacketManager is NULL.\n"));
		return -1;
	}

	return 0;
}
