#ifndef _UDPBASECOMMAND_H
#define _UDPBASECOMMAND_H

#include "../FreeeyesServer/BuffPacket.h"
#include "../FreeeyesServer/ClientCommand.h"
#include "../FreeeyesServer/IObject/ILogManager.h"
#include "../FreeeyesServer/IObject/IConnectManager.h"
#include "../FreeeyesServer/IObject/IPacketManager.h"
#include "../FreeeyesServer/IObject/IPostManager.h"

#include <string>

using namespace std;

class CUDPBaseCommand : public CClientCommand
{
public:
	CUDPBaseCommand(void);
	~CUDPBaseCommand(void);

	int DoMessage(IMessage* pMessage, bool& bDeleteFlag);
	void SetLogManager(ILogManager* pLogManager);
	void SetConnectManager(IConnectManager* pConnectManager);
	void SetBuffPacketmanager(IPacketManager* pPacketManager);

private:
	ILogManager*     m_pLogManager;
	IConnectManager* m_pConnectManager;
	IPacketManager*  m_pPacketManager;
};
#endif
