// UDPBase.cpp : ���� DLL Ӧ�ó������ڵ㡣
//

#include "UDPBaseCommand.h"
#include "../FreeeyesServer/IObject/IObject.h"

static char *g_szDesc      = "UDPBase";       //ģ�����������
static char *g_szName      = "UDPBase";       //ģ�������
static char *g_szModuleKey = "UDPBase";       //ģ���Key

#ifdef WIN32
#if defined DLL_EXPORT
	#define DECLDIR __declspec(dllexport)
#else
	#define DECLDIR __declspec(dllimport)
#endif
#else
	#define DECLDIR
#endif

extern "C"
{
	DECLDIR int LoadModuleData(CServerObject* pServerObject);
	DECLDIR int UnLoadModuleData();
	DECLDIR const char* GetDesc();
	DECLDIR const char* GetName();
	DECLDIR const char* GetModuleKey();
}

static CUDPBaseCommand g_UDPBaseCommand;
CServerObject*         g_pServerObject = NULL;

int LoadModuleData(CServerObject* pServerObject)
{
	g_pServerObject = pServerObject;
	OUR_DEBUG((LM_INFO, "[Base LoadModuleData] Begin.\n"));
	if(g_pServerObject != NULL)
	{
		ILogManager* pLogManager = g_pServerObject->GetLogManager();
		if(NULL != pLogManager)
		{
			g_UDPBaseCommand.SetLogManager(pLogManager);
		}

		IConnectManager* pConnectManager = g_pServerObject->GetConnectManager();
		if(NULL != pConnectManager)
		{
			g_UDPBaseCommand.SetConnectManager(pConnectManager);
		}

		IPacketManager* pPacketManager = g_pServerObject->GetPacketManager();
		if(NULL != pPacketManager)
		{
			g_UDPBaseCommand.SetBuffPacketmanager(pPacketManager);
		}

		IUDPMessageManager* pUDPMessageManager = g_pServerObject->GetUDPMessageManager();
		if(NULL != pUDPMessageManager)
		{
			pUDPMessageManager->AddClientCommand(COMMAND_UDP_BASE, &g_UDPBaseCommand);
		}

	}
	OUR_DEBUG((LM_INFO, "[UDPBase LoadModuleData] End.\n"));

	return 0;
}

int UnLoadModuleData()
{
	OUR_DEBUG((LM_INFO, "[UDPBase UnLoadModuleData] Begin.\n"));
	if(g_pServerObject != NULL)
	{
		IUDPMessageManager* pUDPMessageManager = g_pServerObject->GetUDPMessageManager();
		if(NULL != pUDPMessageManager)
		{
			pUDPMessageManager->DelClientCommand(COMMAND_UDP_BASE);
			pUDPMessageManager = NULL;
		}
	}

	OUR_DEBUG((LM_INFO, "[UDPBase UnLoadModuleData] End.\n"));
	return 0;
}

const char* GetDesc()
{
	return g_szDesc;
}

const char* GetName()
{
	return g_szName;
}

const char* GetModuleKey()
{
	return g_szModuleKey;
}


