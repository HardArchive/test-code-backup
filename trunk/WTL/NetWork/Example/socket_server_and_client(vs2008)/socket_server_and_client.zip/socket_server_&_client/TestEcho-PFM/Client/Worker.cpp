#include "StdAfx.h"
#include "Worker.h"


CWorker::CWorker(void)
{
}


CWorker::~CWorker(void)
{
}
