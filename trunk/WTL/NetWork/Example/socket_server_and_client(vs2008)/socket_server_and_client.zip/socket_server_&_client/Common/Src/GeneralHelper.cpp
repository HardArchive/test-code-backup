#include "stdafx.h"
#include "GeneralHelper.h"
