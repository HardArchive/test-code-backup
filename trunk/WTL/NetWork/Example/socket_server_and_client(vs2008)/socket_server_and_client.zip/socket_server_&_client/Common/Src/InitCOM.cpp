/******************************************************************************
Module:  initcom.cpp
Notices: Copyright (c) 2006 Bruce Liang
Purpose: 
Desc:
******************************************************************************/
#include "stdafx.h"
#include ".\initcom.h"
