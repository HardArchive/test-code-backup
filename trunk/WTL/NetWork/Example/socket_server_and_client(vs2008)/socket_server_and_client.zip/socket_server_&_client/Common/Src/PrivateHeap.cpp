/******************************************************************************
Module:  PrivateHeap.cpp
Notices: Copyright (c) 2006 Bruce Liang
Purpose: ��������˽�ж�.
******************************************************************************/

#include "StdAfx.h"
#include "PrivateHeap.h"
