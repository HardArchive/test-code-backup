/******************************************************************************
Module:  BufferPtr.cpp
Notices: Copyright (c) 2006 Bruce Liang
Purpose: ���ڼ򻯶��ڴ��������ͷ�.
Desc:
******************************************************************************/

#include "stdafx.h"
#include "bufferptr.h"