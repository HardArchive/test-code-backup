//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by CJ60Lib.rc
//
#define IDS_HIDE                        5000
#define IDS_EXPAND                      5001
#define IDS_CONTRACT                    5002
#define IDB_BUTTON_IMAGES               5003
#define IDC_TABCTRLBAR                  5003
#define IDR_CBAR_POPUP                  5004
#define IDC_URL_CODEJOCKEY              5005
#define IDB_BTN_EXPLORER                5006
#define IDM_CBAR_MENU                   5007
#define IDC_BUTTON_HIDE                 5008
#define IDC_BUTTON_MINI                 5009
#define IDC_BAR_BUTTON                  5010
#define IDC_BAR_CAPTION                 5011
#define IDB_BTN_ARROW                   5012
#define IDC_VSPLITBAR                   5015
#define IDC_HSPLITBAR                   5016

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        5017
#define _APS_NEXT_COMMAND_VALUE         5012
#define _APS_NEXT_CONTROL_VALUE         5012
#define _APS_NEXT_SYMED_VALUE           5012
#endif
#endif
