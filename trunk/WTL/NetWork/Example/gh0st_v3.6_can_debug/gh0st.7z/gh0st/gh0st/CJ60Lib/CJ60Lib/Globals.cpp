////////////////////////////////////////////////////////////////
// Copyright 1998 Paul DiLascia
// If this code works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
//
#include "StdAfx.h"

#ifdef _DEBUG
int CTraceFn::nIndent=-1;	    // current TRACE indent level
#endif
