// accelDemo.h
