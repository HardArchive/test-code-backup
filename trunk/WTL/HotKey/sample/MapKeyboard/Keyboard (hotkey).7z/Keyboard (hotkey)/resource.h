//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by accelDemo.rc
//
#define IDD_ABOUTBOX                    100
#define IDD_ACCELEDIT_DLG               101
#define IDR_MAINFRAME                   128
#define IDC_ZABKAT                      1000
#define IDC_COMBO_CATEGORY              1100
#define IDC_LIST_COMMANDS               1101
#define IDC_LIST_KEYS                   1102
#define IDC_HOTKEY                      1103
#define IDC_BUT_ASSIGN                  1104
#define IDC_BUT_REMOVE                  1105
#define IDC_BUT_RESET                   1106
#define IDC_STATIC_DESCRIPTION          1107
#define ID_CUSTOMIZE_KEYBOARD           32772
#define IDS_MSG_KEYOVERWRITE            32773

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        201
#define _APS_NEXT_COMMAND_VALUE         32773
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           102
#endif
#endif
