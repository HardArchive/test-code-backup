// accelDemoView.cpp : implementation of the CAccelDemoView class
//
/////////////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "resource.h"

#include "accelDemoView.h"

BOOL CAccelDemoView::PreTranslateMessage(MSG* pMsg)
{
	pMsg;
	return FALSE;
}
