#pragma once
#include "afxcmn.h"


// CDialogSetIP �Ի���

class CDialogSetIP : public CDialog
{
	DECLARE_DYNAMIC(CDialogSetIP)

public:
	CDialogSetIP(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CDialogSetIP();

// �Ի�������
	enum { IDD = IDD_DIALOG_SETIP };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedButtonSetserverIp();
	virtual BOOL OnInitDialog();
protected:
//	virtual void OnOK();
//	virtual void OnCancel();
public:
	afx_msg void OnDestroy();
	CIPAddressCtrl m_IPAddress;
};
