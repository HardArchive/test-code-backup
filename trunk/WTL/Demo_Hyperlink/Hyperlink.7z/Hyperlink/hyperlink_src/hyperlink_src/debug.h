/*
 * Module ID: debug.h
 * Title    : Header file for debugging services.
 * Purpose  : Provide debugging macros
 *
 * Author   : Olivier Langlois <olanglois@sympatico.ca>
 * Date     : June, 25 1996
 *
 * Revision :
 *
 * 001        22-Nov-1997 - Olivier Langlois
 *            Add macros using assert()
 *
 * 002        12-Mar-1998 - Olivier Langlois
 *            Add <iostream.h>. It is very frequent to need iostreams
 *            when debugging.
 *
 * 003        26-Sep-1998 - Olivier Langlois
 *            Modify ASSERT() macro name for uASSERT() to avoid conflict
 *            a MFC macro having the same name.
 *
 * 004        13-Jan-2006 - Olivier Langlois
 *            Change <iostream.h> to <iostream> as <iostream.h> is not
 *            supported anymore in newer MS compilers.
 */

#ifndef _DEBUG_H_
#define _DEBUG_H_

#ifdef  DEBUG
#ifdef  __GNUG__
//#       include <std/typeinfo.h>
#endif
#       include <iostream>
#       include <assert.h>
#       define D(x)  x

		  /* Check pre- and post-conditions */
#       define uPRECONDITION(a)    assert( (a) != 0 )
#       define POSTCONDITION(a)    assert( (a) != 0 )
#       define PRECONDITION2(a,b)  assert((b, (a) !=0))
#       define POSTCONDITION2(a,b) assert((b, (a) !=0))
#       define uASSERT(a)          assert( (a) != 0 )

/*
 * DEBUGTAG can be used with an object from the ostream class in C++
 * or with the printf() function in C.
 *
 * Examples:
 * With C++  : cerr << DEBUGTAG;
 * With C    : printf( "%s:%d", DEBUGTAG );
 */
#       ifdef  __cplusplus
#       define DEBUGTAG  __FILE__ << ":" << __LINE__ << " "
#       else
#       define DEBUGTAG  __FILE__, __LINE__
#       endif

#else
#       define D(x)
#       define uPRECONDITION(a)
#       define POSTCONDITION(a)
#       define PRECONDITION2(a,b)
#       define POSTCONDITION2(a,b)
#       define uASSERT(a)
#       ifdef  __cplusplus
#       define DEBUGTAG ""
#       else

/*
 * There is no way to make DEBUGTAG disapear completely in C without
 * causing problems.
 * The ideal usage of DEBUGTAG in C is to use it only inside the D()
 * macro.
 */
#       define DEBUGTAG "", 0
#       endif
#endif

/*
 * Old 16 bits stuff...
 *
 * SEG(p)	Evaluate the address segment
 * OFF(p)   Evaluate the address offset
 * PHYS(p)	Return the physical address in an unsigned long
 *          type variable.
 */

#define SEG(p)	 ( ((unsigned *)&(p))[1] )
#define OFF(p)  ( ((unsigned *)&(p))[0] )
#define PHYS(p) (((unsigned long)OFF(p)) + ((unsigned long)SEG(p) << 4))

/* NUMELE(array)	  Evaluate the number of elements in a list
 * LASTELE(array)     Evaluate the pointer of the last element of a list
 * INBOUNDS(array,p)  Evaluate true is p is inside array
 * RANGE(a,b,c)       Evaluate true if a <= b <= c
 *
 * NBITS(type)        Return the number of bits in the variable type t
 *
 * MAXINT             Evaluate the maximum value that can reach a signed int
 *                    variable.
 */

#define NUMELE(a)     (sizeof(a)/sizeof(*(a)))
#define LASTELE(a)    ((a) + (NUMELE(a)-1))
#define TOOHIGH(a,p)  ((p) - (a) > (NUMELE(a) - 1))
#define TOOLOW(a,p)   ((p) - (a) < 0 )
#define INBOUNDS(a,p) ( ! (TOOHIGH(a,p) || TOOLOW(a,p)) )

#define _IS(t,x)  (((t)1 << (x))!=0) /* Evaluate true if the variable type */
									 /* t length is < x.                   */

#define NBITS(t)     (4 * (1 + _IS(t,4)  + _IS(t,8)  + _IS(t,12) + _IS(t,16) \
					  + _IS(t,20) + _IS(t,24) + _IS(t,28) + _IS(t,32)) )

#define MAXINT    (((unsigned)~0) >> 1)

#endif  /* _DEBUG_H_ */
