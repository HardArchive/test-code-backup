// hyperlinkdemo.cpp : Defines the class behaviors for the application.
//

#include "stdafx.h"
#include "hyperlinkdemo.h"

#include "MainFrm.h"
#include "win/hyperlink.h"
#include "win/mfcpp.h"
#include "win/windebug.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CHyperlinkdemoApp

BEGIN_MESSAGE_MAP(CHyperlinkdemoApp, CWinApp)
	//{{AFX_MSG_MAP(CHyperlinkdemoApp)
	ON_COMMAND(ID_APP_ABOUT, OnAppAbout)
	ON_COMMAND(ID_APP_ABOUT2, OnAppAbout2)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CHyperlinkdemoApp construction

CHyperlinkdemoApp::CHyperlinkdemoApp()
{
	// TODO: add construction code here,
	// Place all significant initialization in InitInstance
}

/////////////////////////////////////////////////////////////////////////////
// The one and only CHyperlinkdemoApp object

CHyperlinkdemoApp theApp;

/////////////////////////////////////////////////////////////////////////////
// CHyperlinkdemoApp initialization

BOOL CHyperlinkdemoApp::InitInstance()
{
	// Standard initialization
	// If you are not using these features and wish to reduce the size
	//  of your final executable, you should remove from the following
	//  the specific initialization routines you do not need.

#ifdef _AFXDLL
	Enable3dControls();			// Call this when using MFC in a shared DLL
#else
	Enable3dControlsStatic();	// Call this when linking to MFC statically
#endif

	// Change the registry key under which our settings are stored.
	// TODO: You should modify this string to be something appropriate
	// such as the name of your company or organization.
	SetRegistryKey(_T("Local AppWizard-Generated Applications"));


	// To create the main window, this code creates a new frame window
	// object and then sets it as the application's main window object.

	CMainFrame* pFrame = new CMainFrame;
	m_pMainWnd = pFrame;

	// create and load the frame with its resources

	pFrame->LoadFrame(IDR_MAINFRAME,
		WS_OVERLAPPEDWINDOW | FWS_ADDTOTITLE, NULL,
		NULL);




	// The one and only window has been initialized, so show and update it.
	pFrame->ShowWindow(SW_SHOW);
	pFrame->UpdateWindow();

	return TRUE;
}

/////////////////////////////////////////////////////////////////////////////
// CHyperlinkdemoApp message handlers





/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CDemoLink : public CHyperLink
{
protected:
	virtual void OnSelect(void)
	{ ((CFrameWnd *)AfxGetMainWnd())->SetMessageText(m_strURL); }
	virtual void OnDeselect(void)
	{ ((CFrameWnd *)AfxGetMainWnd())->SetMessageText(AFX_IDS_IDLEMESSAGE); }
};

class CAboutDlg : public CHyperLinkDlg
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

	virtual BOOL OnInitDialog();
};

class CAboutDlgWithStatusURL : public CAboutDlg
{
protected:
	virtual BOOL OnInitDialog();

private:
	CDemoLink   m_DemoIcon;
	CDemoLink	m_DemoMail;
	CDemoLink	m_DemoLink;
};

class CAboutDlgWithToolTipURL : public CAboutDlg
{
protected:
	virtual BOOL OnInitDialog();

private:
	CSubclassToolTipCtrl m_ctlTT;
	CHyperLink  m_DemoIcon;
	CHyperLink	m_DemoMail;
	CHyperLink	m_DemoLink;
};

CAboutDlg::CAboutDlg() : CHyperLinkDlg(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CHyperLinkDlg)
	//{{AFX_MSG_MAP(CAboutDlg)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

// App command to run the dialog
void CHyperlinkdemoApp::OnAppAbout()
{
	CAboutDlgWithStatusURL aboutDlg;
	aboutDlg.DoModal();
}

void CHyperlinkdemoApp::OnAppAbout2() 
{
	CAboutDlgWithToolTipURL aboutDlg;
	aboutDlg.DoModal();
}

/////////////////////////////////////////////////////////////////////////////
// CHyperlinkdemoApp message handlers

BOOL CAboutDlg::OnInitDialog() 
{
	CHyperLinkDlg::OnInitDialog();
	
	// TODO: Add extra initialization here
    HICON hIco = (HICON) LoadImage( AfxGetInstanceHandle(), 
                                    MAKEINTRESOURCE(IDR_MAINFRAME), 
                                    IMAGE_ICON, 0, 0, 
                                    0 );
	CStatic iconCtrl;
	iconCtrl.Attach(GetDlgItem(IDC_STATIC_ICON)->m_hWnd);
	LASTERRORDISPLAYR(::DestroyIcon(iconCtrl.SetIcon(hIco)));
	iconCtrl.Detach();
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

BOOL CAboutDlgWithStatusURL::OnInitDialog() 
{
	CAboutDlg::OnInitDialog();
	
	// TODO: Add extra initialization here
	setURL(m_DemoIcon,IDC_MYICON);
	setURL(m_DemoLink,IDC_HOMEPAGE);
	setURL(m_DemoMail,IDC_EMAIL);
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

BOOL CAboutDlgWithToolTipURL::OnInitDialog() 
{
	CAboutDlg::OnInitDialog();
	
	// TODO: Add extra initialization here
	m_ctlTT.Create(this);
	setURL(m_DemoIcon,IDC_MYICON);
	setURL(m_DemoLink,IDC_HOMEPAGE);
	setURL(m_DemoMail,IDC_EMAIL);

	/*
	 * It is OK to add a Window tool to the tool tip control with
	 * the CHyperLink dynamically allocated URL string because
	 * the windows are destroyed with WM_DESTROY before the CHyperLink
	 * destructor call where the URL string is freed.
	 */
	m_ctlTT.AddWindowTool(GetDlgItem(IDC_MYICON)->GetSafeHwnd(),
		                  (LPTSTR)m_DemoIcon.getURL());
	m_ctlTT.AddWindowTool(GetDlgItem(IDC_HOMEPAGE)->GetSafeHwnd(),
		                  (LPTSTR)m_DemoLink.getURL());
	m_ctlTT.AddWindowTool(GetDlgItem(IDC_EMAIL)->GetSafeHwnd(),
		                  (LPTSTR)m_DemoMail.getURL());
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}
