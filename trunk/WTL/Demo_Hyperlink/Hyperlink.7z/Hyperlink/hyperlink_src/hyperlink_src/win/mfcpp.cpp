/*
 * Module ID: mfcpp.cpp
 * Title    : MFC++: Extend MFC classes.
 *
 * Author   : Olivier Langlois <olanglois@sympatico.ca>
 * Date     : December 12, 2005
 */

#include "win/mfcpp.h"
#include "win/hyperlink.h"

/////////////////////////////////////////////////////////////////////////////
// CSubclassToolTipCtrl operations

/*
 * Function CSubclassToolTipCtrl::AddWindowTool
 */
BOOL CSubclassToolTipCtrl::AddWindowTool( HWND hWin, LPTSTR pszText )
{
	TOOLINFO ti;
	FillInToolInfo(ti,hWin,0);
	ti.uFlags  |= TTF_SUBCLASS;
	ti.hinst    = AfxGetInstanceHandle();
    ti.lpszText = pszText;

	return (BOOL)SendMessage(TTM_ADDTOOL,0,(LPARAM)&ti);
}

/*
 * Function CSubclassToolTipCtrl::AddRectTool
 */
BOOL CSubclassToolTipCtrl::AddRectTool( HWND hWin, LPTSTR pszText,
									    LPCRECT lpRect, UINT nIDTool )
{
	TOOLINFO ti;
	FillInToolInfo(ti,hWin,nIDTool);
	ti.uFlags  |= TTF_SUBCLASS;
	ti.hinst    = AfxGetInstanceHandle();
    ti.lpszText = pszText;
	::CopyRect(&ti.rect,lpRect);

	return (BOOL)SendMessage(TTM_ADDTOOL,0,(LPARAM)&ti);
}

// Implementation

/*
 * Function CSubclassToolTipCtrl::FillInToolInfo
 */
void CSubclassToolTipCtrl::FillInToolInfo(TOOLINFO& ti, HWND hWnd, UINT nIDTool) const
{
	::ZeroMemory(&ti, sizeof(TOOLINFO));
	ti.cbSize   = sizeof(TOOLINFO);
	if (nIDTool == 0)
	{
		ti.hwnd = ::GetParent(hWnd);
		ti.uFlags = TTF_IDISHWND;
		ti.uId = (UINT)hWnd;
	}
	else
	{
		ti.hwnd = hWnd;
		ti.uFlags = 0;
		ti.uId = nIDTool;
	}
}

/////////////////////////////////////////////////////////////////////////////
// CHyperLinkDlg operations

/*
 * Function CHyperLinkDlg::setURL
 */
void CHyperLinkDlg::setURL(CHyperLink &ctr, int id)
{
	TCHAR buffer[URLMAXLENGTH];
	int nLen = ::LoadString(AfxGetResourceHandle(), id, buffer, URLMAXLENGTH);
	if( !nLen )
	{
		lstrcpy( buffer, __TEXT(""));
	}
    ctr.ConvertStaticToHyperlink(GetSafeHwnd(),id,buffer);
}
