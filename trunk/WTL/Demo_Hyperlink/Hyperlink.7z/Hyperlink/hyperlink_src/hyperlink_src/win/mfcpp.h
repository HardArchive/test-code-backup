/*
 * Module ID: mfcpp.h
 * Title    : MFC++: Extend MFC classes.
 *
 * Author   : Olivier Langlois <olanglois@sympatico.ca>
 * Date     : December 12, 2005
 */

#ifndef   _MFCPP_H_
#define   _MFCPP_H_

#include <afxext.h>         // MFC extensions
#include <afxcmn.h>			// MFC support for Windows Common Controls

/*
 * Defines
 */
#define URLMAXLENGTH 256

/*
 * Forward declaration
 */
class CHyperLink;

class CStrechyStatusBar : public CStatusBar
{
protected:
	void MakeStrechy(void)
	{
		UINT nID, nStyle;
		int  cxWidth;
		/*
		 * Set the first strechy indicator width to its minimum to
		 * make sure that the right side indicators do not disapear when
		 * the status bar width is reduced.
		 */
		GetPaneInfo(0, nID, nStyle, cxWidth);
		SetPaneInfo(0, nID, nStyle, 1);
	}
};

class CSubclassToolTipCtrl : public CToolTipCtrl
{
// Operations
public:
/******************************************************************************
 *
 * Name      : AddWindowTool
 *
 * Purpose   : Add a window tool by using the Tooltip subclass feature
 *
 * Parameters:
 *     hWin    (HWND)    Tool window
 *     pszText (LPTSTR)  Tip text (can also be a string resource ID).
 *
 * Return value : Returns TRUE if successful, or FALSE otherwise.
 *
 ****************************************************************************/
	BOOL AddWindowTool( HWND hWin, LPTSTR pszText );

/******************************************************************************
 *
 * Name      : AddRectTool
 *
 * Purpose   : Add a rect tool by using the Tooltip subclass feature
 *
 * Parameters:
 *     hWin    (HWND)    Tool window parent
 *     pszText (LPTSTR)  Tip text (can also be a string resource ID).
 *     lpRect  (LPCRECT) Tool rect
 *     nIDTool (UINT)    User defined Tool ID
 *
 * Return value : Returns TRUE if successful, or FALSE otherwise.
 *
 ****************************************************************************/
	BOOL AddRectTool( HWND hWin, LPTSTR pszText, LPCRECT lpRect, UINT nIDTool );

// Implementation
	void FillInToolInfo(TOOLINFO& ti, HWND hWnd, UINT nIDTool) const;
};

class CHyperLinkDlg : public CDialog
{
public:
	CHyperLinkDlg(UINT nIDTemplate) : CDialog(nIDTemplate) {}
protected:
/******************************************************************************
 *
 * Name      : setURL
 *
 * Purpose   : Convert the static control id and load URL string from
 *             resource associated with id.
 *
 * Parameters:
 *     ctr     (CHyperLink &) Reference to the hyperlink object to setup.
 *     id      (int)          Static control ID and URL String ID.
 *
 * Return value : None.
 *
 ****************************************************************************/
	void setURL(CHyperLink &ctr, int id);
};

#endif /* _MFCPP_H_ */
