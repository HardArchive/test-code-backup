// -----------------------------------------------------------------------------------------------------
// Header file for the CMFCHyperlinkDlg class, derived from CDialogEx.
// -----------------------------------------------------------------------------------------------------
// Dennis Dykstra, 08 Oct 2010
// -----------------------------------------------------------------------------------------------------

#pragma once

#include "Hyperlink.h"
#include "afxwin.h"

// CMFCHyperlinkDlg dialog
class CMFCHyperlinkDlg : public CDialogEx
	{
// Construction
public:
	CMFCHyperlinkDlg(CWnd* pParent = NULL);	// standard constructor

	~CMFCHyperlinkDlg(void);				// destructor

// Dialog Data
	enum { IDD = IDD_MFCHYPERLINK_DIALOG };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support

// Implementation
private:
	CFont  m_Font;				// Font to be used for the hyperlink.
	int    m_nPoints;			// Point size of the font.
	CRect  m_rectDlgWnd;		// Coordinates of the dialog window when it is first shown.
	CRect  m_rectDlgClient;		// Coordinates of the dialog window client when it is first shown.
	CRect  m_rectGroup;			// Coordinates of the group box.
	CRect  m_rectCloseBtn;		// Coordinates of the "close" button.
	BOOL   m_bDlgShown;			// TRUE after the dialog window has been opened.
	BOOL   m_bFirstCtlColor;	// TRUE until OnCtlColor has been called once.
	BOOL   m_bPointsSelected;	// TRUE if a font size in points has just been selected.

protected:
	HICON m_hIcon;

	// Generated message map functions
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()

public:
	// Member variables
	CHyperlink		 m_ctlLINK;					// Hyperlink member variable (was originally a CMFCLinkCtrl object).
	CMFCFontComboBox m_ctlComboFonts;			// Font combobox member variable.
	CComboBox		 m_ctlComboPoints;			// ComboBox to select the font size in points.
	CComboBox		 m_ctlComboHyperlinkStyle;	// ComboBox to select the hyperlink style.
	CComboBox		 m_ctlComboAlignment;		// ComboBox to select the alignment property.
	CMFCColorButton  m_ctlColorNormal;			// Normal  hyperlink color.
	CMFCColorButton  m_ctlColorHover;			// Hover   hyperlink color.
	CMFCColorButton  m_ctlColorVisited;			// Visited hyperlink color.
	CButton			 m_ctlUnderline;			// Checkbox member variable for the underline option.
	CButton			 m_ctlCheckBoxBold;			// Checkbox member variable for the bold font option.
	CButton			 m_ctlCheckBoxItalics;		// Checkbox member variable for the italics font option.

protected:
	// Event handlers
	afx_msg void	 OnSelChangeComboFont();
	afx_msg void	 OnSetFocusComboPoints();
	afx_msg void	 OnSelChangeComboPoints();
	afx_msg void	 OnSelChangeComboHyperlinkStyle();
	afx_msg void	 OnSelChangeComboAlignment();
	afx_msg void	 OnClickedCheckBold();
	afx_msg void	 OnClickedCheckItalics();
	afx_msg void	 OnColorBtnNormal();
	afx_msg void	 OnColorBtnHover();
	afx_msg void	 OnColorBtnVisited();
	afx_msg void	 OnClickedCheckUnderlineHoverOnly();
	afx_msg void	 OnEditChangeComboPoints();
	virtual BOOL 	 PreTranslateMessage(MSG* pMsg);
	afx_msg void	 OnKillFocusComboPoints();
	afx_msg void	 OnSize(UINT nType, int cx, int cy);
	afx_msg void	 OnGetMinMaxInfo(MINMAXINFO* lpMMI);
	afx_msg void	 OnShowWindow(BOOL bShow, UINT nStatus);
	afx_msg HBRUSH	 OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);
	afx_msg void	 OnBnClickedButtonDlgfont();
	afx_msg void	 OnBnClickedButtonDefaultfont();

	// Methods
	void ChangePointFont(void);
	int  GetPointsFromComboBox(CComboBox* pCombo);
	int	 GetCBItemIndex(CString strValue);
	void ResizeDialogIfNeeded(void);
	};
