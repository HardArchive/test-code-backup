﻿// -----------------------------------------------------------------------------------------------------
// Demo_Hyperlink.cpp : Defines the class behaviors for the application.
// -----------------------------------------------------------------------------------------------------
// Dennis Dykstra, 08 Oct 2010
// -----------------------------------------------------------------------------------------------------
// This class runs the application and is produced by the MFC framework, with some modifications as
// noted below.
// -----------------------------------------------------------------------------------------------------
// LICENSE
//      This software is licensed under the Code Project Open License (CPOL). You are free to use the
// software in any way you like, except that you may not sell the source code. The software is provided
// "as is" with no expressed or implied warranty. I accept no liability for any damage or loss of
// business that this software might cause.
//      Please note that this software code is derived from software owned and copyrighted by Microsoft®
// as part of the Microsoft Foundation Classes for Visual C++®. As such it is a derivative work that
// could be subject to more restrictive licensing policies under terms promulgated by Microsoft®.
// -----------------------------------------------------------------------------------------------------
#include "stdafx.h"
#include "Demo_Hyperlink.h"
#include "Demo_HyperlinkDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

// CMFCHyperlinkApp
BEGIN_MESSAGE_MAP(CMFCHyperlinkApp, CWinAppEx)
	ON_COMMAND(ID_HELP, &CWinAppEx::OnHelp)
END_MESSAGE_MAP()

// CMFCHyperlinkApp construction
CMFCHyperlinkApp::CMFCHyperlinkApp()
	{
	// Place any significant initialization in InitInstance
	}

// The one and only CMFCHyperlinkApp object
CMFCHyperlinkApp theApp;

// -------------------------------------------------------------------------------------------------------
// CMFCHyperlinkApp initialization
// -------------------------------------------------------------------------------------------------------
BOOL CMFCHyperlinkApp::InitInstance()
	{
	// ------------------------------------------------------------------
	// Use the visual manager associated with Windows and enable theming.
	// ------------------------------------------------------------------
	CMFCVisualManager::SetDefaultManager(RUNTIME_CLASS(CMFCVisualManagerWindows));
	CMFCButton::EnableWindowsTheming();

	// --------------------------------------------------------------------------------------------------
	// InitCommonControlsEx() is required on Windows XP if an application manifest specifies use of
	// ComCtl32.dll version 6 or later to enable visual styles. Otherwise, any window creation will fail.
	// --------------------------------------------------------------------------------------------------
	INITCOMMONCONTROLSEX InitCtrls;
	InitCtrls.dwSize = sizeof(InitCtrls);
	// Set this to include all the common control classes you want to use in your application.
	InitCtrls.dwICC = ICC_STANDARD_CLASSES;
	InitCommonControlsEx(&InitCtrls);

	CWinAppEx::InitInstance();

	// -------------------------------------------------------------------------------------------------
	// Create the shell manager in case the dialog contains shell tree view or shell list view controls.
	// Dykstra note: These aren't needed for this application.
	// -------------------------------------------------------------------------------------------------
	// CShellManager *pShellManager = new CShellManager;

	// --------------------------------------------------------------------------
	// Dykstra note: Uncomment these and replace the placeholders to set the HKCU
	// registry key under which the application settings are to be stored.
	// --------------------------------------------------------------------------
	// SetRegistryKey(_T("Company Name"));
	// WriteProfileString(_T("Key Name"), _T("Value Name"), _T("Value"));

	// -----------------------
	// Open the dialog window.
	// -----------------------
	CMFCHyperlinkDlg dlg;
	m_pMainWnd = &dlg;
	INT_PTR nResponse = dlg.DoModal();
	if (nResponse == IDOK)
		{
		// Place code here to be executed when the dialog is dismissed with OK.
		}
	else if (nResponse == IDCANCEL)
		{
		// Place code here to be executed when the dialog is dismissed with Cancel.
		}

	// ---------------------------------------------------------------------------
	// Delete the shell manager created above. (Not needed because we aren't using
	// the shell manager).
	// ---------------------------------------------------------------------------
	//if (pShellManager != NULL)
	//	{
	//	delete pShellManager;
	//	}

	delete dlg;	// Delete the dialog object.

	// ---------------------------------------------------------------------------
	// Since the dialog has been closed, return FALSE so that we exit the
	// application rather than start the application's message pump.
	// ---------------------------------------------------------------------------
	return FALSE;
	}
