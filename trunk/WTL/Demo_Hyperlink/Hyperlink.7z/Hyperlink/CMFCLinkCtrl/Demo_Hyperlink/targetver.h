﻿// -----------------------------------------------------------------------------------------------------
// Header file used for targeting particular versions of Windows and IE.
// -----------------------------------------------------------------------------------------------------
// Dennis Dykstra, 10 Oct 2010
// -----------------------------------------------------------------------------------------------------
#pragma once

#include <winsdkver.h>

// ----------------------------------------------------------------------
// Modify the following defines to target a prior platform. Refer to MSDN
// for the latest info on corresponding values for different platforms.
// ----------------------------------------------------------------------

#ifndef WINVER
#define WINVER WINVER_MAXVER
#endif

#ifndef _WIN32_WINNT
#define _WIN32_WINNT _WIN32_WINNT_MAXVER
#endif

#ifndef _WIN32_WINDOWS
#define _WIN32_WINDOWS _WIN32_WINDOWS_MAXVER
#endif

#ifndef _WIN32_IE
#define _WIN32_IE _WIN32_IE_MAXVER
#endif

#include <sdkddkver.h>
