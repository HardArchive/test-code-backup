﻿// -----------------------------------------------------------------------------------------------------
// Demo_HyperlinkDlg.cpp : implementation file
// -----------------------------------------------------------------------------------------------------
// Dennis Dykstra, 08 Oct 2010
// -----------------------------------------------------------------------------------------------------
// The purpose of this dialog class is to illustrate the use of the CHyperlink class, an Demo_Hyperlink
// derived from CMFCLinkCtrl.
// -----------------------------------------------------------------------------------------------------
// LICENSE
//      This software is licensed under the Code Project Open License (CPOL). You are free to use the
// software in any way you like, except that you may not sell the source code. The software is provided
// "as is" with no expressed or implied warranty. I accept no liability for any damage or loss of
// business that this software might cause.
//      Please note that this software code is derived from software owned and copyrighted by Microsoft®
// as part of the Microsoft Foundation Classes for Visual C++®. As such it is a derivative work that
// could be subject to more restrictive licensing policies under terms promulgated by Microsoft®.
// -----------------------------------------------------------------------------------------------------
#include "stdafx.h"
#include "Demo_Hyperlink.h"
#include "Demo_HyperlinkDlg.h"
#include "afxdialogex.h"
#include <MMSystem.h>	// Needed for PlaySound(), used in the About box. Also must link with winmm.lib.

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

// -----------------------------------------------------------------------------------------------------
// About dialog
// -----------------------------------------------------------------------------------------------------
class CAboutDlg : public CDialogEx
	{
	public:
		CAboutDlg();
		~CAboutDlg();

	// Dialog Data
		enum { IDD = IDD_ABOUTBOX };

	protected:
		CBrush m_rectBrush;
		virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	// Implementation
	protected:
		DECLARE_MESSAGE_MAP()
	public:
		afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);
	};

CAboutDlg::CAboutDlg() : CDialogEx(CAboutDlg::IDD)
	{
	}

CAboutDlg::~CAboutDlg()
	{
	m_rectBrush.DeleteObject();	// Delete the brush used for IDC_RECTANGLE.
	}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
	{
	CDialogEx::DoDataExchange(pDX);
	}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialogEx)
	ON_WM_CTLCOLOR()
END_MESSAGE_MAP()

// -----------------------------------------------------------------------------------------------------
// CMFCHyperlinkDlg dialog
// -----------------------------------------------------------------------------------------------------
CMFCHyperlinkDlg::CMFCHyperlinkDlg(CWnd* pParent /*=NULL*/)
	: CDialogEx(CMFCHyperlinkDlg::IDD, pParent)
	{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
	m_bDlgShown = FALSE;		// TRUE after the dialog has been shown once.
	m_bFirstCtlColor = TRUE;	// FALSE after OnCtlColor() has been called once.
	m_bPointsSelected = FALSE;	// TRUE if the "points" combo box's edit window is selected.
	}

CMFCHyperlinkDlg::~CMFCHyperlinkDlg()
	{
	m_Font.DeleteObject();		// Delete the font used for the hyperlink.
	}

void CMFCHyperlinkDlg::DoDataExchange(CDataExchange* pDX)
	{
	CDialogEx::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_MFCLINK_LINK,			m_ctlLINK);
	DDX_Control(pDX, IDC_COMBOFONTS,			m_ctlComboFonts);
	DDX_Control(pDX, IDC_COMBOPOINTS,			m_ctlComboPoints);
	DDX_Control(pDX, IDC_MFCCOLORBTNNORMAL,		m_ctlColorNormal);
	DDX_Control(pDX, IDC_MFCCOLORBTNHOVER,		m_ctlColorHover);
	DDX_Control(pDX, IDC_MFCCOLORBTNVISITED,	m_ctlColorVisited);
	DDX_Control(pDX, IDC_CHECKBOLD,				m_ctlCheckBoxBold);
	DDX_Control(pDX, IDC_CHECKITALICS,			m_ctlCheckBoxItalics);
	DDX_Control(pDX, IDC_UNDERLINEHOVERONLY,	m_ctlUnderline);
	DDX_Control(pDX, IDC_COMBOHYPERLINKSTYLE,	m_ctlComboHyperlinkStyle);
	DDX_Control(pDX, IDC_COMBOALIGNMENT,		m_ctlComboAlignment);
	}

BEGIN_MESSAGE_MAP(CMFCHyperlinkDlg, CDialogEx)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_CBN_SELCHANGE( IDC_COMBOFONTS,			&CMFCHyperlinkDlg::OnSelChangeComboFont)
	ON_CBN_SELCHANGE( IDC_COMBOPOINTS,			&CMFCHyperlinkDlg::OnSelChangeComboPoints)
	ON_CBN_EDITCHANGE(IDC_COMBOPOINTS,			&CMFCHyperlinkDlg::OnEditChangeComboPoints)
	ON_CBN_KILLFOCUS( IDC_COMBOPOINTS,			&CMFCHyperlinkDlg::OnKillFocusComboPoints)
	ON_CBN_SELCHANGE( IDC_COMBOHYPERLINKSTYLE,	&CMFCHyperlinkDlg::OnSelChangeComboHyperlinkStyle)
	ON_CBN_SELCHANGE( IDC_COMBOALIGNMENT,		&CMFCHyperlinkDlg::OnSelChangeComboAlignment)
	ON_BN_CLICKED(	  IDC_MFCCOLORBTNNORMAL,	&CMFCHyperlinkDlg::OnColorBtnNormal)
	ON_BN_CLICKED(	  IDC_MFCCOLORBTNHOVER,		&CMFCHyperlinkDlg::OnColorBtnHover)
	ON_BN_CLICKED(	  IDC_MFCCOLORBTNVISITED,	&CMFCHyperlinkDlg::OnColorBtnVisited)
	ON_BN_CLICKED(	  IDC_CHECKBOLD,			&CMFCHyperlinkDlg::OnClickedCheckBold)
	ON_BN_CLICKED(	  IDC_CHECKITALICS,			&CMFCHyperlinkDlg::OnClickedCheckItalics)
	ON_BN_CLICKED(	  IDC_UNDERLINEHOVERONLY,	&CMFCHyperlinkDlg::OnClickedCheckUnderlineHoverOnly)
	ON_BN_CLICKED(	  IDC_BUTTON_DLGFONT,		&CMFCHyperlinkDlg::OnBnClickedButtonDlgfont)
	ON_BN_CLICKED(	  IDC_BUTTON_DEFAULTFONT,	&CMFCHyperlinkDlg::OnBnClickedButtonDefaultfont)
	ON_WM_SIZE()
	ON_WM_SHOWWINDOW()
	ON_WM_CTLCOLOR()
	ON_WM_GETMINMAXINFO()
END_MESSAGE_MAP()

// -----------------------------------------------------------------------------------------------------
// CAboutDlg message handlers and helper functions.
// -----------------------------------------------------------------------------------------------------
// Recolor a static textbox as a rectangle within the window.
// -----------------------------------------------------------------------------------------------------
HBRUSH CAboutDlg::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor)
	{
	HBRUSH hbr = CDialogEx::OnCtlColor(pDC, pWnd, nCtlColor);

	if (pWnd->GetDlgCtrlID() == IDC_RECTANGLE)
		{
		// ----------------------------------------------------------------------------
		// This adds a lightly shaded rectangle to the bottom of the white "About" box.
		// ----------------------------------------------------------------------------
		CRect rectWnd, rectBG;
		this->GetClientRect(rectWnd);
		pWnd->GetWindowRect(rectBG);
		this->ScreenToClient(rectBG);
		int height = rectWnd.bottom - rectBG.top;
		pWnd->MoveWindow(rectWnd.left, rectBG.top, rectWnd.Width(), height);
		m_rectBrush.DeleteObject();
		m_rectBrush.CreateSolidBrush(RGB(192,255,255));
		hbr = (HBRUSH) m_rectBrush.GetSafeHandle();
		// ---------------------------------------------------------------
		// Make sure the OK button gets painted in front of the rectangle.
		// ---------------------------------------------------------------
		this->GetDlgItem(IDOK)->Invalidate();
		}

	return hbr;
	}

// -----------------------------------------------------------------------------------------------------
// CMFCHyperlinkDlg message handlers and helper functions.
// -----------------------------------------------------------------------------------------------------
// System menu command handler--open the "About" box.
// -----------------------------------------------------------------------------------------------------
void CMFCHyperlinkDlg::OnSysCommand(UINT nID, LPARAM lParam)
	{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
		{
		// ---------------------------------------------------------------
		// Instantiate the About box, then change its background to white,
		// play an opening riff, and display the box. When the user closes
		// it, play a closing sound.
		// ---------------------------------------------------------------
		CAboutDlg dlgAbout;
		dlgAbout.SetBackgroundColor(RGB(255,255,255));
		PlaySound(_T("Harpstring"), AfxGetInstanceHandle(), SND_RESOURCE | SND_ASYNC);
		dlgAbout.DoModal();
		PlaySound(_T("Wee-Ooo"), AfxGetInstanceHandle(), SND_RESOURCE | SND_ASYNC);
		}
	else
		{
		CDialogEx::OnSysCommand(nID, lParam);
		}
	}

// -----------------------------------------------------------------------------------------------------
// Initialize the dialog window before it opens.
// -----------------------------------------------------------------------------------------------------
BOOL CMFCHyperlinkDlg::OnInitDialog()
	{
	CDialogEx::OnInitDialog();

	// -------------------------------------------------
	// Add the "About..." menu item to the system menu.
	// IDM_ABOUTBOX must be in the system command range.
	// -------------------------------------------------
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
		{
		BOOL bNameValid;
		CString strAboutMenu;
		bNameValid = strAboutMenu.LoadString(IDS_ABOUTBOX);
		ASSERT(bNameValid);
		if (!strAboutMenu.IsEmpty())
			{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
			}
		}

	// -----------------------------
	// Set the icon for this dialog.
	// -----------------------------
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon

	// ===========================================================================================
	// Setup for the IMMUTABLE hyperlink.
	// -------------------------------------------------------------------------------------------
	// Change the default font used for the 'IMMUTABLE' hyperlink. The disadvantage of this method
	// is that it changes every instance of the immutable hyperlink in the application.
	// -------------------------------------------------------------------------------------------
	//LOGFONT lf;												// Declare a logfont object.
	//memset(&lf, 0, sizeof(LOGFONT));							// Clear the logfont structure.
	//_tcscpy_s(lf.lfFaceName, LF_FACESIZE, _T("Segoe UI"));	// Use the Segoe UI typeface.
	//lf.lfHeight = 100;										// lfHeight is in 10ths of points.
	//lf.lfItalic = (BYTE)FALSE;								// Not in italics.
	//lf.lfWeight = FW_NORMAL;									// Normal weight; not bold.
	//lf.lfUnderline = (BYTE)TRUE;								// Underlined.
	//CClientDC dc(this);										// Get a DC for the hyperlink.
	//afxGlobalData.fontDefaultGUIUnderline.Detach();
	//VERIFY(afxGlobalData.fontDefaultGUIUnderline.CreatePointFontIndirect(&lf, &dc));
	// -------------------------------------------------------------------------------------------
	// Resize the focus rectangle for the 'IMMUTABLE' hyperlink.
	// -------------------------------------------------------------------------------------------
	((CMFCLinkCtrl*)GetDlgItem(IDC_MFCLINKDEFAULT))->SizeToContent(TRUE, FALSE);
	// -------------------------------------------------------------------------------------------
	// End of setup for the IMMUTABLE hyperlink.
	// ===========================================================================================

	// ===========================================================================================
	// Setup for the MUTABLE hyperlink.
	// -------------------------------------------------------------------------------------------
	// Enable the "other" color buttons in the MFCColorButton controls and set initial colors.
	// ---------------------------------------------------------------------------------------
	m_ctlColorNormal. EnableOtherButton(_T("More colors..."));	// Enable the "other" buttons and
	m_ctlColorHover.  EnableOtherButton(_T("More colors..."));	// set their text.
	m_ctlColorVisited.EnableOtherButton(_T("More colors..."));
	m_ctlColorNormal. SetColor(RGB(  0,  0,255));	// Normal  = Blue
	m_ctlColorHover.  SetColor(RGB(255,  0,  0));	// Hover   = Red
	m_ctlColorVisited.SetColor(RGB(  0,128,128));	// Visited = Teal

	// ------------------------------------------------------------------------------------
	// Set the dialog window's background color to make the group control more visible.
	// This can be done here because the dialog is a CDialogEx, which provides this method.
	// ------------------------------------------------------------------------------------
	SetBackgroundColor(RGB(159,239,255));

	// ------------------------------------------------------------------------------------
	// Initialize the MUTABLE text hyperlink. These three properties could alternatively
	// have been set in the VS2010 designer's property window for this object, as they were
	// for the IMMUTABLE hyperlink.
	// ------------------------------------------------------------------------------------
	m_ctlLINK.SetURL(_T("http://msdn.microsoft.com/"));
	m_ctlLINK.SetWindowText(_T("Open the MSDN Home Page"));
	m_ctlLINK.SetTooltip(_T("Hyperlink derived from CMFCLinkCtrl"));

	// ------------------------------------------------------------------------------------
	// Uncomment these to initially use a font other than the dialog font in the hyperlink.
	// ------------------------------------------------------------------------------------
	// m_ctlLINK.SetMatchParentFont(FALSE);
	// ------------------------------------------------------------------------------------
	// If the above line is uncommented but a new hyperlink font IS NOT set as in the
	// line below, CHyperlink will use the afxGlobalData.fontDefaultGUIUnderline font.
	// ------------------------------------------------------------------------------------
	// m_ctlLINK.SetHyperlinkFont(_T("Trebuchet MS"), 18, TRUE, TRUE);

	// ---------------------------------------------------------------------------------------
	// Initialize the "Points" combo box with sizes 6-24 (6,7,8,9,10,11 then 12,14,16,...).
	// ---------------------------------------------------------------------------------------
	m_ctlComboPoints.LimitText(2);		// Permit no more than two characters in the edit box.
	CString strInt;
	for (int i = HL_MINPOINTS; i <= HL_MAXPOINTS; ++i)	// Constants set in stdafx.h.
		{
		if ((i > 12) && ((i % 2) != 0))	// Beyond 12 points, include only even-numbered point sizes.
			continue;
		strInt.Format(_T("%d"), i);
		m_ctlComboPoints.AddString(strInt);
		}
	// -----------------------------------------------------
	// Set the current font size in points in the combo box.
	// -----------------------------------------------------
	m_nPoints = m_ctlLINK.GetHyperlinkFontPoints();
	CString strFontPoints;
	strFontPoints.Format(_T("%d"), m_nPoints);
	m_ctlComboPoints.SelectString(-1, strFontPoints);

	// -------------------------------------------
	// Initialize the "Hyperlink Style" combo box.
	// -------------------------------------------
	m_ctlComboHyperlinkStyle.AddString(_T("3D Button"));
	m_ctlComboHyperlinkStyle.AddString(_T("Flat Button"));
	m_ctlComboHyperlinkStyle.AddString(_T("Text Only"));
	m_ctlComboHyperlinkStyle.AddString(_T("Semi-Flat Button"));
	m_ctlComboHyperlinkStyle.SelectString(-1, _T("Text Only"));

	// -------------------------------------
	// Initialize the "Alignment" combo box.
	// -------------------------------------
	m_ctlComboAlignment.AddString(_T("Left"));
	m_ctlComboAlignment.AddString(_T("Right"));
	m_ctlComboAlignment.AddString(_T("Center"));
	m_ctlComboAlignment.SelectString(-1, _T("Left"));
	// -------------------------------------------------------------------------------------------
	// End of setup for the MUTABLE hyperlink.
	// ===========================================================================================

	UpdateData(FALSE);

	return TRUE;	// Return TRUE unless the focus has been set to a control.
}

// -----------------------------------------------------------------------------------------------------
// The window is being shown.
// -----------------------------------------------------------------------------------------------------
void CMFCHyperlinkDlg::OnShowWindow(BOOL bShow, UINT nStatus)
	{
	CDialogEx::OnShowWindow(bShow, nStatus);

	if (!m_bDlgShown)
		{
		// ---------------------------------------
		// Get positional data to use in OnSize().
		// ---------------------------------------
		GetWindowRect(&m_rectDlgWnd);		// Full area of the dialog, including nonclient areas.
		GetClientRect(&m_rectDlgClient);	// The dialog window's client area only.
		GetDlgItem(IDC_STATIC_GROUP)->GetWindowRect(&m_rectGroup);
		GetDlgItem(IDCANCEL)->GetWindowRect(&m_rectCloseBtn);
		// -------------------------------------------------------------------------
		// Convert the data for the two controls to the dialog's client coordinates.
		// -------------------------------------------------------------------------
		ScreenToClient(&m_rectGroup);
		ScreenToClient(&m_rectCloseBtn);
		// ----------------------------------------------------
		// Only ever do this once, when the window first opens.
		// ----------------------------------------------------
		m_bDlgShown = TRUE;
		}
	}

// -----------------------------------------------------------------------------------------------------
// METHOD: Get font data from the dialog controls and change the hyperlink font accordingly.
// -----------------------------------------------------------------------------------------------------
void CMFCHyperlinkDlg::ChangePointFont()
	{
	CMFCFontInfo* pFontInfo;
	pFontInfo = m_ctlComboFonts.GetSelFont();		// Get the currently selected font.
	if (pFontInfo != NULL)
		{
		int nPoints =								// Get the font size from the "points" combo box.
			GetPointsFromComboBox(&m_ctlComboPoints);
		if (nPoints >= 0) m_nPoints = nPoints;
		m_ctlLINK.SetHyperlinkFont(					// Set the new hyperlink font:
			(LPCTSTR)pFontInfo->m_strName,			//   ... using the font name from the combo box,
			m_nPoints,								//   ... the point size,
			m_ctlCheckBoxItalics.GetCheck(),		//   ... italics if selected,
			m_ctlCheckBoxBold.   GetCheck());		//   ... bold if selected.
		m_ctlLINK.SetHyperlinkColors(				// Set the hyperlink colors:
			m_ctlColorNormal. GetColor(),			//   ... normal link,
			m_ctlColorHover.  GetColor(),			//   ... hover,
			m_ctlColorVisited.GetColor());			//   ... visited link.
		m_ctlLINK.SizeToContent(TRUE, FALSE);		// Resize the control to fit the text.
		OnClickedCheckUnderlineHoverOnly();			// Underline the font if indicated.
		ResizeDialogIfNeeded();						// Resize the dialog window if the hyperlink won't fit.
		}
	else
		{
		AfxMessageBox(_T("No font selected"), MB_ICONWARNING | MB_OK);
		m_ctlComboFonts.SetFocus();
		}
	}

// -----------------------------------------------------------------------------------------------------
// METHOD: Get an integer value corresponding to the current selection in the "Points" combo box.
// -----------------------------------------------------------------------------------------------------
int CMFCHyperlinkDlg::GetPointsFromComboBox(CComboBox* pCombo)
	{
	CString strValue;
	int nValue = -1;
	int index = pCombo->GetCurSel();
	if (index >= 0)
		{
		pCombo->GetLBText(index, strValue);
		nValue = _ttoi((LPCTSTR)strValue);
		}
	return nValue;
	}

// -----------------------------------------------------------------------------------------------------
// Resize the dialog window if needed when the hyperlink is resized.
// -----------------------------------------------------------------------------------------------------
void CMFCHyperlinkDlg::ResizeDialogIfNeeded()
	{
	CRect rectDlgClient, rectDlgWnd, rectLINK;
	GetWindowRect(&rectDlgWnd);			// Positional data for the full dialog window at present.
	GetClientRect(&rectDlgClient);		// Positional data for the dialog window's client area only.
	int nonClientWidth					// Total width of the left and right nonclient areas.
		= m_rectDlgWnd.Width()
		- m_rectDlgClient.Width();
	int nRightPadding					// Padding on the right within the client area.
		= m_rectDlgClient.right
		- m_rectGroup.right;
	m_ctlLINK.GetWindowRect(&rectLINK);	// Screen coordinates of the hyperlink focus rectangle.
	ScreenToClient(&rectLINK);			// ... converted to client coordinates.

	if (rectLINK.right > (rectDlgClient.right - nRightPadding))
		{
		// ---------------------------------------------------------------------
		// The hyperlink is wider than the dialog window; make the window wider.
		// ---------------------------------------------------------------------
		int dx = rectLINK.right + nRightPadding + nonClientWidth;
		MoveWindow(rectDlgWnd.left, rectDlgWnd.top, dx, rectDlgWnd.Height());
		}
	else if (m_rectDlgClient.Width() < rectDlgClient.Width())
		{
		// --------------------------------------------------------------------
		// The hyperlink is narrower than the dialog window; shrink the window.
		// --------------------------------------------------------------------
		int dx;			// dx is the total window width, including nonclient areas.
		if (rectLINK.right > (m_rectDlgClient.right - nRightPadding))
			{
			// ---------------------------------------------------------
			// The hyperlink is too wide for the ORIGINAL client window,
			// so compute a new width.
			// ---------------------------------------------------------
			dx = rectLINK.right + nRightPadding + nonClientWidth;
			}
		else
			{
			// ---------------------------------------------------------
			// The hyperlink will now fit in the ORIGINAL client window,
			// so revert to the original width.
			// ---------------------------------------------------------
			dx = m_rectDlgWnd.Width();
			}
		MoveWindow(rectDlgWnd.left, rectDlgWnd.top, dx, rectDlgWnd.Height());
		}
	}

// -----------------------------------------------------------------------------------------------------
// What to do when the selection in the font combo box changes.
// -----------------------------------------------------------------------------------------------------
void CMFCHyperlinkDlg::OnSelChangeComboFont()
	{
	ChangePointFont();
	}

// -----------------------------------------------------------------------------------------------------
// What to do when the selection in the "Points" combo box changes.
// -----------------------------------------------------------------------------------------------------
void CMFCHyperlinkDlg::OnSelChangeComboPoints()
	{
	m_bPointsSelected = TRUE;	// Set this for use in OnKillFocusComboPoints().
	ChangePointFont();
	}

// -----------------------------------------------------------------------------------------------------
// What to do when the value in the edit control of the "Points" combo box changes.
// -----------------------------------------------------------------------------------------------------
void CMFCHyperlinkDlg::OnEditChangeComboPoints()
	{
	CString strValue;
	m_ctlComboPoints.GetWindowText(strValue);
	// -----------------------------------------
	// Make sure the value contains only digits.
	// -----------------------------------------
	CString strResult = strValue.SpanIncluding(_T("0123456789"));
	if (strResult.GetLength() != strValue.GetLength())
		{
		// ----------------------------------------------------------
		// Nonnumeric character detected; select all text and return.
		// ----------------------------------------------------------
		m_ctlComboPoints.SetEditSel(0, -1);
		::MessageBeep(MB_ICONWARNING);
		return;
		}
	// ----------------------------------------------------------------
	// Determine whether the value already exists in the combobox list.
	// ----------------------------------------------------------------
	int index = GetCBItemIndex(strValue);
	if (index > 0)
		{
		// ------------------------------------------------------------
		// The value either already existed or was added; select it and
		// change the font to incorporate the new point size.
		// ------------------------------------------------------------
		m_ctlComboPoints.SetCurSel(index);
		ChangePointFont();
		}
	else
		{
		// ------------------------------------------------------------
		// The entered value was either too small or too large.
		// Just ignore it here but handle it in OnKillFocusComboPoints.
		// ------------------------------------------------------------
		}
	}

// -----------------------------------------------------------------------------------------------------
// If a value can be found in m_ctlComboPoints, return its index; else add it and return the new index.
// -----------------------------------------------------------------------------------------------------
int CMFCHyperlinkDlg::GetCBItemIndex(CString strValue)
	{
	// ----------------------------------------------------------------------------------
	// Assumes: strValue corresponds to an integer between HL_MINPOINTS and HL_MAXPOINTS,
	//			constants that have been set in stdafx.h.
	// ----------------------------------------------------------------------------------
	int index;
	if ((index = m_ctlComboPoints.FindStringExact(-1, (LPCTSTR)strValue)) == CB_ERR)
		{
		// -----------------------------------------------------------------------
		// The value doesn't already exist, so try to add it to the combobox list.
		// -----------------------------------------------------------------------
		// (a) Convert it to an integer.
		// -----------------------------
		int i = _ttoi((LPCTSTR)strValue);
		// ----------------------------------------------------------------
		// (b) If it's not too small or large, convert it back to a string.
		// ----------------------------------------------------------------
		if ((i > HL_MINPOINTS) && (i <= HL_MAXPOINTS))
			{
			strValue.Format(_T("%d"), i);
			// ----------------------------------------------
			// Insert it in the proper place within the list.
			// ----------------------------------------------
			for (index = 0; index < m_ctlComboPoints.GetCount(); ++index)
				{
				CString strItem;
				m_ctlComboPoints.GetLBText(index, strItem);
				int j = _ttoi((LPCTSTR)strItem);
				if (i == (j + 1))
					{
					// -------------------------------------------
					// Insert the new string and return its index.
					// -------------------------------------------
					m_ctlComboPoints.InsertString(index + 1, strValue);
					m_ctlComboPoints.SetCurSel(index + 1);
					return index + 1;
					}
				}
			}
		else
			{
			return -1;
			}
		}

	return index;
	}

// -----------------------------------------------------------------------------------------------------
// When the "Points" combo box loses the focus, make sure the value entered was valid.
// -----------------------------------------------------------------------------------------------------
void CMFCHyperlinkDlg::OnKillFocusComboPoints()
	{
	if (m_bPointsSelected)
		{
		// -------------------------------------------------------------------
		// A selection was made from the list so the check below isn't needed.
		// -------------------------------------------------------------------
		m_bPointsSelected = FALSE;
		return;
		}

	// ---------------------------------------------------------------------------
	// The selection is coming from the edit box so we need to check its validity.
	// ---------------------------------------------------------------------------
	CString strValue;
	m_ctlComboPoints.GetWindowText(strValue);
	int i = _ttoi((LPCTSTR)strValue);
	if (i < HL_MINPOINTS)				// HL_MINPOINTS was set in stdafx.h.
		{
		// -----------------------------------------------------------------
		// "Points" entry too small; select the smallest font size and beep.
		// -----------------------------------------------------------------
		m_ctlComboPoints.SetCurSel(0);
		::MessageBeep(MB_ICONWARNING);
		}
	else if (i > HL_MAXPOINTS)			// HL_MAXPOINTS was set in stdafx.h.
		{
		// -----------------------------------------------------------------
		// "Points" entry too large; select the largest font size and beep.
		// -----------------------------------------------------------------
		m_ctlComboPoints.SetCurSel(m_ctlComboPoints.GetCount() - 1);
		::MessageBeep(MB_ICONWARNING);
		}
	else
		{
		// ---------------------------------------------------
		// "Points" entry just right; make sure it's selected.
		// ---------------------------------------------------
		strValue.Format(_T("%d"), i);
		m_ctlComboPoints.SelectString(-1, (LPCTSTR)strValue);
		}

	ChangePointFont();
	}

// -----------------------------------------------------------------------------------------------------
// What to do when the Bold checkbox is clicked.
// -----------------------------------------------------------------------------------------------------
void CMFCHyperlinkDlg::OnClickedCheckBold()
	{
	ChangePointFont();
	}

// -----------------------------------------------------------------------------------------------------
// What to do when the Italics checkbox is clicked.
// -----------------------------------------------------------------------------------------------------
void CMFCHyperlinkDlg::OnClickedCheckItalics()
	{
	ChangePointFont();
	}

// -----------------------------------------------------------------------------------------------------
// What to do when the user makes a selection from the HyperlinkStyle combo box.
// -----------------------------------------------------------------------------------------------------
void CMFCHyperlinkDlg::OnSelChangeComboHyperlinkStyle()
	{
	CString strSelection;
	int index = m_ctlComboHyperlinkStyle.GetCurSel();
	m_ctlComboHyperlinkStyle.GetLBText(index, strSelection);
	if (strSelection == _T("3D Button"))
		{
		m_ctlLINK.SetHyperlinkStyle(m_ctlLINK.ThreeDButton);
		}
	if (strSelection == _T("Flat Button"))
		{
		m_ctlLINK.SetHyperlinkStyle(m_ctlLINK.FlatButton);
		}
	if (strSelection == _T("Text Only"))
		{
		m_ctlLINK.SetHyperlinkStyle(m_ctlLINK.TextOnly);
		}
	if (strSelection == _T("Semi-Flat Button"))
		{
		m_ctlLINK.SetHyperlinkStyle(m_ctlLINK.SemiFlatButton);
		}
	}

// -----------------------------------------------------------------------------------------------------
// What to do when the user makes a selection from the Alignment combo box.
// -----------------------------------------------------------------------------------------------------
void CMFCHyperlinkDlg::OnSelChangeComboAlignment()
	{
	CString strSelection;
	int index = m_ctlComboAlignment.GetCurSel();
	m_ctlComboAlignment.GetLBText(index, strSelection);
	if (strSelection == _T("Left"))
		{
		m_ctlLINK.SetTextAlignment(m_ctlLINK.Left);
		}
	if (strSelection == _T("Right"))
		{
		m_ctlLINK.SetTextAlignment(m_ctlLINK.Right);
		}
	if (strSelection == _T("Center"))
		{
		m_ctlLINK.SetTextAlignment(m_ctlLINK.Center);
		}
	}

// -----------------------------------------------------------------------------------------------------
// What to do when the user makes a selection in the "normal" color button.
// -----------------------------------------------------------------------------------------------------
void CMFCHyperlinkDlg::OnColorBtnNormal()
	{
	ChangePointFont();
	}

// -----------------------------------------------------------------------------------------------------
// What to do when the user makes a selection in the "hover" color button.
// -----------------------------------------------------------------------------------------------------
void CMFCHyperlinkDlg::OnColorBtnHover()
	{
	ChangePointFont();
	}

// -----------------------------------------------------------------------------------------------------
// What to do when the user makes a selection in the "visited" color button.
// -----------------------------------------------------------------------------------------------------
void CMFCHyperlinkDlg::OnColorBtnVisited()
	{
	ChangePointFont();
	}

// -----------------------------------------------------------------------------------------------------
// What to do when the "underline hyperlink" option checkbox is clicked.
// -----------------------------------------------------------------------------------------------------
void CMFCHyperlinkDlg::OnClickedCheckUnderlineHoverOnly()
	{
	// -------------------------------------------------------------------------------------
	// Unchecked: Hyperlinks should always be underlined.
	// Checked:   Hyperlinks should be underlined only when the mouse is hovering over them.
	// -------------------------------------------------------------------------------------
	if (m_ctlUnderline.GetCheck() == 0)
		{
		m_ctlLINK.UnderlineHyperlink(TRUE);		// Underline always, not only on hover.
		}
	else
		{
		m_ctlLINK.UnderlineHyperlink(FALSE);	// Underline only on hover.
		}

	m_ctlLINK.Invalidate();						// Force the hyperlink to redraw.
	}

// -----------------------------------------------------------------------------------------------------
// What to do when the "Dialog Font" button is clicked.
// -----------------------------------------------------------------------------------------------------
void CMFCHyperlinkDlg::OnBnClickedButtonDlgfont()
	{
	// -----------------------------------------------------
	// Get the dialog font and set it as the hyperlink font.
	// -----------------------------------------------------
	LOGFONT lf;
	GetFont()->GetLogFont(&lf);
	BOOL bBold = lf.lfWeight > FW_NORMAL ? TRUE : FALSE;
	m_ctlLINK.SetHyperlinkFont(lf.lfFaceName, lf.lfHeight, lf.lfItalic, bBold);
	m_ctlLINK.SizeToContent(TRUE, FALSE);

	// -----------------------------------------------------
	// Check or uncheck the italics checkbox as appropriate.
	// -----------------------------------------------------
	if ((BOOL)lf.lfItalic)
		{
		m_ctlCheckBoxItalics.SetCheck(1);
		}
	else
		{
		m_ctlCheckBoxItalics.SetCheck(0);
		}

	// --------------------------------------------------
	// Check or uncheck the bold checkbox as appropriate.
	// --------------------------------------------------
	if (bBold)
		{
		m_ctlCheckBoxBold.SetCheck(1);
		}
	else
		{
		m_ctlCheckBoxBold.SetCheck(0);
		}

	// --------------------------------------------
	// Select the font name in the fonts combo box.
	// --------------------------------------------
	m_ctlComboFonts.SelectFont(m_ctlLINK.GetHyperlinkFontName());

	// --------------------------------------------
	// Set the font size in the "points" combo box.
	// --------------------------------------------
	int nPoints = m_ctlLINK.GetHyperlinkFontPoints();
	CString strPoints;
	strPoints.Format(_T("%d"), nPoints);
	m_ctlComboPoints.SetWindowText(strPoints);
	OnEditChangeComboPoints();
	}

// -----------------------------------------------------------------------------------------------------
// What to do when the "Default Font" button is clicked.
// -----------------------------------------------------------------------------------------------------
void CMFCHyperlinkDlg::OnBnClickedButtonDefaultfont()
	{
	// -------------------------------------------
	// Set the default font as the hyperlink font.
	// -------------------------------------------
	m_ctlLINK.SetHyperlinkFontToDefault();
	m_ctlLINK.SizeToContent(TRUE, FALSE);

	// -----------------------------------------------------
	// Check or uncheck the italics checkbox as appropriate.
	// -----------------------------------------------------
	if (m_ctlLINK.IsHyperlinkFontItalic())
		{
		m_ctlCheckBoxItalics.SetCheck(1);
		}
	else
		{
		m_ctlCheckBoxItalics.SetCheck(0);
		}

	// --------------------------------------------------
	// Check or uncheck the bold checkbox as appropriate.
	// --------------------------------------------------
	if (m_ctlLINK.IsHyperlinkFontBold())
		{
		m_ctlCheckBoxBold.SetCheck(1);
		}
	else
		{
		m_ctlCheckBoxBold.SetCheck(0);
		}

	// --------------------------------------------
	// Select the font name in the fonts combo box.
	// --------------------------------------------
	m_ctlComboFonts.SelectFont(m_ctlLINK.GetHyperlinkFontName());

	// --------------------------------------------
	// Set the font size in the "points" combo box.
	// --------------------------------------------
	int nPoints = m_ctlLINK.GetHyperlinkFontPoints();
	CString strPoints;
	strPoints.Format(_T("%d"), nPoints);
	m_ctlComboPoints.SetWindowText(strPoints);
	OnEditChangeComboPoints();
	}

// -----------------------------------------------------------------------------------------------------
// Needed to draw the icon when the window is minimized.
// -----------------------------------------------------------------------------------------------------
void CMFCHyperlinkDlg::OnPaint()
	{
	if (IsIconic())
		{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// -------------------------------
		// Center icon in client rectangle
		// -------------------------------
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width()  - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// -------------
		// Draw the icon
		// -------------
		dc.DrawIcon(x, y, m_hIcon);
		}
	else
		{
		CDialogEx::OnPaint();
		}
	}

// -----------------------------------------------------------------------------------------------------
// The system calls this to obtain the cursor to display while the user drags the minimized window.
// -----------------------------------------------------------------------------------------------------
HCURSOR CMFCHyperlinkDlg::OnQueryDragIcon()
	{
	return static_cast<HCURSOR>(m_hIcon);
	}

// -----------------------------------------------------------------------------------------------------
// Prevent the RETURN key from shutting down the application.
// -----------------------------------------------------------------------------------------------------
BOOL CMFCHyperlinkDlg::PreTranslateMessage(MSG* pMsg)
	{
	if ((pMsg->message >= WM_KEYFIRST) && (pMsg->message <= WM_KEYLAST))
		{
		// --------------------------------------------------------------------------------------
		// Prevent RETURN keystrokes from closing the dialog, which has no IDOK control.
		// Note: RETURN keystrokes are handled directly by CMFCLinkCtrl (or CHyperlink) controls
		// and therefore will never get here if one of those controls has the focus.
		// --------------------------------------------------------------------------------------
		if (pMsg->wParam == VK_RETURN)
			{
			return TRUE;
			}
		}

	// --------------------------------
	// Anything else just goes through.
	// --------------------------------
	return CDialogEx::PreTranslateMessage(pMsg);
	}

// -----------------------------------------------------------------------------------------------------
// Handle WM_SIZE messages.
// -----------------------------------------------------------------------------------------------------
void CMFCHyperlinkDlg::OnSize(UINT nType, int cx, int cy)
	{
	// ----------------------------------------------
	// Note that cx and cy are in CLIENT coordinates.
	// ----------------------------------------------
	CDialogEx::OnSize(nType, cx, cy);	// First call the parent routine.

	// -------------------------------------------------------------------------
	// If the dialog window is LARGER than the ORIGINAL window, move the "close"
	// button to the right and make the group control wider.
	// -------------------------------------------------------------------------
	if (m_bDlgShown)	// Don't do this until the window has been shown once.
		{
		if ((cx >= m_rectDlgClient.Width()) || (cy >= m_rectDlgClient.Height()))
			{
			int dx = cx - m_rectDlgClient.Width();
			int dy = cy - m_rectDlgClient.Height();
			if (dx < 0) dx = 0;
			if (dy < 0) dy = 0;
			// --------------
			// Group control.
			// --------------
			this->GetDlgItem(IDC_STATIC_GROUP)->MoveWindow(
				m_rectGroup.left,
				m_rectGroup.top,
				m_rectGroup.Width() + dx,
				m_rectGroup.Height());
			// -------------
			// Close button.
			// -------------
			this->GetDlgItem(IDCANCEL)->MoveWindow(
				m_rectCloseBtn.left + dx,
				m_rectCloseBtn.top  + dy,
				m_rectCloseBtn.Width(),
				m_rectCloseBtn.Height());
			}
		}
	}

// -----------------------------------------------------------------------------------------------------
// Prevent the dialog window from shrinking smaller than its original size.
// -----------------------------------------------------------------------------------------------------
	void CMFCHyperlinkDlg::OnGetMinMaxInfo(MINMAXINFO* lpMMI)
		{
		if (m_bDlgShown)	// Only do this after the window has been shown at least once.
			{
			// -----------------------------------------------------------------------------
			// m_rectDlgWnd has been initialized the first time the dialog window was shown.
			// -----------------------------------------------------------------------------
			POINT p;
			p.x = m_rectDlgWnd.Width();
			p.y = m_rectDlgWnd.Height();
			lpMMI->ptMinTrackSize = p;	// This prevents the window from getting too small.
			}

		CDialogEx::OnGetMinMaxInfo(lpMMI);
		}

// -----------------------------------------------------------------------------------------------------
// Handle WM_CTLCOLOR messages.
// -----------------------------------------------------------------------------------------------------
HBRUSH CMFCHyperlinkDlg::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor)
	{
	HBRUSH hbr = CDialogEx::OnCtlColor(pDC, pWnd, nCtlColor);

	if ((pWnd == GetDlgItem(IDC_MFCLINK_LINK)) && m_bFirstCtlColor)
		{
		// -------------------------------
		// Get the current hyperlink font.
		// -------------------------------
		CString strFontName = m_ctlLINK.GetHyperlinkFontName();

		// -----------------------------------------
		// 1. Select the font name in the combo box.
		// -----------------------------------------
		m_ctlComboFonts.SelectFont(strFontName);
		if (m_ctlLINK.GetMatchParentFont())
			{
			// ----------------------------------------------------------------
			// User wants to match the dialog font, so check the hyperlink font
			// against the dialog font; if they're different don't proceed.
			// ----------------------------------------------------------------
			LOGFONT lf;
			GetFont()->GetLogFont(&lf);			// Get the dialog font.
			if (strFontName != lf.lfFaceName)	// See if the font names are the same.
				{
				return hbr;						// ... Not, so don't continue.
				}
			}

		// ----------------------------------------------------------------------------
		// 2. Get the hyperlink font's point size, convert it to a string, then select
		//    the value in the "Points" combo box.
		// ----------------------------------------------------------------------------
		int nPoints = m_ctlLINK.GetHyperlinkFontPoints();
		CString strPoints;
		strPoints.Format(_T("%d"), nPoints);
		int index = m_ctlComboPoints.FindStringExact(-1, strPoints);
		if (index == CB_ERR)
			{
			if ((nPoints >= HL_MINPOINTS) && (nPoints <= HL_MAXPOINTS))
				{
				// ----------------------------------------------------------------
				// The point size is not in the list but is between the minimum and
				// maximum values set in stdafx.h; add it and change the font.
				// ----------------------------------------------------------------
				m_ctlComboPoints.SetWindowText(strPoints);
				int index = GetCBItemIndex(strPoints);
				m_ctlComboPoints.SetCurSel(index);
				}
			else
				{
				// -------------------------------------------------------
				// The point size is too small or too large; select either
				// the smallest or largest existing point size.
				// -------------------------------------------------------
				int n;
				if (nPoints < HL_MINPOINTS) n = 0;
				if (nPoints > HL_MAXPOINTS) n = m_ctlComboPoints.GetCount() - 1;
				m_ctlComboPoints.SetCurSel(n);
				}
			}
		else
			{
			m_ctlComboPoints.SetCurSel(index);
			}

		// ----------------------------------------------
		// 3. Resize the focus rectangle to fit the text.
		// ----------------------------------------------
		m_ctlLINK.SizeToContent(TRUE, FALSE);

		// ----------------------------------------------------
		// 4. Check or uncheck the "italics" checkbox depending
		//    on the value of the hyperlink's italic property.
		// ----------------------------------------------------
		if (m_ctlLINK.IsHyperlinkFontItalic())
			{
			m_ctlCheckBoxItalics.SetCheck(1);
			}
		else
			{
			m_ctlCheckBoxItalics.SetCheck(0);
			}

		// -------------------------------------------------
		// 5. Check or uncheck the "bold" checkbox depending
		//    on the value of the hyperlink's bold property.
		// -------------------------------------------------
		if (m_ctlLINK.IsHyperlinkFontBold())
			{
			m_ctlCheckBoxBold.SetCheck(1);
			}
		else
			{
			m_ctlCheckBoxBold.SetCheck(0);
			}

		// ---------------------------------------------------------------
		// 6. Set the "underline only on hover" checkbox to the complement
		//    of the hyperlink's m_bAlwaysUnderlineText property.
		// ---------------------------------------------------------------
		m_ctlUnderline.SetCheck(!m_ctlLINK.m_bAlwaysUnderlineText);

		// ---------------------------------------
		// 7. Update the font to the new settings.
		// ---------------------------------------
		ChangePointFont();

		// ---------------------------------------------------------------
		// 8. Select the hyperlink font's name in the font combo box and
		//    set the focus to that control.
		// ---------------------------------------------------------------
		m_ctlComboFonts.SelectFont(strFontName);
		m_ctlComboFonts.SetFocus();

		m_bFirstCtlColor = FALSE;	// Only ever do this once.
		}

	return hbr;
	}
