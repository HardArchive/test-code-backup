﻿// -----------------------------------------------------------------------------------------------------
// Header file for the CMFCHyperlinkApp class, derived from CWinApp.
// -----------------------------------------------------------------------------------------------------
// Dennis Dykstra, 10 Oct 2010
// -----------------------------------------------------------------------------------------------------
#pragma once

#ifndef __AFXWIN_H__
	#error "include 'stdafx.h' before including this file for PCH"
#endif

#include "resource.h"		// main symbols

class CMFCHyperlinkApp : public CWinAppEx
	{
	private:

	public:
		CMFCHyperlinkApp();

	// Overrides
	public:
		virtual BOOL InitInstance();

	// Implementation

	DECLARE_MESSAGE_MAP()
	};

extern CMFCHyperlinkApp theApp;
