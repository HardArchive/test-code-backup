//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by SystemTrayDemo.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_SYSTEMTYPE                  129
#define IDR_POPUP_MENU                  130
#define IDI_ICON1                       130
#define IDI_ICON2                       131
#define IDD_TRAY_ICON_BALLOON           131
#define IDI_ICON3                       132
#define IDI_ICON4                       133
#define IDC_BALLOON_TEXT                1001
#define IDC_BALLOON_TITLE               1002
#define IDC_COMBO                       1003
#define IDC_TIMEOUT                     1004
#define IDC_TIMEOUT_SPIN                1005
#define ID_POPUP_OPTION1                32771
#define ID_POPUP_OPTION2                32772
#define ID_POPUP_ANIMATE                32773
#define IDC_SHOW_ICON                   32774
#define IDC_HIDE_ICON                   32775
#define IDC_MOVE_TO_RIGHT               32776
#define IDC_SHOW_BALLOON                32777
#define IDC_SET_FOCUS                   32778
#define ID_DEMO_REMOVETASKBARICON       32779
#define ID_DEMO_MAXIMISE                32780
#define ID_DEMO_MINIMISE                32781
#define ID_DEMO_RESTORETASKBAR          32783

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        132
#define _APS_NEXT_COMMAND_VALUE         32784
#define _APS_NEXT_CONTROL_VALUE         1006
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
