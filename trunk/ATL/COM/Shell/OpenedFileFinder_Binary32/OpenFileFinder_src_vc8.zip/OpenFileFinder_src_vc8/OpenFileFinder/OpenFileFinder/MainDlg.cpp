// MainDlg.cpp : implementation file
//
#include "stdafx.h"
#include "resource.h"
#include "MainDlg.h"
#include "AboutDlg.h"
#include "Utils.h"
#include <Tlhelp32.h>
#include <Psapi.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// MainDlg dialog

MainDlg::MainDlg(CString csPath, CWnd* pParent /*=NULL*/)
	: CDialog(MainDlg::IDD, pParent),
    m_bSortAscending(true),
    m_nCoumnclicked(-1)
{
    m_csPath = csPath;
	m_csPath.Replace( L"\"", L"" );
	//{{AFX_DATA_INIT(MainDlg)
	//}}AFX_DATA_INIT
}


void MainDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(MainDlg)
	DDX_Control(pDX, IDC_COMBO1, m_combobox);
	DDX_Control(pDX, IDC_LIST1, m_list);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(MainDlg, CDialog)
	//{{AFX_MSG_MAP(MainDlg)
	ON_COMMAND(ID_MAIN_TERMINATE, OnMainTerminate)
	ON_NOTIFY(NM_RCLICK, IDC_LIST1, OnRclickList1)
	ON_COMMAND(ID_MAIN_TERMINATEALLPROCESS, OnMainTerminateallprocess)
	ON_WM_SYSCOMMAND()
	ON_NOTIFY(LVN_COLUMNCLICK, IDC_LIST1, OnColumnclickList1)
	ON_WM_SIZING()
	ON_COMMAND(ID_BUTTONREFRESH, OnButtonrefresh)
	ON_CBN_SELCHANGE(IDC_COMBO1, OnSelchangeCombo2)
	ON_COMMAND(ID_BUTTON32771, OnButtonGo )
	ON_WM_GETMINMAXINFO()
	ON_COMMAND(ID_MAIN_COPYFILENAME, OnMainCopyfilename)
	//}}AFX_MSG_MAP
    ON_NOTIFY_EX_RANGE( TTN_NEEDTEXT, 0, 0xFFFF, OnToolTipText )
	ON_COMMAND(ID_MAIN_FINDTARGET, &MainDlg::OnMainFindtarget)
	ON_COMMAND(ID_MAIN_CLOSEHANDLE, &MainDlg::OnMainClosehandle)
	ON_COMMAND(ID_MAIN_CLOSEALLHANDLES, &MainDlg::OnMainCloseallhandles)
	ON_COMMAND(ID_MAIN_SHOWLOADEDMODULESONLY, &MainDlg::OnMainShowloadedmodulesonly)
	ON_COMMAND(ID_MAIN_SHOWOPENEDFILESONLY, &MainDlg::OnMainShowopenedfilesonly)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// MainDlg message handlers

BOOL MainDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
    HICON hIcon =  AfxGetApp()->LoadIcon( IDI_ICON1 );
    SetIcon(hIcon, TRUE);			// Set big icon
	SetIcon(hIcon, FALSE);		// Set small icon
	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu( "About OpenFileFinder");		
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, 0x0010, strAboutMenu);
		}
	}
    ListView_SetExtendedListViewStyleEx( m_list.m_hWnd, LVS_EX_GRIDLINES|LVS_EX_FULLROWSELECT, 
                                                        LVS_EX_GRIDLINES|LVS_EX_FULLROWSELECT );
    m_list.InsertColumn( 0, _T("Process"), LVCFMT_LEFT, 100 );
    m_list.InsertColumn( 1, _T("Pid"), LVCFMT_LEFT, 100);
    m_list.InsertColumn( 2, _T("File Opened"), LVCFMT_LEFT, 350);
    
    // Create image list and add icons
    m_imgToolbar1.Create( 24,24, ILC_COLOR32|ILC_MASK, 1 , RGB(0,0,0));
    m_imgToolbar2.Create( 24,24, ILC_COLOR32|ILC_MASK, 1 , RGB(255,0,0));    
    
    m_imgToolbar1.Add( AfxGetApp()->LoadIcon( IDI_ICON3 ));
    m_imgToolbar1.Add( AfxGetApp()->LoadIcon( IDI_ICON2 ));
    m_imgToolbar1.Add( AfxGetApp()->LoadIcon( IDI_ICON4 ));
    m_imgToolbar2.Add( AfxGetApp()->LoadIcon( IDI_ICON5 ));    
    

    // create tool bars
    m_toolBar.CreateEx( this, TBSTYLE_FLAT|TBSTYLE_TOOLTIPS|TBSTYLE_TRANSPARENT );    
    m_toolBar.LoadToolBar( IDR_TOOLBAR1 );    
    m_toolBar.SetSizes( CSize( 31,30), CSize(24,24));      

    m_toolBarGo.CreateEx( this, TBSTYLE_FLAT|TBSTYLE_TOOLTIPS|TBSTYLE_TRANSPARENT );
    m_toolBarGo.LoadToolBar( IDR_TOOLBAR2 );
    m_toolBarGo.SetSizes( CSize( 35,30),CSize(24,24));

    // set image list
    m_toolBar.SendMessage( TB_SETIMAGELIST, 0, (LPARAM)m_imgToolbar1.m_hImageList );    
    m_toolBarGo.SendMessage( TB_SETIMAGELIST, 0, (LPARAM)m_imgToolbar2.m_hImageList );   
	
	
    
    RepositionBars( AFX_IDW_CONTROLBAR_FIRST, AFX_IDW_CONTROLBAR_LAST,0, reposDefault,0, CRect(10,0, 300, 50 ));
    CRect m_comboRect;
    m_combobox.GetWindowRect( &m_comboRect );    
    ScreenToClient( &m_comboRect );

    m_toolBar.SetWindowPos( 0, 10,0,0,0, SWP_NOSIZE|SWP_NOZORDER );    
    m_toolBarGo.MoveWindow( m_comboRect.right, m_comboRect.top - 3, 35, 30 );

	// Add all drives to the combobox
    TCHAR tc[50];
    DWORD dwCount = GetLogicalDriveStrings( 50, tc );
    TCHAR *pDrive = tc;
    do
    {   CString csDrive = pDrive;
		csDrive.MakeLower();
        m_combobox.AddString( csDrive );
        pDrive += 4;
        dwCount -= 4;
        
    }
	while( dwCount > 0 );
    
	// Add current path is not already added
	int nPos = m_combobox.FindStringExact( -1, m_csPath );
	if( -1 == nPos )
	{
		nPos = m_combobox.AddString( m_csPath );
	}
    m_combobox.SetCurSel( nPos );

    m_combobox.AddString( _T("Browse...") );

	// Set auto complete in the combobox
	CWnd* pEdit =  m_combobox.GetDlgItem( 1001 );
	if( pEdit )
	{
		SHAutoComplete( pEdit->m_hWnd, SHACF_FILESYSTEM );
	}

	// Now list all files	
    Populate();
	return TRUE;
}



void MainDlg::Populate( OF_TYPE ListType ) 
{
    try
    {
        // Clear the list control and icon map
        m_list.DeleteAllItems();
		m_nCount = 0;
		m_imgListCtrl.DeleteImageList();
		m_stProcessInfo.RemoveAll();
		m_imgListCtrl.Create( 16,16, ILC_COLOR32|ILC_MASK, 1 , RGB(0,0,0));
		m_list.SetImageList( &m_imgListCtrl, LVSIL_SMALL );
        
		
        HICON hIcon = AfxGetApp()->LoadIcon( IDI_ICON2 );
        m_imgListCtrl.Add( hIcon );
        DestroyIcon( hIcon );
		// Remove any sort marks in header
		if( -1 != m_nCoumnclicked )
		{
			HDITEM stHItem = {0};
			stHItem.mask = HDI_FORMAT;
			stHItem.fmt = HDF_LEFT|HDF_STRING;
			m_list.GetHeaderCtrl()->SetItem( m_nCoumnclicked, &stHItem );
		}
		GetOpenedFiles( m_csPath, ListType, CallBackFunc, (ULONG_PTR)this );
	}
    catch(...)
    {
        OutputDebugString( _T("Exception occured in MainDlg::Populate()"));
    }
}

// This Function will be called when the user click on the "Terminate process"
void MainDlg::OnMainTerminate() 
{
    try
    {
        int nItem =  m_list.GetNextItem( -1, LVNI_SELECTED );
        if( -1 == nItem )
        {
            return;
        }
    
        if( IDYES == MessageBox( _T("Terminate selected Process?"), _T("Terminate"), MB_YESNO))
        {
            CString csPid = m_list.GetItemText( nItem, 1 );
            DWORD dwPid = _ttoi( csPid );        
            HANDLE hProcess = OpenProcess( PROCESS_TERMINATE , FALSE, dwPid );
            if( !hProcess )
            {
                MessageBox( _T("Failed to Terminate process"), _T("Error"), MB_OK|MB_ICONERROR );
                return;
            }
            BOOL b = TerminateProcess( hProcess, 0 );
            CloseHandle( hProcess );
            if( !b )
            {
                MessageBox( _T("Failed to Terminate process"), _T("Error"), MB_OK|MB_ICONERROR );
                return;
            }
            m_list.DeleteAllItems();
			// Refresh
            Populate();            
        }
    }
    catch(...)
    {
    }
    
}

// Function to show the context menu
void MainDlg::OnRclickList1(NMHDR* pNMHDR, LRESULT* pResult) 
{
    int nItem =  m_list.GetNextItem( -1, LVNI_SELECTED );
    //if( -1 == nItem )
    //{
    //    return;
    //}
    CMenu PopUpMenu;
    PopUpMenu.LoadMenu( IDR_MENU1 );
    CPoint pt;
    pt = GetCurrentMessage()->pt;
    PopUpMenu.GetSubMenu( 0 )->TrackPopupMenu( TPM_LEFTALIGN, pt.x, pt.y, this, 0 );
	*pResult = 0;
}

// This function will be called when the user clicks the "Terminate All" context menu
void MainDlg::OnMainTerminateallprocess() 
{
    try
    {
        if( IDYES == MessageBox( _T("Terminate All Process?"), _T("Terminate"), MB_YESNO))
        {
            int nCount = m_list.GetItemCount();
            bool bDeleted = true;
            for( int nIdx = 0; nIdx < nCount; nIdx++ )
            {        
                CString csPid = m_list.GetItemText( nIdx, 1 );
                DWORD dwPid = _ttoi( csPid );        
                HANDLE hProcess = OpenProcess(  PROCESS_TERMINATE , FALSE, dwPid );
                if( !hProcess )
                {
                    continue;
                }
                BOOL b = TerminateProcess( hProcess, 0 );
                CloseHandle( hProcess );
                if( !b )
                {
                    bDeleted = false;
                }
            }
            if( !bDeleted )
            {
                MessageBox(  _T("Failed to Terminate some process"),_T("Error"), MB_OK|MB_ICONERROR );
            }
            m_list.DeleteAllItems();
            Populate();
        }
    }
    catch(...)
    {
    }
}

void MainDlg::OnSysCommand(UINT nID, LPARAM lParam) 
{
	if ((nID & 0xFFF0) == 0x0010 )
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
	
}

// Function called when user clicks on the header
void MainDlg::OnColumnclickList1(NMHDR* pNMHDR, LRESULT* pResult) 
{
	try
	{
		NM_LISTVIEW* pNMListView = (NM_LISTVIEW*)pNMHDR;
		HDITEM stHItem = {0};
		stHItem.mask = HDI_FORMAT;
		stHItem.fmt = HDF_LEFT|HDF_STRING;
		if( -1 != m_nCoumnclicked )
		{
			m_list.GetHeaderCtrl()->SetItem( m_nCoumnclicked, &stHItem );
		}
		if( m_nCoumnclicked != pNMListView->iSubItem )
		{
			m_bSortAscending = true;
		}
		m_nCoumnclicked = pNMListView->iSubItem;
		ListView_SortItemsEx( m_list.m_hWnd, CompareFunc, (LPARAM)this );
		stHItem.fmt |= (m_bSortAscending)? HDF_SORTUP:HDF_SORTDOWN;
		m_list.GetHeaderCtrl()->SetItem( m_nCoumnclicked, &stHItem );
		m_bSortAscending = !m_bSortAscending;
	}
	catch(...)
	{		
	}  	
	*pResult = 0;
}

// The comparison function for deciding the sort order
int MainDlg::CompareFunc( LPARAM lParam1, LPARAM lParam2, LPARAM lParamSort )
{
    MainDlg* pThis = (MainDlg*)lParamSort;
    CString csText1 = pThis->m_list.GetItemText( (int)lParam1, pThis->m_nCoumnclicked );
    CString csText2 = pThis->m_list.GetItemText( (int)lParam2, pThis->m_nCoumnclicked );    
    int nReturn = 0;
    if( pThis->m_bSortAscending )
    {
        nReturn = csText1.Compare( csText2 );
    }
    else
    {
        nReturn = csText2.Compare( csText1 );
    }
    return nReturn;
}

// Function to size the List control when user sizes the dialog
void MainDlg::OnSizing(UINT fwSide, LPRECT pRect) 
{
	CDialog::OnSizing(fwSide, pRect);
    m_list.SetWindowPos( 0,0,0, max( 1, pRect->right -  pRect->left - 30), max( 1, pRect->bottom - pRect->top -72), SWP_NOMOVE|SWP_NOZORDER );
}


// Refresh the list
void MainDlg::OnButtonrefresh() 
{
    Populate();
}


// this function will be called when the item in combobox is chaged
void MainDlg::OnSelchangeCombo2() 
{
    CString csText;
    m_combobox.GetLBText( m_combobox.GetCurSel(), csText );
    if( csText == _T("Browse...") )
    {
		// User have selected the browse item. so browse for folder
        BROWSEINFO bi = {0};
        bi.hwndOwner = m_hWnd;
        bi.ulFlags = BIF_RETURNONLYFSDIRS ;
        LPITEMIDLIST pIt= SHBrowseForFolder( &bi );
        if( pIt )
        {
			// Set the new path as the selected folder and refresh
            TCHAR tcPath[ MAX_PATH ];
            if( SHGetPathFromIDList( pIt, tcPath ))
            {
                m_csPath = tcPath;
                int nPos =m_combobox.FindStringExact( -1, m_csPath );
                if( -1 == nPos )
                {
                    nPos = m_combobox.AddString( m_csPath );                    
                }
                m_combobox.SetCurSel( nPos );
                Populate();
                return;
            }
        }
        m_combobox.SetCurSel( -1 );
        return;
    }
    m_csPath = csText;
    Populate();
}


BOOL MainDlg::PreTranslateMessage(MSG* pMsg) 
{
	//Handled the enter key press in the combobox
    if( WM_KEYDOWN == pMsg->message && ::GetParent( pMsg->hwnd ) == m_combobox.m_hWnd && VK_RETURN == pMsg->wParam )
    {		
		CString csText;
		m_combobox.GetWindowText( csText );
		m_csPath = csText;
		int nPos =m_combobox.FindStringExact( -1, csText );
		if( -1 == nPos )
		{
			nPos = m_combobox.AddString( m_csPath );                    
		}
		m_combobox.SetCurSel( nPos );
		Populate();
		return TRUE;
    }
	return CDialog::PreTranslateMessage(pMsg);
}

// Function called when the Go button is clicked
void MainDlg::OnButtonGo() 
{
    CString csText;
    m_combobox.GetWindowText( csText );
    m_csPath = csText;
    int nPos =m_combobox.FindStringExact( -1, csText );
    if( -1 == nPos )
    {
        nPos = m_combobox.AddString( m_csPath );                    
    }
    m_combobox.SetCurSel( nPos );
    Populate();
}

// Function for showing the tooltip
BOOL MainDlg::OnToolTipText(UINT, NMHDR* pNMHDR, LRESULT* pResult)
{
    // Tooltip handler struct
    LPTOOLTIPTEXT pTTT = (LPTOOLTIPTEXT)pNMHDR;

    // If pointer invalid return false;
    if( !pTTT )
    {
        return FALSE;
    }

    // Get id of the sender
    UINT_PTR uCtrlID = pNMHDR->idFrom;

    // If idFrom is an HWND, then use GetDlgCtrlID to get the id of the control
    if ( pNMHDR->code == TTN_NEEDTEXT && ( pTTT->uFlags & TTF_IDISHWND ))
    {
        uCtrlID = ::GetDlgCtrlID( (HWND)uCtrlID );
    }

    if ( uCtrlID != 0 ) // will be zero on a separator
    {
        CString strTipText;
        strTipText.LoadString( (UINT)uCtrlID );
        if ( pNMHDR->code == TTN_NEEDTEXT )
        {
            lstrcpyn( pTTT->szText, strTipText, sizeof( pTTT->szText ));
        }
        
        *pResult = 0;
        
        // Move tooltip window up
        ::SetWindowPos( pNMHDR->hwndFrom, 
                        HWND_TOP, 
                        0, 
                        0, 
                        0, 
                        0,
                        SWP_NOACTIVATE | SWP_NOSIZE | SWP_NOMOVE | SWP_NOOWNERZORDER );

        // Continue notification
        return TRUE;
    }

    // Stop notification
    return FALSE;
}

// Function to prevent the user from decreasing the size below a limit
void MainDlg::OnGetMinMaxInfo(MINMAXINFO FAR* lpMMI) 
{	    
    lpMMI->ptMinTrackSize = CPoint( 597, 150 );
	CDialog::OnGetMinMaxInfo(lpMMI);
}


// Function to copy the filename to clipboard
void MainDlg::OnMainCopyfilename() 
{
	int nItem =  m_list.GetNextItem( -1, LVNI_SELECTED );
    if( -1 == nItem )
    {
        return;
    }
	CString csPath;
	csPath = m_list.GetItemText( nItem,2 );
	OpenClipboard();
	EmptyClipboard(); 
	int nSize = (csPath.GetLength() + 1) * sizeof(TCHAR);
    HGLOBAL  hglbCopy = GlobalAlloc(GMEM_MOVEABLE, nSize ); 
    if (hglbCopy == NULL) 
    { 
        CloseClipboard(); 
        return; 
    } 
    LPTSTR lpData = (LPTSTR)GlobalLock(hglbCopy); 
    memcpy(lpData, csPath, nSize ); 
    lpData[nSize-1] = (TCHAR) 0;
    GlobalUnlock(hglbCopy);
    SetClipboardData( CF_UNICODETEXT, hglbCopy ); 
	CloseClipboard();

}

void MainDlg::OnMainFindtarget()
{
	int nItem =  m_list.GetNextItem( -1, LVNI_SELECTED );
	if( -1 == nItem )
	{
		return;
	}
	CString csPath;
	csPath = m_list.GetItemText( nItem,2 );
	LPITEMIDLIST stId = 0;
	SFGAOF stSFGAOFIn = 0;	
	SFGAOF stSFGAOFOut = 0;
	if( !FAILED(SHParseDisplayName( csPath, 0, &stId,stSFGAOFIn, &stSFGAOFOut )))
	{
		SHOpenFolderAndSelectItems( stId, 0, 0, 0 );
	}
	
}

void MainDlg::OnMainClosehandle()
{
	int nItem =  m_list.GetNextItem( -1, LVNI_SELECTED );
	if( -1 == nItem )
	{
		return;
	}
	HANDLE hFile = (HANDLE)m_list.GetItemData( nItem );
	if( !hFile )
	{
		return;
	}
	CString csFileName = m_list.GetItemText( nItem, 2 );
	CString csPid = m_list.GetItemText( nItem, 1 );
	DWORD dwPid = _ttoi( csPid );
	HANDLE hProcess = OpenProcess( PROCESS_DUP_HANDLE , FALSE, dwPid );
	if( !hProcess )
	{
		AfxMessageBox( L"Failed to open the process" );
		return;
	}
	HANDLE hDup = 0;
	BOOL b = DuplicateHandle( hProcess, hFile, GetCurrentProcess(), &hDup, DUPLICATE_SAME_ACCESS , FALSE, DUPLICATE_CLOSE_SOURCE );
	if( hDup )
	{
		CloseHandle( hDup );
	}    
	CloseHandle( hProcess );
	//b = DeleteFile( csFileName );
	Populate();
}

void MainDlg::OnMainCloseallhandles()
{
	int nCount = m_list.GetItemCount();    
	for( int nIdx = 0; nIdx < nCount; nIdx++ )
	{        
		CString csPid = m_list.GetItemText( nIdx, 1 );
		DWORD dwPid = _ttoi( csPid );                
		HANDLE hFile = (HANDLE)m_list.GetItemData( nIdx );
		if( !hFile )
		{
			continue;
		}        
		HANDLE hProcess = OpenProcess( PROCESS_DUP_HANDLE , FALSE, dwPid );
		if( !hProcess )
		{
			//AfxMessageBox( L"Failed to open the process" );
			continue;
		}
		HANDLE hDup = 0;
		BOOL b = DuplicateHandle( hProcess, hFile, GetCurrentProcess(), &hDup, DUPLICATE_SAME_ACCESS , FALSE, DUPLICATE_CLOSE_SOURCE );
		if( hDup )
		{
			CloseHandle( hDup );
		}    
		CloseHandle( hProcess );
	}

	Populate();
}

void MainDlg::OnMainShowloadedmodulesonly()
{
	Populate( MODULES_ONLY );
}

void MainDlg::OnMainShowopenedfilesonly()
{
	Populate( FILES_ONLY );
}

void CALLBACK MainDlg::CallBackFunc( OF_INFO_t OpenedFileInfo, UINT_PTR pUserContext )
{
	((MainDlg*)pUserContext)->OnFileFound( OpenedFileInfo );
}

void MainDlg::OnFileFound(OF_INFO_t OpenedFileInfo )
{
	PROCESS_INFO_t stInfo = {0};
	if( !m_stProcessInfo.Lookup( OpenedFileInfo.dwPID, stInfo))
	{
		TCHAR tcFileName[MAX_PATH];
		CString csModule;
		HANDLE hProcess = OpenProcess( PROCESS_QUERY_INFORMATION|PROCESS_VM_READ, TRUE, OpenedFileInfo.dwPID );
		stInfo.dwImageListIndex = 0;
		if( !hProcess || !GetProcessImageFileName( hProcess, tcFileName, MAX_PATH ))
		{
			if( hProcess )
			{
				CloseHandle( hProcess );
			}
			
			if( OpenedFileInfo.dwPID == 4 )// system process
			{
				stInfo.csProcess = L"System";
			}
			else
			{
				stInfo.csProcess = L"Unknown Process";
			}
		}
		else
		{
			GetDrive( tcFileName, csModule, false );
			CloseHandle( hProcess );		
			PathStripPath( tcFileName );
			stInfo.csProcess = tcFileName;			
			SHFILEINFO stIcon = {0};
			if( SHGetFileInfo( csModule, 0, &stIcon, sizeof( stIcon), SHGFI_ICON ))
			{
				stInfo.dwImageListIndex = m_imgListCtrl.Add( stIcon.hIcon );
				DestroyIcon( stIcon.hIcon );
			}
		}
		m_stProcessInfo[OpenedFileInfo.dwPID] = stInfo;
	}	
	// Insert Process name, PID and file name
	m_list.InsertItem( m_nCount, stInfo.csProcess, stInfo.dwImageListIndex );                    
	CString csPid;
	csPid.Format( _T("%d ( 0x%x )"), OpenedFileInfo.dwPID , OpenedFileInfo.dwPID );			
	m_list.SetItemText( m_nCount, 1, csPid );
	m_list.SetItemText( m_nCount, 2, OpenedFileInfo.lpFile );
	m_list.SetItemData( m_nCount, (DWORD_PTR)OpenedFileInfo.hFile );
	m_nCount++;
}