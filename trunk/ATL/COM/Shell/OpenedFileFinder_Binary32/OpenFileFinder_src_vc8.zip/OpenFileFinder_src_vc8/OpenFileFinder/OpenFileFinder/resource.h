//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by OpenFileFinder.rc
//
#define IDS_PROJNAME                    100
#define IDR_OPENFILEFINDER              101
#define IDR_INTERFACECLS                103
#define IDS_STRING103                   103
#define IDS_STRING104                   104
#define IDD_DIALOG1                     201
#define IDC_LIST1                       201
#define IDD_DIALOG2                     201
#define IDC_COMBO1                      202
#define IDR_MENU1                       202
#define IDI_ICON1                       207
#define IDI_ICON2                       208
#define IDI_ICON3                       209
#define IDI_ICON4                       210
#define IDI_ICON5                       211
#define IDR_TOOLBAR1                    212
#define IDR_TOOLBAR2                    214
#define IDR_XPDRIVER                    217
#define IDR_XPDRIVER32                  217
#define IDR_VISTA_DRIVER                218
#define IDD_DIALOG3                     219
#define IDR_BINARY1                     223
#define IDR_XPDRIVER64                  223
#define ID_MAIN_TERMINATE               32768
#define ID_MAIN_TERMINATEALLPROCESS     32769
#define ID_MAIN_COPYFILENAME            32770
#define ID_BUTTON32770                  32770
#define ID_BUTTON32771                  32771
#define ID_BUTTONREFRESH                32772
#define ID_MAIN_FINDTARGET              32773
#define ID_MAIN_CLOSEHANDLE             32774
#define ID_MAIN_CLOSEALLHANDLES         32775
#define ID_MAIN_SHOWLOADEDMODULESONLY   32776
#define ID_MAIN_SHOWOPENEDFILESONLY     32777

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        224
#define _APS_NEXT_COMMAND_VALUE         32778
#define _APS_NEXT_CONTROL_VALUE         203
#define _APS_NEXT_SYMED_VALUE           104
#endif
#endif
