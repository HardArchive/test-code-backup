//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by FileTime.rc
//
#define IDS_PROJNAME                    100
#define IDR_FILETIMESHLEXT              101
#define IDD_FILETIME_PROPPAGE           107
#define IDI_ICON                        201
#define IDC_MODIFIED_DATE               202
#define IDC_MODIFIED_TIME               203
#define IDC_ACCESSED_DATE               204
#define IDC_CREATED_DATE                206
#define IDC_CREATED_TIME                207
#define IDC_FILENAME                    209

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        202
#define _APS_NEXT_COMMAND_VALUE         32768
#define _APS_NEXT_CONTROL_VALUE         210
#define _APS_NEXT_SYMED_VALUE           102
#endif
#endif
