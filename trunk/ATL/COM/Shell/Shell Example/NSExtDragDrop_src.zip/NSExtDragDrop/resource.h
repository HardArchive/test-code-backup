//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by NSExtDragDrop.rc
//
#define IDS_PROJNAME                    100
#define IDR_MYVIRTUALFOLDER             101
#define IDS_VFNAME                      101
#define IDS_INFOTIP                     102
#define IDR_NSFSHELLVIEW                103
#define IDS_DESCRIPTION                 104
#define IDS_CLASSNAME                   105
#define IDC_STATIC_FLD_NAME             201
#define IDI_NSFROOT                     201
#define IDC_STATIC_FILE_NAME            202
#define IDD_FOLDER_PROPERTY_E           207
#define IDD_FILE_PROPERTY_E             208
#define IDR_LISTVIEW_CTXMENU_E          209
#define IDI_FOLDER                      211
#define IDI_FOLDER_OPEN                 212
#define IDI_FILE                        214
#define ID_EDIT_DELETE                  700
#define ID_EDIT_PROPERTIES              701
#define ID_VIEW_REFRESH                 710
#define ID_NEWITEM_FOLDER               32778

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        215
#define _APS_NEXT_COMMAND_VALUE         32779
#define _APS_NEXT_CONTROL_VALUE         203
#define _APS_NEXT_SYMED_VALUE           104
#endif
#endif
