// SubButton.cpp: Implementierungsdatei
//

#include "stdafx.h"
#include "SubButton.h"
#include "resource.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CSubButton

CSubButton::CSubButton()
{
	m_crTextClr = RGB(0,0,255);
}

CSubButton::~CSubButton()
{
}


BEGIN_MESSAGE_MAP(CSubButton, CButton)
	//{{AFX_MSG_MAP(CSubButton)
	ON_WM_CTLCOLOR_REFLECT()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// Behandlungsroutinen f�r Nachrichten CSubButton 

HBRUSH CSubButton::CtlColor(CDC* pDC, UINT nCtlColor) 
{
// TODO: Attribute des Ger�tekontexts hier �ndern
	pDC->SetBkMode(TRANSPARENT);
	pDC->SetTextColor(m_crTextClr);				// text

return (HBRUSH)::GetStockObject(HOLLOW_BRUSH);	// ctl bkgnd
}







