// Shortcut DemoDlg.h : Header-Datei
//

#if !defined(AFX_SHORTCUTDEMODLG_H__78745182_0D8E_40F5_A50E_B70D4B1DE3F3__INCLUDED_)
#define AFX_SHORTCUTDEMODLG_H__78745182_0D8E_40F5_A50E_B70D4B1DE3F3__INCLUDED_

#include "Shortcut.h"	// Hinzugef�gt von der Klassenansicht
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "SubButton.h"

/////////////////////////////////////////////////////////////////////////////
// CShortcutDemoDlg Dialogfeld

class CShortcutDemoDlg : public CDialog
{
// Konstruktion
public:
	CShortcutDemoDlg(CWnd* pParent = NULL);	// Standard-Konstruktor

// Dialogfelddaten
	//{{AFX_DATA(CShortcutDemoDlg)
	enum { IDD = IDD_SHORTCUTDEMO_DIALOG };
	CStatic	m_statPath;
	CStatic	m_statDesc;
	CSubButton	m_R4;
	CSubButton	m_R3;
	CSubButton	m_R2;
	CSubButton	m_R1;
	//}}AFX_DATA

	// Vom Klassenassistenten generierte �berladungen virtueller Funktionen
	//{{AFX_VIRTUAL(CShortcutDemoDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV-Unterst�tzung
	//}}AFX_VIRTUAL

// Implementierung
protected:
	HICON m_hIcon;
	CFont m_cfSmall;
	
	// Generierte Message-Map-Funktionen
	//{{AFX_MSG(CShortcutDemoDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnBCreate();
	afx_msg void OnBDelete();
	afx_msg void OnDestroy();
	afx_msg void OnBResolve();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	CShortcut *m_pShortcut;
	int iIconIndex;
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ f�gt unmittelbar vor der vorhergehenden Zeile zus�tzliche Deklarationen ein.

#endif // !defined(AFX_SHORTCUTDEMODLG_H__78745182_0D8E_40F5_A50E_B70D4B1DE3F3__INCLUDED_)
