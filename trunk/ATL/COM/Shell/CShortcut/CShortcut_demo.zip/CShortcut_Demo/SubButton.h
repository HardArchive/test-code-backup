#if !defined(AFX_SUBBUTTON_H__111A4210_CC9B_4F1F_8D8A_449A0E55CAF2__INCLUDED_)
#define AFX_SUBBUTTON_H__111A4210_CC9B_4F1F_8D8A_449A0E55CAF2__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// SubButton.h : Header-Datei
//

/////////////////////////////////////////////////////////////////////////////
// Fenster CSubButton 

class CSubButton : public CButton
{
// Konstruktion
public:
	CSubButton();

// Attribute
public:

// Operationen
public:

// �berschreibungen
	// Vom Klassen-Assistenten generierte virtuelle Funktions�berschreibungen
	//{{AFX_VIRTUAL(CSubButton)
	//}}AFX_VIRTUAL

// Implementierung
public:
	virtual ~CSubButton();
	COLORREF m_crTextClr;	// The textcolor
	// Generierte Nachrichtenzuordnungsfunktionen
protected:
	//{{AFX_MSG(CSubButton)
	afx_msg HBRUSH CtlColor(CDC* pDC, UINT nCtlColor);
	//}}AFX_MSG


	DECLARE_MESSAGE_MAP()
private:
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ f�gt unmittelbar vor der vorhergehenden Zeile zus�tzliche Deklarationen ein.

#endif // AFX_SUBBUTTON_H__111A4210_CC9B_4F1F_8D8A_449A0E55CAF2__INCLUDED_
