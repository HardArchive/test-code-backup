// Shortcut DemoDlg.cpp : Implementierungsdatei
//

#include "stdafx.h"
#include "Shortcut Demo.h"
#include "Shortcut DemoDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg-Dialogfeld f�r Anwendungsbefehl "Info"

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialogfelddaten
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// Vom Klassenassistenten generierte �berladungen virtueller Funktionen
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV-Unterst�tzung
	//}}AFX_VIRTUAL

// Implementierung
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// Keine Nachrichten-Handler
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CShortcutDemoDlg Dialogfeld

CShortcutDemoDlg::CShortcutDemoDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CShortcutDemoDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CShortcutDemoDlg)
	//}}AFX_DATA_INIT
	// Beachten Sie, dass LoadIcon unter Win32 keinen nachfolgenden DestroyIcon-Aufruf ben�tigt
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CShortcutDemoDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CShortcutDemoDlg)
	DDX_Control(pDX, IDC_LINKPATH, m_statPath);
	DDX_Control(pDX, IDC_LINKDESC, m_statDesc);
	DDX_Control(pDX, IDR_4, m_R4);
	DDX_Control(pDX, IDR_3, m_R3);
	DDX_Control(pDX, IDR_2, m_R2);
	DDX_Control(pDX, IDR_1, m_R1);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CShortcutDemoDlg, CDialog)
	//{{AFX_MSG_MAP(CShortcutDemoDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDB_CREATE, OnBCreate)
	ON_BN_CLICKED(IDB_DELETE, OnBDelete)
	ON_WM_DESTROY()
	ON_BN_CLICKED(IDB_RESOLVE, OnBResolve)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CShortcutDemoDlg Nachrichten-Handler

BOOL CShortcutDemoDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Hinzuf�gen des Men�befehls "Info..." zum Systemmen�.

	// IDM_ABOUTBOX muss sich im Bereich der Systembefehle befinden.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{	
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Symbol f�r dieses Dialogfeld festlegen. Wird automatisch erledigt
	//  wenn das Hauptfenster der Anwendung kein Dialogfeld ist
	SetIcon(m_hIcon, TRUE);			// Gro�es Symbol verwenden
	SetIcon(m_hIcon, FALSE);		// Kleines Symbol verwenden
	
	// ZU ERLEDIGEN: Hier zus�tzliche Initialisierung einf�gen
	m_pShortcut = new CShortcut;
	iIconIndex = 38;
	m_R1.SetCheck(1);

		if(m_cfSmall.CreatePointFont(80, "New courier"))
			{
				m_statPath.SetFont(&m_cfSmall);
			}
	
	
	// check on startup if links are already there:
	if(m_pShortcut->isLinkAvailable("Test Link", CSIDL_DESKTOP))
			m_R1.m_crTextClr = RGB(250,0,0);
	if(m_pShortcut->isLinkAvailable("Test Link", CSIDL_STARTMENU))
			m_R2.m_crTextClr = RGB(250,0,0);
	if(m_pShortcut->isLinkAvailable("Test Link", CSIDL_SENDTO))
			m_R3.m_crTextClr = RGB(250,0,0);
	if(m_pShortcut->isLinkAvailable("Test Link", CSIDL_PROGRAMS))
			m_R4.m_crTextClr = RGB(250,0,0);

	return TRUE;  // Geben Sie TRUE zur�ck, au�er ein Steuerelement soll den Fokus erhalten
}

void CShortcutDemoDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// Wollen Sie Ihrem Dialogfeld eine Schaltfl�che "Minimieren" hinzuf�gen, ben�tigen Sie 
//  den nachstehenden Code, um das Symbol zu zeichnen. F�r MFC-Anwendungen, die das 
//  Dokument/Ansicht-Modell verwenden, wird dies automatisch f�r Sie erledigt.

void CShortcutDemoDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // Ger�tekontext f�r Zeichnen

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Symbol in Client-Rechteck zentrieren
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Symbol zeichnen
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

void CShortcutDemoDlg::OnDestroy() 
{
	CDialog::OnDestroy();
	
delete m_pShortcut;
}


HCURSOR CShortcutDemoDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}



///////////////////////////////////////////////////////////////////////////////////////////
void CShortcutDemoDlg::OnBCreate() 
{
CString sBuf;
CHAR *buf = sBuf.GetBuffer(MAX_PATH);
	GetSystemDirectory(buf, 256);
	lstrcat(buf,"\\shell32.dll");   
		sBuf.ReleaseBuffer();
	
	iIconIndex++;
	
	if(m_R1.GetCheck())
		{
			if(m_pShortcut->CreateShortCut("_this",
									"Test Link",
									CSIDL_DESKTOP,
									"Desktop ShellLink",
									sBuf,
									iIconIndex))
				{
					m_R1.m_crTextClr = RGB(250,0,0);
					m_R1.SetWindowText("link on the \"DESKTOP\" exists");
					RedrawWindow();
				}
		}
	if(m_R2.GetCheck())
		{
			if(m_pShortcut->CreateShortCut("_this",
										"Test Link",
										CSIDL_STARTMENU,
										"Startmenu ShellLink",
										sBuf,
										iIconIndex))
				{
					m_R2.m_crTextClr = RGB(250,0,0);
					m_R2.SetWindowText("link in the \"STARTMENU\" exists");
					RedrawWindow();
				}
		}
	if(m_R3.GetCheck())
		{
			if(m_pShortcut->CreateShortCut("_this",
										"Test Link",
										CSIDL_SENDTO,
										"SendTo-folder ShellLink",
										sBuf,
										iIconIndex))
				{
					m_R3.m_crTextClr = RGB(250,0,0);
					m_R3.SetWindowText("link in the \"SENDTO\" folder exists");
					RedrawWindow();
				}
		}
	if(m_R4.GetCheck())
		{
			if(m_pShortcut->CreateShortCut("_this",
										"Test Link",
										CSIDL_PROGRAMS,
										"Programms-menu ShellLink",
										sBuf,
										iIconIndex))
				{
					m_R4.m_crTextClr = RGB(250,0,0);
					m_R4.SetWindowText("link in the \"PROGRAMMS\" menu exists");
					RedrawWindow();
				}
		}
}





void CShortcutDemoDlg::OnBDelete() 
{
	if(m_R1.GetCheck())
		{
			if(m_pShortcut->DeleteShortCut("Test Link", CSIDL_DESKTOP))
				{
					m_R1.m_crTextClr = RGB(0,0,255);
					m_R1.SetWindowText("create link on the \"DESKTOP\"");
					RedrawWindow();
				}
		}
	if(m_R2.GetCheck())
		{
			if(m_pShortcut->DeleteShortCut("Test Link", CSIDL_STARTMENU))
				{
					m_R2.m_crTextClr = RGB(0,0,255);
					m_R2.SetWindowText("create link in the \"STARTMENU\"");
					RedrawWindow();
				}
		}
	if(m_R3.GetCheck())
		{
			if(m_pShortcut->DeleteShortCut("Test Link", CSIDL_SENDTO))
				{
					m_R3.m_crTextClr = RGB(0,0,255);
					m_R3.SetWindowText("create link in the \"SENDTO\" folder");
					RedrawWindow();
				}
		}
	if(m_R4.GetCheck())
		{
			if(m_pShortcut->DeleteShortCut("Test Link", CSIDL_PROGRAMS))
				{
					m_R4.m_crTextClr = RGB(0,0,255);
					m_R4.SetWindowText("create link in the \"PROGRAMMS\" menu");
					RedrawWindow();
				}
		}
}






void CShortcutDemoDlg::OnBResolve() 
{
	CString sPath, sDesc;

	if(m_R1.GetCheck())
		{
			m_pShortcut->ResolveLink("Test Link", CSIDL_DESKTOP, m_hWnd, sPath, sDesc);
				m_statPath.SetWindowText(sPath);
					m_statDesc.SetWindowText(sDesc);
		}
	if(m_R2.GetCheck())
		{
			m_pShortcut->ResolveLink("Test Link", CSIDL_STARTMENU, m_hWnd, sPath, sDesc);
				m_statPath.SetWindowText(sPath);
					m_statDesc.SetWindowText(sDesc);
		}
	if(m_R3.GetCheck())
		{
			m_pShortcut->ResolveLink("Test Link", CSIDL_SENDTO, m_hWnd, sPath, sDesc);
				m_statPath.SetWindowText(sPath);
					m_statDesc.SetWindowText(sDesc);
		}
	if(m_R4.GetCheck())
		{
			m_pShortcut->ResolveLink("Test Link", CSIDL_PROGRAMS, m_hWnd, sPath, sDesc);
				m_statPath.SetWindowText(sPath);
					m_statDesc.SetWindowText(sDesc);
		}
}
