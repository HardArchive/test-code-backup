//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by duck.rc
//
#define IDS_PROJNAME                    100
#define IDR_Duck                        100
#define IDR_DUCKINT                     101
#define IDD_MAINDLG                     201
#define IDC_CREATEDODUCK                201
#define IDC_DESTROYDODUCK               205
#define IDC_COOKIE                      206
#define IDC_STATUS                      207
#define IDC_ADVISE                      210
#define IDC_UNADVISE                    211

// Next default values for new objects
//
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        203
#define _APS_NEXT_COMMAND_VALUE         32768
#define _APS_NEXT_CONTROL_VALUE         211
#define _APS_NEXT_SYMED_VALUE           103
#endif
#endif
