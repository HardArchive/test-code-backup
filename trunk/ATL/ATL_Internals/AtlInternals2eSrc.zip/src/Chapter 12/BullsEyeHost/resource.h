//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by BullsEyeHost.rc
//
#define IDS_PROJNAME                    100
#define IDS_WINDOWTITLE                 101
#define IDD_DARTBOARD                   102
#define IDR_MENU1                       201
#define IDR_MAINMENU                    201
#define IDC_BULLSEYE1                   201
#define IDC_BULLSEYE                    201
#define IDC_SCORE                       202
#define ID_STATIC                       202
#define ID_RESET                        203
#define File                            32768
#define ID_FILE_EXIT                    32769
#define ID_WINDOWS_DARTBOARD            32770

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        203
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         204
#define _APS_NEXT_SYMED_VALUE           103
#endif
#endif
