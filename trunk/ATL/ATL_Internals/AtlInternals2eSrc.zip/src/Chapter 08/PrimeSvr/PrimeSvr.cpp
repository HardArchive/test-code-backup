// PrimeSvr.cpp : Implementation of WinMain

#include "stdafx.h"
#include "resource.h"

// The module attribute causes WinMain to be automatically implemented for you
[ module(EXE, uuid = "{CAE2D17F-5557-47D6-A7DC-C919C4F87EC8}", 
		 name = "PrimeSvr", 
		 helpstring = "PrimeSvr 1.0 Type Library",
		 resource_name = "IDR_PRIMESVR") ];
