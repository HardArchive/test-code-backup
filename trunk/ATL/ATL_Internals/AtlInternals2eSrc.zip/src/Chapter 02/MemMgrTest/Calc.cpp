// Calc.cpp : Implementation of CCalc

#include "stdafx.h"
#include "Calc.h"


// CCalc

