// MemMgrTest.cpp : Implementation of DLL Exports.

#include "stdafx.h"
#include "resource.h"

// The module attribute causes DllMain, DllRegisterServer and DllUnregisterServer to be automatically implemented for you
[ module(dll, uuid = "{AB9C13F1-07B7-46E7-BC35-74C4D72E33DB}", 
		 name = "MemMgrTest", 
		 helpstring = "MemMgrTest 1.0 Type Library",
		 resource_name = "IDR_MEMMGRTEST") ];
