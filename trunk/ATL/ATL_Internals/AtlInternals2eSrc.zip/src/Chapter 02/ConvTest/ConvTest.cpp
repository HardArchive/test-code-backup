// ConvTest.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <atlbase.h>
#define OLE2ANSI

int _tmain(int argc, _TCHAR* argv[])
{
	FuncA();
	return 0;
}

void FuncA()
{
}

void FuncB()
{
}

