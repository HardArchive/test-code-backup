// Documents.cpp : Implementation of CDocuments
#include "stdafx.h"
#include "ObjectModel.h"
#include "Documents.h"

/////////////////////////////////////////////////////////////////////////////
// CDocuments

