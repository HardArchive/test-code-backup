// Application.cpp : Implementation of CApplication
#include "stdafx.h"
#include "ObjectModel.h"
#include "Application.h"

/////////////////////////////////////////////////////////////////////////////
// CApplication

