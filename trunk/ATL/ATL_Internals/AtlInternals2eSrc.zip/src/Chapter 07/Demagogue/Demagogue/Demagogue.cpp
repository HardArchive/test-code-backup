// Demagogue.cpp : Implementation of DLL Exports.

#include "stdafx.h"
#include "resource.h"

// The module attribute causes DllMain, DllRegisterServer and DllUnregisterServer to be automatically implemented for you
[ module(dll, uuid = "{CCE3588E-05D9-440A-80AD-EA0CC00DEAC3}", 
		 name = "Demagogue", 
		 helpstring = "Demagogue 1.0 Type Library",
		 resource_name = "IDR_DEMAGOGUE") ];
