// CoEarPolitic.cpp : Implementation of CEarPolitic

#include "stdafx.h"
#include "CoEarPolitic.h"


// CEarPolitic

