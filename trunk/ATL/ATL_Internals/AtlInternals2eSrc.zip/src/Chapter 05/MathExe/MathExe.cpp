// MathExe.cpp : Implementation of WinMain

#include "stdafx.h"
#include "resource.h"

// The module attribute causes WinMain to be automatically implemented for you
[ module(EXE, uuid = "{F8D5EF98-6A4C-4E92-899F-97A7B8FB31F6}", 
		 name = "MathExe", 
		 helpstring = "MathExe 1.0 Type Library",
		 resource_name = "IDR_MATHEXE") ];
