// ShowTrafDoc.cpp : implementation of the CShowTrafDoc class
//

#include "stdafx.h"
#include "ShowTraf.h"

#include "ShowTrafDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CShowTrafDoc

IMPLEMENT_DYNCREATE(CShowTrafDoc, CDocument)

BEGIN_MESSAGE_MAP(CShowTrafDoc, CDocument)
	//{{AFX_MSG_MAP(CShowTrafDoc)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CShowTrafDoc construction/destruction

CShowTrafDoc::CShowTrafDoc()
{
	// TODO: add one-time construction code here

}

CShowTrafDoc::~CShowTrafDoc()
{
}

BOOL CShowTrafDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	// TODO: add reinitialization code here
	// (SDI documents will reuse this document)

	return TRUE;
}



/////////////////////////////////////////////////////////////////////////////
// CShowTrafDoc serialization

void CShowTrafDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO: add storing code here
	}
	else
	{
		// TODO: add loading code here
	}
}

/////////////////////////////////////////////////////////////////////////////
// CShowTrafDoc diagnostics

#ifdef _DEBUG
void CShowTrafDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CShowTrafDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CShowTrafDoc commands
