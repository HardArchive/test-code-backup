//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by ShowTraf.rc
//
#define IDD_ABOUTBOX                    100
#define ID_BYTES_SEC                    101
#define IDR_MAINFRAME                   128
#define IDR_SHOWTRTYPE                  129
#define IDD_SETTINGS                    131
#define IDD_FILTERS                     134
#define IDC_IDLESECONDS                 1000
#define IDC_SITE                        1001
#define IDC_DELETEMB                    1001
#define IDC_AUTHOR                      1002
#define IDC_INFO                        1003
#define IDC_HOME                        1005
#define IDC_USELOG                      1006
#define IDC_LOGTYPE                     1007
#define IDC_LOGFILE                     1008
#define IDC_BROWSE                      1009
#define IDC_DELETELOG                   1010
#define IDC_STATIC1                     1012
#define IDC_STATIC2                     1013
#define IDC_STATIC3                     1014
#define IDC_AUTOSTART                   1015
#define IDC_UNITS                       1016
#define IDC_FILTERS                     1018
#define IDC_ADD                         1019
#define IDC_REMOVE                      1020
#define IDC_CHANGE                      1021
#define IDC_APPLY                       1022
#define IDC_WINPCAP                     1022
#define IDC_SYNTAX                      1023
#define ID_COMMAND_START                32771
#define ID_COMMAND_STOP                 32772
#define ID_COMMAND_EXIT                 32773
#define ID_FILTER_TCP                   32777
#define ID_FILTER_UDP                   32778
#define ID_FILTER_ICMP                  32779
#define ID_COPY_SRC_IP                  32780
#define ID_COPY_DEST_IP                 32781
#define ID_COPY_SRC_PORT                32782
#define ID_COPY_DEST_PORT               32783
#define ID_COPY_ALL                     32784
#define IDC_ADAPTER_COMBO               32785
#define ID_FILTER_REMOVESORTING         32786
#define ID_VIEW_ALWAYSONTOP             32788
#define ID_VIEW_RESOLVEADDRESSES        32792
#define ID_VIEW_RESOLVEPORTNAMES        32795
#define ID_VIEW_SETTINGS                32797
#define ID_HELP_DOCUMENTATION           32800
#define ID_HELP_TEST_TEST2              32803
#define IDC_TOOLS_FILTERS               32804
#define ID_TOOLS_FILTERS                32805
#define ID_FILTER_SETUP                 -32730
#define ID_COMMAND_FREEZE               32809
#define IDS_BEGIN                       61204
#define IDS_NODATA                      61205
#define IDS_INFO                        61206
#define IDS_OPENED                      61207

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        138
#define _APS_NEXT_COMMAND_VALUE         32811
#define _APS_NEXT_CONTROL_VALUE         1023
#define _APS_NEXT_SYMED_VALUE           102
#endif
#endif
