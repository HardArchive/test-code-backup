// FilterManager.h: interface for the CFilterManager class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_FILTERMANAGER_H__D58B7B7E_6F00_4E46_A5E6_21A3C73FCAA7__INCLUDED_)
#define AFX_FILTERMANAGER_H__D58B7B7E_6F00_4E46_A5E6_21A3C73FCAA7__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define MAX_FILTER_LINE_LEN		500

class CFilterManager  
{
public:
	CFilterManager();
	virtual ~CFilterManager();

	void OnCaptureStarted();
	void OnCaptureStop();
	void Clear();

	void SaveFiltersFile();
	void ToListCtrl(CListCtrl* ctrl);
	void FromListCtrl(const CListCtrl* ctrl);

protected:

	typedef struct _TFilterLine {
		char szFilter[MAX_FILTER_LINE_LEN];
		BOOL checked;
		struct bpf_program bpf;
		struct _TFilterLine* next;
	} TFilterLine;

	TFilterLine* m_filters;
	TFilterLine** m_last;

	TCHAR m_szFiltersFileName[MAX_PATH];

	void LoadFiltersFile();
	void ApplyFilters(BOOL forsed = FALSE);
	BOOL m_applied;

};

#endif // !defined(AFX_FILTERMANAGER_H__D58B7B7E_6F00_4E46_A5E6_21A3C73FCAA7__INCLUDED_)
