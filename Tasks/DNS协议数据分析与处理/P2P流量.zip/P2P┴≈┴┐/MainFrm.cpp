// MainFrm.cpp : implementation of the CMainFrame class
//

#include "stdafx.h"
#include "ShowTraf.h"
#include "PacketCapture.h"
#include "SettingsDlg.h"
#include "pcap.h"
#include "FiltersSetupDlg.h"

#include "MainFrm.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMainFrame

IMPLEMENT_DYNCREATE(CMainFrame, CFrameWnd)

BEGIN_MESSAGE_MAP(CMainFrame, CFrameWnd)
	//{{AFX_MSG_MAP(CMainFrame)
	ON_WM_CREATE()
	ON_UPDATE_COMMAND_UI(ID_COMMAND_EXIT, OnUpdateCommandExit)
	ON_COMMAND(ID_COMMAND_EXIT, OnCommandExit)
	ON_UPDATE_COMMAND_UI(ID_VIEW_ALWAYSONTOP, OnUpdateViewAlwaysOnTop)
	ON_COMMAND(ID_VIEW_ALWAYSONTOP, OnViewAlwaysOnTop)
	ON_UPDATE_COMMAND_UI(ID_VIEW_RESOLVEADDRESSES, OnUpdateViewResolveAddresses)
	ON_COMMAND(ID_VIEW_RESOLVEADDRESSES, OnViewResolveAddresses)
	ON_UPDATE_COMMAND_UI(ID_VIEW_RESOLVEPORTNAMES, OnUpdateViewResolvePortNames)
	ON_COMMAND(ID_VIEW_RESOLVEPORTNAMES, OnViewResolvePortNames)
	ON_WM_CLOSE()
	ON_UPDATE_COMMAND_UI(ID_VIEW_SETTINGS, OnUpdateViewSettings)
	ON_COMMAND(ID_VIEW_SETTINGS, OnViewSettings)
	ON_WM_MEASUREITEM()
	ON_WM_MENUCHAR()
	ON_WM_INITMENUPOPUP()
	ON_UPDATE_COMMAND_UI(ID_HELP_DOCUMENTATION, OnUpdateHelpDocumentation)
	ON_COMMAND(ID_HELP_DOCUMENTATION, OnHelpDocumentation)
	ON_COMMAND(ID_FILTER_SETUP, OnFilterSetup)
	ON_WM_DESTROY()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

static UINT indicators[] =
{
	ID_SEPARATOR,           // status line indicator
	ID_BYTES_SEC
};

/////////////////////////////////////////////////////////////////////////////
// CMainFrame construction/destruction

CMainFrame::CMainFrame()
{
WSADATA wsadata;

	WSAStartup(0x0101, &wsadata);	
}

CMainFrame::~CMainFrame()
{
	m_menu.DestroyMenu();
	WSACleanup();
}

int CMainFrame::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CFrameWnd::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	if (!m_wndToolBar.CreateEx(this) ||
		!m_wndToolBar.LoadToolBar(IDR_MAINFRAME)) {
		TRACE0("Failed to create toolbar\n");
		return -1;      // fail to create
	}
	if (!m_wndReBar.Create(this) ||
		!m_wndReBar.AddBar(&m_wndToolBar)) {
		TRACE0("Failed to create rebar\n");
		return -1;      // fail to create
	}

	if (!m_wndStatusBar.Create(this) ||
		!m_wndStatusBar.SetIndicators(indicators,
		  sizeof(indicators)/sizeof(UINT)))
	{
		TRACE0("Failed to create status bar\n");
		return -1;      // fail to create
	}
	m_wndStatusBar.SetPaneInfo(1, ID_BYTES_SEC, SBPS_NORMAL, 200);

	m_wndToolBar.SetBarStyle(m_wndToolBar.GetBarStyle() |
		CBRS_TOOLTIPS | CBRS_FLYBY);

	// update application title
	CString sTitle;
	sTitle.LoadString(AFX_IDS_APP_TITLE);
	SetWindowText(sTitle);

	// init toolbar adapter combo
    #define ADAPTER_WIDTH 250 //the width of the combo box

    //First get the index of the placeholder's position in the toolbar
	int index = 0;
	while (m_wndToolBar.GetItemID(index) != IDC_ADAPTER_COMBO) index++;

	//next convert that button to a seperator and get its position
	m_wndToolBar.SetButtonInfo(index, IDC_ADAPTER_COMBO, TBBS_SEPARATOR, ADAPTER_WIDTH);
	CRect rect;
	m_wndToolBar.GetItemRect(index, &rect);

	//expand the rectangle to allow the combo box room to drop down
	rect.top += 1;
	rect.bottom += 200;

    // then .Create the combo box and show it
	if (!m_wndAdapter.Create(WS_CHILD|WS_VISIBLE | CBS_AUTOHSCROLL | 
                                       CBS_DROPDOWNLIST | CBS_HASSTRINGS ,
                                       rect, &m_wndToolBar, IDC_ADAPTER_COMBO))
	{
		TRACE0("Failed to create combo-box\n");
		return -1;
    }
	// set combo box font
	CFont *pFnt = m_wndStatusBar.GetFont();
	m_wndAdapter.SetFont(pFnt);

	m_wndAdapter.ShowWindow(SW_SHOW);

	//fill the combo box
	GetAdapterList();
	m_wndAdapter.SetCurSel(g_Settings.m_iAdapterNum);

	g_pwndAdapter = &m_wndAdapter;
	g_pwndStatusBar = &m_wndStatusBar;

	// init from .ini file
	if (g_Settings.m_bAlwaysOnTop) 
		::SetWindowPos(m_hWnd, HWND_TOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE);
	else
		::SetWindowPos(m_hWnd, HWND_NOTOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE);
	g_NSCashe.EnableNameResolve(g_Settings.m_bNSResolve);
	g_ServicesParser.EnableServicesResolve(g_Settings.m_bPortResolve);

	if (g_Settings.m_bAutoStart)
		PostMessage(WM_COMMAND, ID_COMMAND_START);

	return 0;
}

BOOL CMainFrame::PreCreateWindow(CREATESTRUCT& cs)
{
	if( !CFrameWnd::PreCreateWindow(cs) )
		return FALSE;

	cs.style &= ~FWS_ADDTOTITLE;

	// restore saved window position
	if ((-1 != g_Settings.m_iMainStatus) &&
		(-1 != g_Settings.m_iMainTop) &&
		(-1 != g_Settings.m_iMainBottom) &&
		(-1 != g_Settings.m_iMainLeft) &&
		(-1 != g_Settings.m_iMainRight)) {

		AfxGetApp()->m_nCmdShow = g_Settings.m_iMainStatus; // restore the window's status
		// restore the window's width and height
		cs.cx = g_Settings.m_iMainRight - g_Settings.m_iMainLeft;
		cs.cy = g_Settings.m_iMainBottom - g_Settings.m_iMainTop;
                             
		// the following correction is needed when the taskbar is
		// at the left or top and it is not "auto-hidden"
		RECT workArea;
		SystemParametersInfo(SPI_GETWORKAREA, 0, &workArea, 0);
		g_Settings.m_iMainLeft += workArea.left;
		g_Settings.m_iMainTop += workArea.top;
                             
		// make sure the window is not completely out of sight
		int max_x = GetSystemMetrics(SM_CXSCREEN) - GetSystemMetrics(SM_CXICON);
		int max_y = GetSystemMetrics(SM_CYSCREEN) - GetSystemMetrics(SM_CYICON);
		cs.x = min(g_Settings.m_iMainLeft, max_x);
		cs.y = min(g_Settings.m_iMainTop, max_y);
	}
		
	return TRUE;
}

void CMainFrame::OnClose() 
{
	WINDOWPLACEMENT wp;
	GetWindowPlacement(&wp);

	// store saved window position
	g_Settings.m_iMainStatus = wp.showCmd;
	g_Settings.m_iMainTop = wp.rcNormalPosition.top;
	g_Settings.m_iMainBottom = wp.rcNormalPosition.bottom;
	g_Settings.m_iMainLeft =  wp.rcNormalPosition.left;
	g_Settings.m_iMainRight = wp.rcNormalPosition.right;	

	g_Settings.m_iAdapterNum = m_wndAdapter.GetCurSel();
	
	CFrameWnd::OnClose();
}
/////////////////////////////////////////////////////////////////////////////
// CMainFrame diagnostics

#ifdef _DEBUG
void CMainFrame::AssertValid() const
{
	CFrameWnd::AssertValid();
}

void CMainFrame::Dump(CDumpContext& dc) const
{
	CFrameWnd::Dump(dc);
}

#endif //_DEBUG

HMENU CMainFrame::NewMenu()
{
  // Load the menu from the resources
  m_menu.LoadMenu(IDR_MAINFRAME);  
  m_menu.LoadToolbar(IDR_MAINFRAME);

  return(m_menu.Detach());
}

/////////////////////////////////////////////////////////////////////////////
// CMainFrame methods

int CMainFrame::GetAdapterList()
{
	pcap_if_t *alldevs, *d;
	char errbuf[PCAP_ERRBUF_SIZE+1];

	if (pcap_findalldevs(&alldevs, errbuf) == -1) {
		TRACE("pcap_findalldevs(..) failed!\n");
		//m_wndAdapter.AddString(_T("Cannot find any supported device!"));
		return 0;
	}

	CString item;
	for (d = alldevs; d; d = d->next) {
		pcap_addr_t *a;
		BOOL found = FALSE;
		for(a = d->addresses; a; a = a->next) {
			switch(a->addr->sa_family) {
			case AF_INET:
				if (a->addr) {
					item = iptos(((struct sockaddr_in *)a->addr)->sin_addr.s_addr);
					found = TRUE;
				}
				break;
			}

			if (found) {
				item += _T(" - ");
				item += d->description;

				int pos = m_wndAdapter.AddString(item);
				char* data = new char[strlen(d->name) + 10];
				strcpy(data, d->name);
				m_wndAdapter.SetItemData(pos, (DWORD)data);
				break;
			}
		}
	}
	pcap_freealldevs(alldevs);

	// Find the longest string in the combo box.
	CString str;
	CSize   sz;
	int     dx = 0;
	CDC*    pDC = m_wndAdapter.GetDC();
	
	for (int i=0;i < m_wndAdapter.GetCount(); i++) {
		m_wndAdapter.GetLBText( i, str );
		sz = pDC->GetTextExtent(str);

		if (sz.cx > dx)
			dx = sz.cx;
	}
	m_wndAdapter.ReleaseDC(pDC);

	// Adjust the width for the vertical scroll bar and the left and right border.
	dx += ::GetSystemMetrics(SM_CXVSCROLL) + 2 * ::GetSystemMetrics(SM_CXEDGE);

	// Set the width of the list box so that every item is completely visible.
	m_wndAdapter.SetDroppedWidth(dx);

	return m_wndAdapter.GetCount();
}

void CMainFrame::OnUpdateCommandExit(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable();	
}

void CMainFrame::OnCommandExit() 
{
	PostQuitMessage(0);	
}

void CMainFrame::OnUpdateViewAlwaysOnTop(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable();
	pCmdUI->SetCheck(g_Settings.m_bAlwaysOnTop);
}

void CMainFrame::OnViewAlwaysOnTop() 
{
	g_Settings.m_bAlwaysOnTop = !g_Settings.m_bAlwaysOnTop;
	if (g_Settings.m_bAlwaysOnTop) 
		::SetWindowPos(m_hWnd, HWND_TOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE);
	else
		::SetWindowPos(m_hWnd, HWND_NOTOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE);
}

void CMainFrame::OnUpdateViewResolveAddresses(CCmdUI* pCmdUI) 
{
	pCmdUI->SetCheck(g_Settings.m_bNSResolve);
}

void CMainFrame::OnViewResolveAddresses() 
{
	g_Settings.m_bNSResolve = !g_Settings.m_bNSResolve;
	g_NSCashe.EnableNameResolve(g_Settings.m_bNSResolve);
}

void CMainFrame::OnUpdateViewResolvePortNames(CCmdUI* pCmdUI) 
{
	pCmdUI->SetCheck(g_Settings.m_bPortResolve);
}

void CMainFrame::OnViewResolvePortNames() 
{
	g_Settings.m_bPortResolve = !g_Settings.m_bPortResolve;
	g_ServicesParser.EnableServicesResolve(g_Settings.m_bPortResolve);
}

void CMainFrame::OnUpdateViewSettings(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable();	
}

void CMainFrame::OnViewSettings() 
{
	CSettingsDlg dlg;
	dlg.m_dwIdleSeconds = g_Settings.m_dwIdleSeconds / 1000;
	dlg.m_bUseLog = g_Settings.m_bUseLog;
	dlg.m_iLogType = g_Settings.m_iLogType;
	dlg.m_sLogFile = g_Settings.m_sLogFile;
	dlg.m_bAutoDelete = g_Settings.m_bAutoDelete;
	dlg.m_iMBDelete = g_Settings.m_iMBDelete;
	dlg.m_bAutoStart = g_Settings.m_bAutoStart;
	dlg.m_iUnits = g_Settings.m_iUnits;
	if (IDOK == dlg.DoModal()) {
		g_Settings.m_dwIdleSeconds = dlg.m_dwIdleSeconds * 1000;
		g_Settings.m_bUseLog = dlg.m_bUseLog;
		g_Settings.m_iLogType = dlg.m_iLogType;
		_tcscpy(g_Settings.m_sLogFile, (LPCTSTR)dlg.m_sLogFile);
		g_Settings.m_bAutoDelete = dlg.m_bAutoDelete;
		g_Settings.m_iMBDelete = dlg.m_iMBDelete;
		g_lTotalDelBytes = dlg.m_iMBDelete * 1024 * 1024;
		g_Settings.m_bAutoStart = dlg.m_bAutoStart;
		g_Settings.m_iUnits = dlg.m_iUnits;
	}
}

void CMainFrame::OnMeasureItem(int nIDCtl, LPMEASUREITEMSTRUCT lpMeasureItemStruct) 
{
BOOL setflag=FALSE;
	
	if(lpMeasureItemStruct->CtlType==ODT_MENU) {
		if(IsMenu((HMENU)lpMeasureItemStruct->itemID)) {
			CMenu* cmenu = 
			CMenu::FromHandle((HMENU)lpMeasureItemStruct->itemID);

			if(m_menu.IsMenu(cmenu)) {
				m_menu.MeasureItem(lpMeasureItemStruct);
				setflag=TRUE;
			}
		}
	}

	if (!setflag)	
		CFrameWnd::OnMeasureItem(nIDCtl, lpMeasureItemStruct);
}

LRESULT CMainFrame::OnMenuChar(UINT nChar, UINT nFlags, CMenu* pMenu) 
{
	if (m_menu.IsMenu(pMenu))
		return BCMenu::FindKeyboardShortcut(nChar, nFlags, pMenu);
	else
		return CFrameWnd::OnMenuChar(nChar, nFlags, pMenu);
}

void CMainFrame::OnInitMenuPopup(CMenu* pPopupMenu, UINT nIndex, BOOL bSysMenu) 
{
	CFrameWnd::OnInitMenuPopup(pPopupMenu, nIndex, bSysMenu);
	
	if (!bSysMenu)
		if (m_menu.IsMenu(pPopupMenu))
			BCMenu::UpdateMenu(pPopupMenu);
}

void CMainFrame::OnUpdateHelpDocumentation(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable();	
}

void CMainFrame::OnHelpDocumentation() 
{
char szFileName[_MAX_PATH], *SlashPos;

	// create directory name
	GetModuleFileName(NULL, szFileName, _MAX_PATH);
	SlashPos = strrchr(szFileName, '\\');
	if (NULL == SlashPos)
		SlashPos = szFileName;
	else
		SlashPos++;
	strcpy(SlashPos, "help");
	// execute HTML file
	::ShellExecute(m_hWnd, "open", "ShowTraf.html", NULL, szFileName, SW_SHOWNORMAL);
}

// From tcptraceroute, convert a numeric IP address to a string
#define IPTOSBUFFERS	12
char* CMainFrame::iptos(u_long in)
{
	static char output[IPTOSBUFFERS][3*4+3+1];
	static short which;
	u_char *p;

	p = (u_char *)&in;
	which = (which + 1 == IPTOSBUFFERS ? 0 : which + 1);
	sprintf(output[which], "%d.%d.%d.%d", p[0], p[1], p[2], p[3]);
	return output[which];
}

void CMainFrame::OnFilterSetup() 
{
	CFiltersSetupDlg dlg;
	dlg.DoModal();
}

void CMainFrame::OnDestroy() 
{
	CFrameWnd::OnDestroy();
	
	int count = m_wndAdapter.GetCount();
	for (int i = 0; i < count; i++) {
		delete (char *)m_wndAdapter.GetItemData(i);
	}

	m_menu.DestroyMenu();
}
