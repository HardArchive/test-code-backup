#if !defined(AFX_FILTERSSETUPDLG_H__7A995D8F_204D_4FEF_8343_374F93E56EB1__INCLUDED_)
#define AFX_FILTERSSETUPDLG_H__7A995D8F_204D_4FEF_8343_374F93E56EB1__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// FiltersSetupDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CFiltersSetupDlg dialog

class CFiltersSetupDlg : public CDialog
{
// Construction
public:
	CFiltersSetupDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CFiltersSetupDlg)
	enum { IDD = IDD_FILTERS };
	CListCtrl	m_filters;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFiltersSetupDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	char* CheckFilter(char* filter);

	// Generated message map functions
	//{{AFX_MSG(CFiltersSetupDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnAdd();
	afx_msg void OnEndLabelEditFilters(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnItemChangedFilters(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnRemove();
	afx_msg void OnChange();
	virtual void OnOK();
	afx_msg void OnApply();
	afx_msg void OnSyntax();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FILTERSSETUPDLG_H__7A995D8F_204D_4FEF_8343_374F93E56EB1__INCLUDED_)
