// ShowTrafView.cpp : implementation of the CShowTrafView class
//

#include "stdafx.h"
#include "ShowTraf.h"
#include "ShowTrafDoc.h"
#include "ShowTrafView.h"
#include "PacketCapture.h"
#include "TrafficList.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#define TIMER_ID		(1)

// global file vars
static int s_iSortColumn;
static BOOL s_bSortAscending;
static LVFINDINFO fi;

int CALLBACK CompareFunction(LPARAM lParam1,LPARAM lParam2,LPARAM lParamData);

/////////////////////////////////////////////////////////////////////////////
// data for the list view control

#define NUM_COLUMNS	8

static _TCHAR *_gszColumnLabel[NUM_COLUMNS] =
{
	_T("Source"), _T("src port"), _T("Destination"), _T("dest port"), _T("Proto"), _T("Traffic"), _T("Speed"), _T("Average speed")
};

static int _gnColumnFmt[NUM_COLUMNS] = 
{
	LVCFMT_LEFT, LVCFMT_RIGHT, LVCFMT_LEFT, LVCFMT_RIGHT, LVCFMT_RIGHT, LVCFMT_RIGHT, LVCFMT_RIGHT, LVCFMT_RIGHT
};

static int _gnColumnWidth[NUM_COLUMNS] = 
{
	120, 80, 120, 80, 50, 100, 90, 90
};

static BOOL _gbColumnNumber[NUM_COLUMNS] = 
{
	FALSE, TRUE, FALSE, TRUE, FALSE, TRUE, TRUE, TRUE
};

/////////////////////////////////////////////////////////////////////////////
// CShowTrafView

IMPLEMENT_DYNCREATE(CShowTrafView, CListView)

BEGIN_MESSAGE_MAP(CShowTrafView, CListView)
	//{{AFX_MSG_MAP(CShowTrafView)
	ON_UPDATE_COMMAND_UI(ID_COMMAND_START, OnUpdateCommandStart)
	ON_UPDATE_COMMAND_UI(ID_COMMAND_STOP, OnUpdateCommandStop)
	ON_WM_PAINT()
	ON_COMMAND(ID_COMMAND_START, OnCommandStart)
	ON_COMMAND(ID_COMMAND_STOP, OnCommandStop)
	ON_WM_DESTROY()
	ON_NOTIFY_REFLECT(LVN_COLUMNCLICK, OnColumnClick)
	ON_UPDATE_COMMAND_UI(ID_FILTER_REMOVESORTING, OnUpdateFilterRemoveSorting)
	ON_COMMAND(ID_FILTER_REMOVESORTING, OnFilterRemoveSorting)
	ON_UPDATE_COMMAND_UI(ID_FILTER_TCP, OnUpdateFilterTcp)
	ON_UPDATE_COMMAND_UI(ID_FILTER_UDP, OnUpdateFilterUdp)
	ON_UPDATE_COMMAND_UI(ID_FILTER_ICMP, OnUpdateFilterIcmp)
	ON_COMMAND(ID_FILTER_TCP, OnFilterTcp)
	ON_COMMAND(ID_FILTER_UDP, OnFilterUdp)
	ON_COMMAND(ID_FILTER_ICMP, OnFilterIcmp)
	ON_WM_RBUTTONDOWN()
	ON_COMMAND(ID_COPY_SRC_IP, OnCopySourceIP)
	ON_COMMAND(ID_COPY_SRC_PORT, OnCopySourcePort)
	ON_COMMAND(ID_COPY_DEST_IP, OnCopyDestinationIP)
	ON_COMMAND(ID_COPY_DEST_PORT, OnCopyDestinationPort)
	ON_COMMAND(ID_COPY_ALL, OnCopyAll)
	ON_COMMAND(ID_EDIT_CLEAR_ALL, OnEditClearAll)
	ON_COMMAND(ID_COMMAND_FREEZE, OnCommandFreeze)
	ON_UPDATE_COMMAND_UI(ID_COMMAND_FREEZE, OnUpdateCommandFreeze)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CShowTrafView construction/destruction

CShowTrafView::CShowTrafView()
{
	m_hAdapterMutex = NULL;
	memset(&fi, 0, sizeof(LVFINDINFO));
	fi.flags = LVFI_PARAM;
	s_iSortColumn = -1;
}

CShowTrafView::~CShowTrafView()
{
}

/////////////////////////////////////////////////////////////////////////////
// CShowTrafView drawing

void CShowTrafView::OnDraw(CDC* pDC)
{
	CShowTrafDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	// TODO: add draw code for native data here
}

void CShowTrafView::OnInitialUpdate()
{
	CListView::OnInitialUpdate();

	// my code
	_gnColumnWidth[0] = g_Settings.m_iListSrcAddr;
	_gnColumnWidth[2] = g_Settings.m_iListDestAddr;
	_gnColumnWidth[1] = g_Settings.m_iListSrcPort;
	_gnColumnWidth[3] = g_Settings.m_iListDestPort;
	_gnColumnWidth[4] = g_Settings.m_iListProto;
	_gnColumnWidth[5] = g_Settings.m_iListTraffic;
	_gnColumnWidth[6] = g_Settings.m_iListBS;
	_gnColumnWidth[7] = g_Settings.m_iListABS;
	
	CListCtrl& lc_AddrList = GetListCtrl();

	// set report style
	long lStyle = GetWindowLong(lc_AddrList.m_hWnd, GWL_STYLE);
	lStyle &= ~(LVS_TYPEMASK);  // turn off all the style (view mode) bits
	lStyle |= LVS_REPORT;       // Set the new style for the control
	SetWindowLong(lc_AddrList.m_hWnd, GWL_STYLE, lStyle);

	// set other styles
	DWORD dwExStyle = lc_AddrList.GetExtendedStyle();
	lc_AddrList.SetExtendedStyle(dwExStyle | 
		LVS_EX_FULLROWSELECT | LVS_EX_HEADERDRAGDROP | LVS_EX_GRIDLINES);

	// insert columns
	LV_COLUMN lvc;
	lvc.mask = LVCF_FMT | LVCF_WIDTH | LVCF_TEXT | LVCF_SUBITEM;

	for(int iCounter = 0; iCounter < NUM_COLUMNS; iCounter++) {
		lvc.iSubItem = iCounter;
		lvc.pszText = _gszColumnLabel[iCounter];
		lvc.cx = _gnColumnWidth[iCounter];
		lvc.fmt = _gnColumnFmt[iCounter];
		lc_AddrList.InsertColumn(iCounter, &lvc);
	}

	g_pwndTraffic = &GetListCtrl();

	VERIFY(m_ctlHeader.SubclassWindow(lc_AddrList.GetHeaderCtrl()->GetSafeHwnd()));
}

/////////////////////////////////////////////////////////////////////////////
// CShowTrafView diagnostics

#ifdef _DEBUG
void CShowTrafView::AssertValid() const
{
	CListView::AssertValid();
}

void CShowTrafView::Dump(CDumpContext& dc) const
{
	CListView::Dump(dc);
}

CShowTrafDoc* CShowTrafView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CShowTrafDoc)));
	return (CShowTrafDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CShowTrafView message handlers

void CShowTrafView::OnUpdateCommandStart(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(!g_bStarted);	
}

void CShowTrafView::OnUpdateCommandStop(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(g_bStarted);	
}

void CShowTrafView::OnPaint() 
{
    if (GetListCtrl().GetItemCount() == 0)  { // show empty list message
        CPaintDC dc( this );
        int nSavedDC = dc.SaveDC();
        
        CRect rc;
        GetClientRect( &rc );
        
        CHeaderCtrl* pHC;
        pHC = GetListCtrl().GetHeaderCtrl();
        if (pHC != NULL) {
            CRect rcH;
            pHC->GetItemRect( 0, &rcH );
            rc.top += rcH.bottom;
        }
        rc.top += 10;
        
        CString strText;
        if (g_bStarted)
			strText.LoadString(IDS_NODATA);
		else
			strText.LoadString(IDS_BEGIN);
        
        dc.SetTextColor( ::GetSysColor( COLOR_WINDOWTEXT ) );
        dc.SetBkColor( ::GetSysColor( COLOR_WINDOW ) );
        dc.SelectStockObject( ANSI_VAR_FONT );
        dc.DrawText( strText, rc, DT_CENTER | DT_WORDBREAK | DT_NOPREFIX | DT_NOCLIP );
        
        dc.RestoreDC(nSavedDC);
    }
    else {
        Default();
    }
}

void CShowTrafView::CreateMutexName(const char *szInput, char *szOutput)
{
	strcpy(szOutput, "st_"); // mutex name begin (st comes from ShowTraf)
	strcat(szOutput, szInput); // adds Input as the rest of the mutex name
	int iLen = strlen(szOutput);
	// replace all '\\' with '_'
	for (int i = 0; i < iLen; i++)
		if (('\\' == szOutput[i]) || ('/' == szOutput[i]) || (':' == szOutput[i]))
			szOutput[i] = '_';
}

void CShowTrafView::OnCommandStart() 
{
	// get selected adapter
	char szMutexName[512];
	const char* szAdapter = (char *)g_pwndAdapter->GetItemData(g_pwndAdapter->GetCurSel());
	if ((CB_ERR == (int)szAdapter) || (NULL == szAdapter))
		return;

	// check if we have such adapter already started
	CreateMutexName(szAdapter, szMutexName);
	m_hAdapterMutex = OpenMutex(MUTEX_ALL_ACCESS, FALSE, szMutexName);
	if (m_hAdapterMutex != NULL) {
		CString msg;
		msg.LoadString(IDS_OPENED);
		MessageBox(msg, g_szError, MB_OK | MB_ICONSTOP);
		CloseHandle(m_hAdapterMutex);
		return;
	}
	m_hAdapterMutex = CreateMutex(NULL, FALSE, szMutexName);
	
	if (0 != StartCapture(szAdapter))
		return;	

	g_bStarted = TRUE;
	g_pwndTraffic->Invalidate();

	::SetTimer(m_hWnd, TIMER_ID, 1000, &(CShowTrafView::MyTimerProc)); // init statistics timer

	// update application title
	char szAdapterName[512];
	g_pwndAdapter->GetWindowText(szAdapterName, 512);
	CString sTitle;
	sTitle.LoadString(AFX_IDS_APP_TITLE);
	sTitle += " - [";
	sTitle += szAdapterName;
	sTitle += "]";
	GetParentFrame()->SetWindowText(sTitle);
}

void CShowTrafView::OnCommandStop() 
{
	EndCapture();
	g_bStarted = FALSE;
	KillTimer(TIMER_ID); // kill statistics timer
	CloseHandle(m_hAdapterMutex);
	// update application title
	CString sTitle;
	sTitle.LoadString(AFX_IDS_APP_TITLE);
	GetParentFrame()->SetWindowText(sTitle);
}

void CShowTrafView::OnDestroy() 
{
HDITEM hdi;

	// store columns width
	CHeaderCtrl *pHdr = GetListCtrl().GetHeaderCtrl();
	hdi.mask = HDI_WIDTH;
	pHdr->GetItem(0, &hdi);
	g_Settings.m_iListSrcAddr = hdi.cxy;
	pHdr->GetItem(2, &hdi);
	g_Settings.m_iListDestAddr = hdi.cxy;
	pHdr->GetItem(1, &hdi);
	g_Settings.m_iListSrcPort = hdi.cxy;
	pHdr->GetItem(3, &hdi);
	g_Settings.m_iListDestPort = hdi.cxy;
	pHdr->GetItem(4, &hdi);
	g_Settings.m_iListProto = hdi.cxy;
	pHdr->GetItem(5, &hdi);
	g_Settings.m_iListTraffic = hdi.cxy;
	pHdr->GetItem(6, &hdi);
	g_Settings.m_iListBS = hdi.cxy;
	pHdr->GetItem(7, &hdi);
	g_Settings.m_iListABS = hdi.cxy;

	if (g_bStarted) {
		OnCommandStop();
		g_TrafficList.ClearPackets();
		g_bStarted = FALSE;
	}
	CListView::OnDestroy();
}

void CALLBACK CShowTrafView::MyTimerProc(HWND hWnd, UINT nMsg, UINT nIDEvent, DWORD dwTime)
{
	TRACE("Timer called\n");
	if (TIMER_ID == nIDEvent) {
		g_bTimerEvent = TRUE;
		char szNum[300];
		sprintf(szNum, "cur: %s, avr: %s", FormatBytes(g_dwBPS, TRUE), FormatBytes(g_dwABS, TRUE));
		g_pwndStatusBar->SetPaneText(1, szNum, FALSE);
	}
}

void CShowTrafView::OnColumnClick(NMHDR* pNMHDR, LRESULT* pResult) 
{
	NM_LISTVIEW* pNMListView = (NM_LISTVIEW*)pNMHDR;
	// TODO: Add your control notification handler code here
	
	const int iColumn = pNMListView->iSubItem;

	// if it's a second click on the same column then reverse the sort order,
	// otherwise sort the new column in ascending order.
	Sort( iColumn, iColumn == s_iSortColumn ? !s_bSortAscending : TRUE );

	*pResult = 0;
}

void CShowTrafView::Sort(int iColumn, BOOL bAscending)
{
	s_iSortColumn = iColumn;
	s_bSortAscending = bAscending;

	// show the appropriate arrow in the header control.
	m_ctlHeader.SetSortArrow(s_iSortColumn, s_bSortAscending );

	g_pwndTraffic->SortItems(CompareFunction, (DWORD)g_pwndTraffic);
}

BOOL IsNumber(LPCTSTR pszText)
{
	for( int i = 0; i < lstrlen( pszText ); i++ )
		if( !_istdigit( pszText[ i ] ) )
			return false;

	return true;
}

int NumberCompare( LPCTSTR pszNumber1, LPCTSTR pszNumber2 )
{
	const int iNumber1 = atoi( pszNumber1 );
	const int iNumber2 = atoi( pszNumber2 );

	if( iNumber1 < iNumber2 )
		return -1;
	
	if( iNumber1 > iNumber2 )
		return 1;

	return 0;
}

int CALLBACK CompareFunction( LPARAM lParam1, LPARAM lParam2, LPARAM lParamData )
{
	CListCtrl *pListCtrl = (CListCtrl *)lParamData;
	fi.lParam = lParam1;
	int iItem1 = pListCtrl->FindItem(&fi);
	fi.lParam = lParam2;
	int iItem2 = pListCtrl->FindItem(&fi);
	if ((-1 == iItem1) || (-1 == iItem2))
		return 0;
	CString strItem1 = pListCtrl->GetItemText(iItem1, s_iSortColumn);
	CString strItem2 = pListCtrl->GetItemText(iItem2, s_iSortColumn);

	if (_gbColumnNumber[s_iSortColumn])
		return s_bSortAscending ? NumberCompare( strItem1, strItem2 ) : NumberCompare( strItem2, strItem1 );
	else // text.
		return s_bSortAscending ? lstrcmp( strItem1, strItem2 ) : lstrcmp( strItem2, strItem1 );
}

void CShowTrafView::OnUpdateFilterRemoveSorting(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable((0 <= s_iSortColumn) ? TRUE : FALSE);
}

void CShowTrafView::OnFilterRemoveSorting() 
{
	s_iSortColumn = -1;
	m_ctlHeader.SetSortArrow(s_iSortColumn, s_bSortAscending );
}

void CShowTrafView::OnUpdateFilterTcp(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable();
	pCmdUI->SetCheck(g_Settings.m_bFilterTCP);	
}

void CShowTrafView::OnUpdateFilterUdp(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable();
	pCmdUI->SetCheck(g_Settings.m_bFilterUDP);	
}

void CShowTrafView::OnUpdateFilterIcmp(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable();
	pCmdUI->SetCheck(g_Settings.m_bFilterICMP);	
}

void CShowTrafView::OnFilterTcp() 
{
	g_Settings.m_bFilterTCP = !g_Settings.m_bFilterTCP;
	if (g_Settings.m_bFilterTCP)  // we are about to remove all filtered
		g_TrafficList.FilterProto(6); // 6 = TCP
}

void CShowTrafView::OnFilterUdp() 
{
	g_Settings.m_bFilterUDP = !g_Settings.m_bFilterUDP;
	if (g_Settings.m_bFilterUDP)  // we are about to remove all filtered
		g_TrafficList.FilterProto(17); // 17 = UDP
}

void CShowTrafView::OnFilterIcmp() 
{
	g_Settings.m_bFilterICMP = !g_Settings.m_bFilterICMP;
	if (g_Settings.m_bFilterICMP)  // we are about to remove all filtered
		g_TrafficList.FilterProto(1); // 1 = ICMP
}

void CShowTrafView::OnRButtonDown(UINT nFlags, CPoint point) 
{
	CListView::OnRButtonDown(nFlags, point);

	POSITION pos = GetListCtrl().GetFirstSelectedItemPosition();
	if (pos != NULL) {
		int iItem = GetListCtrl().GetNextSelectedItem(pos);
		PTrafInfo pTrafInfo = (PTrafInfo)GetListCtrl().GetItemData(iItem);
		if (pTrafInfo) {
			CMenu menu;
			menu.CreatePopupMenu();

			// add items
			CString sText;

			sText = _T("Copy src ip: ");
			m_sSrcIp = inet_ntoa(*(in_addr *)(&pTrafInfo->addr.dwSrcIP));
			sText += m_sSrcIp;
			menu.AppendMenu(MF_ENABLED | MF_STRING, ID_COPY_SRC_IP, sText);

			sText = _T("Copy src port: ");
			m_sSrcPort.Format(_T("%u"), ntohs(pTrafInfo->addr.wSrcPort));
			sText += m_sSrcPort;
			menu.AppendMenu(MF_ENABLED | MF_STRING, ID_COPY_SRC_PORT, sText);

			menu.AppendMenu(MF_SEPARATOR);

			sText = _T("Copy dest ip: ");
			m_sDestIp = inet_ntoa(*(in_addr *)(&pTrafInfo->addr.dwDestIP));
			sText += m_sDestIp;
			menu.AppendMenu(MF_ENABLED | MF_STRING, ID_COPY_DEST_IP, sText);

			sText = _T("Copy dest port: ");
			m_sDestPort.Format(_T("%u"), ntohs(pTrafInfo->addr.wDestPort));
			sText += m_sDestPort;
			menu.AppendMenu(MF_ENABLED | MF_STRING, ID_COPY_DEST_PORT, sText);

			menu.AppendMenu(MF_SEPARATOR);
			menu.AppendMenu(MF_ENABLED | MF_STRING, ID_COPY_ALL, _T("Copy selected lines"));

			// show the menu
			ClientToScreen(&point);
			menu.TrackPopupMenu(TPM_LEFTALIGN, point.x, point.y, this);
		}
	}
}

void CShowTrafView::OnCopySourceIP() 
{
	ClipboardCopyText(m_sSrcIp);
}

void CShowTrafView::OnCopySourcePort() 
{
	ClipboardCopyText(m_sSrcPort);
}

void CShowTrafView::OnCopyDestinationIP() 
{
	ClipboardCopyText(m_sDestIp);
}

void CShowTrafView::OnCopyDestinationPort() 
{
	ClipboardCopyText(m_sDestPort);
}

void CShowTrafView::OnCopyAll() 
{
	CString str = "", tmp;
	POSITION pos = GetListCtrl().GetFirstSelectedItemPosition();
	while (pos) {
		int iItem = GetListCtrl().GetNextSelectedItem(pos);
		PTrafInfo pTrafInfo = (PTrafInfo)GetListCtrl().GetItemData(iItem);
		if (pTrafInfo) {
			str += inet_ntoa(*(in_addr *)(&pTrafInfo->addr.dwSrcIP));
			str += _T('\t');

			tmp.Format(_T("%u"), ntohs(pTrafInfo->addr.wSrcPort));
			str += tmp;
			str += _T('\t');

			str += inet_ntoa(*(in_addr *)(&pTrafInfo->addr.dwDestIP));
			str += _T('\t');

			tmp.Format(_T("%u"), ntohs(pTrafInfo->addr.wDestPort));
			str += tmp;
			str += _T("\r\n");
		}
	}
	if (!str.IsEmpty())
		ClipboardCopyText(str);
}

void CShowTrafView::ClipboardCopyText(const CString& text)
{
	if (OpenClipboard()) {
		EmptyClipboard();
		HGLOBAL hClipboardData = GlobalAlloc(GMEM_DDESHARE, text.GetLength() + 1);

		char * pchData;
		pchData = (char *)GlobalLock(hClipboardData);
		strcpy(pchData, LPCSTR(text));
		  
		GlobalUnlock(hClipboardData);
		SetClipboardData(CF_TEXT, hClipboardData);
		CloseClipboard();
	}
}

void CShowTrafView::OnEditClearAll() 
{
	g_TrafficList.ClearPackets();
}

void CShowTrafView::OnCommandFreeze() 
{
	g_Settings.m_bFreezed = !g_Settings.m_bFreezed;
}

void CShowTrafView::OnUpdateCommandFreeze(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(g_bStarted);
	pCmdUI->SetCheck(g_Settings.m_bFreezed);	
}
