
This is README file for ShowTraf project

ToDo:

7. Sorting - dynamic ?
19. Make columns select in settings dialog ?
21. Add source and destination MAC to columns ?

History:

11.12.2005 (version 1.6.0)
    - Packet list now stay filled after pressing the stop button
    - Added "Freeze" button to temporary freeze the traffic list, so you can take 
      a better look at the traffic without stopping the capture (and logging).
    - Added "Clear" button to delete all the traffic from the list
    - Added CSV and CSV + HEX data logging modes :) at last
    - Selecting "Copy selected lines" from the context menu will copy to clipboard 
      information for all the selected lines (src ip, src port, dest ip, dest port)
    - Changed the log date/time format to yyyy.mm.dd - hh:mm:ss:mmm for easier sorting
    - Included WinPcap 3.1

11.04.2005 (version 1.5.1)
    - Fixed crash when WinPcap is not installed
    - Fixed incorrect average speed (was same as the current speed)

06.02.2005 (version 1.5.0)
    - Added support for WinPcap filters. 
    - Fixed some problems with adapter lists. 
    - Included WinPcap 3.0

10.04.2003 (version 1.4.1)
    - Fixed a bug, which causes a crash when using log files functionality to 
      log data without packet headers

26.11.2002 (version 1.4.0)
    - Added log files functionality

25.10.2002 (version 1.3.0)
    - First Open Source version released under the terms of the BSD license

06.04.2002 (version 1.2.0)
    - Included WinPcap 2.3. Now runs under MS Windows XP!

07.01.2002 (version 1.0 beta 2)
    - Fixed bug, adapters list is now correctly shown in Windows 95/98/Me
    - Changed synhronization algorithm. Must crash less now :)
    - Fixed setup, "resolve port names" now works.

20.12.2001 (version 1.0 beta 1)
    - Initial version
