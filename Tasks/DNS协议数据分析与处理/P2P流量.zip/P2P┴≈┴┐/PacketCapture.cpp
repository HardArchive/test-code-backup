
/****************************************************************
Author: Demosten - http://demosten.com (stjordanov@hotmail.com)
****************************************************************/

#include "stdafx.h"

#include "pcap.h"
#include "remote-ext.h"

#include "PacketCapture.h"

// global vars
CComboBox *g_pwndAdapter = NULL;	// for global usage (not in this file)
CListCtrl *g_pwndTraffic = NULL;
CStatusBar *g_pwndStatusBar = NULL; 
CTrafficList g_TrafficList;
CNSCashe g_NSCashe;
CServicesParser g_ServicesParser;
CSettings g_Settings;
CFilterManager g_FilterMan;

DWORD g_dwTotalPackets;
DWORD g_dwTotalBytes;
TCHAR g_szError[] = _T("Error"); // error message title
TCHAR g_szWarning[] = _T("Warning"); // warning message title
volatile BOOL g_bTimerEvent = FALSE; // timer event
DWORD g_dwBPS;	// bytes per second
DWORD g_dwABS;	// average bytes per second
FILE *g_logfile = NULL; // log file handle
long g_lTotalDelBytes = 0; 
BOOL g_bStarted = FALSE; // is capturing started
pcap_t* g_pAdapter = 0;			    // define a pointer to an ADAPTER structure 

// global constants
const TCHAR g_szBytesPerSec[] = _T(" b/s");
const TCHAR g_szKBytesPerSec[] = _T(" Kb/s");
const TCHAR g_szMBytesPerSec[] = _T(" Mb/s");
const TCHAR g_szBytes[] = _T(" bytes");
const TCHAR g_szKBytes[] = _T(" Kb");
const TCHAR g_szMBytes[] = _T(" Mb");
const float g_fBytesPerKB = 1024.0f;
const float g_fBytesPerMB = 1048576.0f;

#define BUFFER_SIZE		(1048576) /* 1M */

// local file vars
static int iLanDataOffset;			/* offset of IP data in LAN data frame */
static DWORD dwBytesSec;
static DWORD dwTimeStampStart;
static BOOL bThreadActive = TRUE;	/* is the thread active? */
static HANDLE hSniffThread;			/* sniff-thread handle */
static DWORD dwSniffThreadID;		/* sniff-thread id */
char buffer[BUFFER_SIZE];			/* buffer to hold the data coming from the driver */
char szErrorString[300];			/* buffer to hold error messages */

/****************************************************************
Check network type and specify an offset of real data in iLanDataOffset
****************************************************************/
int GetLanType(void)
{
	int nettype = pcap_datalink(g_pAdapter);
	switch (nettype) {
	case DLT_IEEE802: iLanDataOffset = 22; return 0; // Token Ring (802.5) 
	//case DLT_EN10MB: iLanDataOffset = 14; return 0; // Ethernet - 802.3 - (10Mb, 100Mb, 1000Mb, and up)
	default: iLanDataOffset = 14; return 0; // Ethernet (802.3) ??? and others
	}
	return 3;
}
/****************************************************************
create sniffing socket and bind it to the adapter iAdapterNr
****************************************************************/
int InitializeCapture(const char *szAdapterName)
{
	char szError[512];
	//g_pAdapter = pcap_open(szAdapterName, 2048 * 1024, PCAP_OPENFLAG_PROMISCUOUS, 1000, NULL, szError);
	g_pAdapter = pcap_open_live(szAdapterName, 2048 * 1024, PCAP_OPENFLAG_PROMISCUOUS, 20, szError);
	
	if (!g_pAdapter) {
		sprintf(szErrorString, "Unable to open the driver\r\nError message : %s", szError); 
		::MessageBox(NULL, szErrorString, g_szError, MB_OK | MB_ICONSTOP);
		return 1;
	}	

	// set a 2Mb buffer in the driver 
	pcap_setbuff(g_pAdapter, 2048 * 1024);
	GetLanType();

	return 0; //GetLanType();
}
/****************************************************************
stop sniffing thread and close sniffing socket
****************************************************************/
void EndCapture(void)
{
	if (bThreadActive) {
		bThreadActive = FALSE;
		Sleep(500);
		TerminateThread(hSniffThread, dwSniffThreadID);
		// free packet space
		g_FilterMan.OnCaptureStop();
		pcap_close(g_pAdapter);
		CloseLogFile();
	}
	g_pAdapter = 0;
	g_dwTotalBytes = g_dwTotalPackets = 0;
	g_Settings.m_bFreezed = FALSE;
}
/****************************************************************
timer
****************************************************************/
void _stdcall OnTimer()
{
	PTrafInfo pTrafInfo;
	DWORD dwPacketTime, dwSeconds;

	for (int iCounter = 0; iCounter < g_pwndTraffic->GetItemCount(); iCounter++) {
		pTrafInfo = (PTrafInfo)g_pwndTraffic->GetItemData(iCounter);
		if (!g_Settings.m_bFreezed) {
			dwPacketTime = GetTickCount() - pTrafInfo->dwTimeStamp;
			if (g_Settings.m_dwIdleSeconds < dwPacketTime) {
				// timeout .. packet line is about to be removed
				delete (PTrafInfo)g_pwndTraffic->GetItemData(iCounter);
				g_pwndTraffic->DeleteItem(iCounter);
				iCounter--;
				continue;
			}

			// show bytes per second
			g_pwndTraffic->SetItemText(iCounter, 6, FormatBytes(pTrafInfo->dwBytes - pTrafInfo->dwBytesSec, FALSE));
			pTrafInfo->dwBytesSec = pTrafInfo->dwBytes;
			// show average bytes per second
			if ((pTrafInfo->dwTimeStamp > pTrafInfo->dwTimeStampStart) && 
				(0 != (dwSeconds = (pTrafInfo->dwTimeStamp - pTrafInfo->dwTimeStampStart) / 1000))) {
				g_pwndTraffic->SetItemText(iCounter, 7, FormatBytes(pTrafInfo->dwBytes / dwSeconds, FALSE));
			}
		}
		else {
			// timer is ticking at 1000 ms 
			// we should update the time for frozen list packets
			// otherwise the list will be cleared because of the timeout
			// right after the user unfreeze it
			
			pTrafInfo->dwTimeStamp += 1000;
		}
	}
	
	// show total info 
	DWORD dwTicks = GetTickCount();
	if ((dwTicks > dwTimeStampStart) && 
		(0 != (dwSeconds = (dwTicks - dwTimeStampStart) / 1000))) {
		g_dwABS = g_dwTotalBytes / dwSeconds;
	}
	else
		g_dwABS = 0;

	g_dwBPS = g_dwTotalBytes - dwBytesSec;
	dwBytesSec = g_dwTotalBytes;

	g_bTimerEvent = FALSE; // remove timer event
}
/****************************************************************
sniffing thread
****************************************************************/
DWORD _stdcall SniffThread(void *param)
{
const BYTE *pkt_data;
pcap_pkthdr *header;

	while (bThreadActive) {
		if (pcap_next_ex(g_pAdapter, &header, &pkt_data) > 0) {
			if (0x45 == *(pkt_data + iLanDataOffset))  { // IP packets only plz 
				g_TrafficList.ShowPacket(pkt_data + iLanDataOffset);
			}
		}

		if (g_bTimerEvent)
			OnTimer();
	}
	
	return 0;
}
/****************************************************************
init all and start sniffing thread
****************************************************************/
int StartCapture(const char *szAdapterName)
{
	if (0 != InitializeCapture(szAdapterName)) 
		return 1;

	// init statistic vars
	dwTimeStampStart = GetTickCount();
	dwBytesSec = 0;

	g_TrafficList.ClearPackets();

	bThreadActive = TRUE;
	if (NULL == (hSniffThread = CreateThread(NULL, 0, SniffThread, 0, 0, &dwSniffThreadID))) {
		::MessageBox(NULL, "Thread  creation failed!", g_szError, MB_OK | MB_ICONSTOP);
		return 1;
	}
	SetThreadPriority(hSniffThread, THREAD_PRIORITY_HIGHEST);
	g_dwTotalBytes = g_dwTotalPackets = 0;

	OpenLogFile(_T("a+"));
	g_FilterMan.OnCaptureStarted();

	return 0;	
}

/****************************************************************
open log file for writing
****************************************************************/
void OpenLogFile(TCHAR *mode)
{
	if (g_Settings.m_bUseLog) {
		g_logfile = _tfopen(g_Settings.m_sLogFile, mode);
		if (NULL == g_logfile) {
			TCHAR message[MAX_PATH * 2];
			_stprintf(message, _T("Cannot open log file \"%s\" for writing!\r\nThe logging will be disabled.\r\nYou could enable it from the Settings."),
				g_Settings.m_sLogFile);
			::MessageBox(NULL, message, g_szWarning, MB_OK | MB_ICONINFORMATION);
			g_Settings.m_bUseLog = FALSE;
		}
	}
}

/****************************************************************
close the log file
****************************************************************/
void CloseLogFile(void)
{
	if (NULL != g_logfile) {
		fclose(g_logfile);
		g_logfile = NULL;
	}
}

/****************************************************************
format the bytes according to the settings dialog
****************************************************************/
TCHAR* FormatBytes(DWORD dwBytes, BOOL bAddUnits, BOOL bAddSecongs)
{
	static int idx = 0;
	static TCHAR szResult[3][20];

	// init
	idx = (idx + 1) % 3;
	szResult[idx][0] = 0;

	switch (g_Settings.m_iUnits) {
	case 1: // K/bytes
		_stprintf(szResult[idx], _T("%.2f"), (float)dwBytes / g_fBytesPerKB);
		if (bAddUnits)
			if (bAddSecongs)
				_tcscat(szResult[idx], g_szKBytesPerSec);
			else
				_tcscat(szResult[idx], g_szKBytes);
		break;

	case 2: // M/Bytes
		_stprintf(szResult[idx], _T("%.2f"), (float)dwBytes / g_fBytesPerMB);
		if (bAddUnits)
			if (bAddSecongs)
				_tcscat(szResult[idx], g_szMBytesPerSec);
			else
				_tcscat(szResult[idx], g_szMBytes);
		break;

	case 3: // dynamic
		if (dwBytes > g_fBytesPerMB) {
			_stprintf(szResult[idx], _T("%.2f"), (float)dwBytes / g_fBytesPerMB);
			if (bAddSecongs)
				_tcscat(szResult[idx], g_szMBytesPerSec);
			else
				_tcscat(szResult[idx], g_szMBytes);
		}
		else if (dwBytes > g_fBytesPerKB) {
			_stprintf(szResult[idx], _T("%.2f"), (float)dwBytes / g_fBytesPerKB);
			if (bAddSecongs)
				_tcscat(szResult[idx], g_szKBytesPerSec);
			else
				_tcscat(szResult[idx], g_szKBytes);
		}
		else {
			_ultoa(dwBytes, szResult[idx], 10);
			if (bAddSecongs)
				_tcscat(szResult[idx], g_szBytesPerSec);
			else
				_tcscat(szResult[idx], g_szBytes);
		}

		break;

	default: // bytes
		_ultoa(dwBytes, szResult[idx], 10);
		if (bAddUnits)
			if (bAddSecongs)
				_tcscat(szResult[idx], g_szBytesPerSec);
			else
				_tcscat(szResult[idx], g_szBytes);
		break;
	}

	return szResult[idx];
}

