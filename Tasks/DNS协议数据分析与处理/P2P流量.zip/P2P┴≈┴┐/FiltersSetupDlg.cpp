// FiltersSetupDlg.cpp : implementation file
//

#include "stdafx.h"
#include "ShowTraf.h"
#include "PacketCapture.h"

#include "FiltersSetupDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CFiltersSetupDlg dialog


CFiltersSetupDlg::CFiltersSetupDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CFiltersSetupDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CFiltersSetupDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CFiltersSetupDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CFiltersSetupDlg)
	DDX_Control(pDX, IDC_FILTERS, m_filters);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CFiltersSetupDlg, CDialog)
	//{{AFX_MSG_MAP(CFiltersSetupDlg)
	ON_BN_CLICKED(IDC_ADD, OnAdd)
	ON_NOTIFY(LVN_ENDLABELEDIT, IDC_FILTERS, OnEndLabelEditFilters)
	ON_NOTIFY(LVN_ITEMCHANGED, IDC_FILTERS, OnItemChangedFilters)
	ON_BN_CLICKED(IDC_REMOVE, OnRemove)
	ON_BN_CLICKED(IDC_CHANGE, OnChange)
	ON_BN_CLICKED(IDC_APPLY, OnApply)
	ON_BN_CLICKED(IDC_SYNTAX, OnSyntax)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CFiltersSetupDlg message handlers

BOOL CFiltersSetupDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// set other styles
	DWORD dwExStyle = m_filters.GetExtendedStyle();
	m_filters.SetExtendedStyle(dwExStyle | 
		LVS_EX_FULLROWSELECT | LVS_EX_CHECKBOXES);

	// insert columns
	LV_COLUMN lvc;
	lvc.mask = LVCF_FMT | LVCF_WIDTH | LVCF_TEXT | LVCF_SUBITEM;

	lvc.iSubItem = 0;
	lvc.pszText = _T("Filter");
	lvc.cx = 300;
	lvc.fmt = LVCFMT_LEFT;
	m_filters.InsertColumn(0, &lvc);

	lvc.iSubItem = 1;
	lvc.pszText = _T("Status");
	lvc.cx = 300;
	lvc.fmt = LVCFMT_LEFT;
	m_filters.InsertColumn(1, &lvc);

	g_FilterMan.ToListCtrl(&m_filters);
	GetDlgItem(IDC_APPLY)->EnableWindow(FALSE);

	return TRUE;  // return TRUE unless you set the focus to a control
}

void CFiltersSetupDlg::OnAdd() 
{
	int item = m_filters.InsertItem(m_filters.GetItemCount(), _T("enter your filter"));
	//m_filters.SetSelectionMark(item);
	m_filters.SetFocus();
	m_filters.EditLabel(item);
	GetDlgItem(IDC_APPLY)->EnableWindow(TRUE);
}

void CFiltersSetupDlg::OnEndLabelEditFilters(NMHDR* pNMHDR, LRESULT* pResult) 
{
	LV_DISPINFO* pDispInfo = (LV_DISPINFO*)pNMHDR;
	*pResult = 1;

	//if (pDispInfo->item.pszText && m_filters.GetCheck(pDispInfo->item.iItem))
	//	m_filters.SetItemText(pDispInfo->item.iItem, 1, CheckFilter(pDispInfo->item.pszText));
	// ToDo: check the filter

	GetDlgItem(IDC_APPLY)->EnableWindow(TRUE);
}

char* CFiltersSetupDlg::CheckFilter(char *filter)
{
	static char err[PCAP_ERRBUF_SIZE + 10];

	strcpy(err,  "no error");
	bpf_program prg;
	int res;

	if (!g_bStarted) {
		pcap_t*adp = pcap_open_dead(0, DLT_EN10MB);
		res = pcap_compile(adp, &prg, filter, 0, 0xFFFFFFFF);
		if (-1 == res)
			strcpy(err, pcap_geterr(adp));
		else
			pcap_freecode(&prg);
		pcap_close(adp);
	}
	else {
		res = pcap_compile(g_pAdapter, &prg, filter, 0, 0xFFFFFFFF);
		if (-1 == res)
			strcpy(err, pcap_geterr(g_pAdapter));
		else
			pcap_freecode(&prg);
	}
	
	return err;
}

void CFiltersSetupDlg::OnItemChangedFilters(NMHDR* pNMHDR, LRESULT* pResult) 
{
	NM_LISTVIEW* pNMListView = (NM_LISTVIEW*)pNMHDR;

	m_filters.SetItemText(pNMListView->iItem, 1, _T(""));
	if (m_filters.GetCheck(pNMListView->iItem)) {
		char txt[256];
		m_filters.GetItemText(pNMListView->iItem, 0, txt, 256);
		m_filters.SetItemText(pNMListView->iItem, 1, CheckFilter(txt));
	}

	TRACE("Item changed\n");
	
	*pResult = 0;
	GetDlgItem(IDC_APPLY)->EnableWindow(TRUE);
}

void CFiltersSetupDlg::OnRemove() 
{
	POSITION pos = m_filters.GetFirstSelectedItemPosition();
	while (pos) {
		int nItem = m_filters.GetNextSelectedItem(pos);
		m_filters.DeleteItem(nItem);
		pos = m_filters.GetFirstSelectedItemPosition();
	}
	GetDlgItem(IDC_APPLY)->EnableWindow(TRUE);
}

void CFiltersSetupDlg::OnChange() 
{
	POSITION pos = m_filters.GetFirstSelectedItemPosition();
	if (pos) {
		int nItem = m_filters.GetNextSelectedItem(pos);
		m_filters.SetFocus();
		m_filters.EditLabel(nItem);
	}
	GetDlgItem(IDC_APPLY)->EnableWindow(TRUE);
}

void CFiltersSetupDlg::OnOK() 
{
	g_FilterMan.FromListCtrl(&m_filters);
	g_FilterMan.SaveFiltersFile();
	CDialog::OnOK();
}

void CFiltersSetupDlg::OnApply() 
{
	g_FilterMan.FromListCtrl(&m_filters);
	g_FilterMan.SaveFiltersFile();
	GetDlgItem(IDC_APPLY)->EnableWindow(FALSE);
}

void CFiltersSetupDlg::OnSyntax() 
{
char szFileName[_MAX_PATH], *SlashPos;

	// create directory name
	GetModuleFileName(NULL, szFileName, _MAX_PATH);
	SlashPos = strrchr(szFileName, '\\');
	if (NULL == SlashPos)
		SlashPos = szFileName;
	else
		SlashPos++;
	strcpy(SlashPos, "help");
	// execute HTML file
	::ShellExecute(m_hWnd, "open", "group__language.html", NULL, szFileName, SW_SHOWNORMAL);
}
