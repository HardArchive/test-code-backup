// FilterManager.cpp: implementation of the CFilterManager class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include <shlwapi.h>
#include "ShowTraf.h"
#include "PacketCapture.h"

#include "FilterManager.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

const TCHAR s_szFiltersFileName[] = _T("filters.dat");
const TCHAR s_szTrimChars[] = _T("\n\r\t ");

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CFilterManager::CFilterManager()
{
	TCHAR *SlashPos;
	GetModuleFileName(NULL, m_szFiltersFileName, MAX_PATH);
	SlashPos = _tcsrchr(m_szFiltersFileName, _T('\\'));
	if (SlashPos == NULL) 	// no '\\' in file name! huh?
		_tcscpy(m_szFiltersFileName, s_szFiltersFileName);
	else {
		SlashPos++;
		_tcscpy(SlashPos, s_szFiltersFileName);
	}

	m_filters = NULL;
	m_last = &m_filters;
	m_applied = FALSE;
}

CFilterManager::~CFilterManager()
{
	Clear();
}

void CFilterManager::Clear()
{
	if (m_filters) {
		TFilterLine* filter = m_filters;
		TFilterLine* next;

		while (filter) {
			if (m_applied)
				pcap_freecode(&filter->bpf);

			next = filter->next;
			delete filter;
			filter = next;
		}
	}
	m_filters = NULL;
	m_last = &m_filters;
	m_applied = FALSE;
}

void CFilterManager::OnCaptureStop()
{
	Clear();
}

void CFilterManager::OnCaptureStarted()
{
	if (!m_filters)
		LoadFiltersFile();
	ApplyFilters(TRUE);
}

void CFilterManager::SaveFiltersFile()
{
	FILE* f = fopen(m_szFiltersFileName, "wt");
	if (!f)
		return;

	if (m_filters) {
		TFilterLine* filter = m_filters;
		
		while (filter) {
			if (0 == strlen(filter->szFilter))
				continue;

			if (filter->checked)
				fputc('+', f);
			else
				fputc('-', f);
			
			fputs(filter->szFilter, f);
			fputc('\n', f);

			filter = filter->next;
		}
	}
	
	fclose(f);
}

void CFilterManager::LoadFiltersFile()
{
	Clear();

	FILE* f = fopen(m_szFiltersFileName, "rt");
	if (!f)
		return;

	TCHAR text[MAX_FILTER_LINE_LEN];
	int start = 0;
	BOOL checked = FALSE;

	while (!feof(f)) {
		if (!fgets(text, MAX_FILTER_LINE_LEN, f))
			break;

		StrTrim(text, s_szTrimChars);
		if (0 == strlen(text))
			continue;

		switch(text[0]) {
		case '+': checked = TRUE; start = 1; break;
		case '-': checked = FALSE; start = 1; break;
		case ';': continue; break;
		default: checked = FALSE; start = 0; break;
		}

		*m_last = new TFilterLine;
		(*m_last)->next = NULL;
		(*m_last)->checked = checked;
		ZeroMemory(&(*m_last)->bpf, sizeof(bpf_program));
		strcpy((*m_last)->szFilter, &text[start]);
		m_last = &(*m_last)->next;
	}

	fclose(f);
}

void CFilterManager::ApplyFilters(BOOL forsed)
{
	BOOL force = forsed || g_bStarted;

	if (m_filters && !m_applied && force) {
		TFilterLine* filter = m_filters;
		
		while (filter) {
			if (filter->checked) {
				if (-1 != pcap_compile(g_pAdapter, &filter->bpf, 
					filter->szFilter, 0, 0xFFFFFFFF))
				{
					pcap_setfilter(g_pAdapter, &filter->bpf);
				}
			}

			filter = filter->next;
		}

		m_applied = TRUE;
	}
}

void CFilterManager::ToListCtrl(CListCtrl* ctrl)
{
	ctrl->DeleteAllItems();

	if (!m_filters)
		LoadFiltersFile();

	TFilterLine* filter = m_filters;
	int item;
		
	while (filter) {
		item = ctrl->InsertItem(ctrl->GetItemCount(), filter->szFilter);
		ctrl->SetCheck(item, filter->checked);

		filter = filter->next;
	}
}

void CFilterManager::FromListCtrl(const CListCtrl* ctrl)
{
	Clear();

	int count = ctrl->GetItemCount();
	CString text;
	for (int i = 0; i < count; i++) {
		text = ctrl->GetItemText(i, 0);
		if (0 == text.GetLength())
			continue;

		*m_last = new TFilterLine;
		(*m_last)->next = NULL;
		ZeroMemory(&(*m_last)->bpf, sizeof(bpf_program));
		(*m_last)->checked = ctrl->GetCheck(i);
		strcpy((*m_last)->szFilter, (LPCTSTR)text);
		m_last = &(*m_last)->next;
	}

	ApplyFilters();
}
