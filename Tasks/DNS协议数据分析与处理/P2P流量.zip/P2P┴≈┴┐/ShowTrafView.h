// ShowTrafView.h : interface of the CShowTrafView class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_SHOWTRAFVIEW_H_INCLUDED_)
#define AFX_SHOWTRAFVIEW_H_INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


#ifndef SORTHEADERCTRL_H
	#include "SortHeaderCtrl.h"
#endif	// SORTHEADERCTRL_H

class CShowTrafView : public CListView
{
protected: // create from serialization only
	CShowTrafView();
	DECLARE_DYNCREATE(CShowTrafView)

// Attributes
public:
	CShowTrafDoc* GetDocument();

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CShowTrafView)
	public:
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
	protected:
	virtual void OnInitialUpdate(); // called first time after construct
	//}}AFX_VIRTUAL

// Implementation
public:
	void Sort(int iColumn, BOOL bAscending);
	static void CALLBACK MyTimerProc(HWND hWnd, UINT nMsg, UINT nIDEvent, DWORD dwTime);
	virtual ~CShowTrafView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

// Generated message map functions
protected:
	//{{AFX_MSG(CShowTrafView)
	afx_msg void OnUpdateCommandStart(CCmdUI* pCmdUI);
	afx_msg void OnUpdateCommandStop(CCmdUI* pCmdUI);
	afx_msg void OnPaint();
	afx_msg void OnCommandStart();
	afx_msg void OnCommandStop();
	afx_msg void OnDestroy();
	afx_msg void OnColumnClick(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnUpdateFilterRemoveSorting(CCmdUI* pCmdUI);
	afx_msg void OnFilterRemoveSorting();
	afx_msg void OnUpdateFilterTcp(CCmdUI* pCmdUI);
	afx_msg void OnUpdateFilterUdp(CCmdUI* pCmdUI);
	afx_msg void OnUpdateFilterIcmp(CCmdUI* pCmdUI);
	afx_msg void OnFilterTcp();
	afx_msg void OnFilterUdp();
	afx_msg void OnFilterIcmp();
	afx_msg void OnRButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnCopySourceIP();
	afx_msg void OnCopySourcePort();
	afx_msg void OnCopyDestinationIP();
	afx_msg void OnCopyDestinationPort();
	afx_msg void OnCopyAll();
	afx_msg void OnEditClearAll();
	afx_msg void OnCommandFreeze();
	afx_msg void OnUpdateCommandFreeze(CCmdUI* pCmdUI);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

private:
	void CreateMutexName(const char *szInput, char *szOutput);
	void ClipboardCopyText(const CString& text);
	UINT m_wTimer;
	HANDLE m_hAdapterMutex;

	CSortHeaderCtrl m_ctlHeader;
	int m_iNumColumns;

	CString m_sSrcIp, m_sSrcPort, m_sDestIp, m_sDestPort;
};

#ifndef _DEBUG  // debug version in ShowTrafView.cpp
inline CShowTrafDoc* CShowTrafView::GetDocument()
   { return (CShowTrafDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SHOWTRAFVIEW_H_INCLUDED_)
