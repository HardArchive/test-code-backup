#include "stdafx.h"
#include "MyCap.h"
#include "InterfaceDlg.h"
#include "pcap.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

CInterfaceDlg::CInterfaceDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CInterfaceDlg::IDD, pParent)
{	
  strcpy(m_szName ,"");
  strcpy(m_szNetmask, "");	
}


void CInterfaceDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);	
	DDX_Control(pDX, IDC_INTERFACE_LIST, m_lstInterface);	
}


BEGIN_MESSAGE_MAP(CInterfaceDlg, CDialog)
	
END_MESSAGE_MAP()

BOOL CInterfaceDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();	
  pcap_if_t *alldevs;
  pcap_if_t *d;
  u_int netmask;
  int inum = 0;
  int i=0;
  char errbuf[PCAP_ERRBUF_SIZE];
  CString strMsg;

	if (pcap_findalldevs_ex(PCAP_SRC_IF_STRING, NULL, &alldevs, errbuf) == -1)
	{
		strMsg.Format("Error in pcap_findalldevs: %s", errbuf);
    MessageBox(strMsg);
    return FALSE;
	}	
  CString strText;
  CRect rect;
  m_lstInterface.SetExtendedStyle(m_lstInterface.GetExtendedStyle()|LVS_EX_FULLROWSELECT );
	m_lstInterface.GetWindowRect(&rect);
	m_lstInterface.InsertColumn(0, "NO.", LVCFMT_LEFT,
		rect.Width()*1/10 , 0);
	m_lstInterface.InsertColumn(1, "˵��", LVCFMT_LEFT,
		rect.Width()*9/10 , 0);
	m_lstInterface.InsertColumn(2, "Name", LVCFMT_LEFT,
		0, 1);
	m_lstInterface.InsertColumn(3, "netmask", LVCFMT_LEFT,
		0, 1);
  
	for(d=alldevs; d; d=d->next)
	{
    strText.Format("%d", i);
    m_lstInterface.InsertItem(i,strText.GetBuffer(16));
		m_lstInterface.SetItemText(i, 1, d->description);
		m_lstInterface.SetItemText(i, 2, d->name);
	  if(d->addresses != NULL)		  
		  netmask=((struct sockaddr_in *)(d->addresses->netmask))->sin_addr.S_un.S_addr;
	  else		 
		  netmask=0xffffff; 
		m_lstInterface.SetItemText(i, 3, itoa(netmask,m_szNetmask, 10));
    if (strcmp(d->name, m_szName) == 0)
    {
      m_lstInterface.SetFocus();
      m_lstInterface.SetItemState(i, LVIS_SELECTED, LVIS_SELECTED);
      m_lstInterface.SetHotItem(i);    
    }
    i++;
	}	
  pcap_freealldevs(alldevs);
	return TRUE; 
}

void CInterfaceDlg::OnOK() 
{
  if (!m_lstInterface.GetItemCount( ))
  {    
    return;  
  }
  POSITION pos = m_lstInterface.GetFirstSelectedItemPosition();
  if (pos == NULL)
  {
    MessageBox("No items were selected!");
    return;
  }
  else
  {
     if (pos)
     {
        int nItem = m_lstInterface.GetNextSelectedItem(pos);
        TRACE1("Item %d was selected!\n", nItem);
        m_lstInterface.GetItemText(nItem, 1, m_szDescription, 255);
        m_lstInterface.GetItemText(nItem, 2, m_szName, 255);       
     }
  }
	CDialog::OnOK();
}
