#include "stdafx.h"
#include "mycap.h"
#include "packetfilter.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

packetfilter::packetfilter(CWnd* pParent /*=NULL*/)
	: CDialog(packetfilter::IDD, pParent)
{	
	m_tcp = FALSE;
	m_udp = FALSE;
	m_icmp = FALSE;	
}


void packetfilter::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);	
	DDX_Control(pDX, IDC_CHECK_ICMP, m_icmpctrl);
	DDX_Control(pDX, IDC_CHECK_UDP, m_udpctrl);
	DDX_Control(pDX, IDC_CHECK_TCP, m_tcpctrl);
	DDX_Check(pDX, IDC_CHECK_TCP, m_tcp);
	DDX_Check(pDX, IDC_CHECK_UDP, m_udp);
	DDX_Check(pDX, IDC_CHECK_ICMP, m_icmp);	
}


BEGIN_MESSAGE_MAP(packetfilter, CDialog)	
	ON_BN_CLICKED(IDC_CHECK_TCP, OnCheckTcp)
	ON_BN_CLICKED(IDC_CHECK_UDP, OnCheckUdp)
	ON_BN_CLICKED(IDC_CHECK_ICMP, OnCheckIcmp)	
END_MESSAGE_MAP()

void packetfilter::OnCheckTcp() 
{	
	if(m_tcpctrl.GetCheck() == BST_CHECKED)
		m_tcp = TRUE;
	if(m_tcpctrl.GetCheck() == BST_UNCHECKED)
		m_tcp = FALSE;
}

void packetfilter::OnCheckUdp() 
{	
	if(m_udpctrl.GetCheck() == BST_CHECKED)
		m_udp = TRUE;
	if(m_udpctrl.GetCheck() == BST_UNCHECKED)
		m_udp = FALSE;
}

void packetfilter::OnCheckIcmp() 
{	
	if(m_icmpctrl.GetCheck() == BST_CHECKED)
		m_icmp = TRUE;
	if(m_icmpctrl.GetCheck() == BST_UNCHECKED)
		m_icmp = FALSE;
}
