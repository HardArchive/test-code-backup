// MyCapView.h : interface of the CMyCapView class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_MYCAPVIEW_H__08EE81CC_43A3_41A0_AD4F_824621E1FE54__INCLUDED_)
#define AFX_MYCAPVIEW_H__08EE81CC_43A3_41A0_AD4F_824621E1FE54__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <pcap.h>
//#include <vector>
//////////////////////////////////////////////////////////
//GLOBAL DEFNITION

UINT ThreadFunc(LPVOID pParam);

/* 4 bytes IP address */
typedef struct ip_address{
	u_char byte1;
	u_char byte2;
	u_char byte3;
	u_char byte4;
}ip_address;

/* IPv4 header */
typedef struct ip_header{
	u_char	ver_ihl;		// Version (4 bits) + Internet header length (4 bits)
	u_char	tos;			// Type of service 
	u_short tlen;			// Total length 
	u_short identification; // Identification
	u_short flags_fo;		// Flags (3 bits) + Fragment offset (13 bits)
	u_char	ttl;			// Time to live
	u_char	proto;			// Protocol
	u_short crc;			// Header checksum
	ip_address	saddr;		// Source address
	ip_address	daddr;		// Destination address
	u_int	op_pad;			// Option + Padding
}ip_header;

/* UDP header*/
typedef struct udp_header{
	u_short sport;			// Source port
	u_short dport;			// Destination port
	u_short len;			// Datagram length
	u_short crc;			// Checksum
}udp_header;

typedef struct tcp_header{
	u_short tcpsport;
	u_short tcpdport;
	unsigned long int 	sernum;
	unsigned long int	acknum;
	u_char	len;
	u_char  bit;
	u_short	winlen;
	u_short	tcpchecksum;
	u_short	point;
	u_int	op_pad;
}tcp_header;

typedef struct icmp_header{
	u_char type;
	u_char code;
	u_short checksum;
	u_short identifier;
	u_short sernum;
}icmp_header;

/* prototype of the packet handler */
void packet_handler(u_char *param, const struct pcap_pkthdr *header, const u_char *pkt_data);

typedef struct tagTHREADPARMS
{
  //HWND  hWnd;
  char szName[255];
  u_int netmask;
}THREADPARMS;

typedef struct tagPACKET
{
	char timestr[16];
  ip_header   IpHead;
  udp_header  UdpHead;
  tcp_header  TcpHead;
  icmp_header IcmpHead;
}PACKET;



////////////////////////////////////////////////////////


class CMyCapView : public CListView
{
protected: // create from serialization only
	CMyCapView();
	DECLARE_DYNCREATE(CMyCapView)

// Attributes
public:
	CMyCapDoc* GetDocument();

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMyCapView)
	public:
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	protected:
	virtual void OnInitialUpdate(); // called first time after construct
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	virtual void OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnEndPrinting(CDC* pDC, CPrintInfo* pInfo);
	//}}AFX_VIRTUAL

// Implementation
public:
	char m_szName[255];
	char m_szDescription[255];
  char m_szNetmask[16];
	virtual ~CMyCapView();
  CWinThread *pThread;
  afx_msg LONG OnGetPacket(WPARAM wParam, LPARAM lParam);
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CMyCapView)
	afx_msg void OnFileStart();
	afx_msg void OnOptionCard();
	afx_msg void OnFileStop();
	afx_msg void OnClick(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnFileSave();
	afx_msg void OnOptionFilter();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in MyCapView.cpp
inline CMyCapDoc* CMyCapView::GetDocument()
   { return (CMyCapDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MYCAPVIEW_H__08EE81CC_43A3_41A0_AD4F_824621E1FE54__INCLUDED_)
