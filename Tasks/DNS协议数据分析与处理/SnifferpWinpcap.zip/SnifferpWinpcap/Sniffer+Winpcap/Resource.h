//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by MyCap.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_MYCAPTYPE                   129
#define IDD_INTERFACE_DLG               130
#define IDD_DIALOG_PACKETFILTER         131
#define IDC_INTERFACE_LIST              1000
#define IDC_IPADDRESS1                  1001
#define IDC_STATIC_SELECT               1002
#define IDC_CHECK_TCP                   1003
#define IDC_CHECK_UDP                   1004
#define IDC_CHECK_ICMP                  1006
#define ID_FILE_START                   32773
#define ID_FILE_STOP                    32774
#define ID_OPTION_CARD                  32775
#define ID_OPTION_FILTER                32776

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        132
#define _APS_NEXT_COMMAND_VALUE         32777
#define _APS_NEXT_CONTROL_VALUE         1007
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
