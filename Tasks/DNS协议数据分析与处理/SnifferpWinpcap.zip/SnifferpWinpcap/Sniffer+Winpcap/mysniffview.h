#if !defined(AFX_MYSNIFFVIEW_H__F64DE444_0EE6_4DBF_8D56_32F801B86E85__INCLUDED_)
#define AFX_MYSNIFFVIEW_H__F64DE444_0EE6_4DBF_8D56_32F801B86E85__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// mysniffview.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// mysniffview view

class mysniffview : public CScrollView
{
protected:
	mysniffview();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(mysniffview)

// Attributes
public:
	CMyCapDoc* GetDocument();

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(mysniffview)
	protected:
	virtual void OnDraw(CDC* pDC);      // overridden to draw this view
	virtual void OnInitialUpdate();     // first time after construct
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~mysniffview();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Generated message map functions
	//{{AFX_MSG(mysniffview)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in netinterfaceView.cpp
inline CMyCapDoc* mysniffview::GetDocument()
   { return (CMyCapDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MYSNIFFVIEW_H__F64DE444_0EE6_4DBF_8D56_32F801B86E85__INCLUDED_)
