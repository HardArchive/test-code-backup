#if !defined(AFX_INTERFACEDLG_H__AFA43992_34B0_4F71_BFB8_F25D0AD85AF2__INCLUDED_)
#define AFX_INTERFACEDLG_H__AFA43992_34B0_4F71_BFB8_F25D0AD85AF2__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// InterfaceDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CInterfaceDlg dialog

class CInterfaceDlg : public CDialog
{
// Construction
public:
	char m_szName[255];
	char m_szDescription[255];
  char m_szNetmask[16];
	CInterfaceDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CInterfaceDlg)
	enum { IDD = IDD_INTERFACE_DLG };
	CListCtrl	m_lstInterface;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CInterfaceDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CInterfaceDlg)
	virtual BOOL OnInitDialog();
	virtual void OnOK();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_INTERFACEDLG_H__AFA43992_34B0_4F71_BFB8_F25D0AD85AF2__INCLUDED_)
