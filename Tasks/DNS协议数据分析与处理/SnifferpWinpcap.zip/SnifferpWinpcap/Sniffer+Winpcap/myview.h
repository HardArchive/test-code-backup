#if !defined(AFX_MYVIEW_H__02B3A010_9679_46B0_90B1_B3160C8DFBD2__INCLUDED_)
#define AFX_MYVIEW_H__02B3A010_9679_46B0_90B1_B3160C8DFBD2__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// myview.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// myview view

class myview : public CScrollView
{
protected:
	myview();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(myview)

// Attributes
public:
	CMyCapDoc* GetDocument();

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(myview)
	protected:
	virtual void OnDraw(CDC* pDC);      // overridden to draw this view
	virtual void OnInitialUpdate();     // first time after construct
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~myview();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Generated message map functions
	//{{AFX_MSG(myview)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in netinterfaceView.cpp
inline CMyCapDoc* myview::GetDocument()
   { return (CMyCapDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MYVIEW_H__02B3A010_9679_46B0_90B1_B3160C8DFBD2__INCLUDED_)
