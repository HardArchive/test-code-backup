#include "stdafx.h"
#include "mycap.h"
#include "MycapDoc.h"
#include "myview.h"
#include "mycapview.h"
#include <vector>
#include <pcap.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

extern int m_flag;
using namespace std;
typedef vector<const u_char *> v;
extern v myvector;

using namespace std;
typedef vector<u_short> u;
extern u mycount;

IMPLEMENT_DYNCREATE(myview, CScrollView)

myview::myview()
{
}

myview::~myview()
{
}

BEGIN_MESSAGE_MAP(myview, CScrollView)
	
END_MESSAGE_MAP()

void myview::OnInitialUpdate()
{
	CScrollView::OnInitialUpdate();
	CSize sizeTotal;	
	sizeTotal.cx = 700;
	sizeTotal.cy = 700;//ָ��ˢ�µķ�Χ
	SetScrollSizes(MM_TEXT, sizeTotal);	
}

void myview::OnDraw(CDC* pDC)
{
	CMyCapDoc* pDoc = GetDocument();	
	TEXTMETRIC font;
	pDC->GetTextMetrics(&font);
	LONG height= font.tmHeight;
	LONG width = font.tmMaxCharWidth;//����ַ���ƽ���߶Ⱥͳ���
	int mycon;
	CString str = _T("");
	CString total = _T("");
	mycon = pDoc->GetCount();
	if(mycon != -1)
	{//�����׼λ�����ڣ�1������ѡ����CListView�����е�ĳһ��		
		BYTE *bufer = new BYTE[mycount[mycon]];
		//��ջ�Ϸ���һ��mycount[mycon]��СBYTE���͵Ļ�����
		memcpy(bufer, myvector[mycon], mycount[mycon]);
		for(int i=0; i<mycount[mycon]; i++)
		{
			BYTE bt = *(u_char *)(bufer + i);
			str.Format("%02X ", bt);
			total += str;//��BYTE���͵����ݷŵ�һ���ַ�����
		}		
		int count = 0;	
		int length = total.GetLength();
		if(length < 51)
		{
			pDC->TextOut(0, 0, total);
		}
		else
		{
			int left = length % 51;//ָ��ÿһ��ֻ��ӡ50���ַ�
			if(left == 0)
			{
				count = length / 51;
			}
			if(left != 0)
			{
				count = (length - left) / 51 + 1;
			}
		}
		CString *aa = new CString[count];
		int t = 0;
		int h = 0;
		CString mystr = "";
		while(t < total.GetLength())
		{		
			mystr += total[t];
			aa[h] = mystr;
			if(t % 51 == 50)
			{
				h++;
				mystr = "";
			}
			t++;
		}		
		int n = 0;
		pDC->TextOut(0, 0, "��������");
		while(n < count)
		{
			pDC->TextOut(0, (n + 1) * height, aa[n]);
			n++;
		}	
		delete []aa;		
		delete bufer;	
	}
}

#ifdef _DEBUG
void myview::AssertValid() const
{
	CScrollView::AssertValid();
}

void myview::Dump(CDumpContext& dc) const
{
	CScrollView::Dump(dc);
}
#endif //_DEBUG

CMyCapDoc* myview::GetDocument() 
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CMyCapDoc)));
	return (CMyCapDoc*)m_pDocument;
}