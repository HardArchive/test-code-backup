// MainTab.cpp : implementation file
//

#include "stdafx.h"
#include "arpDetector.h"
#include "MainTab.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMainTab

CMainTab::CMainTab()
{
}

CMainTab::~CMainTab()
{
}


BEGIN_MESSAGE_MAP(CMainTab, CTabCtrl)
	//{{AFX_MSG_MAP(CMainTab)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMainTab message handlers
