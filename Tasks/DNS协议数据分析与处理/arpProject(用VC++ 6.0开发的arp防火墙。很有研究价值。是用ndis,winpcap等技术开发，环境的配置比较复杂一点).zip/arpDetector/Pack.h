// Pack.h: interface for the CPack class.
//
//////////////////////////////////////////////////////////////////////

#define __MINGW32__

#include <pcap.h>
#include <iphlpapi.h>
#include <afxtempl.h>

#if !defined(AFX_PACK_H__5D457BE1_9C07_415D_8E54_EC7E33EE19FF__INCLUDED_)
#define AFX_PACK_H__5D457BE1_9C07_415D_8E54_EC7E33EE19FF__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define PACKALIVE 5
#define ADAPTER_INDEX 0

#define ETH_TYPE_ARP 0x0806
typedef struct _ETHeader        // 14�ֽڵ���̫ͷ
{
    UCHAR    dhost[6];    // Ŀ��MAC��ַ
    UCHAR    shost[6];    // ԴMAC��ַ
    USHORT    type;        // �²�Э�����ͣ���IP��ETHERTYPE_IP����ARP��ETHERTYPE_ARP����
} ETHeader, *PETHeader;

// #ifndef _ARPHeader
// #define ARPOP_REQUEST	1
// #define ARPOP_REPLY		2
// typedef struct _ARPHeader    // 28�ֽڵ�ARPͷ
// {
//     USHORT    hrd;        //Ӳ����ַ�ռ䣬��̫����ΪARPHRD_ETHER
//     USHORT	eth_type;    // ��̫������
//     UCHAR    maclen;        // MAC��ַ�ĳ��ȣ�Ϊ6
//     UCHAR    iplen;        // IP��ַ�ĳ��ȣ�Ϊ4
//     USHORT    opcode;        // �������룬ARPOP_REQUESTΪ����ARPOP_REPLYΪ��Ӧ
//     UCHAR    smac[6];    // ԴMAC��ַ
//     UCHAR    saddr[4];    // ԴIP��ַ
//     UCHAR    dmac[6];    // Ŀ��MAC��ַ
//     UCHAR    daddr[4];    // Ŀ��IP��ַ
// } ARPHeader, *PARPHeader;
// #endif

//IPv4��ͷ�ṹ��
typedef struct ip_header {
	unsigned char ver_ihl;  //Version (4 bits) + Internet header length (4 bits)
	unsigned char tos;     //Type of service
	unsigned short tlen;    //Total length
	unsigned short identification;   //Identification
	unsigned short flags_fo;       //Flags (3 bits) + Fragment offset (13 bits)
    unsigned char ttl;            //Time to live
	unsigned char proto;          //Protocol
	unsigned short crc;           //Header checksum
	u_char ip_src[4];            //Source address
	u_char ip_dst[4];            //Destination address
}IPHEADER,*PIPHEADER;
//TCP��ͷ�ṹ��
typedef struct tcp_header {
	WORD SourPort;    //Դ�˿ںš���
	WORD DestPort;    //Ŀ�Ķ˿ں�
	DWORD SeqNo;    //���
	DWORD AckNo;    //ȷ�����
	BYTE HLen;       //�ײ����ȣ�����λ��
	BYTE Flag;        //��ʶ������λ��
	WORD Window;    //���ڴ�С
	WORD ChkSum;    //У���
	WORD UrgPtr;     //����ָ��
}TCPHEADER,*PTCPHEADER;
//UDP��ͷ�ṹ��
typedef struct udp_header {
	u_short sport;          //Դ�˿ں�
	u_short dport;          //Ŀ�Ķ˿ں�
	u_short len;            //���ݱ�����
	u_short crc;            //У���
}UDPHEADER,*PUDPHEADER;

#pragma pack (1) /*ָ����2�ֽڶ���*/
typedef struct arp_pkt {
	ETHeader eth;
	ARPHeader arp;
}ARPPKT, *PARPPKT;
//UDP���ݰ�
typedef struct upd_pkt {
	ETHeader	eth;
	IPHEADER	ip;
	UDPHEADER	udp;
}UDPPKT, *PUDPPKT;
//TCP���ݰ�
typedef struct tcp_pkt {
	ETHeader	eth;
	IPHEADER	ip;
	TCPHEADER	tcp;
}TCPPKT, *PTCPPKT;
#pragma pack () /*ȡ��ָ�����룬�ָ�ȱʡ����*/
#define IPTOSBUFFERS    12

typedef struct det_pkt {
	ARPPKT arp;
	int		alive;
}DETPKT, *PDETPKT;

class CPack  
{
public:
	BOOL m_bIsSetAdapter;
	time_t m_nDefenseInterval;
	int AddDetect(CList<PDETPKT,PDETPKT>&pktList, PDETPKT pkt);
	BOOL m_bIsRisk;
// 	CPack(const CPack &source);
	int refreshDetect(CList<PDETPKT,PDETPKT>&pktList);
	BOOL m_bIsSetGatewayMac;
	int KeepDefense(time_t interval);
	BOOL m_bKeepDefense;
	unsigned char m_pGatewayMac[6];
	int SendARPPacket(char* smac, char* dmac, char* psmac, char*pshost, char* pdmac, char* pdhost,  unsigned short opCode);
	int SendARPPack(u_char *smac, u_char *dmac, u_char *psmac, u_char *pshost, u_char *pdmac, u_char *pdhost,  unsigned short opCode);
	static int str2ip(char* strIP, unsigned char* ip);
	int GetCurrAdapter();
	int sendAskPack(u_char *smac, u_char*dmac, u_char *psmac, u_char *pshost, u_char*pdmac, u_char* pdhost);
	unsigned char * m_pGatewayIp;
	unsigned char m_szGWip[4];
	int dumpPack(char *buf);
	int RetrGatewayMac(unsigned char **pGatewayMacs, int *len);
	DWORD m_dwAdapterIndex;
	unsigned char* GetGateWayIP(DWORD adapterIndex);
	static BOOL CompareMAC(unsigned char mac1[6], unsigned char mac2[6]);
	static BOOL CompareIP(unsigned char ip1[4], unsigned char ip2[4]);
	static CString GetAdaptersString();
	static char* iptos(u_long in);
	static char* mac2str(u_char* mac);
	static unsigned char* str2mac(char* strMac);
	static PUDPPKT parseUDP(u_char *pkt_data);
	static char* ip2str(UCHAR* ip);
	pcap_t * adhandle;
	int openDev();
	int recvPack(char * buf);
	int sendPack(u_char *pack, int len);
	int sendAsk(char* smac, char* dmac, char* psmac, char*pshost, char* pdmac, char* pdhost);
	int sendPack(u_char *pack);
	pcap_if_t* dev;
	PIP_ADAPTER_INFO m_pAdapter;
	char* test2();
	int sendTestPack(pcap_if_t* dev);
	void test();
	int sendPack(pcap_if_t* dev, u_char* pack);
	CPack();
	virtual ~CPack();

};

#endif // !defined(AFX_PACK_H__5D457BE1_9C07_415D_8E54_EC7E33EE19FF__INCLUDED_)
