#if !defined(AFX_MAINPANEL_H__8FA67B78_1D8E_4622_85EF_F3CB204D7F65__INCLUDED_)
#define AFX_MAINPANEL_H__8FA67B78_1D8E_4622_85EF_F3CB204D7F65__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// MainPanel.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CMainPanel dialog

#include "Pack.h"
#include "gfxoutbarctrl.h"

class CMainPanel : public CDialog
{
// Construction
public:
	BOOL bIsThreadRuning;
	int m_nBobo;
	CGfxOutBarCtrl wndBar;
	CImageList imaLarge;
	CImageList imaSmall;
	void print(CString str);
	CWinThread* pThread;
	CPack m_packMon;
	CMainPanel(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CMainPanel)
	enum { IDD = IDD_MAINPANEL };
	CButton	m_btnSafeMode;
	CButton	m_btnSend;
	CButton	m_btnClearLog;
	CButton	m_btnStart;
	CEdit	m_wndPsMac;
	CEdit	m_wndPdMac;
	CButton	m_btnGo;
	CButton	m_btnPause;
	CButton	m_btnTest;
	CEdit	m_wndsIp;
	CEdit	m_wnddIp;
	CEdit	m_wnddMac;
	CEdit	m_wndsMac;
	CEdit	m_winPeterLog;
	CTabCtrl	m_winMainTab;
	int		m_nArpOpType;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMainPanel)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CMainPanel)
	virtual BOOL OnInitDialog();
	virtual void OnOK();
	afx_msg void OnSuspend();
	afx_msg void OnResume();
	afx_msg void OnStart();
	afx_msg void OnClearLog();
	afx_msg void OnSend();
	afx_msg void OnRequestRadio();
	afx_msg void OnReplyRadion();
	afx_msg void OnSafemode();
	//}}AFX_MSG
	afx_msg void OnLogWinMov(WPARAM wParam, LPARAM lParam);
	afx_msg void ShowPackLog(WPARAM wParam, LPARAM lParam);
	afx_msg long OnOutBarNotify(WPARAM wParam, LPARAM lParam);
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MAINPANEL_H__8FA67B78_1D8E_4622_85EF_F3CB204D7F65__INCLUDED_)
