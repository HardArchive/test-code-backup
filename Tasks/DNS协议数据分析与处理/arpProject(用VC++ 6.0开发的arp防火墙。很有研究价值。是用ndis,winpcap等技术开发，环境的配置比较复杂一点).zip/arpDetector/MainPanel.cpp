// MainPanel.cpp : implementation file
//

#include "stdafx.h"
#include "arpDetector.h"
#include "MainPanel.h"
#include "PackThread.h"
#include "ARP.h"
#include "ptutils.h"

#include <remote-ext.h>
#include <WINSOCK2.H>
#include <process.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMainPanel dialog

CMainPanel::CMainPanel(CWnd* pParent /*=NULL*/)
	: CDialog(CMainPanel::IDD, pParent)
{
	//{{AFX_DATA_INIT(CMainPanel)
	m_nArpOpType = 0;
	//}}AFX_DATA_INIT
}


void CMainPanel::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CMainPanel)
	DDX_Control(pDX, IDC_SAFEMODE, m_btnSafeMode);
	DDX_Control(pDX, IDC_SEND, m_btnSend);
	DDX_Control(pDX, IDC_CLEAR_LOG, m_btnClearLog);
	DDX_Control(pDX, IDC_START, m_btnStart);
	DDX_Control(pDX, IDC_PSMAC, m_wndPsMac);
	DDX_Control(pDX, IDC_PDMAC, m_wndPdMac);
	DDX_Control(pDX, IDC_RESUME, m_btnGo);
	DDX_Control(pDX, IDC_SUSPEND, m_btnPause);
	DDX_Control(pDX, IDOK, m_btnTest);
	DDX_Control(pDX, IDC_IPSOURCE, m_wndsIp);
	DDX_Control(pDX, IDC_IPDEST, m_wnddIp);
	DDX_Control(pDX, IDC_MACDEST, m_wnddMac);
	DDX_Control(pDX, IDC_MACSOURCE, m_wndsMac);
	DDX_Control(pDX, IDC_PETERLOG, m_winPeterLog);
	DDX_Control(pDX, IDC_MAINTAB, m_winMainTab);
	DDX_Radio(pDX, IDC_REQUEST, m_nArpOpType);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CMainPanel, CDialog)
	//{{AFX_MSG_MAP(CMainPanel)
	ON_BN_CLICKED(IDC_SUSPEND, OnSuspend)
	ON_BN_CLICKED(IDC_RESUME, OnResume)
	ON_BN_CLICKED(IDC_START, OnStart)
	ON_BN_CLICKED(IDC_CLEAR_LOG, OnClearLog)
	ON_BN_CLICKED(IDC_SEND, OnSend)
	ON_BN_CLICKED(IDC_REQUEST, OnRequestRadio)
	ON_BN_CLICKED(IDC_REPLY, OnReplyRadion)
	ON_MESSAGE(WM_LOGWINMOV, OnLogWinMov)
	ON_MESSAGE(WM_PACKLOGCHANGE, ShowPackLog)
	ON_MESSAGE(WM_OUTBAR_NOTIFY, OnOutBarNotify)
	ON_BN_CLICKED(IDC_SAFEMODE, OnSafemode)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMainPanel message handlers

BOOL CMainPanel::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	PostMessage(WM_LOGWINMOV);
	bIsThreadRuning = FALSE;
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CMainPanel::OnLogWinMov(WPARAM wParam, LPARAM lParam)
{
	CRect rect;
	GetClientRect(rect);

	int logWndHeight = rect.Height()*2/3;
	int nLPanelwidth = 200;
	m_winPeterLog.MoveWindow(nLPanelwidth,0,rect.Width()-nLPanelwidth,logWndHeight);

	m_wndsMac.SetWindowText("00:39:0a:55:60:9f");
	m_wnddMac.SetWindowText("00:16:36:E9:55:00");
	m_wndsIp.SetWindowText("192.168.1.1");
	m_wnddIp.SetWindowText("192.168.3.36");
	m_wndPdMac.SetWindowText("00:16:36:E9:55:00");
	m_wndPsMac.SetWindowText("00:39:0a:55:60:9f");

	//opcode is request
	if(m_packMon.m_bIsSetAdapter) {
		m_wndsMac.SetWindowText(CPack::mac2str(m_packMon.m_pAdapter->Address));
		m_wnddMac.SetWindowText("FF:FF:FF:FF:FF:FF");
		m_wndPsMac.SetWindowText(CPack::mac2str(m_packMon.m_pAdapter->Address));
		m_wndsIp.SetWindowText(m_packMon.m_pAdapter->IpAddressList.IpAddress.String);
		m_wndPdMac.SetWindowText("00:00:00:00:00:00");
		m_wnddIp.SetWindowText(CPack::ip2str(m_packMon.m_pGatewayIp));
	}

	int addrWinLen = 150;
	int labelLen = 30;
	int addrGap = 15;
	int addrLen = addrWinLen+labelLen+addrGap;
	int addrWinHeight = 20;
	int left = 20;
	int top = logWndHeight+30;
	m_wndsMac.MoveWindow(left+labelLen,top,addrWinLen,addrWinHeight);
	m_wndPsMac.MoveWindow(addrLen+left+labelLen,top,addrWinLen,addrWinHeight);
	m_wndsIp.MoveWindow(addrLen*2+left+labelLen,top,addrWinLen,addrWinHeight);
	
	top += 30;
	m_wnddMac.MoveWindow(left+labelLen,top,addrWinLen,addrWinHeight);
	m_wndPdMac.MoveWindow(addrLen+left+labelLen,top,addrWinLen,addrWinHeight);
	m_wnddIp.MoveWindow(addrLen*2+left+labelLen,top,addrWinLen,addrWinHeight);

	GetDlgItem(IDC_STATIC_OPTYPE)->MoveWindow(addrLen*3+left+labelLen,top-30,
		addrWinLen/2+20,addrWinHeight+30);
	GetDlgItem(IDC_REQUEST)->MoveWindow(addrLen*3+left+labelLen+10,top-25,
		addrWinLen/2,addrWinHeight);
	GetDlgItem(IDC_REPLY)->MoveWindow(addrLen*3+left+labelLen+10,top,
		addrWinLen/2,addrWinHeight-5);

	int btnWidth = 60;
	int btnHeight = 20;
	int btnUnitWid = btnWidth+addrGap;
	top += 30;
 	m_btnStart.MoveWindow(left+labelLen,top,btnWidth,btnHeight);
	m_btnPause.MoveWindow(btnUnitWid+left+labelLen,top,btnWidth,btnHeight);
	m_btnGo.MoveWindow(btnUnitWid*2+left+labelLen,top,btnWidth,btnHeight);
	m_btnClearLog.MoveWindow(btnUnitWid*3+left+labelLen,top,btnWidth,btnHeight);
	m_btnSend.MoveWindow(btnUnitWid*4+left+labelLen,top,btnWidth,btnHeight);
	m_btnSafeMode.MoveWindow(btnUnitWid*5+left+labelLen,top,btnWidth,btnHeight);

	m_btnTest.MoveWindow(btnUnitWid*6+left+labelLen,top,btnWidth,btnHeight);

	wndBar.Create(WS_CHILD|WS_VISIBLE,CRect(0,0,200,logWndHeight),this,3000);
	wndBar.SetOwner(this);

	imaLarge.Create(IDB_IMAGELIST, 32, 0, RGB(128,128,128));
	imaSmall.Create(IDB_SMALL_IMAGELIST, 16, 0, RGB(0,128,128));
	wndBar.SetImageList(&imaLarge,CGfxOutBarCtrl::fLargeIcon);
	wndBar.SetImageList(&imaSmall,CGfxOutBarCtrl::fSmallIcon);
	wndBar.SetAnimationTickCount(20);

	wndBar.AddFolder("����ǽ",0);
	wndBar.AddFolder("ϵͳ����",1);
	wndBar.AddFolder("��־��¼",2);

	wndBar.SetSelFolder(0);

	wndBar.InsertItem(0,0,"��������ǽ",3,0);
	wndBar.InsertItem(1,0,"��������",0,0);
	wndBar.InsertItem(2,0,"��������",0,0);

//	char* smac	= "00:39:0a:55:60:9f";
//	char* dmac	= "FF:FF:FF:FF:FF:FF";
//	char* shost	= "192.168.3.3";
//	char* pdmac = "00:00:00:00:00:00";
//	char* dhost	= "192.168.3.36";
}

void CMainPanel::OnOK() 
{
// 	print(CPack::ip2str(m_packMon.m_szGWip));
// 	print(CPack::mac2str(m_packMon.m_pGatewayMac));
// 	if(m_packMon.m_bIsSetGatewayMac) {
// 		PARPHeader	arp = new ARPHeader;
// 		memcpy(arp->daddr,m_packMon.m_szGWip,4);
// 		memcpy(arp->dmac,m_packMon.m_pGatewayMac,6);
// 		arp->opcode = htons(ARPOP_REPLY);
// 		LPTSTR pszAdapterName = "\\DEVICE\\{BB9B160D-EDC0-4423-90AB-B8419599BCC9}";
// 		SetARPBlockList(pszAdapterName, arp);
// 		free(arp);
// 		print("filter is set");
// 	}

//	print(CPack::mac2str(CPack::str2mac("aa:bb:cc:dd:ee:ff")));

// 	AfxBeginThread(CPackThread::SetGatewayARPEntity, (LPVOID)&m_packMon);
// 	while(!m_packMon.m_bIsSetGatewayMac) {
// 		Sleep(200);
// 	}
// 	CString str;
// 	str.Format("Gateway mac is set to: %s",CPack::mac2str(m_packMon.m_pGatewayMac));
// 	print(str);
// 	pThread = AfxBeginThread(CPackThread::detect, (LPVOID)&m_packMon);
// 	AfxBeginThread(CPackThread::keepDefense, (LPVOID)&m_packMon);
// 	print("Start defense process, send defense packet in each 1 second.");


// 	unsigned char *ip = new unsigned char[4];
// 	CPack::str2ip("190.168.3.36",ip);
// 	print(CPack::ip2str(ip));


// 	u_char *gmac = m_packMon.RetrGatewayMac();
// 	if(gmac != NULL)
// 		print(m_packMon.mac2str(gmac));
// 	else
// 		print("get gateway mac failed");
	

// 	char *strIP;
// 	unsigned char *szIP;
// 	if((szIP = m_packMon.GetGateWayIP(m_packMon.m_dwAdapterIndex)) != NULL) {
// 		strIP = CPack::ip2str(szIP);
// 		print(strIP);
// 	} else {
// 		print("get gateway failed");
// 	}

// 	unsigned char *ip;
// 	unsigned char *mac = new unsigned char[6*20];
// 	u_long uip;
// 	int len = 0;
// 
// 	len = m_packMon.RetrGatewayMac(&mac, &len);
// 	uip = inet_addr(m_packMon.m_pAdapter->GatewayList.IpAddress.String);
// 	ip = (unsigned char *)&uip;
// 	CString str;
// 	for(int n=0; n<len; n++) {
// 		str.Format("%s  %s STATIC",CPack::mac2str(mac+6*n),CPack::ip2str(ip));
// 		print(str);
// 	}
// 	return;
// 
// 	CARP arp;
// 	if (arp.EditEntry(ip, mac[0], 4, m_packMon.m_dwAdapterIndex))
// 		print("update success");
// 	else
// 		AfxMessageBox(_T("Error, Update failed"), MB_ICONSTOP|MB_OK);


// 	char *args[5];
// 
// 	args[0] = "C:\\WINDOWS\\system32\\arp.exe";
// 	args[1] = "-s";
// 	args[2] = "192.168.3.1";
// 	args[3] = "00-35-92-e6-f0-55";
// 	args[4] = NULL;
// 
// 	char szError[256];
// 	_execv(args[0], args);
// 	DWORD dwError = GetLastError();
// 	FormatMessage(
//     FORMAT_MESSAGE_FROM_SYSTEM,
//     NULL,                        
//     0,
//     0,
//     szError,
//     sizeof(szError),
//     NULL);
// 	AfxMessageBox(szError);
// 	print("exec failed");


	print(m_packMon.GetAdaptersString());


//	pcap_if_t *alldevs;
//	pcap_if_t *d;
//	int inum;
//	int i=0;
//	pcap_t *adhandle;
//	int res;
//	char errbuf[PCAP_ERRBUF_SIZE];
//	struct tm *ltime;
//	char timestr[16];
//	struct pcap_pkthdr *header;
//	const u_char *pkt_data;
//	time_t local_tv_sec;
//	pcap_addr_t *a;
//    
//    
//    /* ��ȡ�����豸�б� */
//    if (pcap_findalldevs_ex(PCAP_SRC_IF_STRING, NULL, &alldevs, errbuf) == -1)
//    {
//		CString strError;
//		strError.Format("Error in pcap_findalldevs: %s\r\n",errbuf);
//		print(strError);
//        return;
//    }
//    
//    /* ��ӡ�б� */
//	CString tmp;
//    for(d=alldevs; d; d=d->next)
//    {
//		CString adapterInfo;
//        adapterInfo.Format("%d. %s\r\n", ++i, d->name);
//        if (d->description) {
//			adapterInfo.Insert(adapterInfo.GetLength(),d->description);
//			adapterInfo.Insert(adapterInfo.GetLength(),"\r\n");
//        }
//		
//		/* IP addresses */
//		for(a=d->addresses;a;a=a->next) {
//			tmp.Format("\tAddress Family: #%d\r\n",a->addr->sa_family);
//			adapterInfo.Insert(adapterInfo.GetLength(),tmp);
//			if (a->addr) {
//				tmp.Format("\tAddress: %s\r\n",
//					m_packMon.iptos(((struct sockaddr_in *)a->addr)->sin_addr.s_addr));
//				adapterInfo.Insert(adapterInfo.GetLength(),tmp);
//			}
//			if (a->netmask) {
//				tmp.Format("\tNetmask: %s\r\n",
//					m_packMon.iptos(((struct sockaddr_in *)a->netmask)->sin_addr.s_addr));
//				adapterInfo.Insert(adapterInfo.GetLength(),tmp);
//			}
//			if (a->broadaddr) {
//				tmp.Format("\tBroadcast Address: %s\r\n",
//					m_packMon.iptos(((struct sockaddr_in *)a->broadaddr)->sin_addr.s_addr));
//				adapterInfo.Insert(adapterInfo.GetLength(),tmp);
//			}
//			if (a->dstaddr) {
//				tmp.Format("\tDestination Address: %s\r\n",
//					m_packMon.iptos(((struct sockaddr_in *)a->dstaddr)->sin_addr.s_addr));
//				adapterInfo.Insert(adapterInfo.GetLength(),tmp);
//			}
//		}
//		print(adapterInfo);
//    }


// 	pThread = AfxBeginThread(CPackThread::DumpPacket, (LPVOID)&m_packMon);

//	char *buf = new char[512];
//	CString log;
//	int retval;
//
//	m_packMon.openDev();
//	m_packMon.recvPack(buf);
//	
//	m_winPeterLog.GetWindowText(log);
//	if(log.GetLength()>65536)
//		log = "";
//	log.Insert(log.GetLength(), "\r\n");
//	log.Insert(log.GetLength(), buf);
//	m_winPeterLog.SetWindowText(log);
//	m_winPeterLog.SetSel(m_winPeterLog.GetWindowTextLength(), 
//	m_winPeterLog.GetWindowTextLength());
//
//	while((retval = m_packMon.recvPack(buf)) >= 0) {
//		if(retval == 0)
//			continue;
//
// 		MessageBox(buf);
//		
//		m_winPeterLog.GetWindowText(log);
//		if(log.GetLength()>65536)
//			log = "";
//		log.Insert(log.GetLength(), "\r\n");
//		log.Insert(log.GetLength(), buf);
//		m_winPeterLog.SetWindowText(log);
//		m_winPeterLog.SetSel(m_winPeterLog.GetWindowTextLength(), 
//			m_winPeterLog.GetWindowTextLength());
//	}

// 	char* smac = new char[20];
// 	char* dmac = new char[20];
// 	char* sip = new char[20];
// 	char* dip = new char[20];
// 	char* psmac = new char[20];
// 	char* pdmac = new char[20];
// 
// 	m_wndsMac.GetWindowText(smac, 20);
// 	m_wnddMac.GetWindowText(dmac, 20);
// 	m_wndsIp.GetWindowText(sip, 20);
// 	m_wnddIp.GetWindowText(dip, 20);
// 	m_wndPsMac.GetWindowText(psmac, 20);
// 	m_wndPdMac.GetWindowText(pdmac, 20);
// 	for(;;) {
// 		m_packMon.SendARPPacket(smac,dmac,psmac,sip,pdmac,dip,ARPOP_REPLY);
// 		Sleep(2000);
// 		if(m_nBobo == 1)
// 			break;
// 	}
}


void CMainPanel::ShowPackLog(WPARAM wParam, LPARAM lParam)
{
	CString log = *(CString*)lParam;

	CString text;
	m_winPeterLog.GetWindowText(text);
	if(text.GetLength() > 1024*64)
		text = "";
	text.Insert(text.GetLength(),"\r\n");
	text.Insert(text.GetLength(),log);
	m_winPeterLog.SetWindowText(text);
	m_winPeterLog.SetSel(
		m_winPeterLog.GetWindowTextLength(), 
		m_winPeterLog.GetWindowTextLength()
	);
	UpdateData();
}

void CMainPanel::print(CString str)
{
	CString text;
	m_winPeterLog.GetWindowText(text);
	if(text.GetLength() > 1024*64)
		text = "";
	text.Insert(text.GetLength(),"\r\n");
	text.Insert(text.GetLength(),str);
	m_winPeterLog.SetWindowText(text);
	m_winPeterLog.SetSel(
		m_winPeterLog.GetWindowTextLength(), 
		m_winPeterLog.GetWindowTextLength()
	);
	UpdateData();
}

void CMainPanel::OnSuspend() 
{
	if(!bIsThreadRuning)
		return;
	pThread->SuspendThread();
	bIsThreadRuning = FALSE;
}

void CMainPanel::OnResume() 
{
	if(bIsThreadRuning)
		return;
	pThread->ResumeThread();
	bIsThreadRuning = TRUE;
}

void CMainPanel::OnStart() 
{
	if(bIsThreadRuning) {
		CString str;
		str.LoadString(FIREWALL_ALREADY_START);
		MessageBox(str);
		return;
	}
	AfxBeginThread(CPackThread::SetGatewayARPEntity, (LPVOID)&m_packMon);
	while(!m_packMon.m_bIsSetGatewayMac) {
		Sleep(200);
	}
	CString str;
	str.LoadString(GATEWAY_MAC_IS_SET_TO);
	str.Insert(str.GetLength(),CPack::mac2str(m_packMon.m_pGatewayMac));
	print(str);
	str.LoadString(GATEWAY_MAC_OPTIONAL);
	print(str);
	pThread = AfxBeginThread(CPackThread::detect, (LPVOID)&m_packMon);
	bIsThreadRuning = TRUE;
}

long CMainPanel::OnOutBarNotify(WPARAM wParam, LPARAM lParam)
{
	switch (wParam)
	{
		case NM_OB_ITEMCLICK:
		// cast the lParam to an integer to get the clicked item
			{
				int index = (int) lParam;
				CString cs, cs1;
				cs1 = wndBar.GetItemText(index);
				int iFolder = wndBar.GetSelFolder();

				if(iFolder==0) {
					switch (index)
					{
					case 0:
						OnStart();
						break;
					case 1:
						OnSuspend();
						break;
					case 2:
						OnResume();
						break;
					}
				} else {
					cs.Format("Clicked on %d Floder -> %d :: <%s>", iFolder, (int)lParam, cs1);
					AfxMessageBox(cs);
				}
	
			}
		return 0;

		case NM_OB_ONLABELENDEDIT:
		// cast the lParam to an OUTBAR_INFO * struct; it will contain info about the edited item
		// return 1 to do the change and 0 to cancel it
			{
				OUTBAR_INFO * pOI = (OUTBAR_INFO *) lParam;
				TRACE2("Editing item %d, new text:%s\n", pOI->index, pOI->cText);
			}
		return 1;

		case NM_OB_ONGROUPENDEDIT:
		// cast the lParam to an OUTBAR_INFO * struct; it will contain info about the edited folder
		// return 1 to do the change and 0 to cancel it
			{
				OUTBAR_INFO * pOI = (OUTBAR_INFO *) lParam;
				TRACE2("Editing folder %d, new text:%s\n", pOI->index, pOI->cText);
			}
		return 1;

		case NM_OB_DRAGITEM:
		// cast the lParam to an OUTBAR_INFO * struct; it will contain info about the dragged items
		// return 1 to do the change and 0 to cancel it
			{
				OUTBAR_INFO * pOI = (OUTBAR_INFO *) lParam;
				TRACE2("Drag item %d at position %d\n", pOI->iDragFrom, pOI->iDragTo);
			}
		return 1;
	}
	return 0;
}

void CMainPanel::OnClearLog() 
{
	m_winPeterLog.SetWindowText("");
}

void CMainPanel::OnSend() 
{
	char* smac = new char[20];
	char* dmac = new char[20];
	char* sip = new char[20];
	char* dip = new char[20];
	char* psmac = new char[20];
	char* pdmac = new char[20];
	u_short opCode;

	m_wndsMac.GetWindowText(smac, 20);
	m_wnddMac.GetWindowText(dmac, 20);
	m_wndsIp.GetWindowText(sip, 20);
	m_wnddIp.GetWindowText(dip, 20);
	m_wndPsMac.GetWindowText(psmac, 20);
	m_wndPdMac.GetWindowText(pdmac, 20);
	if(m_nArpOpType == 0) {
		opCode = ARPOP_REQUEST;
	} else {
		opCode = ARPOP_REPLY;
	}
	m_packMon.SendARPPacket(smac,dmac,psmac,sip,pdmac,dip,opCode);
}

void CMainPanel::OnRequestRadio() 
{
	m_nArpOpType = 0;
}

void CMainPanel::OnReplyRadion() 
{
	m_nArpOpType = 1;
}

void CMainPanel::OnSafemode() 
{
	print(CPack::ip2str(m_packMon.m_szGWip));
	print(CPack::mac2str(m_packMon.m_pGatewayMac));
	CString adapterName;
	adapterName.Format("\\DEVICE\\%s",m_packMon.m_pAdapter->AdapterName);
	print(adapterName);
	if(m_packMon.m_bIsSetGatewayMac) {
		PARPHeader	arp = new ARPHeader;
		memcpy(arp->daddr,m_packMon.m_szGWip,4);
		memcpy(arp->dmac,m_packMon.m_pGatewayMac,6);
		arp->opcode = htons(ARPOP_REPLY);
		LPTSTR pszAdapterName = adapterName.GetBuffer(0);
		SetARPBlockList(pszAdapterName, arp);
		free(arp);
		print("filter is set");
	}
}
