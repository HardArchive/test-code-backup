// arpDetector.h : main header file for the ARPDETECTOR application
//

#if !defined(AFX_ARPDETECTOR_H__454D3ACF_1FA0_4CD3_8D21_EFC791339A56__INCLUDED_)
#define AFX_ARPDETECTOR_H__454D3ACF_1FA0_4CD3_8D21_EFC791339A56__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"       // main symbols


#define WM_SHOWMAINPANEL				WM_USER+101
#define WM_LOGWINMOV					WM_USER+102
#define WM_PACKLOGCHANGE				WM_USER+103

/////////////////////////////////////////////////////////////////////////////
// CArpDetectorApp:
// See arpDetector.cpp for the implementation of this class
//

class CArpDetectorApp : public CWinApp
{
public:
	CAppFace m_af;
	CArpDetectorApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CArpDetectorApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation
	//{{AFX_MSG(CArpDetectorApp)
	afx_msg void OnAppAbout();
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_ARPDETECTOR_H__454D3ACF_1FA0_4CD3_8D21_EFC791339A56__INCLUDED_)
