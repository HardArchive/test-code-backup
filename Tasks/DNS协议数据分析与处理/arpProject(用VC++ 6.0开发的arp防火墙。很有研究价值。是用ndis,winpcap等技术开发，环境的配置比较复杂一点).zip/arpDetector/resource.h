//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by arpDetector.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_ARPDETTYPE                  129
#define IDD_MAINPANEL                   130
#define IDB_IMAGELIST                   130
#define IDB_SMALL_IMAGELIST             131
#define IDC_DRAGGING                    132
#define IDC_HANDCUR                     133
#define IDC_NODRAGGING                  134
#define IDR_CJWEBHTML                   135
#define IDC_MAINTAB                     1000
#define IDC_MACSOURCE                   1001
#define IDC_MACDEST                     1002
#define IDC_PDMAC                       1003
#define IDC_IPSOURCE                    1004
#define IDC_IPDEST                      1005
#define IDC_PSMAC                       1006
#define IDC_PETERLOG                    1007
#define IDC_SUSPEND                     1008
#define IDC_RESUME                      1009
#define IDC_START                       1012
#define IDC_CLEAR_LOG                   1013
#define IDC_LIST2                       1014
#define IDC_SEND                        1014
#define IDC_LST_MENU                    1015
#define IDC_SAFEMODE                    1015
#define IDC_REQUEST                     1017
#define IDC_REPLY                       1018
#define IDC_STATIC_OPTYPE               1019
#define ID_GFX_SMALLICON                50000
#define ID_GFX_LARGEICON                50001
#define ID_GFX_RENAMEITEM               50002
#define ID_GFX_REMOVEITEM               50003
#define GATEWAY_MAC_IS_SET_TO           61446
#define GATEWAY_MAC_OPTIONAL            61447
#define GATEWAY_MAC_ARP_TABLE_SETTO_STATIC 61448
#define FILTER_PACKET                   61449
#define RISK_DETECTED                   61450
#define START_DEFENSE_PROCESS           61451
#define FIREWALL_ALREADY_START          61452

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        132
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1020
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
