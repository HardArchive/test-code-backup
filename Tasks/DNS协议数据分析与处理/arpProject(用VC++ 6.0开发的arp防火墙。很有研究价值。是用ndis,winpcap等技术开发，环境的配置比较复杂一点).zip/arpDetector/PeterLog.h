#if !defined(AFX_PETERLOG_H__BE11D246_4603_4478_BF79_B74739BD9ED1__INCLUDED_)
#define AFX_PETERLOG_H__BE11D246_4603_4478_BF79_B74739BD9ED1__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// PeterLog.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CPeterLog window

class CPeterLog : public CEdit
{
// Construction
public:
	CPeterLog();

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPeterLog)
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CPeterLog();

	// Generated message map functions
protected:
	//{{AFX_MSG(CPeterLog)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PETERLOG_H__BE11D246_4603_4478_BF79_B74739BD9ED1__INCLUDED_)
