// Pack.cpp: implementation of the CPack class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "arpDetector.h"
#include "Pack.h"

#include <WINSOCK2.H>
#include <remote-ext.h>

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

#define LINE_LEN 16
#define LINE_LEN_32 32
#define MAX_PACK_SIZE 1500

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CPack::CPack()
{
    char errbuf[PCAP_ERRBUF_SIZE];

	pcap_findalldevs(&this->dev, errbuf);
	while((this->dev=this->dev->next)) {
		if(strstr(this->dev->description, "Broadcom") != NULL) {
			break;
		}
	}
	m_pGatewayIp = new unsigned char[4];
	int retVal = GetCurrAdapter();
	if(retVal != 0) {
		m_bIsSetAdapter = FALSE;
		AfxMessageBox("no adapter found");
//		exit(1);
	}
	adhandle = NULL;
	m_bIsSetGatewayMac = FALSE;
	m_bIsRisk = FALSE;
}

CPack::~CPack()
{
	
}

int CPack::sendPack(pcap_if_t *dev, u_char *pack)
{
	pcap_t *fp;
    char errbuf[PCAP_ERRBUF_SIZE];
	
	if ((fp = pcap_open_live(dev->name,		// name of the device
							 65536,			// portion of the packet to capture. It doesn't matter in this case 
							 1,				// promiscuous mode (nonzero means promiscuous)
							 1000,			// read timeout
							 errbuf			// error buffer
							 )) == NULL)
	{
		fprintf(stderr,"\nUnable to open the adapter. %s is not supported by WinPcap\n", errbuf);
		return 2;
	}

	/* Send down the packet */
	if (pcap_sendpacket(fp,	// Adapter
		pack,				// buffer with the packet
		60					// size
		) != 0)
	{
		fprintf(stderr,"\nError sending the packet: \n", pcap_geterr(fp));
		return 3;
	}

	pcap_close(fp);

	return 0;
}

int CPack::sendPack(u_char *pack)
{
	pcap_t *fp;
    char errbuf[PCAP_ERRBUF_SIZE];
	
	if ((fp = pcap_open_live(this->dev->name,		// name of the device
							 65536,			// portion of the packet to capture. It doesn't matter in this case 
							 1,				// promiscuous mode (nonzero means promiscuous)
							 1000,			// read timeout
							 errbuf			// error buffer
							 )) == NULL)
	{
		fprintf(stderr,"\nUnable to open the adapter. %s is not supported by WinPcap\n", errbuf);
		return 2;
	}

	/* Send down the packet */
	if (pcap_sendpacket(fp,	// Adapter
		pack,				// buffer with the packet
		42					// size
		) != 0)
	{
		fprintf(stderr,"\nError sending the packet: \n", pcap_geterr(fp));
		return 3;
	}

	pcap_close(fp);

	return 0;
}


int CPack::sendTestPack(pcap_if_t *dev)
{
	u_char packet[60];

	//info
	ETHeader etHeader;
	ARPHeader arpHeader;

	memcpy(etHeader.shost, this->str2mac("00:35:72:9f:33:9a"),6);
	memcpy(etHeader.dhost, this->str2mac("ff:ff:ff:ff:ff:ff"),6);
	etHeader.type = 0x0608;

	arpHeader.hrd = 0x0100;
	arpHeader.eth_type = 0x0008;
	arpHeader.maclen = 6;
	arpHeader.iplen = 4;
	arpHeader.opcode = 0x0100;
	memcpy(arpHeader.smac, etHeader.shost, sizeof(etHeader.shost));
	long sourceIp = inet_addr("192.168.3.3");
	memcpy(arpHeader.saddr, &sourceIp, 4);
	memcpy(arpHeader.dmac, etHeader.dhost,sizeof(etHeader.dhost));
	long destIp = inet_addr("192.168.3.36");
	memcpy(arpHeader.daddr, &destIp, 4);
	
	/* Supposing to be on ethernet, set mac destination to 1:1:1:1:1:1 */
//	packet[0]=1;
//	packet[1]=1;
//	packet[2]=1;
//	packet[3]=1;
//	packet[4]=1;
//	packet[5]=1;
	
	/* set mac source to 2:2:2:2:2:2 */
//	packet[6]=2;
//	packet[7]=2;
//	packet[8]=2;
//	packet[9]=2;
//	packet[10]=2;
//	packet[11]=2;

	memcpy(packet, &etHeader, sizeof(etHeader));
	memcpy(packet+sizeof(etHeader), &arpHeader, sizeof(arpHeader));	
	
	this->sendPack(dev, packet);

	return 0;
}

void CPack::test()
{


//	pcap_if_t* alldevs;
//    pcap_if_t* d;
//    char errbuf[PCAP_ERRBUF_SIZE];
//
//	
//	pcap_findalldevs(&alldevs, errbuf);
//	d = alldevs->next;

// 	this->sendTestPack(this->dev);
}

char* CPack::test2()
{
	char* b;
	b = "val";
	return b;

//	int a = atoi("30");
//	a = 21;
//	char b[4];
//	sprintf(b,"bbp %s","tip");
//	memcpy(b, "koh",3);
//	return "kof32";

//	pcap_if_t* alldevs;
//    pcap_if_t* d;
//    char errbuf[PCAP_ERRBUF_SIZE];
//
//	
//	pcap_findalldevs(&alldevs, errbuf);
//	d = alldevs->next;
//	char b[sizeof(d)];
//	memcpy(b, d, sizeof(d));
//	return d->description;
}

unsigned char* CPack::str2mac(char *strMac)
{
	unsigned char* mac = new unsigned char[6];
	for(int i=0; i<6; i++) {
		char str[3];
		str[0] = strMac[i*3];
		str[1] = strMac[i*3+1];
		str[2] = 0;
		mac[i] = (unsigned char)strtol(str, NULL, 16);
	}
	return mac;
}

char* CPack::mac2str(u_char *mac)
{
	char *strMac = new char[18];
	sprintf(strMac, "%.2X:%.2X:%.2X:%.2X:%.2X:%.2X", *mac,*(mac+1),*(mac+2),*(mac+3),*(mac+4),*(mac+5));
	return strMac;
}

int CPack::sendAsk(char *smac, char *dmac, char *psmac, 
				   char *pshost, char *pdmac, char *pdhost)
{
	u_char packet[42];

	//info
	ETHeader etHeader;
	ARPHeader arpHeader;

	memcpy(etHeader.shost, this->str2mac(smac),6);
	memcpy(etHeader.dhost, this->str2mac(dmac),6);
	etHeader.type = 0x0608;

	arpHeader.hrd = 0x0100;
	arpHeader.eth_type = 0x0008;
	arpHeader.maclen = 6;
	arpHeader.iplen = 4;
	arpHeader.opcode = 0x0100;
	memcpy(arpHeader.smac, this->str2mac(psmac), 6);
	long sourceIp = inet_addr(pshost);
	memcpy(arpHeader.saddr, &sourceIp, 4);
	memcpy(arpHeader.dmac, this->str2mac(pdmac), 6);
	long destIp = inet_addr(pdhost);
	memcpy(arpHeader.daddr, &destIp, 4);

	memcpy(packet, &etHeader, sizeof(etHeader));
	memcpy(packet+sizeof(etHeader), &arpHeader, sizeof(arpHeader));	
	
	this->sendPack(packet,42);

	return 0;
}

int CPack::sendPack(u_char *pack, int len)
{
	pcap_t *fp;
    char errbuf[PCAP_ERRBUF_SIZE];
	
	if ((fp = pcap_open_live(this->dev->name,		// name of the device
							 65536,			// portion of the packet to capture. It doesn't matter in this case 
							 1,				// promiscuous mode (nonzero means promiscuous)
							 1000,			// read timeout
							 errbuf			// error buffer
							 )) == NULL)
	{
		fprintf(stderr,"\nUnable to open the adapter. %s is not supported by WinPcap\n", errbuf);
		return 2;
	}

	/* Send down the packet */
	if (pcap_sendpacket(fp,	// Adapter
		pack,				// buffer with the packet
		len					// size
		) != 0)
	{
		fprintf(stderr,"\nError sending the packet: \n", pcap_geterr(fp));
		return 3;
	}

	pcap_close(fp);

	return 0;
}

int CPack::recvPack(char * buf)
{
	int res;
	struct tm *ltime;
	char timestr[16];
	struct pcap_pkthdr *header;
	const u_char *pkt_data;
	time_t local_tv_sec;
    
    /* ��ȡ���ݰ� */
    res = pcap_next_ex(adhandle, &header, &pkt_data);
	if( res > 0){
        /* ��ʱ���ת���ɿ�ʶ��ĸ�ʽ */
        local_tv_sec = header->ts.tv_sec;
        ltime=localtime(&local_tv_sec);
        strftime( timestr, sizeof timestr, "%H:%M:%S", ltime);

		sprintf(buf, "%s,%.6d len:%d\r\n", timestr, header->ts.tv_usec, header->len);		
		
		/* Print the packet */
		if(header->caplen > 1500) {
			sprintf(buf, "%s\r\n", "Too much char");
			return -2;
		}
//		int i;
//		for (i=1; (i < header->caplen + 1 ) ; i++)
//		{
//			sprintf(buf,"%s%.2x ", buf,pkt_data[i-1]);
//			if ( (i % LINE_LEN) == 0) sprintf(buf,"%s    ",buf);
//			if ( (i % LINE_LEN_32) == 0) sprintf(buf,"%s\r\n",buf);
//		}
//		PETHeader eth = (PETHeader)pkt_data;
//		PIPHEADER ip = (PIPHEADER)(pkt_data+sizeof(ETHeader));
//		PTCPHEADER tcp = (PTCPHEADER)(pkt_data+sizeof(ETHeader)+sizeof(IPHEADER));
//		if(ntohs(eth->type) == 0x0800) {
//			sprintf(buf, "%sSource IP: %s  Source Port: %u\r\n",buf,
//				ip2str(ip->ip_src), ntohs(tcp->SourPort));
//		}
//		sprintf(buf,"%s\r\n",buf);
		
		PETHeader eth = (PETHeader)pkt_data;
		PIPHEADER ip = (PIPHEADER)(pkt_data+sizeof(ETHeader));
		if(ntohs(eth->type) == 0x0800) {
			if(ip->proto == 0x11) {
				PUDPPKT udppkt = (PUDPPKT)pkt_data;
				sprintf(buf,"%sUDP source %s:%d    destination %s:%d\r\n", 
					buf,
					ip2str(udppkt->ip.ip_src),ntohs(udppkt->udp.sport),
					ip2str(udppkt->ip.ip_dst), ntohs(udppkt->udp.dport));
			} else if(ip->proto == 0x06) {
				PTCPPKT tcppkt = (PTCPPKT)pkt_data;
				PTCPHEADER tcp = (PTCPHEADER)(pkt_data+sizeof(ETHeader)+
					sizeof(IPHEADER));
				sprintf(buf,"%sTCP source %s:%d    destination %s:%d\r\n", 
					buf,
					ip2str(tcppkt->ip.ip_src),ntohs(tcppkt->tcp.SourPort),
					ip2str(tcppkt->ip.ip_dst), ntohs(tcppkt->tcp.DestPort));
			}
		} else if(ntohs(eth->type) == 0x0806) {
			PARPHeader arp = (PARPHeader)(pkt_data+sizeof(ETHeader));
			sprintf(buf,"%sARP %s/%s	%s/%s\r\n",buf,
				mac2str(arp->smac),ip2str(arp->saddr),
				mac2str(arp->dmac),ip2str(arp->daddr));
		}
    }
    
    if(res == -1){
        return -1;
    }
    
    return res;
}

int CPack::openDev()
{
	char errbuf[PCAP_ERRBUF_SIZE];
    
    /* ���豸 */
    if ( (adhandle= pcap_open(dev->name,          // �豸��
                              65536,            // Ҫ��׽�����ݰ��Ĳ��� 
                                                // 65535��֤�ܲ��񵽲�ͬ������·���ϵ�ÿ�����ݰ���ȫ������
                              PCAP_OPENFLAG_PROMISCUOUS,    // ����ģʽ
                              1000,             // ��ȡ��ʱʱ��
                              NULL,             // Զ�̻�����֤
                              errbuf            // ���󻺳��
                              ) ) == NULL)
    {
        fprintf(stderr,"\nUnable to open the adapter. %s is not supported by WinPcap\n", dev->name);
        return -1;
    }

	return 0;
}

char* CPack::ip2str(UCHAR *ip)
{
	char *strIp = new char[16];
	sprintf(strIp, "%u.%u.%u.%u", *ip,*(ip+1),*(ip+2),*(ip+3));
	return strIp;
}

PUDPPKT CPack::parseUDP(u_char *pkt_data)
{
	PUDPPKT pkt = (PUDPPKT)pkt_data;

	return pkt;
}

char* CPack::iptos(u_long in)
{
    static char output[IPTOSBUFFERS][3*4+3+1];
    static short which;
    u_char *p;

    p = (u_char *)&in;
    which = (which + 1 == IPTOSBUFFERS ? 0 : which + 1);
    sprintf(output[which], "%d.%d.%d.%d", p[0], p[1], p[2], p[3]);
    return output[which];
}

CString CPack::GetAdaptersString()
{
	int fType = 0;
	
	if(fType == 0) {
		PIP_ADAPTER_INFO pAdapterInfo;
		PIP_ADAPTER_INFO pAdapter = NULL;
		DWORD dwRetVal = 0;
		UINT i;
		/* variables used to print DHCP time info */
		//     struct tm newtime;
		//     char buffer[32];
		CString strAdapters;
		CString tmpStr;
		
		pAdapterInfo = (IP_ADAPTER_INFO *) malloc(sizeof(IP_ADAPTER_INFO));
		unsigned   long   ulOutBufLen   =   sizeof(IP_ADAPTER_INFO);
		if(GetAdaptersInfo(pAdapterInfo, &ulOutBufLen) == ERROR_BUFFER_OVERFLOW) {
			free(pAdapterInfo);
			pAdapterInfo = (IP_ADAPTER_INFO *) malloc(ulOutBufLen);
		}
		if((dwRetVal = GetAdaptersInfo(pAdapterInfo, &ulOutBufLen)) == NO_ERROR) {
			pAdapter = pAdapterInfo;
			while (pAdapter) {
				// 			if(strstr(pAdapter->Description, "Broadcom") == NULL) {
				// 				pAdapter = pAdapter->Next;
				// 				continue;
				// 			}
				tmpStr.Format("\tComboIndex: \t%d\r\n", pAdapter->ComboIndex);
				strAdapters.Insert(strAdapters.GetLength(), tmpStr);
				tmpStr.Format("\tAdapter Name: \t%s\r\n", pAdapter->AdapterName);
				strAdapters.Insert(strAdapters.GetLength(), tmpStr);
				tmpStr.Format("\tAdapter Desc: \t%s\r\n", pAdapter->Description);
				strAdapters.Insert(strAdapters.GetLength(), tmpStr);
				tmpStr.Format("\tAdapter Addr: \t");
				strAdapters.Insert(strAdapters.GetLength(), tmpStr);
				for (i = 0; i < pAdapter->AddressLength; i++) {
					if (i == (pAdapter->AddressLength - 1))
						tmpStr.Format("%.2X\r\n", (int) pAdapter->Address[i]);
					else
						tmpStr.Format("%.2X-", (int) pAdapter->Address[i]);
					strAdapters.Insert(strAdapters.GetLength(), tmpStr);
				}
				tmpStr.Format("\tIndex: \t%d\r\n", pAdapter->Index);
				strAdapters.Insert(strAdapters.GetLength(), tmpStr);
				strAdapters.Insert(strAdapters.GetLength(), "\tType: \t");
				switch (pAdapter->Type) {
				case MIB_IF_TYPE_OTHER:
					tmpStr.Format("Other\r\n");
					break;
				case MIB_IF_TYPE_ETHERNET:
					tmpStr.Format("Ethernet\r\n");
					break;
				case MIB_IF_TYPE_TOKENRING:
					tmpStr.Format("Token Ring\r\n");
					break;
				case MIB_IF_TYPE_FDDI:
					tmpStr.Format("FDDI\r\n");
					break;
				case MIB_IF_TYPE_PPP:
					tmpStr.Format("PPP\r\n");
					break;
				case MIB_IF_TYPE_LOOPBACK:
					tmpStr.Format("Lookback\r\n");
					break;
				case MIB_IF_TYPE_SLIP:
					tmpStr.Format("Slip\r\n");
					break;
				default:
					tmpStr.Format("Unknown type %ld\r\n", pAdapter->Type);
					break;
				}
				strAdapters.Insert(strAdapters.GetLength(), tmpStr);
				
				tmpStr.Format("\tIP Address: \t%s\r\n",
					pAdapter->IpAddressList.IpAddress.String);
				strAdapters.Insert(strAdapters.GetLength(), tmpStr);
				tmpStr.Format("\tIP Mask: \t%s\r\n", pAdapter->IpAddressList.IpMask.String);
				strAdapters.Insert(strAdapters.GetLength(), tmpStr);
				
				tmpStr.Format("\tGateway: \t%s\r\n", pAdapter->GatewayList.IpAddress.String);
				strAdapters.Insert(strAdapters.GetLength(), tmpStr);
				strAdapters.Insert(strAdapters.GetLength(), "\t***\r\n");
				
				if (pAdapter->DhcpEnabled) {
					strAdapters.Insert(strAdapters.GetLength(), "\tDHCP Enabled: Yes\r\n");
					tmpStr.Format("\t  DHCP Server: \t%s\r\n",
						pAdapter->DhcpServer.IpAddress.String);
					strAdapters.Insert(strAdapters.GetLength(), tmpStr);
				} else {
					strAdapters.Insert(strAdapters.GetLength(), "\tDHCP Enabled: No\r\n");
				}
				if (pAdapter->HaveWins) {
					strAdapters.Insert(strAdapters.GetLength(), "\tHave Wins: Yes\r\n");
					tmpStr.Format("\t  Primary Wins Server:    %s\r\n",
						pAdapter->PrimaryWinsServer.IpAddress.String);
					strAdapters.Insert(strAdapters.GetLength(), tmpStr);
					tmpStr.Format("\t  Secondary Wins Server:  %s\r\n",
						pAdapter->SecondaryWinsServer.IpAddress.String);
					strAdapters.Insert(strAdapters.GetLength(), tmpStr);
				} else {
					strAdapters.Insert(strAdapters.GetLength(), "\tHave Wins: No\r\n");
				}
				pAdapter = pAdapter->Next;
				strAdapters.Insert(strAdapters.GetLength(), "\r\n");
			}
			
		} else {
			tmpStr.Format("GetAdaptersInfo failed with error: %d\r\n", dwRetVal);
			strAdapters.Insert(strAdapters.GetLength(), tmpStr);
		}
		if(pAdapterInfo)
			free(pAdapterInfo);
		return strAdapters;
	} 
	else if(fType == 1) {
		pcap_if_t *alldevs;
		pcap_if_t *d;
		char errbuf[PCAP_ERRBUF_SIZE];
		int i=0;
// 		int inum;
// 		pcap_t *adhandle;
// 		int res;
// 		struct tm *ltime;
// 		char timestr[16];
// 		struct pcap_pkthdr *header;
// 		const u_char *pkt_data;
// 		time_t local_tv_sec;
		pcap_addr_t *a;
		
		CString infos;
		
		/* ��ȡ�����豸�б� */
		if (pcap_findalldevs_ex(PCAP_SRC_IF_STRING, NULL, &alldevs, errbuf) == -1)
		{
			CString strError;
			strError.Format("Error in pcap_findalldevs: %s\r\n",errbuf);
			return strError;
		}
		
		/* ��ӡ�б� */
		CString tmp;
		for(d=alldevs; d; d=d->next)
		{
			CString adapterInfo;
			adapterInfo.Format("%d. %s\r\n", ++i, d->name);
			if (d->description) {
				adapterInfo.Insert(adapterInfo.GetLength(),d->description);
				adapterInfo.Insert(adapterInfo.GetLength(),"\r\n");
			}
			
			/* IP addresses */
			for(a=d->addresses;a;a=a->next) {
				tmp.Format("\tAddress Family: #%d\r\n",a->addr->sa_family);
				adapterInfo.Insert(adapterInfo.GetLength(),tmp);
				if (a->addr) {
					tmp.Format("\tAddress: %s\r\n",
						iptos(((struct sockaddr_in *)a->addr)->sin_addr.s_addr));
					adapterInfo.Insert(adapterInfo.GetLength(),tmp);
				}
				if (a->netmask) {
					tmp.Format("\tNetmask: %s\r\n",
						iptos(((struct sockaddr_in *)a->netmask)->sin_addr.s_addr));
					adapterInfo.Insert(adapterInfo.GetLength(),tmp);
				}
				if (a->broadaddr) {
					tmp.Format("\tBroadcast Address: %s\r\n",
						iptos(((struct sockaddr_in *)a->broadaddr)->sin_addr.s_addr));
					adapterInfo.Insert(adapterInfo.GetLength(),tmp);
				}
				if (a->dstaddr) {
					tmp.Format("\tDestination Address: %s\r\n",
						iptos(((struct sockaddr_in *)a->dstaddr)->sin_addr.s_addr));
					adapterInfo.Insert(adapterInfo.GetLength(),tmp);
				}
			}
			infos.Insert(infos.GetLength(),adapterInfo);
			infos.Insert(infos.GetLength(),"\r\n");
		}
		
		return infos;
	}
	return "";
}

BOOL CPack::CompareIP(unsigned char ip1[4], unsigned char ip2[4])
{
	BOOL bReturn = FALSE;
	if(ip1[0] != ip2[0])
		return bReturn;
	if(ip1[1] != ip2[1])
		return bReturn;
	if(ip1[2] != ip2[2])
		return bReturn;
	if(ip1[3] != ip2[3])
		return bReturn;

	return TRUE;
}

BOOL CPack::CompareMAC(unsigned char mac1[6], unsigned char mac2[6])
{
	BOOL bReturn = FALSE;
	if(mac1[0] != mac2[0])
		return bReturn;
	if(mac1[1] != mac2[1])
		return bReturn;
	if(mac1[2] != mac2[2])
		return bReturn;
	if(mac1[3] != mac2[3])
		return bReturn;
	if(mac1[4] != mac2[4])
		return bReturn;
	if(mac1[5] != mac2[5])
		return bReturn;

	return TRUE;
}

unsigned char* CPack::GetGateWayIP(DWORD adapterIndex)
{
	PIP_ADAPTER_INFO pAdapterInfo;
	PIP_ADAPTER_INFO pAdapter = NULL;
	DWORD dwRetVal = 0;
	unsigned char *gatewayIP = new unsigned char[4];

	pAdapterInfo = (IP_ADAPTER_INFO *) malloc(sizeof(IP_ADAPTER_INFO));
	unsigned   long   ulOutBufLen   =   sizeof(IP_ADAPTER_INFO);
	if(GetAdaptersInfo(pAdapterInfo, &ulOutBufLen) == ERROR_BUFFER_OVERFLOW) {
		free(pAdapterInfo);
		pAdapterInfo = (IP_ADAPTER_INFO *) malloc(ulOutBufLen);
	}
	if((dwRetVal = GetAdaptersInfo(pAdapterInfo, &ulOutBufLen)) == NO_ERROR) {
		pAdapter = pAdapterInfo;
        while (pAdapter) {
			if(pAdapter->Index == adapterIndex) {
				u_long ulIP = inet_addr(pAdapter->GatewayList.IpAddress.String);
				memcpy(gatewayIP, &ulIP, 4);
				return gatewayIP;
			}
			pAdapter = pAdapter->Next;
		}
	}
	if(pAdapterInfo)
		free(pAdapterInfo);
	return NULL;
}

int CPack::RetrGatewayMac(unsigned char **pGatewayMacs, int *len)
{
	int nRetVal;
	char *buf = new char[MAX_PACK_SIZE];
	*len = 0;

	u_long gip = inet_addr(m_pAdapter->GatewayList.IpAddress.String);
	m_pGatewayIp = (unsigned char *)&gip;

	unsigned char* smac	= (u_char*)m_pAdapter->Address;
	unsigned char* dmac	= str2mac("FF:FF:FF:FF:FF:FF");
	u_long sip = inet_addr(m_pAdapter->IpAddressList.IpAddress.String);
	unsigned char* shost = (u_char *)&sip;
	unsigned char* pdmac = str2mac("00:00:00:00:00:00");
	unsigned char* dhost = (u_char *)&gip;
	if(!adhandle)
		openDev();
	SendARPPack(smac,dmac,smac,shost,pdmac,dhost,ARPOP_REQUEST);

	CTime t = CTime::GetCurrentTime();
	time_t nStart = t.GetTime();
	time_t now = nStart;
	time_t nInterval = 2;
	char *buff = new char[4096];
	int n=0;
	while( (nRetVal = dumpPack(buf)) >= 0) {
		t = CTime::GetCurrentTime();
		now = t.GetTime();
		if((now-nStart)>nInterval)
			break;

		if(nRetVal == 0)
			continue;
		PETHeader eth = (PETHeader)buf;
		DWORD prtcl = ntohs(eth->type);
		if(prtcl == ETH_TYPE_ARP) {
			PARPHeader arp = (PARPHeader)(buf + sizeof(ETHeader));
			if(ntohs(arp->opcode) == ARPOP_REPLY && CompareIP(arp->saddr,dhost)) {
				(*len)++;
				memcpy(*pGatewayMacs+(6*n), arp->smac, 6);
				if(*len == 1) {		//this is the mac address we need
					memcpy(m_pGatewayMac,arp->smac,6);
					m_bIsSetGatewayMac = TRUE;
				}
				n++;
			}
		}
		Sleep(50);
	}
	return *len;
}

int CPack::dumpPack(char *buf)
{
	int res;
	struct pcap_pkthdr *header;
	const u_char *pkt_data;
    
    /* ��ȡ���ݰ� */
    res = pcap_next_ex(adhandle, &header, &pkt_data);
	if( res > 0){
		/* Print the packet */
		if(header->caplen > MAX_PACK_SIZE) {
			sprintf(buf, "%s\r\n", "Too much char");
			return -2;
		}

		memcpy(buf, pkt_data, header->caplen);
    }
    
    if(res == -1){
        return -1;
    }
    
    return res;
}

int CPack::sendAskPack(u_char *smac, u_char *dmac, u_char *psmac, 
					   u_char *pshost, u_char *pdmac, u_char *pdhost)
{
	u_char packet[42];

	//info
	ETHeader etHeader;
	ARPHeader arpHeader;

	memcpy(etHeader.shost, smac,6);
	memcpy(etHeader.dhost, dmac,6);
	etHeader.type = 0x0608;

	arpHeader.hrd = 0x0100;
	arpHeader.eth_type = 0x0008;
	arpHeader.maclen = 6;
	arpHeader.iplen = 4;
	arpHeader.opcode = 0x0100;
	memcpy(arpHeader.smac, psmac, 6);
	memcpy(arpHeader.saddr, pshost, 4);
	memcpy(arpHeader.dmac, pdmac, 6);
	memcpy(arpHeader.daddr, pdhost, 4);

	memcpy(packet, &etHeader, sizeof(etHeader));
	memcpy(packet+sizeof(etHeader), &arpHeader, sizeof(arpHeader));	
	
	this->sendPack(packet,42);

	return 0;
}

int CPack::GetCurrAdapter()
{
	PIP_ADAPTER_INFO pAdapterInfo;
	PIP_ADAPTER_INFO pAdapter = NULL;
	DWORD dwRetVal = 0;
	unsigned char *gatewayIP = new unsigned char[4];

	pAdapterInfo = (IP_ADAPTER_INFO *) malloc(sizeof(IP_ADAPTER_INFO));
	unsigned   long   ulOutBufLen   =   sizeof(IP_ADAPTER_INFO);
	if(GetAdaptersInfo(pAdapterInfo, &ulOutBufLen) == ERROR_BUFFER_OVERFLOW) {
		free(pAdapterInfo);
		pAdapterInfo = (IP_ADAPTER_INFO *) malloc(ulOutBufLen);
	}
	if((dwRetVal = GetAdaptersInfo(pAdapterInfo, &ulOutBufLen)) == NO_ERROR) {
		pAdapter = pAdapterInfo;
        while (pAdapter) {
			if(pAdapter->ComboIndex == ADAPTER_INDEX) {
				m_pAdapter = pAdapter;
				m_dwAdapterIndex = pAdapter->Index;
				str2ip(pAdapter->GatewayList.IpAddress.String, m_pGatewayIp);
				str2ip(pAdapter->GatewayList.IpAddress.String, m_szGWip);
				return 0;
			}
			pAdapter = pAdapter->Next;
		}
	}
	if(pAdapterInfo)
		free(pAdapterInfo);
	return -1;
}

int CPack::str2ip(char *strIP, unsigned char *ip)
{
	u_long uip = inet_addr(strIP);
	ip[3] = (unsigned char)(uip>>24);
	ip[2] = (unsigned char)((uip&0xff0000)>>16);
	ip[1] = (unsigned char)((uip&0xff00)>>8);
	ip[0] = (unsigned char)(uip&0xff);

	return 0;
}

int CPack::SendARPPack(u_char *smac, u_char *dmac, u_char *psmac, u_char *pshost, 
					   u_char *pdmac, u_char *pdhost, unsigned short opCode)
{
	u_char packet[42];

	//info
	ETHeader etHeader;
	ARPHeader arpHeader;

	memcpy(etHeader.shost, smac,6);
	memcpy(etHeader.dhost, dmac,6);
	etHeader.type = 0x0608;

	arpHeader.hrd = 0x0100;
	arpHeader.eth_type = 0x0008;
	arpHeader.maclen = 6;
	arpHeader.iplen = 4;
	arpHeader.opcode = htons(opCode);
	memcpy(arpHeader.smac, psmac, 6);
	memcpy(arpHeader.saddr, pshost, 4);
	memcpy(arpHeader.dmac, pdmac, 6);
	memcpy(arpHeader.daddr, pdhost, 4);

	memcpy(packet, &etHeader, sizeof(etHeader));
	memcpy(packet+sizeof(etHeader), &arpHeader, sizeof(arpHeader));	
	
	this->sendPack(packet,42);

	return 0;
}

int CPack::SendARPPacket(char *smac, char *dmac, char *psmac, char *pshost, 
						 char *pdmac, char *pdhost, unsigned short opCode)
{
	u_char *smac_u = str2mac(smac);
	u_char *dmac_u = str2mac(dmac);
	u_char *psmac_u = str2mac(psmac);
	u_char *pdmac_u = str2mac(pdmac);
	u_char *pshost_u = new u_char[4]; 
	str2ip(pshost,pshost_u);
	u_char *pdhost_u = new u_char[4];
	str2ip(pdhost,pdhost_u);

	return SendARPPack(smac_u, dmac_u, psmac_u, pshost_u, pdmac_u, pdhost_u, opCode);
}

int CPack::KeepDefense(time_t interval)
{
	m_bKeepDefense = TRUE;
	m_nDefenseInterval = interval;
	unsigned char* smac	= (u_char*)m_pAdapter->Address;
	unsigned char* dmac	= m_pGatewayMac;
	unsigned char* shost = new unsigned char[4];
	str2ip(m_pAdapter->IpAddressList.IpAddress.String, shost);
	unsigned char* pdmac = m_pGatewayMac;
	unsigned char* dhost = new unsigned char[4];
	str2ip(m_pAdapter->GatewayList.IpAddress.String,dhost);
	if(!adhandle)
		openDev();
	time_t start;
	time_t now;
	time(&start);
	now = start;
	for(;;) {
		SendARPPack(smac,dmac,smac,shost,pdmac,dhost,ARPOP_REQUEST);
		Sleep(20);
		SendARPPack(smac,dmac,smac,shost,pdmac,dhost,ARPOP_REPLY);
		Sleep(1000);
		if(m_bKeepDefense == FALSE) {
			break;
		}
		start = now;
		time(&now);
		m_nDefenseInterval -= now-start; 
		if(m_nDefenseInterval < 0) {
			break;
		}
	}
	return 0;
}

int CPack::refreshDetect(CList<PDETPKT,PDETPKT>&pktList)
{
	PDETPKT pkt = new DETPKT;
	POSITION pos = pktList.GetHeadPosition();
	int nPos = 0;
	while(pos != NULL) {
		PDETPKT pkt = pktList.GetNext(pos);
		pkt->alive--;
		if(pkt->alive <= 0) {
			POSITION p = pktList.FindIndex(nPos);
			pktList.RemoveAt(p);
			nPos--;
		}
		nPos++;
	}
	return 0;
}

// CPack::CPack(const CPack &source)
// {
// 
// }

int CPack::AddDetect(CList<PDETPKT,PDETPKT>&pktList, PDETPKT pkt)
{
	PDETPKT pack;
	POSITION pos;
	BOOL noMatch = TRUE;
	for(int i=0; i<pktList.GetCount(); i++) {
		pos = pktList.FindIndex(i);
		pack = pktList.GetAt(pos);
		if(CompareMAC(pack->arp.eth.dhost,pkt->arp.eth.dhost) &&
			CompareMAC(pack->arp.eth.shost,pkt->arp.eth.shost) &&
			pack->arp.arp.opcode == pkt->arp.arp.opcode) {
			noMatch = FALSE;
			pack->alive = PACKALIVE;
		}
	}
	if(noMatch)
		pktList.AddTail(pkt);
	return 0;
}
