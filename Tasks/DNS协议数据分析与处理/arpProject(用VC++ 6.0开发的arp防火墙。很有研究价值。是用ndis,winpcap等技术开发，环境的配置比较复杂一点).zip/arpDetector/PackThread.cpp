// PackThread.cpp : implementation file
//

#include "stdafx.h"
#include "arpDetector.h"
#include "PackThread.h"

#include "MainFrm.h"
#include "arpDetectorView.h"
#include "ARP.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPackThread

CPack* CPackThread::m_pack = new CPack;
BOOL CPackThread::bIsDefensing = FALSE;

IMPLEMENT_DYNCREATE(CPackThread, CWinThread)

CPackThread::CPackThread()
{
}

CPackThread::~CPackThread()
{
}

BOOL CPackThread::InitInstance()
{
	// TODO:  perform and per-thread initialization here
	return TRUE;
}

int CPackThread::ExitInstance()
{
	// TODO:  perform any per-thread cleanup here
	return CWinThread::ExitInstance();
}

BEGIN_MESSAGE_MAP(CPackThread, CWinThread)
	//{{AFX_MSG_MAP(CPackThread)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPackThread message handlers

UINT CPackThread::DumpPacket(LPVOID lParam)
{
	char *buf = new char[5500];
	CString log;
	int retval;
	CPack *pPack = (CPack *)lParam;

	pPack->openDev();
	CMainFrame *pMain=(CMainFrame *)AfxGetApp()->m_pMainWnd;
	CArpDetectorView* pView = (CArpDetectorView*)pMain->GetActiveView();

	while((retval = pPack->recvPack(buf)) >= 0) {
		if(retval == 0)
			continue;

		int bufLen = strlen(buf);
		log.Format("%s\r\n",buf);
		::PostMessage(pView->m_winMainPanel.m_hWnd, WM_PACKLOGCHANGE, 
			(WPARAM)0, (LPARAM)(LPSTR)&log);
		Sleep(50);
	}
	
	return 0L;
}

UINT CPackThread::SetGatewayARPEntity(LPVOID lParam)
{
	unsigned char *ip = new unsigned char[4];
	unsigned char *mac = new unsigned char[6*1024];
	int len = 0;
	CPack *pPack = (CPack *)lParam;

	len = pPack->RetrGatewayMac(&mac, &len);
	if(!len) {
		AfxMessageBox(_T("Couldn't get gateway mac"), MB_ICONSTOP|MB_OK);
		exit(1);
	}
	CPack::str2ip(pPack->m_pAdapter->GatewayList.IpAddress.String, ip);
	
	CMainFrame *pMain=(CMainFrame *)AfxGetApp()->m_pMainWnd;
	CArpDetectorView* pView = (CArpDetectorView*)pMain->GetActiveView();
	CString str;
	for(int n=0; n<len; n++) {
		str.Format("#%d  %s", n, CPack::mac2str(mac+n*6));
		::PostMessage(pView->m_winMainPanel.m_hWnd, WM_PACKLOGCHANGE, 
			(WPARAM)0, (LPARAM)(LPSTR)&str);
	}

	CARP arp;
	CString str2;
	if (arp.EditEntry(ip, mac, 4, pPack->m_dwAdapterIndex)) {
		str2.LoadString(GATEWAY_MAC_ARP_TABLE_SETTO_STATIC);
		str2.Insert(str2.GetLength(), CPack::mac2str(mac));
		::PostMessage(pView->m_winMainPanel.m_hWnd, WM_PACKLOGCHANGE, 
			(WPARAM)0, (LPARAM)(LPSTR)&str2);
	} else {
		str2.Format("Update ARP table failed");
		::PostMessage(pView->m_winMainPanel.m_hWnd, WM_PACKLOGCHANGE, 
			(WPARAM)0, (LPARAM)(LPSTR)&str2);
	}
	Sleep(5000);
	return 0L;
}

UINT CPackThread::keepDefense(LPVOID lParam)
{
	CMainFrame *pMain=(CMainFrame *)AfxGetApp()->m_pMainWnd;
	CArpDetectorView* pView = (CArpDetectorView*)pMain->GetActiveView();
	CString str;

	CPack *pPack = (CPack *)lParam;
	time_t interval = DEFENSE_INTERVAL;
	if(!bIsDefensing) {
		bIsDefensing = TRUE;
		str.LoadString(START_DEFENSE_PROCESS);
		::PostMessage(pView->m_winMainPanel.m_hWnd, WM_PACKLOGCHANGE, 
			(WPARAM)0, (LPARAM)(LPSTR)&str);

		pPack->KeepDefense(interval);
		bIsDefensing = FALSE;
	} else {
		pPack->m_nDefenseInterval = interval;
	}
	return 0L;
}

UINT CPackThread::detect(LPVOID lParam)
{
	int nRetVal;
	char *buf = new char[1500];
	CList<PDETPKT, PDETPKT> askPack;		//ask from local
	CList<PDETPKT, PDETPKT> requestPack;	//ask from remote
	DETPKT pack;
	ARPPKT arpPack;
	CPack *pPack = (CPack *)lParam;
	CString str;
	u_char *localIP = new u_char[4];

	CPack::str2ip(pPack->m_pAdapter->IpAddressList.IpAddress.String,localIP);

	time_t start;
	time_t now;
	time_t interval = 2;
	time(&start);

	CMainFrame *pMain=(CMainFrame *)AfxGetApp()->m_pMainWnd;
	CArpDetectorView* pView = (CArpDetectorView*)pMain->GetActiveView();

	while((nRetVal=pPack->dumpPack(buf)) >= 0) {
		time(&now);
		if(now-start>interval) {
			start = now;
			pPack->refreshDetect(requestPack);
			pPack->refreshDetect(askPack);
		}
		BOOL isRisk = FALSE;
		if(nRetVal == 0)
			continue;
		PETHeader eth = (PETHeader)buf;
		u_short prtcl = ntohs(eth->type);
		if(prtcl == ETH_TYPE_ARP) {
			ZeroMemory(&arpPack,sizeof(ARPPKT));
			memcpy(&arpPack,buf,sizeof(ARPPKT));
			pack.alive = PACKALIVE;
			pack.arp = arpPack;
			if(!CPack::CompareMAC(arpPack.arp.smac,arpPack.eth.shost)) {
				isRisk = TRUE;
			}
			if(ntohs(arpPack.arp.opcode) == ARPOP_REQUEST) {
				//store packet for further use
				if(CPack::CompareMAC(arpPack.eth.dhost, 
					(u_char*)pPack->m_pAdapter->Address)) {
					pPack->AddDetect(requestPack, &pack);
				} else if(CPack::CompareMAC(arpPack.eth.shost, 
					(u_char*)pPack->m_pAdapter->Address)) {
					pPack->AddDetect(askPack, &pack);
				}

				if(CPack::CompareIP(arpPack.arp.daddr,localIP) &&
					!CPack::CompareMAC(arpPack.arp.saddr,pPack->m_pGatewayMac))
					isRisk = TRUE;
			} else if(ntohs(arpPack.arp.opcode) == ARPOP_REPLY) {
				if(CPack::CompareMAC(arpPack.arp.smac,pPack->m_pGatewayMac) &&
					CPack::CompareIP(arpPack.arp.saddr,pPack->m_szGWip)){
					//ok if reply from gateway
				}else if(CPack::CompareMAC(arpPack.arp.smac,
					(u_char*)pPack->m_pAdapter->Address) &&
					CPack::CompareIP(arpPack.arp.saddr,localIP)) {
					//ok if it's a send out packet
				} else {
					isRisk = TRUE;
				}
			}
			if(isRisk) {
				pPack->m_bIsRisk = TRUE;
				str.LoadString(RISK_DETECTED);
				::PostMessage(pView->m_winMainPanel.m_hWnd, WM_PACKLOGCHANGE, 
					(WPARAM)0, (LPARAM)(LPSTR)&str);
				AfxBeginThread(CPackThread::keepDefense, (LPVOID)pPack);
			}
			str.Format("Դ��ַ: %s/%s    ->    Ŀ�ĵ�ַ: %s/%s  ����:%s",
				pPack->mac2str(arpPack.eth.shost), 
				pPack->ip2str(arpPack.arp.saddr),
				pPack->mac2str(arpPack.eth.dhost), 
				pPack->ip2str(arpPack.arp.daddr),
				(ntohs(arpPack.arp.opcode)==ARPOP_REQUEST)?"����":"Ӧ��");
			::PostMessage(pView->m_winMainPanel.m_hWnd, WM_PACKLOGCHANGE, 
				(WPARAM)0, (LPARAM)(LPSTR)&str);
		}
		Sleep(200);
	}

	return 0L;
}
