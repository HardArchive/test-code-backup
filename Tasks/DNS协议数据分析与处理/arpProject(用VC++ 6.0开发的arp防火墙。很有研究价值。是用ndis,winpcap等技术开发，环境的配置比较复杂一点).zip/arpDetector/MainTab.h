#if !defined(AFX_MAINTAB_H__D3064DE9_8881_4ECA_BADF_5C2F7EFA8F5C__INCLUDED_)
#define AFX_MAINTAB_H__D3064DE9_8881_4ECA_BADF_5C2F7EFA8F5C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// MainTab.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CMainTab window

class CMainTab : public CTabCtrl
{
// Construction
public:
	CMainTab();

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMainTab)
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CMainTab();

	// Generated message map functions
protected:
	//{{AFX_MSG(CMainTab)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MAINTAB_H__D3064DE9_8881_4ECA_BADF_5C2F7EFA8F5C__INCLUDED_)
