// arpDetectorDoc.h : interface of the CArpDetectorDoc class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_ARPDETECTORDOC_H__A1EC57BB_97A5_4A4E_9893_DBCB33C93B32__INCLUDED_)
#define AFX_ARPDETECTORDOC_H__A1EC57BB_97A5_4A4E_9893_DBCB33C93B32__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


class CArpDetectorDoc : public CDocument
{
protected: // create from serialization only
	CArpDetectorDoc();
	DECLARE_DYNCREATE(CArpDetectorDoc)

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CArpDetectorDoc)
	public:
	virtual BOOL OnNewDocument();
	virtual void Serialize(CArchive& ar);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CArpDetectorDoc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CArpDetectorDoc)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_ARPDETECTORDOC_H__A1EC57BB_97A5_4A4E_9893_DBCB33C93B32__INCLUDED_)
