// arpDetectorView.cpp : implementation of the CArpDetectorView class
//

#include "stdafx.h"
#include "arpDetector.h"

#include "arpDetectorDoc.h"
#include "arpDetectorView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CArpDetectorView

IMPLEMENT_DYNCREATE(CArpDetectorView, CScrollView)

BEGIN_MESSAGE_MAP(CArpDetectorView, CScrollView)
	//{{AFX_MSG_MAP(CArpDetectorView)
	ON_WM_CREATE()
	//}}AFX_MSG_MAP
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CScrollView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CScrollView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CScrollView::OnFilePrintPreview)
	ON_MESSAGE(WM_SHOWMAINPANEL, OnShowMainPanel)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CArpDetectorView construction/destruction

CArpDetectorView::CArpDetectorView()
{
	// TODO: add construction code here

}

CArpDetectorView::~CArpDetectorView()
{
}

BOOL CArpDetectorView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CScrollView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CArpDetectorView drawing

void CArpDetectorView::OnDraw(CDC* pDC)
{
	CArpDetectorDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	// TODO: add draw code for native data here

//	char* smac	= "00:39:0a:55:60:9f";
//	char* dmac	= "FF:FF:FF:FF:FF:FF";
//	char* shost	= "192.168.3.3";
//	char* pdmac = "00:00:00:00:00:00";
//	char* dhost	= "192.168.3.36";
//	m_pack.sendAsk(smac,dmac,smac,shost,pdmac,dhost);

//	MessageBox(m_pack.test2());
//	CString str;
//	int a = strtol("3f",NULL,16);
//	str.Format("%d",a);
//	pDC->TextOut(50,50, m_pack.dev->description);
//	m_pack.test();
}

/////////////////////////////////////////////////////////////////////////////
// CArpDetectorView printing

BOOL CArpDetectorView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	return DoPreparePrinting(pInfo);
}

void CArpDetectorView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add extra initialization before printing
}

void CArpDetectorView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add cleanup after printing
}

/////////////////////////////////////////////////////////////////////////////
// CArpDetectorView diagnostics

#ifdef _DEBUG
void CArpDetectorView::AssertValid() const
{
	CScrollView::AssertValid();
}

void CArpDetectorView::Dump(CDumpContext& dc) const
{
	CScrollView::Dump(dc);
}

CArpDetectorDoc* CArpDetectorView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CArpDetectorDoc)));
	return (CArpDetectorDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CArpDetectorView message handlers

int CArpDetectorView::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CScrollView::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	// TODO: Add your specialized creation code here
	PostMessage(WM_SHOWMAINPANEL);
	
	return 0;
}

afx_msg LRESULT CArpDetectorView::OnShowMainPanel(WPARAM wParam, LPARAM lParam)
{
	CRect rect;
	GetClientRect(rect);

	m_winMainPanel.Create(IDD_MAINPANEL, this);
	m_winMainPanel.MoveWindow(0,0,rect.Width(),rect.Height());
	m_winMainPanel.ShowWindow(SW_SHOW);
	
	return 0L;
}

void CArpDetectorView::OnInitialUpdate() 
{
	CScrollView::OnInitialUpdate();
	    
//	RECT rectDesktop;
//	::GetWindowRect(::GetDesktopWindow(), &rectDesktop);

	RECT rectTray;
	CWnd *traywnd = FindWindow("shell_traywnd", NULL);   
	traywnd->GetWindowRect(&rectTray);  //�@ȡ�΄՗l�Ĵ�С��λ��  
	int nSx = GetSystemMetrics(SM_CXSCREEN);
	int nSy = GetSystemMetrics(SM_CYSCREEN);

//	CPaintDC dc(this); 
//	int cx = ::GetDeviceCaps(dc.m_hDC,HORZRES); // �õ�����   
//    int cy = ::GetDeviceCaps(dc.m_hDC,VERTRES); // �õ��߶�  

//	CRect   rc;   
//	GetWindowRect(&rc);   
//	ClientToScreen(&rc);   
//	int   nHeight   =   rc.Height();   
//	int   nWidth   =   rc.Width();  


	CFrameWnd *pFrame=NULL;   
	pFrame=this->GetParentFrame();   
	if(pFrame)   
	{               
//		pFrame->SetWindowPos(NULL,0,0,rectDesktop.right,rectDesktop.bottom,   
//			SWP_NOACTIVATE|SWP_DRAWFRAME);   
//		pFrame->SetWindowPos(NULL,0,0,nSx,nSy,   
//			SWP_NOACTIVATE|SWP_DRAWFRAME);  
		pFrame->SetWindowPos(NULL,0,0,nSx,rectTray.top,   
				SWP_NOACTIVATE|SWP_DRAWFRAME); 
	}     
    
	CRect rectCient;
	GetClientRect(rectCient);
	CSize sizeTotal; 
	sizeTotal.cx = rectCient.Width();
	sizeTotal.cy = rectCient.Height();   
	SetScrollSizes(MM_TEXT, sizeTotal);

}
