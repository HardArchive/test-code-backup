//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by TestIOCTL.rc
//
#define IDS_COPYRIGHT                   2
#define IDS_DRIVER_OPEN_FAILED          3
#define IDS_UNEXPECTED_ENUMERATION_TERMINATION 4
#define IDS_EMPTY_ENUMERATION           5
#define IDS_APP_TITLE                   103

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        101
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
