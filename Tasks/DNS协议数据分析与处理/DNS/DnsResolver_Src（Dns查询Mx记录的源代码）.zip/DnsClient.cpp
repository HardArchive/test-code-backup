// DnsClient.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "DnsClient.h"
#include "Dns.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// The one and only application object

CWinApp theApp;

using namespace std;

int _tmain(int argc, TCHAR* argv[], TCHAR* envp[])
{


	int nRetCode = 0;

	// initialize MFC and print and error on failure
	if (!AfxWinInit(::GetModuleHandle(NULL), NULL, ::GetCommandLine(), 0))
	{
		// TODO: change error code to suit your needs
		cerr << _T("Fatal Error: MFC initialization failed") << endl;
		nRetCode = 1;
	}
	else
	{
		// TODO: code your application's behavior here.
		if(!AfxSocketInit())
			cout<<"Sorry socket was not initialized\n";

		char domain[1024];


		do
		{

			CDnsClient client;
			CStringList MXs;

			cout<<"Enter domain name to query for MX (type exit to end program)\nDomain=";
			cin>>domain;

			if(stricmp(domain,"exit")==0)
				break;

			cout<<"\n"<<(LPCTSTR)CDnsClient::GetMX(NULL,domain,MXs)<<"\n";

			cout<<"Domain="<<(LPCTSTR)domain<<"\n";

			POSITION Pos = MXs.GetHeadPosition();
			while(Pos)
			{
				CString Host = MXs.GetNext(Pos);
				cout<<"MX="<<(LPCTSTR)Host<<"\n";
			}

			cout<<"\n\n";

		}while(true);

	}

	return nRetCode;
}


