#if (!defined(__NEURO__BYTES__BUFFER__))
#define __NEURO__BYTES__BUFFER__

/************************************************************************
		 
		 Name   : CNeuroBuffer
		 Type   : Class
------------------------------------------------------------------------
		 Author : Akash Kava
		 Purpose: Bytes Buffer to store, allocate, reallocate etc.
		          Append etc
************************************************************************/

class CNeuroBuffer{
protected:

	BYTE *	m_pBuffer;
	int		m_nAllocatedSize;
	int		m_nSize;
	int		m_nGrowBy;
	int		m_nPointer;

	void UnsafeClear()
	{
		m_pBuffer = NULL;
		m_nAllocatedSize = 0;
		m_nSize = 0;
		m_nGrowBy = 64;
		m_nPointer = 0;
	}

public:

	CNeuroBuffer()
	{
		UnsafeClear();
	}

	CNeuroBuffer(BYTE * pBuffer,int nSize)
	{
		UnsafeClear();
		Allocate(nSize);
		Copy(pBuffer,nSize);
	}

	int GetSize()
	{
		return m_nSize;
	}

	BYTE * GetBuffer()
	{
		return m_pBuffer;
	}

	BYTE * GetBufferSetLength(int nSize)
	{
		UnsafeClear();
		Allocate(nSize);
		m_nSize = nSize;
		return m_pBuffer;
	}

	CNeuroBuffer(CNeuroBuffer & Buffer)
	{
		UnsafeClear();
		Allocate(Buffer.GetSize());
		Copy(Buffer.GetBuffer(),Buffer.GetSize());
	}

	virtual ~CNeuroBuffer()
	{
		Clear();
	}

	BOOL Allocate(int nSize)
	{
		int nAllocatedSize = ((nSize / m_nGrowBy) + 1)*m_nGrowBy;

		void * pBuffer = new BYTE [nAllocatedSize];

		if(!pBuffer)
			return false;
		
		if(m_nAllocatedSize)
		{
			memcpy(pBuffer,m_pBuffer,m_nAllocatedSize);
			delete m_pBuffer;
		}

		m_pBuffer = (BYTE *)pBuffer;
		m_nAllocatedSize = nAllocatedSize;
		return true;
	}

	BOOL Append(BYTE * pBuffer,int nSize)
	{
		if(m_nSize + nSize > m_nAllocatedSize)
		{
			if(!Allocate(m_nSize + nSize))
				return false;
		}
		memcpy((m_pBuffer + m_nSize),pBuffer,nSize);
		m_nSize += nSize;
		return true;
	}

	int Copy(BYTE * pBuffer,int nSize)
	{
		int nSizeCopied = m_nAllocatedSize > nSize ? nSize : m_nAllocatedSize;
		memcpy(m_pBuffer,pBuffer,nSizeCopied);
		m_nSize = nSizeCopied;
		return nSizeCopied;
	}

	void Clear()
	{
		if(m_nAllocatedSize)
			delete m_pBuffer;
		UnsafeClear();
	}

	void operator = (CNeuroBuffer & Buffer)
	{
		//UnsafeClear();
		Clear();
		Allocate(Buffer.GetSize());
		Copy(Buffer.GetBuffer(),Buffer.GetSize());
	}

	void operator += (CNeuroBuffer & Buffer)
	{
		Append(Buffer.GetBuffer(),Buffer.GetSize());
	}

	CString Detach()
	{
		CString Data = (LPCTSTR)m_pBuffer;
		Clear();
		return Data;
	}
};









#endif