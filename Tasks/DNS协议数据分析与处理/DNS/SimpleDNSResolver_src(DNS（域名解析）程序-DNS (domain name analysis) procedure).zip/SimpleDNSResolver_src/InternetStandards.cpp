/*=========================================================================== 
    (c) Copyright 2001, Emmanuel KARTMANN, all rights reserved
  =========================================================================== 
    File           : InternetStandards.h
    $Header: $
    Author         : Emmanuel KARTMANN <emmanuel@kartmann.org>
    Creation       : Friday 10/27/01 11:56:35 PM
    Remake         : 
  ------------------------------- Description ------------------------------- 

           Implementation of the CInternetStandards class.

  ------------------------------ Modifications ------------------------------ 
    $Log: $  
  =========================================================================== 
*/

#include "stdafx.h"
#include "InternetStandards.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CInternetStandards::CInternetStandards()
{

}

CInternetStandards::~CInternetStandards()
{

}

CString CInternetStandards::GetProtocolNameFromID(UCHAR chProtocol)
{
    CString szProtocolName = "Unknown";

    // This switch is built based on RFC 1010 - Assigned Numbers Protocol Numbers
    switch(chProtocol) {
    case 0:
        szProtocolName = "Reserved"; // Reserved
        break;
    case 1:
        szProtocolName = "ICMP"; // Internet Control Message
        break;
    case 2:
        szProtocolName = "IGMP"; // Internet Group Management
        break;
    case 3:
        szProtocolName = "GGP"; // Gateway-to-Gateway
        break;
    case 5:
        szProtocolName = "ST"; // Stream
        break;
    case 6:
        szProtocolName = "TCP"; // Transmission Control
        break;
    case 7:
        szProtocolName = "UCL"; // UCL
        break;
    case 8:
        szProtocolName = "EGP"; // Exterior Gateway Protocol
        break;
    case 9:
        szProtocolName = "IGP"; // any private interior gateway
        break;
    case 10:
        szProtocolName = "BBN-RCC-MON"; // BBN RCC Monitoring
        break;
    case 11:
        szProtocolName = "NVP-II"; // Network Voice Protocol
        break;
    case 12:
        szProtocolName = "PUP"; // PUP
        break;
    case 13:
        szProtocolName = "ARGUS"; // ARGUS
        break;
    case 14:
        szProtocolName = "EMCON"; // EMCON
        break;
    case 15:
        szProtocolName = "XNET"; // Cross Net Debugger
        break;
    case 16:
        szProtocolName = "CHAOS"; // Chaos
        break;
    case 17:
        szProtocolName = "UDP"; // User Datagram
        break;
    case 18:
        szProtocolName = "MUX"; // Multiplexing
        break;
    case 19:
        szProtocolName = "DCN-MEAS"; // DCN Measurement Subsystems
        break;
    case 20:
        szProtocolName = "HMP"; // Host Monitoring
        break;
    case 21:
        szProtocolName = "PRM"; // Packet Radio Measurement
        break;
    case 22:
        szProtocolName = "XNS-IDP"; // XEROX NS IDP
        break;
    case 23:
        szProtocolName = "TRUNK-1"; // Trunk-1
        break;
    case 24:
        szProtocolName = "TRUNK-2"; // Trunk-2
        break;
    case 25:
        szProtocolName = "LEAF-1"; // Leaf-1
        break;
    case 26:
        szProtocolName = "LEAF-2"; // Leaf-2
        break;
    case 27:
        szProtocolName = "RDP"; // Reliable Data Protocol
        break;
    case 28:
        szProtocolName = "IRTP"; // Internet Reliable Transaction
        break;
    case 29:
        szProtocolName = "ISO-TP4"; // ISO Transport Protocol Class 4
        break;
    case 30:
        szProtocolName = "NETBLT"; // Bulk Data Transfer Protocol
        break;
    case 31:
        szProtocolName = "MFE-NSP"; // MFE Network Services Protocol
        break;
    case 32:
        szProtocolName = "MERIT-INP"; // MERIT Internodal Protocol
        break;
    case 33:
        szProtocolName = "SEP"; // Sequential Exchange Protocol
        break;
    case 61:
        szProtocolName = "ANYHOST"; // any host internal protocol
        break;
    case 62:
        szProtocolName = "CFTP"; // CFTP
        break;
    case 63:
        szProtocolName = "ANYLAN"; // any local network
        break;
    case 64:
        szProtocolName = "SAT-EXPAK"; // SATNET and Backroom EXPAK
        break;
    case 65:
        szProtocolName = "MIT-SUBNET"; // MIT Subnet Support
        break;
    case 66:
        szProtocolName = "RVD"; // MIT Remote Virtual Disk Protocol
        break;
    case 67:
        szProtocolName = "IPPC"; // Internet Pluribus Packet Core
        break;
    case 68:
        szProtocolName = "ANYDFS"; // any distributed file system
        break;
    case 69:
        szProtocolName = "SAT-MON"; // SATNET Monitoring
        break;
    case 71:
        szProtocolName = "IPCV"; // Internet Packet Core Utility
        break;
    case 76:
        szProtocolName = "BR-SAT-MON"; // Backroom SATNET Monitoring
        break;
    case 78:
        szProtocolName = "WB-MON"; // WIDEBAND Monitoring
        break;
    case 79:
        szProtocolName = "WB-EXPAK"; // WIDEBAND EXPAK
        break;
    case 255:
        szProtocolName = "Reserved"; // Reserved
        break;
    case 4:
    case 70:
    case 77:
        szProtocolName = "Unassigned"; // Unassigned
        break;

    default:
        if ((chProtocol >=34 && chProtocol<=60) || 
            (chProtocol >=72 && chProtocol<=75) || 
            (chProtocol >=80 && chProtocol<=254)) {
            szProtocolName = "Unassigned"; // Unassigned
        } else {
            szProtocolName = "Unknown";
        }
        break;
    }

    return(szProtocolName);
}

int CInternetStandards::GetResourceTypeFromString(LPCTSTR lpszResourceType)
{
    CString szResourceType = lpszResourceType;

    if (szResourceType == "TYPE_A" || 
        szResourceType == "T_A" || 
        szResourceType == "A") {
        // host address
        return(DNS_TYPE_A);
    }

    if (szResourceType == "TYPE_NS" || 
        szResourceType == "T_NS" || 
        szResourceType == "NS") {
        // authoritative server
        return(DNS_TYPE_NS);
    }

    if (szResourceType == "TYPE_MD" ||
        szResourceType == "T_MD" ||
        szResourceType == "MD") {
        // mail destination
        return(DNS_TYPE_MD);
    }

    if (szResourceType == "TYPE_MF" ||
        szResourceType == "T_MF" ||
        szResourceType == "MF") {
        // mail forwarder
        return(DNS_TYPE_MF);
    }

    if (szResourceType == "TYPE_CNAME" ||
        szResourceType == "T_CNAME" ||
        szResourceType == "CNAME") {
        // canonical name
        return(DNS_TYPE_CNAME);
    }

    if (szResourceType == "TYPE_SOA" ||
        szResourceType == "T_SOA" ||
        szResourceType == "SOA") {
        // start of authority zone
        return(DNS_TYPE_SOA);
    }

    if (szResourceType == "TYPE_MB" ||
        szResourceType == "T_MB" ||
        szResourceType == "MB") {
        // mailbox domain name
        return(DNS_TYPE_MB);
    }

    if (szResourceType == "TYPE_MG" ||
        szResourceType == "T_MG" ||
        szResourceType == "MG") {
        // mail group member
        return(DNS_TYPE_MG);
    }

    if (szResourceType == "TYPE_MR" ||
        szResourceType == "T_MR" ||
        szResourceType == "MR") {
        // mail rename name
        return(DNS_TYPE_MR);
    }

    if (szResourceType == "TYPE_NULL" ||
        szResourceType == "T_NULL" ||
        szResourceType == "NULL") {
        // null resource record
        return(DNS_TYPE_NULL);
    }

    if (szResourceType == "TYPE_WKS" ||
        szResourceType == "T_WKS" ||
        szResourceType == "WKS") {
        // well known service
        return(DNS_TYPE_WKS);
    }

    if (szResourceType == "TYPE_PTR" ||
        szResourceType == "T_PTR" ||
        szResourceType == "PTR") {
        // domain name pointer
        return(DNS_TYPE_PTR);
    }

    if (szResourceType == "TYPE_HINFO" ||
        szResourceType == "T_HINFO" ||
        szResourceType == "HINFO") {
        // host information
        return(DNS_TYPE_HINFO);
    }

    if (szResourceType == "TYPE_MINFO" ||
        szResourceType == "T_MINFO" ||
        szResourceType == "MINFO") {
        // mailbox information
        return(DNS_TYPE_MINFO);
    }

    if (szResourceType == "TYPE_MX" ||
        szResourceType == "T_MX" ||
        szResourceType == "MX") {
        // mail routing information
        return(DNS_TYPE_MX);
    }

    if (szResourceType == "TYPE_TEXT" ||
        szResourceType == "T_TEXT" ||
        szResourceType == "TEXT") {
        // text strings
        return(DNS_TYPE_TEXT);
    }

    if (szResourceType == "TYPE_RP" ||
        szResourceType == "T_RP" ||
        szResourceType == "RP") {
        // responsible person
        return(DNS_TYPE_RP);
    }

    if (szResourceType == "TYPE_AFSDB" ||
        szResourceType == "T_AFSDB" ||
        szResourceType == "AFSDB") {
        // AFS cell database
        return(DNS_TYPE_AFSDB);
    }

    if (szResourceType == "TYPE_X25" ||
        szResourceType == "T_X25" ||
        szResourceType == "X25") {
        // X_25 calling address
        return(DNS_TYPE_X25);
    }

    if (szResourceType == "TYPE_ISDN" ||
        szResourceType == "T_ISDN" ||
        szResourceType == "ISDN") {
        // ISDN calling address
        return(DNS_TYPE_ISDN);
    }

    if (szResourceType == "TYPE_RT" ||
        szResourceType == "T_RT" ||
        szResourceType == "RT") {
        // router
        return(DNS_TYPE_RT);
    }

    if (szResourceType == "TYPE_NSAP" ||
        szResourceType == "T_NSAP" ||
        szResourceType == "NSAP") {
        // NSAP address
        return(DNS_TYPE_NSAP);
    }

    if (szResourceType == "TYPE_NSAPPTR" ||
        szResourceType == "T_NSAPPTR" ||
        szResourceType == "NSAPPTR") {
        // reverse NSAP lookup (deprecated)
        return(DNS_TYPE_NSAPPTR);
    }

    if (szResourceType == "TYPE_SIG" ||
        szResourceType == "T_SIG" ||
        szResourceType == "SIG") {
        // security signature
        return(DNS_TYPE_SIG);
    }

    if (szResourceType == "TYPE_KEY" ||
        szResourceType == "T_KEY" ||
        szResourceType == "KEY") {
        // security key
        return(DNS_TYPE_KEY);
    }

    if (szResourceType == "TYPE_PX" ||
        szResourceType == "T_PX" ||
        szResourceType == "PX") {
        // X.400 mail mapping
        return(DNS_TYPE_PX);
    }

    if (szResourceType == "TYPE_GPOS" ||
        szResourceType == "T_GPOS" ||
        szResourceType == "GPOS") {
        // geographical position (withdrawn)
        return(DNS_TYPE_GPOS);
    }

    if (szResourceType == "TYPE_AAAA" ||
        szResourceType == "T_AAAA" ||
        szResourceType == "AAAA") {
        // IPv6 Address
        return(DNS_TYPE_AAAA);
    }

    if (szResourceType == "TYPE_LOC" ||
        szResourceType == "T_LOC" ||
        szResourceType == "LOC") {
        // Location Information
        return(DNS_TYPE_LOC);
    }

    if (szResourceType == "TYPE_NXT" ||
        szResourceType == "T_NXT" ||
        szResourceType == "NXT") {
        // Next Valid Name in Zone
        return(DNS_TYPE_NXT);
    }

    if (szResourceType == "TYPE_EID" ||
        szResourceType == "T_EID" ||
        szResourceType == "EID") {
        // Endpoint identifier
        return(DNS_TYPE_EID);
    }

    if (szResourceType == "TYPE_NIMLOC" ||
        szResourceType == "T_NIMLOC" ||
        szResourceType == "NIMLOC") {
        // Nimrod locator
        return(DNS_TYPE_NIMLOC);
    }

    if (szResourceType == "TYPE_SRV" ||
        szResourceType == "T_SRV" ||
        szResourceType == "SRV") {
        // Server selection
        return(DNS_TYPE_SRV);
    }

    if (szResourceType == "TYPE_ATMA" ||
        szResourceType == "T_ATMA" ||
        szResourceType == "ATMA") {
        // ATM Address
        return(DNS_TYPE_ATMA);
    }

    if (szResourceType == "TYPE_NAPTR" ||
        szResourceType == "T_NAPTR" ||
        szResourceType == "NAPTR") {
        // Naming Authority PoinTeR
        return(DNS_TYPE_NAPTR);
    }

    if (szResourceType == "TYPE_KX" ||
        szResourceType == "T_KX" ||
        szResourceType == "KX") {
        return(DNS_TYPE_KX);
    }

    if (szResourceType == "TYPE_CERT" ||
        szResourceType == "T_CERT" ||
        szResourceType == "CERT") {
        return(DNS_TYPE_CERT);
    }

    if (szResourceType == "TYPE_A6" ||
        szResourceType == "T_A6" ||
        szResourceType == "A6") {
        return(DNS_TYPE_A6);
    }

    if (szResourceType == "TYPE_DNAME" ||
        szResourceType == "T_DNAME" ||
        szResourceType == "DNAME") {
        return(DNS_TYPE_DNAME);
    }

    if (szResourceType == "TYPE_SINK" ||
        szResourceType == "T_SINK" ||
        szResourceType == "SINK") {
        return(DNS_TYPE_SINK);
    }

    if (szResourceType == "TYPE_OPT" ||
        szResourceType == "T_OPT" ||
        szResourceType == "OPT") {
        return(DNS_TYPE_OPT);
    }

    if (szResourceType == "TYPE_UINFO" ||
        szResourceType == "T_UINFO" ||
        szResourceType == "UINFO") {
        return(DNS_TYPE_UINFO);
    }

    if (szResourceType == "TYPE_UID" ||
        szResourceType == "T_UID" ||
        szResourceType == "UID") {
        return(DNS_TYPE_UID);
    }

    if (szResourceType == "TYPE_GID" ||
        szResourceType == "T_GID" ||
        szResourceType == "GID") {
        return(DNS_TYPE_GID);
    }

    if (szResourceType == "TYPE_UNSPEC" ||
        szResourceType == "T_UNSPEC" ||
        szResourceType == "UNSPEC") {
        return(DNS_TYPE_UNSPEC);
    }

    if (szResourceType == "TYPE_ADDRS" ||
        szResourceType == "T_ADDRS" ||
        szResourceType == "ADDRS") {
        return(DNS_TYPE_ADDRS);
    }

    if (szResourceType == "TYPE_TKEY" ||
        szResourceType == "T_TKEY" ||
        szResourceType == "TKEY") {
        return(DNS_TYPE_TKEY);
    }

    if (szResourceType == "TYPE_TSIG" ||
        szResourceType == "T_TSIG" ||
        szResourceType == "TSIG") {
        return(DNS_TYPE_TSIG);
    }

    if (szResourceType == "TYPE_IXFR" ||
        szResourceType == "T_IXFR" ||
        szResourceType == "IXFR") {
        return(DNS_TYPE_IXFR);
    }

    if (szResourceType == "TYPE_AXFR" ||
        szResourceType == "T_AXFR" ||
        szResourceType == "AXFR") {
        return(DNS_TYPE_AXFR);
    }

    if (szResourceType == "TYPE_MAILB" ||
        szResourceType == "T_MAILB" ||
        szResourceType == "MAILB") {
        return(DNS_TYPE_MAILB);
    }

    if (szResourceType == "TYPE_MAILA" ||
        szResourceType == "T_MAILA" ||
        szResourceType == "MAILA") {
        return(DNS_TYPE_MAILA);
    }

    if (szResourceType == "TYPE_ALL" ||
        szResourceType == "T_ALL" ||
        szResourceType == "ALL") {
        return(DNS_TYPE_ALL);
    }

    if (szResourceType == "TYPE_ANY" ||
        szResourceType == "T_ANY" ||
        szResourceType == "ANY") {
        return(DNS_TYPE_ANY);
    }

    if (szResourceType == "TYPE_WINS" ||
        szResourceType == "T_WINS" ||
        szResourceType == "WINS") {
        return(DNS_TYPE_WINS);
    }

    if (szResourceType == "TYPE_WINSR" ||
        szResourceType == "T_WINSR" ||
        szResourceType == "WINSR") {
        return(DNS_TYPE_WINSR);
    }

    if (szResourceType == "TYPE_NBSTAT" ||
        szResourceType == "T_NBSTAT" ||
        szResourceType == "NBSTAT") {
        return(DNS_TYPE_NBSTAT);
    }

    return(DNS_INVALID_RESOURCE_TYPE);
}

int CInternetStandards::GetResourceClassFromString(LPCTSTR lpszResourceClass)
{
    CString szResourceClass = lpszResourceClass;

    if (szResourceClass == "C_IN" ||
        szResourceClass == "IN") {
        // the arpa internet (surely the only class in use these days)
        return(DNS_CLASS_INTERNET);
    }
    if (szResourceClass == "C_CHAOS" ||
        szResourceClass == "CHAOS") {
        // chaos net (MIT)
        return(DNS_CLASS_CHAOS);
    }
    if (szResourceClass == "C_HS" ||
        szResourceClass == "HS") {
        // Hesiod name server (MIT)
        return(DNS_CLASS_HESIOD);
    }
    if (szResourceClass == "*" ||
        szResourceClass == "C_ANY" ||
        szResourceClass == "ANY") {
        // wildcard match
        return(DNS_CLASS_ANY);
    }

    if (szResourceClass == "C_CSNET" ||
        szResourceClass == "CSNET") {
        return(DNS_CLASS_CSNET);
    }
    if (szResourceClass == "C_NONE" ||
        szResourceClass == "NONE") {
        return(DNS_CLASS_NONE);
    }
    if (szResourceClass == "C_ALL" ||
        szResourceClass == "ALL") {
        return(DNS_CLASS_ALL);
    }

    return(DNS_INVALID_RESOURCE_CLASS);
}

