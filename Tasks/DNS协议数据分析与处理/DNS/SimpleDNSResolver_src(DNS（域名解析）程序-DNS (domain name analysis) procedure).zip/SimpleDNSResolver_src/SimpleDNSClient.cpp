/*=========================================================================== 
    (c) Copyright 2000, Emmanuel KARTMANN, all rights reserved
  =========================================================================== 
    File           : SimpleDNSClient.cpp
    $Header: $
    Author         : Emmanuel KARTMANN <emmanuel@kartmann.org>
    Creation       : Monday 1/31/00 3:51:31 PM
    Remake         : 
  ------------------------------- Description ------------------------------- 

           Implementation of the CSimpleDNSClient

  ------------------------------ Modifications ------------------------------ 
    $Log: $  
  =========================================================================== 
*/

#include "stdafx.h"
#include "SimpleDNSResolver.h"
#include "SimpleDNSClient.h"
#include "WindowsErrorText.h"
#include "InternetStandards.h"

/////////////////////////////////////////////////////////////////////////////
// CSimpleDNSClient: Public (Exported) methods

STDMETHODIMP CSimpleDNSClient::InterfaceSupportsErrorInfo(REFIID riid)
{
	static const IID* arr[] = 
	{
		&IID_ISimpleDNSClient
	};
	for (int i=0; i < sizeof(arr) / sizeof(arr[0]); i++)
	{
        if (IsEqualGUID((REFGUID)*arr[i],(REFGUID)riid))
			return S_OK;
	}
	return S_FALSE;
}

STDMETHODIMP CSimpleDNSClient::Resolve(BSTR BSearchedNames, VARIANT *pvFoundNames, BSTR BResourceClass, BSTR BResourceType)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState())
    return(ResolveMultiple(BSearchedNames, pvFoundNames, BResourceClass, BResourceType));
}

HRESULT CSimpleDNSClient::ResolveMultiple(BSTR BSearchedNames, VARIANT *pvFoundNames, BSTR BResourceClass, BSTR BResourceType)
{
    HRESULT hResult = S_OK;
    CStringList oDomainList;
    CString szDomainName;
    if (!BuildListFromString((LPCTSTR)_bstr_t(BSearchedNames), oDomainList)) {
        SetError("Invalid resource name (empty): ", ERROR_INVALID_PARAMETER);
        return(HRESULT_FROM_WIN32(ERROR_INVALID_PARAMETER));
    }

    POSITION pDomainName = oDomainList.GetHeadPosition();
    BOOL bFoundAtLeastOne = FALSE;
    _variant_t vFoundNames;
    _bstr_t BSeparator;
    _bstr_t BFoundNames;

    while (pDomainName != NULL) {

        szDomainName = oDomainList.GetNext(pDomainName);
        // Call the resolve method with class INternet and type Mail eXchanger
        hResult = ResolveOne(_bstr_t(szDomainName), &vFoundNames, _bstr_t(BResourceClass), _bstr_t(BResourceType));
        if (SUCCEEDED(hResult)) {
            bFoundAtLeastOne = TRUE;
            BFoundNames += BSeparator + _bstr_t(vFoundNames);
            BSeparator = m_szSeparator;
        }

    }
    // Set output variable
    if (pvFoundNames) {
        vFoundNames = BFoundNames;
        *pvFoundNames = vFoundNames.Detach();
    }
    if (bFoundAtLeastOne) {
        hResult = S_OK;
    }
    return(hResult);
}

HRESULT CSimpleDNSClient::ResolveOne(BSTR BSearchedName, VARIANT *pvFoundNames, BSTR BResourceClass, BSTR BResourceType)
{
    HRESULT hReturnCode = S_OK; // Failure

    DNS_STATUS nStatus = 0;
    WORD wType = 0;
    PIP4_ARRAY pSrvList = NULL;      // pointer to IP4_ARRAY structure
    PDNS_RECORD pDnsRecords = NULL;
    PVOID pReserved = NULL;
    CString szSearchedName;
    CString szFoundNames;

    // Convert parameters and init output

    szSearchedName = BSearchedName;
    if (szSearchedName.IsEmpty()) {
        SetError("Invalid resource name (empty): ", ERROR_INVALID_PARAMETER);
        return(HRESULT_FROM_WIN32(ERROR_INVALID_PARAMETER));
    }

    wType = CInternetStandards::GetResourceTypeFromString((LPCTSTR)_bstr_t(BResourceType));
    if (wType == DNS_INVALID_RESOURCE_TYPE) {
        CString szErrorMessage = "Invalid DNS Resource Type ";
        szErrorMessage+= CString((LPCTSTR)_bstr_t(BResourceType));
        szErrorMessage+=": ";
        SetError(szErrorMessage, ERROR_INVALID_PARAMETER);
        return(HRESULT_FROM_WIN32(ERROR_INVALID_PARAMETER));
    }
    // TODO: hanlde non-internet type (how? There's no such parameter in MS API...)
    int nClass = CInternetStandards::GetResourceClassFromString((LPCTSTR)_bstr_t(BResourceClass));
    if (nClass != DNS_CLASS_INTERNET) {
        CString szErrorMessage = "Invalid DNS Resource Class (only C_IN is supported): ";
        SetError(szErrorMessage, ERROR_INVALID_PARAMETER);
        return(HRESULT_FROM_WIN32(ERROR_INVALID_PARAMETER));
    }

    // If request is a reverse (address->name) lookup (type PTR), then silently convert
    // request to a in-arpa format
    if (wType == DNS_TYPE_PTR) {
	    unsigned long addr = inet_addr(szSearchedName);
	    if (addr != INADDR_NONE) {
            char *p = (char *)&addr;
            szSearchedName.Format("%u.%u.%u.%u.in-addr.arpa",
                                  ((unsigned)p[3] & 0xff),  // CAUTION: reverse byte order (p[3]...p[0])
                                  ((unsigned)p[2] & 0xff),
                                  ((unsigned)p[1] & 0xff),
                                  ((unsigned)p[0] & 0xff));
        } else {
            // Must be an address for a PTR request: error
            SetError("Invalid resource name (empty): ", ERROR_INVALID_PARAMETER);
            return(HRESULT_FROM_WIN32(ERROR_INVALID_PARAMETER));
        }
    }
    LPCTSTR lpstrName = szSearchedName;

    // use all known servers (or use method FindAllDNSServers if empty)
    if (m_szServerAddresses.IsEmpty()) {
        m_szServerAddresses = FindAllDNSServers();
    }

    BOOL bNoServer = TRUE;
    CStringList oServerList;
    CString szServerAddress;
    BuildListFromString(m_szServerAddresses, oServerList);
    POSITION pServer = oServerList.GetHeadPosition();
    int i=0;

    pSrvList = (PIP4_ARRAY) LocalAlloc(LPTR,sizeof(IP4_ARRAY));
    if (!pSrvList) {
        DWORD dwLastError = GetLastError();
        SetError("Memory Allocation Error:" , dwLastError);
        hReturnCode = HRESULT_FROM_WIN32(dwLastError);
    } else {

/* 
 ****

  WARNING: if the DNS server is non-standard, the option flag fOptions must NOT be 
           equal to DNS_QUERY_STANDARD, but to DNS_QUERY_BYPASS_CACHE.
           Thanks to Thomas Heike (t.heike@lit.lineas.de) for his help on this...
 ****
*/
        DWORD fOptions = DNS_QUERY_STANDARD;
        while (pServer != NULL) {
            szServerAddress = oServerList.GetNext(pServer);
            // Convert dotted notation into address (4 bytes)
            // Store it in configuration (memory)
            pSrvList->AddrCount = 1;
            pSrvList->AddrArray[0] = inet_addr(szServerAddress);
            bNoServer = FALSE;
            fOptions = DNS_QUERY_BYPASS_CACHE;
            // TODO: store all servers in IP4_ARRAY (how??? there's only one element is array!)
            // For now, exit loop after 1st server
            break;
        }
        if (bNoServer) {
            CString szErrorMessage = "Invalid DNS server addresses \"";
            szErrorMessage+=m_szServerAddresses;
            szErrorMessage+="\": ";
            SetError(szErrorMessage, ERROR_INVALID_PARAMETER);
            return(HRESULT_FROM_WIN32(ERROR_INVALID_PARAMETER));
        }
        // Send query to DNS Server and fetch reply
        nStatus = DnsQuery(lpstrName,
                           wType,
                           fOptions,
                           pSrvList,
                           &pDnsRecords,
                           NULL);

        if (nStatus) {
            DWORD dwLastError = nStatus;
            SetError("DNS Resolution failure: ", dwLastError);
            hReturnCode = HRESULT_FROM_WIN32(dwLastError);
        } else {

            switch(wType) {

            // A (IP v4 address)
            case DNS_TYPE_A: 
                {
                    // convert address into string (dotted notation) and add to result
                    do {
                        IN_ADDR ipaddr;
                        ipaddr.S_un.S_addr = (pDnsRecords->Data.A.IpAddress);
                        if (pDnsRecords->Flags.S.Section == DNSREC_ANSWER) {
                            AppendResult(wType, pDnsRecords->wType, inet_ntoa(ipaddr), szFoundNames);
                        }
                        pDnsRecords = pDnsRecords->pNext;
                    } while (pDnsRecords);
                }
                break;

            // PTR (reverse lookup: address->name)
            case DNS_TYPE_PTR: 
                {
                    do {
                        if (pDnsRecords->Flags.S.Section == DNSREC_ANSWER) {
                            AppendResult(wType, pDnsRecords->wType, pDnsRecords->Data.PTR.pNameHost, szFoundNames);
                        }
                        pDnsRecords = pDnsRecords->pNext;
                    } while (pDnsRecords);
                }
                break;

            // MX (Mail eXchanger)
            case DNS_TYPE_MX: 
                {
                    do {
                        if (pDnsRecords->Flags.S.Section == DNSREC_ANSWER) {
                            AppendResult(wType, pDnsRecords->wType, pDnsRecords->Data.MX.pNameExchange, szFoundNames);
                        }
                        pDnsRecords = pDnsRecords->pNext;
                    } while (pDnsRecords);
                }
                break;

            // AFSDB (RFC 1183)
            case DNS_TYPE_AFSDB: 
                {
                    do {
                        if (pDnsRecords->Flags.S.Section == DNSREC_ANSWER) {
                            AppendResult(wType, pDnsRecords->wType, pDnsRecords->Data.AFSDB.pNameExchange, szFoundNames);
                        }
                        pDnsRecords = pDnsRecords->pNext;
                    } while (pDnsRecords);
                }
                break;

            // RT (RFC 1183)
            case DNS_TYPE_RT: 
                {
                    do {
                        if (pDnsRecords->Flags.S.Section == DNSREC_ANSWER) {
                            AppendResult(wType, pDnsRecords->wType, pDnsRecords->Data.RT.pNameExchange, szFoundNames);
                        }
                        pDnsRecords = pDnsRecords->pNext;
                    } while (pDnsRecords);
                }
                break;

            // CNAME (Canonical Name)
            case DNS_TYPE_CNAME: 
                {
                    do {
                        if (pDnsRecords->Flags.S.Section == DNSREC_ANSWER) {
                            AppendResult(wType, pDnsRecords->wType, pDnsRecords->Data.NS.pNameHost, szFoundNames);
                        }
                        pDnsRecords = pDnsRecords->pNext;
                    } while (pDnsRecords);
                }
                break;

            // NS (Name Server)
            case DNS_TYPE_NS: 
                {
                    do {
                        if (pDnsRecords->Flags.S.Section == DNSREC_ANSWER) {
                            AppendResult(wType, pDnsRecords->wType, pDnsRecords->Data.NS.pNameHost, szFoundNames);
                        }
                        pDnsRecords = pDnsRecords->pNext;
                    } while (pDnsRecords);
                }
                break;

            // SOA (start of authority)
            case DNS_TYPE_SOA:
                {
                    do {
                        if (pDnsRecords->Flags.S.Section == DNSREC_ANSWER) {
                            AppendResult(wType, pDnsRecords->wType, pDnsRecords->Data.SOA.pNamePrimaryServer, szFoundNames);
                        }
                        pDnsRecords = pDnsRecords->pNext;
                    } while (pDnsRecords);
                }
                break;

            // MB 
            case DNS_TYPE_MB:
                {
                    do {
                        if (pDnsRecords->Flags.S.Section == DNSREC_ANSWER) {
                            AppendResult(wType, pDnsRecords->wType, pDnsRecords->Data.MB.pNameHost, szFoundNames);
                        }
                        pDnsRecords = pDnsRecords->pNext;
                    } while (pDnsRecords);
                }
                break;

            // MD 
            case DNS_TYPE_MD:
                {
                    do {
                        if (pDnsRecords->Flags.S.Section == DNSREC_ANSWER) {
                            AppendResult(wType, pDnsRecords->wType, pDnsRecords->Data.MD.pNameHost, szFoundNames);
                        }
                        pDnsRecords = pDnsRecords->pNext;
                    } while (pDnsRecords);
                }
                break;

            // MF 
            case DNS_TYPE_MF:
                {
                    do {
                        if (pDnsRecords->Flags.S.Section == DNSREC_ANSWER) {
                            AppendResult(wType, pDnsRecords->wType, pDnsRecords->Data.MF.pNameHost, szFoundNames);
                        }
                        pDnsRecords = pDnsRecords->pNext;
                    } while (pDnsRecords);
                }
                break;

            // MG 
            case DNS_TYPE_MG:
                {
                    do {
                        if (pDnsRecords->Flags.S.Section == DNSREC_ANSWER) {
                            AppendResult(wType, pDnsRecords->wType, pDnsRecords->Data.MG.pNameHost, szFoundNames);
                        }
                        pDnsRecords = pDnsRecords->pNext;
                    } while (pDnsRecords);
                }
                break;

            // MR 
            case DNS_TYPE_MR:
                {
                    do {
                        if (pDnsRecords->Flags.S.Section == DNSREC_ANSWER) {
                            AppendResult(wType, pDnsRecords->wType, pDnsRecords->Data.MR.pNameHost, szFoundNames);
                        }
                        pDnsRecords = pDnsRecords->pNext;
                    } while (pDnsRecords);
                }
                break;

            // MINFO (mail information)
            case DNS_TYPE_MINFO:
                {
                    do {
                        if (pDnsRecords->Flags.S.Section == DNSREC_ANSWER) {
                            AppendResult(wType, pDnsRecords->wType, pDnsRecords->Data.MINFO.pNameMailbox, szFoundNames);
                        }
                        pDnsRecords = pDnsRecords->pNext;
                    } while (pDnsRecords);
                }
                break;

            // RP (Responsible Person)
            case DNS_TYPE_RP:
                {
                    do {
                        if (pDnsRecords->Flags.S.Section == DNSREC_ANSWER) {
                            AppendResult(wType, pDnsRecords->wType, pDnsRecords->Data.RP.pNameMailbox, szFoundNames);
                        }
                        pDnsRecords = pDnsRecords->pNext;
                    } while (pDnsRecords);
                }
                break;

            // HINFO 
            case DNS_TYPE_HINFO:
                {
                    do {
                        if (pDnsRecords->Flags.S.Section == DNSREC_ANSWER) {
                            AppendResult(wType, pDnsRecords->wType, pDnsRecords->Data.HINFO.pStringArray[1], szFoundNames);
                        }
                        pDnsRecords = pDnsRecords->pNext;
                    } while (pDnsRecords);
                }
                break;

            // ISDN 
            case DNS_TYPE_ISDN:
                {
                    do {
                        if (pDnsRecords->Flags.S.Section == DNSREC_ANSWER) {
                            AppendResult(wType, pDnsRecords->wType, pDnsRecords->Data.ISDN.pStringArray[1], szFoundNames);
                        }
                        pDnsRecords = pDnsRecords->pNext;
                    } while (pDnsRecords);
                }
                break;

            // X25 
            case DNS_TYPE_X25:
                {
                    do {
                        if (pDnsRecords->Flags.S.Section == DNSREC_ANSWER) {
                            AppendResult(wType, pDnsRecords->wType, pDnsRecords->Data.X25.pStringArray[1], szFoundNames);
                        }
                        pDnsRecords = pDnsRecords->pNext;
                    } while (pDnsRecords);
                }
                break;

            // NXT (next record, see RFC 2065, Secure negative response)
            case DNS_TYPE_NXT:
                {
                    do {
                        if (pDnsRecords->Flags.S.Section == DNSREC_ANSWER) {
                            AppendResult(wType, pDnsRecords->wType, pDnsRecords->Data.NXT.pNameNext, szFoundNames);
                        }
                        pDnsRecords = pDnsRecords->pNext;
                    } while (pDnsRecords);
                }
                break;

            // SRV (service record, see RFC 2052, Service location)
            case DNS_TYPE_SRV:
                {
                    do {
                        if (pDnsRecords->Flags.S.Section == DNSREC_ANSWER) {
                            AppendResult(wType, pDnsRecords->wType, pDnsRecords->Data.SRV.pNameTarget, szFoundNames);
                        }
                        pDnsRecords = pDnsRecords->pNext;
                    } while (pDnsRecords);
                }
                break;

            // Null 
            case DNS_TYPE_NULL:
                {
                    do {
                        if (pDnsRecords->Flags.S.Section == DNSREC_ANSWER) {
                            AppendResult(wType, pDnsRecords->wType, "NULL" /*pDnsRecords->Data.Null.Data[1]*/, szFoundNames);
                        }
                        pDnsRecords = pDnsRecords->pNext;
                    } while (pDnsRecords);
                }
                break;

            // WKS (well-known services)
            case DNS_TYPE_WKS:
                {
                    do {
                        if (pDnsRecords->Flags.S.Section == DNSREC_ANSWER) {
                            CString szWKS = CInternetStandards::GetProtocolNameFromID(pDnsRecords->Data.WKS.chProtocol);
                            szWKS += ":";
                            IN_ADDR ipaddr;
                            ipaddr.S_un.S_addr = (pDnsRecords->Data.WKS.IpAddress);
                            szWKS += inet_ntoa(ipaddr);
                            AppendResult(wType, pDnsRecords->wType, szWKS, szFoundNames);
                        }
                        pDnsRecords = pDnsRecords->pNext;
                    } while (pDnsRecords);
                }
                break;

/*


            // TKEY (TKEY record, used to establish and delete shared-secret keys between a DNS resolver and server)
            case DNS_TYPE_TKEY:
                {
                    do {
                        if (pDnsRecords->Flags.S.Section == DNSREC_ANSWER) {
                            AppendResult(wType, pDnsRecords->wType, pDnsRecords->Data.TKEY.pNameAlgorithm, szFoundNames);
                        }
                        pDnsRecords = pDnsRecords->pNext;
                    } while (pDnsRecords);
                }
                break;
            // TSIG (secret key transaction authentication record)
            case DNS_TYPE_TSIG:
                {
                    do {
                        if (pDnsRecords->Flags.S.Section == DNSREC_ANSWER) {
                            AppendResult(wType, pDnsRecords->wType, pDnsRecords->Data.TSIG.pNameAlgorithm, szFoundNames);
                        }
                        pDnsRecords = pDnsRecords->pNext;
                    } while (pDnsRecords);
                }
                break;
            // KEY (key record, see RFC 2065, DNS security)
            case DNS_TYPE_KEY:
                {
                    do {
                        if (pDnsRecords->Flags.S.Section == DNSREC_ANSWER) {
                            AppendResult(wType, pDnsRecords->wType, pDnsRecords->Data.KEY.?, szFoundNames);
                        }
                        pDnsRecords = pDnsRecords->pNext;
                    } while (pDnsRecords);
                }
                break;
            // SIG (signature, see RFC 2065, DNS security)
            case DNS_TYPE_SIG:
                {
                    do {
                        if (pDnsRecords->Flags.S.Section == DNSREC_ANSWER) {
                            AppendResult(wType, pDnsRecords->wType, pDnsRecords->Data.SIG.pNameSigner, szFoundNames);
                        }
                        pDnsRecords = pDnsRecords->pNext;
                    } while (pDnsRecords);
                }
                break;
            // ATMA (ATM address)
            case DNS_TYPE_ATMA:
                {
                    do {
                        if (pDnsRecords->Flags.S.Section == DNSREC_ANSWER) {
                            AppendResult(wType, pDnsRecords->wType, pDnsRecords->Data.ATMA.Address, szFoundNames);
                        }
                        pDnsRecords = pDnsRecords->pNext;
                    } while (pDnsRecords);
                }
                break;
            

            // AAAA (IP v6 address)
            case DNS_TYPE_AAAA:
                {
                    do {
                        if (pDnsRecords->Flags.S.Section == DNSREC_ANSWER) {
                            AppendResult(wType, pDnsRecords->wType, pDnsRecords->Data.AAAA.Ip6Address, szFoundNames);
                        }
                        pDnsRecords = pDnsRecords->pNext;
                    } while (pDnsRecords);
                }
                break;
            // WINS (Windows Internet Name Service record)
            case DNS_TYPE_WINS:
                {
                    do {
                        if (pDnsRecords->Flags.S.Section == DNSREC_ANSWER) {
                            AppendResult(wType, pDnsRecords->wType, pDnsRecords->Data.WINS.WinsServers[1], szFoundNames);
                        }
                        pDnsRecords = pDnsRecords->pNext;
                    } while (pDnsRecords);
                }
                break;
            // WINSR (Windows Internet Name Service reverse-lookup record)
            case DNS_TYPE_WINSR:
                {
                    do {
                        if (pDnsRecords->Flags.S.Section == DNSREC_ANSWER) {
                            AppendResult(wType, pDnsRecords->wType, pDnsRecords->Data.WINSR.pNameResultDomain, szFoundNames);
                        }
                        pDnsRecords = pDnsRecords->pNext;
                    } while (pDnsRecords);
                }
                break;
            // NBSTAT
            case DNS_TYPE_NBSTA:
                {
                    do {
                        if (pDnsRecords->Flags.S.Section == DNSREC_ANSWER) {
                            AppendResult(wType, pDnsRecords->wType, pDnsRecords->Data.NBSTA.?, szFoundNames);
                        }
                        pDnsRecords = pDnsRecords->pNext;
                    } while (pDnsRecords);
                }
                break;

                */
            default:
                {
                    SetLastError(ERROR_NOT_SUPPORTED);
                    DWORD dwLastError = GetLastError();
                    SetError("DNS type not supported: ",dwLastError);
                    hReturnCode = HRESULT_FROM_WIN32(dwLastError);
                }
                break;
            }
        }

    }

    // Set output variable
    if (pvFoundNames) {
        _variant_t vFoundNames;
        vFoundNames.SetString((LPCTSTR)szFoundNames);
        *pvFoundNames = vFoundNames.Detach();
    }

    // Cleanup
    if (pDnsRecords) {
        DNS_FREE_TYPE freetype = DnsFreeRecordListDeep;
        DnsRecordListFree(pDnsRecords, freetype);
        pDnsRecords = NULL;
    }
    if (pSrvList) {
        LocalFree(pSrvList);
        pSrvList = NULL;
    }
	return hReturnCode;
}

STDMETHODIMP CSimpleDNSClient::GetDNSDomain(VARIANT *pvDNSDomainName)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState())

    HKEY hKey = NULL;
    CString szDNSDomain;
    CString szDomainName;
    CStringList oDNSDomainList;
    oDNSDomainList.RemoveAll();

    LONG nResult = S_OK;

    CString szDomainKeys[] = {
        "Domain",
        "DhcpDomain",
        "SearchList"
    };

    // Find DNS domain with IP Helper API (function GetNetworkParams)
    // CAUTION: this code should run on Windows 2000 and Windows Me only
    PFIXED_INFO pNetInfo = (FIXED_INFO *)GlobalAlloc(GPTR, sizeof(FIXED_INFO));
    ULONG nNetInfoSize = sizeof(FIXED_INFO);
    DWORD nErrorCode = GetNetworkParams(pNetInfo, &nNetInfoSize);
    if (nErrorCode == ERROR_BUFFER_OVERFLOW) {
        // OK, buffer is too small but function returns the needed size
        GlobalFree(pNetInfo);
        pNetInfo = NULL;
        pNetInfo = (FIXED_INFO *)GlobalAlloc(GPTR, nNetInfoSize);
        nErrorCode = GetNetworkParams(pNetInfo, &nNetInfoSize);
    }
    if (nErrorCode == ERROR_SUCCESS) {

        AddDomain(oDNSDomainList, (LPCTSTR)pNetInfo->DomainName);

    }

    // Find DNS from Registry HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters
    // CAUTION: this code runs on NT4/W2K only, but it's a good fallback and it provides "search list" info
    nResult = RegOpenKeyEx(HKEY_LOCAL_MACHINE,
                           "SYSTEM\\CurrentControlSet\\Services\\Tcpip\\Parameters",
                           0,
                           KEY_READ,
                           &hKey
                           );

    if (nResult == ERROR_SUCCESS) {

        for (int i=0; i < sizeof(szDomainKeys)/sizeof(szDomainKeys[0]); i++) {
            DWORD dwType;
            BYTE lpData[256];
            DWORD dwDataSize = sizeof(lpData);
            nResult = RegQueryValueEx(hKey,
                                      szDomainKeys[i],
                                      NULL,
                                      &dwType,
                                      lpData,
                                      &dwDataSize
                                      );

            if (nResult == ERROR_SUCCESS) {

                TCHAR lpszData[256];
                memcpy((void *)lpszData, (const void *)lpData, dwDataSize);
                lpszData[dwDataSize] = '\0';

                // Append to current Domain
                szDomainName = (LPCTSTR)lpszData;
                if (!szDomainName.IsEmpty()) {

                    szDomainName.MakeLower();
                    // Some key contain multiple values separated by commas or spaces
                    int nPosition = szDomainName.Find(',', 0);
                    while (nPosition > 0) {
                        AddDomain(oDNSDomainList, (LPCTSTR)szDomainName.Left(nPosition));
                        szDomainName = szDomainName.Mid(nPosition+1);
                        nPosition = szDomainName.Find(',', 0);
                    }
                    AddDomain(oDNSDomainList, (LPCTSTR)szDomainName);
                }

            } else {

                if (oDNSDomainList.IsEmpty()) {
                    CString szErrorMessage = "Cannot open registry key \"SYSTEM\\CurrentControlSet\\Services\\Tcpip\\Parameters\\" +szDomainKeys[i] + "\":";
                    SetError(szErrorMessage, nResult);
                }

            }

        }

    } else {

        if (oDNSDomainList.IsEmpty()) {
            CString szErrorMessage = "Cannot open registry key \"SYSTEM\\CurrentControlSet\\Services\\Tcpip\\Parameters\":";
            SetError(szErrorMessage, nResult);
        }

    }

    // Return value
    if (pvDNSDomainName) {
        _variant_t vDNSDomain;
        BuildStringFromList(oDNSDomainList, szDNSDomain);
        vDNSDomain.SetString((LPCTSTR)szDNSDomain);
        *pvDNSDomainName = vDNSDomain.Detach();
    }

    // Cleanup
    if (hKey) {
        RegCloseKey(hKey);
        hKey = NULL;
    }
    if (pNetInfo) {
        GlobalFree(pNetInfo);
        pNetInfo = NULL;
    }

	return HRESULT_FROM_WIN32(nResult);
}

STDMETHODIMP CSimpleDNSClient::FindServerAddresses(VARIANT *pvServerAddresses)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState())

    CString szServerAddresses = FindAllDNSServers();
    HRESULT hResult = S_OK;

    if (szServerAddresses.IsEmpty()) {
        DWORD dwLastError = GetLastError();
        SetError("Cannot find DNS Servers in registry: ", dwLastError);
        hResult = HRESULT_FROM_WIN32(dwLastError);
    } else {
        hResult = S_OK;
    }

    // Return value
    if (pvServerAddresses) {
        _variant_t vServerAddresses = szServerAddresses;
        *pvServerAddresses = vServerAddresses.Detach();
    }

	return hResult;
}

STDMETHODIMP CSimpleDNSClient::get_Separator(BSTR *pVal)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState())

    if (pVal) {
        *pVal = _bstr_t(m_szSeparator);
    }

	return S_OK;
}

STDMETHODIMP CSimpleDNSClient::put_Separator(BSTR newVal)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState())

    _bstr_t BNewVal = newVal;
	m_szSeparator = (LPCTSTR)BNewVal;

	return S_OK;
}


STDMETHODIMP CSimpleDNSClient::GetInterfaceSafetyOptions(REFIID riid, DWORD *pdwSupportedOptions, DWORD *pdwEnabledOptions)
{
    ATLTRACE(_T("CObjectSafetyImpl::GetInterfaceSafetyOptions\n"));
    if (!pdwSupportedOptions || !pdwEnabledOptions) {
        return E_FAIL;
    }
    LPUNKNOWN pUnk = NULL;
    if (_InternalQueryInterface (riid, (void**)&pUnk) == E_NOINTERFACE) {
        // Our object doesn't even support this interface.
        return E_NOINTERFACE;
    } else {
        // Cleanup after ourselves.
        pUnk->Release();
        pUnk = NULL;
    }
    if (riid == IID_IDispatch) {
        // IDispatch is an interface used for scripting. If your
        // control supports other IDispatch or Dual interfaces, you
        // may decide to add them here as well. Client wants to know
        // if object is safe for scripting. Only indicate safe for
        // scripting when the interface is safe.
        *pdwSupportedOptions = INTERFACESAFE_FOR_UNTRUSTED_CALLER;
        *pdwEnabledOptions = m_dwCurrentSafety &
        INTERFACESAFE_FOR_UNTRUSTED_CALLER;
        return S_OK;
    } else if ((riid == IID_IPersistStreamInit) ||
               (riid == IID_IPersistStorage)) {
        // IID_IPersistStreamInit and IID_IPersistStorage are
        // interfaces used for Initialization. If your control
        // supports other Persistence interfaces, you may decide to
        // add them here as well. Client wants to know if object is
        // safe for initializing. Only indicate safe for initializing
        // when the interface is safe.
        *pdwSupportedOptions = INTERFACESAFE_FOR_UNTRUSTED_DATA;
        *pdwEnabledOptions = m_dwCurrentSafety &
        INTERFACESAFE_FOR_UNTRUSTED_DATA;
        return S_OK;
    } else {
        // We are saying that no other interfaces in this control are
        // safe for initializing or scripting.
        *pdwSupportedOptions = 0;
        *pdwEnabledOptions = 0;
        return E_FAIL;
    }
}

STDMETHODIMP CSimpleDNSClient::SetInterfaceSafetyOptions(REFIID riid, DWORD dwOptionSetMask, DWORD dwEnabledOptions)
{
    ATLTRACE(_T("CObjectSafetyImpl::SetInterfaceSafetyOptions\n"));
    if (!dwOptionSetMask && !dwEnabledOptions) {
        return E_FAIL;
    }
    LPUNKNOWN pUnk = NULL;
    if (_InternalQueryInterface (riid, (void**)&pUnk) == E_NOINTERFACE) {
        // Our object doesn't even support this interface.
        return E_NOINTERFACE;
    } else {
        // Cleanup after ourselves.
        pUnk->Release();
        pUnk = NULL;
    }
    // Store our current safety level to return in
    // GetInterfaceSafetyOptions
    m_dwCurrentSafety |= dwEnabledOptions & dwOptionSetMask;
    if ((riid == IID_IDispatch) &&
        (m_dwCurrentSafety & INTERFACESAFE_FOR_UNTRUSTED_CALLER)) {
        // Client wants us to disable any functionality that would
        // make the control unsafe for scripting. The same applies to
        // any other IDispatch or Dual interfaces your control may
        // support. Because our control is safe for scripting by
        // default we just return S_OK.
        return S_OK;
    } else if (((riid == IID_IPersistStreamInit) ||
                (riid == IID_IPersistStorage)) &&
                (m_dwCurrentSafety & INTERFACESAFE_FOR_UNTRUSTED_DATA)) {
        // Client wants us to make the control safe for initializing
        // from persistent data. For these interfaces, this control
        // is safe so we return S_OK. For Any interfaces that are not
        // safe, we would return E_FAIL.
        return S_OK;
    } else {
        // This control doesn't allow Initialization or Scripting
        // from any other interfaces so return E_FAIL.
        return E_FAIL;
    }
}


/////////////////////////////////////////////////////////////////////////////
// Protected methods
/////////////////////////////////////////////////////////////////////////////

CString CSimpleDNSClient::FindAllDNSServers()
{
    CString szDNSAllServers;
    HKEY hKey = NULL;
    LONG nResult = S_OK;

    CString szServerKeys[] = {
        "NameServer",
        "DhcpNameServer"
    };

    // Find DNS servers with IP Helper API (function GetNetworkParams)
    // CAUTION: this code should run on Windows 2000 and Windows Me only
    PFIXED_INFO pNetInfo = (FIXED_INFO *)GlobalAlloc(GPTR, sizeof(FIXED_INFO));
    ULONG nNetInfoSize = sizeof(FIXED_INFO);
    DWORD nErrorCode = GetNetworkParams(pNetInfo, &nNetInfoSize);
    if (nErrorCode == ERROR_BUFFER_OVERFLOW) {
        // OK, buffer is too small but function returns the needed size
        GlobalFree(pNetInfo);
        pNetInfo = NULL;
        pNetInfo = (FIXED_INFO *)GlobalAlloc(GPTR, nNetInfoSize);
        nErrorCode = GetNetworkParams(pNetInfo, &nNetInfoSize);
    }
    if (nErrorCode == ERROR_SUCCESS) {

        IP_ADDR_STRING *oDNSServers = &(pNetInfo->DnsServerList);
        szDNSAllServers += oDNSServers->IpAddress.String;
        while (oDNSServers->Next) {
            oDNSServers = oDNSServers->Next;
            szDNSAllServers += " ";
            szDNSAllServers += oDNSServers->IpAddress.String;
        }
    
    }

    if (szDNSAllServers.GetLength() == 0) {
        // Find DNS from Registry HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters
        // CAUTION: this code runs on NT4 only, but it's a good fallback
        nResult = RegOpenKeyEx(HKEY_LOCAL_MACHINE,
                               "SYSTEM\\CurrentControlSet\\Services\\Tcpip\\Parameters",
                               0,
                               KEY_READ,
                               &hKey
                               );

        if (nResult == ERROR_SUCCESS) {

            for (int i=0; i < sizeof(szServerKeys)/sizeof(szServerKeys[0]); i++) {
                DWORD dwType;
                BYTE lpData[256];
                DWORD dwDataSize = sizeof(lpData);
                nResult = RegQueryValueEx(hKey,
                                          szServerKeys[i],
                                          NULL,
                                          &dwType,
                                          lpData,
                                          &dwDataSize
                                          );

                if (nResult == ERROR_SUCCESS) {

                    TCHAR lpszData[256];
                    memcpy((void *)lpszData, (const void *)lpData, dwDataSize);
                    lpszData[dwDataSize] = '\0';

                    szDNSAllServers = lpszData;

                } else {

                    szDNSAllServers.Empty();

                }

            }
        } else {

            szDNSAllServers.Empty();

        }

    }

    // Cleanup
    if (hKey) {
        RegCloseKey(hKey);
        hKey = NULL;
    }
    if (pNetInfo) {
        GlobalFree(pNetInfo);
        pNetInfo = NULL;
    }

    return(szDNSAllServers);
}

CString CSimpleDNSClient::FindFirstDNSServer()
{
    CString szDNSFirstServer;
    CString szDNSAllServers = FindAllDNSServers();

    if (!szDNSAllServers.IsEmpty()) {
        // Servers are separated by spaces
        int nPosition = szDNSAllServers.Find(" ", 0);
        if (nPosition!=-1) {
            szDNSFirstServer = szDNSAllServers.Left(nPosition);
        } else {
            szDNSFirstServer = szDNSAllServers;
        }
    }
    return(szDNSFirstServer);
}


HRESULT CSimpleDNSClient::SetError(LPCTSTR lpszErrorMessage, DWORD dwLastError)
{
    CString szErrorMessage = lpszErrorMessage;
    USES_CONVERSION;

    if (dwLastError != 0) {
        TCHAR lpszSystemErrorText[1024];
        szErrorMessage+=WindowsGetErrorText(dwLastError, lpszSystemErrorText, sizeof(lpszSystemErrorText));
    }
    TRACE1("%s\n", szErrorMessage);

    // Build COM error info object
    ICreateErrorInfo *pcerrinfo;
    IErrorInfo *perrinfo;
    HRESULT hr;

    hr = CreateErrorInfo(&pcerrinfo);

    // Fill error info object
    pcerrinfo->SetDescription(T2OLE(szErrorMessage));
    pcerrinfo->SetSource(T2OLE("SITA.SimpleTelnetClientX"));
    pcerrinfo->SetGUID(IID_ISimpleDNSClient);

    // Set error info object for current thread
    hr = pcerrinfo->QueryInterface(IID_IErrorInfo, (LPVOID FAR*) &perrinfo);
    if (SUCCEEDED(hr))
    {
        SetErrorInfo(0, perrinfo);
        perrinfo->Release();
    }
    pcerrinfo->Release();

    return(S_OK);
}


BOOL CSimpleDNSClient::AppendResult(int nRequestedType, int nType, LPCTSTR lpszResult, CString &szTotalResult)
{
    if (nType == nRequestedType || nRequestedType == DNS_TYPE_ANY) {
        if (szTotalResult.IsEmpty()) {
            szTotalResult = lpszResult;
        } else {
            // Append name (using separator property to separate entries)
            szTotalResult +=m_szSeparator;
            szTotalResult += lpszResult;
        }
    }
    return(TRUE);
}

STDMETHODIMP CSimpleDNSClient::GetEmailServers(BSTR pBDomainName, VARIANT *pvEmailServerNames)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState())

    _bstr_t BDomainName = pBDomainName;
    _variant_t vFoundNames;
    HRESULT hResult = S_OK;

    // Set parameters, if default
    if (BDomainName == _bstr_t("")) {
        _variant_t vLocalDomainName;
        hResult = GetDNSDomain(&vLocalDomainName);
        if (FAILED(hResult) || _bstr_t(vLocalDomainName) == _bstr_t("")) {
            SetError("Invalid parameter: empty domain name and cannot read default domain: ", hResult);
            return(hResult);
        } else {
            BDomainName = vLocalDomainName;
        }
    }

    hResult = ResolveMultiple(BDomainName, &vFoundNames, _bstr_t("C_IN"), _bstr_t("T_MX"));

    // Set output variable
    if (pvEmailServerNames) {
        *pvEmailServerNames = vFoundNames.Detach();
    }

	return(hResult);
}

STDMETHODIMP CSimpleDNSClient::get_ServerAddresses(BSTR *pVal)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState())

    if (pVal) {
        *pVal = _bstr_t((LPCTSTR)m_szServerAddresses);
    }

	return S_OK;
}

STDMETHODIMP CSimpleDNSClient::put_ServerAddresses(BSTR newVal)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState())

	m_szServerAddresses = (LPCTSTR)bstr_t(newVal);

	return S_OK;
}


CString CSimpleDNSClient::GetParentDomainName(LPCTSTR lpszDomainName)
{
    CString szParentDomainName;
    CString szDomainName = lpszDomainName;
    int nPosition = szDomainName.Find('.', 0);
    if (nPosition != -1) {
        // Copy string after this position
         szParentDomainName = (LPCTSTR)szDomainName.Mid(nPosition+1);
    }
    if (szParentDomainName.Find('.', 0) == -1) {
        // No more ".", so we have a Top Level Domain (TLD), like "com"
        // Consider that there is NO parent
        szParentDomainName.Empty();
    }
    return(szParentDomainName);
}

BOOL CSimpleDNSClient::BuildStringFromList(CStringList &oList, CString &szStringWithSeparators)
{
    POSITION pString = oList.GetHeadPosition();
    CString szString;
    BOOL bReturnCode = FALSE;
    CString szSeparator;

    while (pString != NULL) {
        szString = oList.GetNext(pString);
        szStringWithSeparators += (szSeparator + szString);
        szSeparator = m_szSeparator;
        bReturnCode = TRUE;
    }

    return(bReturnCode);
}

BOOL CSimpleDNSClient::BuildListFromString(LPCTSTR lpszStringWithSeparators, CStringList &oList)
{
    CString szStringWithSeparators = lpszStringWithSeparators;
    TCHAR cSeparator = ',';
    int nPos = -1;
    oList.RemoveAll();
    int nCurrentPos = 0;
    int nCurrentLength = 0;
    CString szCurrentItem;

    nPos = szStringWithSeparators.Find(cSeparator);
    if (nPos == -1) {
        // Try semi-colon
        cSeparator = ';';
        nPos = szStringWithSeparators.Find(cSeparator);
        if (nPos == -1) {
            // Try space
            cSeparator = ' ';
            nPos = szStringWithSeparators.Find(cSeparator);
        }
    }
    while (nPos != -1) {
        nCurrentLength = nPos - nCurrentPos;
        szCurrentItem = szStringWithSeparators.Mid(nCurrentPos, nCurrentLength);
        // Remove starting/trailing spaces
        szCurrentItem.TrimLeft(" ");
        szCurrentItem.TrimRight(" ");
        if (!szCurrentItem.IsEmpty()) {
            TRACE1("Adding string \"%s\"\n", szCurrentItem);
            oList.AddTail(szCurrentItem);
        }
        nCurrentPos = nPos+1;
        nPos = szStringWithSeparators.Find(cSeparator, nCurrentPos);
    }
    // Add last item
    szCurrentItem = szStringWithSeparators.Mid(nCurrentPos);
    // Remove starting/trailing spaces
    szCurrentItem.TrimLeft(" ");
    szCurrentItem.TrimRight(" ");
    if (!szCurrentItem.IsEmpty()) {
        TRACE1("Adding string \"%s\"\n", szCurrentItem);
        oList.AddTail(szCurrentItem);
    }
    

    return(!oList.IsEmpty());
}

BOOL CSimpleDNSClient::AddDomain(CStringList &oDNSDomainList, LPCTSTR lpszDomainName)
{
    BOOL bReturnCode = FALSE;
    CString szDomainName = lpszDomainName;

    if (!szDomainName.IsEmpty()) {
        szDomainName.MakeLower();
        if (oDNSDomainList.Find(szDomainName) == NULL) {
            oDNSDomainList.AddTail(szDomainName);
            bReturnCode = TRUE;
        }
    }
    // Fallback/Heuristic on parent domain, if any 
    // e.g. if "dept.company.com" is the primary domain, add "company.com" to the list
    szDomainName = GetParentDomainName(szDomainName);
    if (!szDomainName.IsEmpty()) {
        if (oDNSDomainList.Find(szDomainName) == NULL) {
            oDNSDomainList.AddTail(szDomainName);
            bReturnCode = TRUE;
        }
    }
    return(bReturnCode);
}

