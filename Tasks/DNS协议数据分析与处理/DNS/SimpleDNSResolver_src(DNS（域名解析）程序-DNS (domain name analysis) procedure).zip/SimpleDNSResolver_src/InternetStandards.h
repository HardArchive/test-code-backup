/*=========================================================================== 
    (c) Copyright 2001, Emmanuel KARTMANN, all rights reserved
  =========================================================================== 
    File           : InternetStandards.h
    $Header: $
    Author         : Emmanuel KARTMANN <emmanuel@kartmann.org>
    Creation       : Friday 10/27/01 11:55:27 PM
    Remake         : 
  ------------------------------- Description ------------------------------- 

           Declaration of the CInternetStandards class.

  ------------------------------ Modifications ------------------------------ 
    $Log: $  
  =========================================================================== 
*/

#if !defined(AFX_INTERNETSTANDARDS_H__68CDFFA3_D333_4429_BF93_F832ECFCB6EC__INCLUDED_)
#define AFX_INTERNETSTANDARDS_H__68CDFFA3_D333_4429_BF93_F832ECFCB6EC__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define DNS_INVALID_RESOURCE_CLASS -1
#define DNS_INVALID_RESOURCE_TYPE -1

class CInternetStandards  
{
public:
	CInternetStandards();
	virtual ~CInternetStandards();
	static int GetResourceTypeFromString(LPCTSTR lpszResourceType);
    static int GetResourceClassFromString(LPCTSTR lpszResourceClass);
	static CString GetProtocolNameFromID(UCHAR chProtocol);
};

#endif // !defined(AFX_INTERNETSTANDARDS_H__68CDFFA3_D333_4429_BF93_F832ECFCB6EC__INCLUDED_)
