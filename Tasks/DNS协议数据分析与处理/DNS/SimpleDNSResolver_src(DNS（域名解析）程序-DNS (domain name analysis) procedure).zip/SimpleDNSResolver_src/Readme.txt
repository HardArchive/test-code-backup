========================================================================
       ATL COM Object : SimpleDNSResolverX v1.5
========================================================================

Author: Emmanuel KARTMANN <emmanuel@kartmann.org>
Last Update: June 1st, 2002

OVERVIEW
========

This ATL COM component provides very simple Internet name resolving functionality (Domain Name System or DNS).


WHAT'S NEW
==========

This version has several bug fixes and finds DNS domain better than before (it uses the 
complete "search list" as defined in the TCP/IP configuration).

Version 1.4 was a complete rewriting of the DNS component. Instead of using a porting of the 
BIND 8 library (from UNIX to NT), it relies on the Microsoft Platform SDK (August 2001), which, 
at last, contains a decent DNS API. Please refer to the implementation section for more details.

For those of you who are using Windows 95/98/Millenium (where the Microsoft DNS API 
is not available), you have two solutions: get the older versions of my 
component (ask me) or simply copy the DNSAPI.DLL file from a Windows 2000 
installation to the Windows\System directory of your system (Thanks to 
Hans - hans.baerfuss@baerfuss.net - for this tip).


FEATURES
========

    * implements the basics of DNS, as defined in RFC1034 and RFC1035
    * uses the resolver cache, queries first with UDP, then retries with TCP if the response is truncated
    * asks the server to perform recursive resolution on behalf of the client to resolve the query
    * finds DNS server addresses in local configuration (using API or Windows Registry)
    * provides extended error information (ISupportErrorInfo and IErrorInfo are implemented)
    * provides very small executable: 52 KB (MinSize) to 60 KB (MinDependency)
    * requires no Graphical User Interface: the component can be used in non-GUI applications, like a Windows NT Service.
    * is integrated with SimpleEmailClient (another component): the latter calls method GetEmailServers to automatically find SMTP servers
    * runs on Windows 2000 (relies on Windows DNS API from the Platform SDK, August 2001)
    * compiles with VC++ 6.0 SP5



USAGE
=====

To use this component:
    * create an instance of the component,
    * put/get properties from interface ISimpleDNSClient:
        - ServerAddresses
        - Separator
    * call a method from interface ISimpleDNSClient:
        - Resolve
        - GetEmailServers
        - GetDNSDomain
        - FindPrimaryServer
    * handle errors (try/catch in C++, On Error Resume Next in VBScript)


SAMPLE CODE (VJ++)
==================

To be defined

SAMPLE CODE (VC++)
==================

To be defined

SAMPLE CODE (VBScript)
======================

	Dim oDNS
    ' Create object instance
	Set oDNS = CreateObject("Emmanuel.SimpleDNSClient.1")

    ' Declare output variable 
	Dim found_names

    ' Set the server address(es) [optional on Windows NT, mandatory on Win95/98]
    oDNS.ServerAddresses = "99.99.99.99"

    ' Set separator for output variable (if multiple results are found)
    oDNS.Separator = ", "

    ' (1) Find IP address of hostname "www.microsoft.com" (Internet class, type A)
	On Error Resume Next
	oDNS.Resolve "www.microsoft.com", found_names, "C_IN", "T_A"
	If Err <> 0 Then
		MsgBox Err.Description
	Else
        ' Show resolved names (within dialog box)
		MsgBox "Found names:" & vbCrLf & vbCrLf & found_names
	End If

    ' (2) Find Email Servers for domain "microsoft.com"
	On Error Resume Next
	oDNS.GetEmailServers "microsoft.com", found_names
	If Err <> 0 Then
		MsgBox Err.Description
	Else
        ' Show resolved names (within dialog box)
		MsgBox "Found names:" & vbCrLf & vbCrLf & found_names
	End If


Please refer to the test HTML files for a full VBSsript example :
    TestSimpleDNSResolver.htm
    TestDNSMagic.htm



IMPLEMENTATION
==============

* Base API is the new Windows 2000 DNS API
This component relies on the Windows DNS API provided by the Windows Platform SDK (August 2001). The previous version was based on a porting of the BIND resolver library. Due to the high maintenance cost associated with this library, I decided to drop it when the DNS API came out. See the Component online documentation for more details. 

* Automatic Conversion of reverse lookups (PTR)
If your request is a reverse (IP address-> IP name) lookup (type PTR), then the component silently converts request to a in-arpa format. That is, if you request a resolution of type PTR for IP address "207.46.230.229", then the component will send a resolution request for "229.230.46.207.in-addr.arpa" (PTR). The result will be "www.international.microsoft.com". 

* Find Email Server automatically
The method GetEmailServers sends a request of type MX (Mail eXchanger) in order to find registered servers for a domain. It's only a shortcut for the Resolve method. 

* Ignored Parameter: Resource Class
Due to limitations in the current Windows DNS API, the parameter BResourceClass is ignored by the Resolve method (you should always use the default class "C_IN" for Internet Class). 

* Ignored Property: ServerAddresses
Due to limitations (bugs ?) in the current Windows DNS API, the property ServerAddresses is ignored by the Resolve method (the component always uses the local machine DNS configuration to find the DNS servers). 

You can download the Microsoft Platform SDK from the Microsoft Web Site:
    http://www.microsoft.com/msdownload/platformsdk/sdkupdate

TO DO LIST
==========

    * Test All DNS Resource Records (although all RR types are implemented, most of them couldn't be tested)
    * Support DNS Security extensions (RFC 2535, "Domain Name System Security Extensions")


REFERENCE DOCUMENTATION
=======================

    Book: "DNS and BIND", by Paul Albitz & Cricket Liu, O'Reilly & Associates
        http://www.oreilly.com/catalog/dns3/index.html
    RFC 1034: "DOMAIN NAMES - CONCEPTS AND FACILITIES"
        http://www.ietf.org/rfc/rfc1034.txt
    RFC 1035: "DOMAIN NAMES - IMPLEMENTATION AND SPECIFICATION"
        http://www.ietf.org/rfc/rfc1035.txt
    RFC 0974: "Mail routing and the domain system"
        http://www.ietf.org/rfc/rfc0974.txt
    RFC 2181: "Clarifications to the DNS Specification"
        http://www.ietf.org/rfc/rfc2181.txt
    RFC 2671: "Extension Mechanisms for DNS (EDNS0)"
        http://www.ietf.org/rfc/rfc2671.txt
    RFC 2535: "Domain Name System Security Extensions"
        http://www.ietf.org/rfc/rfc2535.txt
    Microsoft Plaform SDK - Domain Name System - "DNS Start Page"
        http://msdn.microsoft.com/library/en-us/dns/dnsstartpage_2lgl.asp
    Microsoft Plaform SDK - Domain Name System - "DNS Reference"
        http://msdn.microsoft.com/library/en-us/dns/dns_api_3fdx.asp
    Microsoft Plaform SDK - Domain Name System - "DNS Functions"
        http://msdn.microsoft.com/library/en-us/dns/dns_api_1wc3.asp
    Microsoft Plaform SDK - Domain Name System - "DNS Structures"
        http://msdn.microsoft.com/library/en-us/dns/dns_api_9837.asp
    Microsoft Platform SDK - Download
        http://www.microsoft.com/msdownload/platformsdk/sdkupdate

