//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by gnslookup.rc
//
#define IDD_ABOUTBOX                    100
#define IDD_NSLOOKUPG2_DIALOG           102
#define IDP_SOCKETS_INIT_FAILED         103
#define IDR_MAINFRAME                   128
#define IDD_DIALOG1                     129
#define IDI_BIND                        131
#define IDD_DIALOG2                     137
#define IDC_DEBUG                       1000
#define IDC_D2                          1001
#define IDC_CHECK3                      1002
#define IDC_IGNORE                      1002
#define IDC_RECURSE                     1003
#define IDC_VC                          1004
#define IDC_TIMEOUT                     1007
#define IDC_DOMAIN                      1008
#define IDC_RETRY                       1009
#define IDC_PORT                        1010
#define IDC_NAMESERVER                  1013
#define IDQUERY                         1014
#define IDC_QUERYSTRING                 1015
#define IDC_QueryType                   1016
#define IDC_CLASS                       1018
#define IDC_ROOTSERVER                  1019
#define IDC_OUTPUT                      1020
#define IDC_GUIHELP                     1025
#define IDC_ALL                         1026
#define IDC_LOCAL                       1027
#define IDC_LSERVER                     1027
#define IDD_ABOUT                       1029
#define IDC_CLEAR                       1033
#define IDC_HIDE                        1034
#define IDC_ENLARGE                     1035
#define IDC_COPY                        1036
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        138
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1040
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
