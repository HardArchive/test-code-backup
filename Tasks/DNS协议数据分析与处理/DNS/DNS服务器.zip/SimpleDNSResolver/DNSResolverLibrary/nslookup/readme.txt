
This directory contains the nslookup tool (DNS resolver, command line program), BIND implementation, 
ported and compiled on Windows NT.

I added a simple feature: the default name server is fetched in the Windows Registry
(instead of a configuration file like it is done on UNIX).

    Windows NT:
        SYSTEM\CurrentControlSet\Services\Tcpip\Parameters
            NameServer = string containing IP address (dotted notation i.e. "X.X.X.X")
    Windows 95/98:
	There's no automatic detection of DNS server addresses. You must use the "server"
	command to use this tool on Windows 95/98

Emmanuel KARTMANN <emmanuel@kartmann.com>
