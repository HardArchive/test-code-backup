========================================================================
       STATIC LIBRARY : DNSResolverLibrary
========================================================================


This static library implements an Internet Domain Name System (DNS) resolver 
(DNS client).

It's a wild porting of the Berkeley Internet Name Domain (BIND) implementation.
The code is neither stable nor easy to maintain. I'm using it until I implement 
my own DNS resolver (probably in Java).

Reuse this code at your own risk...

Emmanuel KARTMANN <emmanuel@kartmann.com>
