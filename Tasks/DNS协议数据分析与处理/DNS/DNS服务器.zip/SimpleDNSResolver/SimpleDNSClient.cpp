/*=========================================================================== 
    (c) Copyright 2000, Emmanuel KARTMANN, all rights reserved
  =========================================================================== 
    File           : SimpleDNSClient.cpp
    $Header: $
    Author         : Emmanuel KARTMANN <emmanuel@kartmann.com>
    Creation       : Monday 1/31/00 3:51:31 PM
    Remake         : 
  ------------------------------- Description ------------------------------- 

           Implementation of the CSimpleDNSClient

  ------------------------------ Modifications ------------------------------ 
    $Log: $  
  =========================================================================== 
*/

#include "stdafx.h"
#include "SimpleDNSResolver.h"
#include "SimpleDNSClient.h"
#include "WindowsErrorText.h"

/////////////////////////////////////////////////////////////////////////////
// CSimpleDNSClient: Public (Exported) methods

STDMETHODIMP CSimpleDNSClient::InterfaceSupportsErrorInfo(REFIID riid)
{
	static const IID* arr[] = 
	{
		&IID_ISimpleDNSClient
	};
	for (int i=0; i < sizeof(arr) / sizeof(arr[0]); i++)
	{
        if (IsEqualGUID((REFGUID)*arr[i],(REFGUID)riid))
			return S_OK;
	}
	return S_FALSE;
}

STDMETHODIMP CSimpleDNSClient::Resolve(BSTR BSearchedName, VARIANT *pvFoundNames, BSTR BResourceClass, BSTR BResourceType)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState())

    HRESULT hReturnCode = FALSE; // Failure
    union {
        HEADER hdr;
        u_char buf[PACKETSZ];
    } oDNSAnswer;
    int nDNSAnswerLength;
    int nResourceClass;
    int nResourceType;
    CString szSearchedName;
    CString szFoundNames;

    // Convert parameters and init output
    szSearchedName = BSearchedName;
    nResourceClass = GetResourceClassFromString((LPCTSTR)_bstr_t(BResourceClass));
    if (nResourceClass == DNS_INVALID_RESOURCE_CLASS) {
        CString szErrorMessage = "Invalid DNS Resource Class ";
        szErrorMessage+=CString((LPCTSTR)_bstr_t(BResourceClass));
        szErrorMessage+=": ";
        SetError(szErrorMessage, ERROR_INVALID_PARAMETER);
        return(HRESULT_FROM_WIN32(ERROR_INVALID_PARAMETER));
    }
    nResourceType = GetResourceTypeFromString((LPCTSTR)_bstr_t(BResourceType));
    if (nResourceType == DNS_INVALID_RESOURCE_TYPE) {
        CString szErrorMessage = "Invalid DNS Resource Type ";
        szErrorMessage+= CString((LPCTSTR)_bstr_t(BResourceType));
        szErrorMessage+=": ";
        SetError(szErrorMessage, ERROR_INVALID_PARAMETER);
        return(HRESULT_FROM_WIN32(ERROR_INVALID_PARAMETER));
    }
    if (szSearchedName == "") {
        SetError("Invalid resource name (empty): ", ERROR_INVALID_PARAMETER);
        return(HRESULT_FROM_WIN32(ERROR_INVALID_PARAMETER));
    }

    // If request is a reverse (address->name) lookup (type PTR), then silently convert
    // request to a in-arpa format
    if (nResourceType == T_PTR) {
	    struct in_addr addr;
	    if (inet_aton(szSearchedName, &addr)) {
            char *p = (char *)&addr.s_addr;
            szSearchedName.Format("%u.%u.%u.%u.in-addr.arpa",
                                  ((unsigned)p[3] & 0xff),  // CAUTION: reverse byte order (p[3]...p[0])
                                  ((unsigned)p[2] & 0xff),
                                  ((unsigned)p[1] & 0xff),
                                  ((unsigned)p[0] & 0xff));
        } else {
            // Must be an address for a PTR request: error
            SetError("Invalid resource name (empty): ", ERROR_INVALID_PARAMETER);
            return(HRESULT_FROM_WIN32(ERROR_INVALID_PARAMETER));
        }
    }

    // use all known servers (or use method FindAllDNSServers if empty)
    if (m_szServerAddresses == "") {
        m_szServerAddresses = FindAllDNSServers();
    }

    BOOL bNoServer = TRUE;
    CStringList oServerList;
    CString szServerAddress;
    res_init();
    BuildListFromString(m_szServerAddresses, oServerList);
    POSITION pServer = oServerList.GetHeadPosition();
    while (pServer != NULL) {
        szServerAddress = oServerList.GetNext(pServer);
        // Convert dotted notation into address
	    struct in_addr addr;
	    if (inet_aton(szServerAddress, &addr)) {
            // Store it in configuration (memory)
            res_addnameserver(&addr);
            bNoServer = FALSE;
        }
    }
    if (bNoServer) {
        CString szErrorMessage = "Invalid DNS server addresses \"";
        szErrorMessage+=m_szServerAddresses;
        szErrorMessage+="\": ";
        SetError(szErrorMessage, ERROR_INVALID_PARAMETER);
        return(HRESULT_FROM_WIN32(ERROR_INVALID_PARAMETER));
    }

    // Send query to DNS Server and fetch reply
    nDNSAnswerLength = res_search(szSearchedName, nResourceClass, nResourceType, (u_char *)&oDNSAnswer, sizeof(oDNSAnswer));
    if (nDNSAnswerLength == -1) {
        DWORD dwLastError = GetLastError();
        if (dwLastError == 0) {
            dwLastError = ERROR_UNEXP_NET_ERR;
        }
        SetError("DNS Resolution failure: ", dwLastError);
        hReturnCode = HRESULT_FROM_WIN32(dwLastError);
    } else {

        if (oDNSAnswer.hdr.rcode != NOERROR) {

            DWORD dwLastError = GetLastError();
            if (dwLastError == 0) {
                dwLastError = ERROR_UNEXP_NET_ERR;
            }
            SetError("DNS Resolution failure: ", dwLastError);
            hReturnCode = HRESULT_FROM_WIN32(dwLastError);

        } else {

            // Set pointers for parsing answers
            u_char *cp = oDNSAnswer.buf + HFIXEDSZ;
            u_char *pEndOfMessage = oDNSAnswer.buf + nDNSAnswerLength;

            // Number of answers
            int nAnswers = ntohs(oDNSAnswer.hdr.ancount);
            TRACE1("Number of answers = %d\n", nAnswers);

            // Authoritative answer
            BOOL bAuthoritative = (oDNSAnswer.hdr.aa?TRUE:FALSE);

            // Skip the question section
            cp += SkipName(oDNSAnswer.buf, cp, pEndOfMessage) + QFIXEDSZ;

            // Extract Data (and skip it)
            u_short nType;
            u_short nClass;
            u_int32_t nTimeToLive;
            u_short nDataLength;
	        struct in_addr inaddr;
            u_char *pCurrentData = NULL;

            cp += SkipData(oDNSAnswer.buf, cp, &nType, &nClass, &nTimeToLive, &nDataLength, pEndOfMessage);

            while (nAnswers-->=0 && cp<pEndOfMessage) {
                pCurrentData = cp;

                // Check of type of data is the requested type: if yes, process it (otherwise: ignore it)
                TRACE1("RR Type %d...\n", nType);

	            /*
	             * Get type specific data, if appropriate
	             */
	            switch (nType) {
	            case T_A:
                    {
                        // IPv4 address
		                switch (nClass) {
		                case C_IN:
		                case C_HS:
			                bcopy(pCurrentData, (char *)&inaddr, INADDRSZ);
			                if (nDataLength == 4) {
				                TRACE("internet address = %s\n", inet_ntoa(inaddr));

                                AppendResult(nResourceType, nType, inet_ntoa(inaddr), szFoundNames);

			                } else if (nDataLength == 7) {
				                TRACE("\tinternet address = %s",
					                inet_ntoa(inaddr));
				                TRACE(", protocol = %d", pCurrentData[4]);
				                TRACE(", port = %d\n",
					                (pCurrentData[5] << 8) + pCurrentData[6]);

                                AppendResult(nResourceType, nType, inet_ntoa(inaddr), szFoundNames);

                                // TODO: return protocol and port
			                }
			                break;
		                default:
			                TRACE("\taddress, class = %d, len = %d\n",
			                    nClass, nDataLength);
                            // TODO: handle unknown class for type T_A
		                }
                        pCurrentData+=nDataLength;
                    }
		            break;

	            case T_MX:
                    {
                        // Mail eXchanger
		                TRACE("\tpreference = %u",getshort((u_char*)pCurrentData));
		                pCurrentData += INT16SZ;
		                TRACE("\tmail exchanger = \"%s\"\n", pCurrentData);
	                    int n;
	                    char name[MAXDNAME];

	                    n = dn_expand(oDNSAnswer.buf, pEndOfMessage, pCurrentData, name, sizeof(name));
                        if (n >= 0) {
                            AppendResult(nResourceType, nType, name, szFoundNames);
                            pCurrentData+=n;
                        }
                    }
                    break;

	            case T_CNAME:
		            TRACE("\tcanonical name = \"");
                    {
	                    int n;
	                    char name[MAXDNAME];

	                    n = dn_expand(oDNSAnswer.buf, pEndOfMessage, pCurrentData, name, sizeof(name));
                        if (n >= 0) {
                            TRACE("%s", name);
                            AppendResult(nResourceType, nType, name, szFoundNames);
                            pCurrentData+=n;
                        }
                    }
                    TRACE("\"\n");
                    break;

	            case T_NS:
		            TRACE("\tnameserver = \"");
                    {
	                    int n;
	                    char name[MAXDNAME];

	                    n = dn_expand(oDNSAnswer.buf, pEndOfMessage, pCurrentData, name, sizeof(name));
                        if (n >= 0) {
                            AppendResult(nResourceType, nType, name, szFoundNames);
                            pCurrentData+=n;
                        }
                    }
                    TRACE("\"\n");
                    break;

	            case T_PTR:
		            TRACE("\tname = \"");
                    {
	                    int n;
	                    char name[MAXDNAME];

	                    n = dn_expand(oDNSAnswer.buf, pEndOfMessage, pCurrentData, name, sizeof(name));
                        if (n >= 0) {
                            AppendResult(nResourceType, nType, name, szFoundNames);
                            pCurrentData+=n;
                        }
                    }
                    TRACE("\"\n");
		            break;

	            case T_MG:
		            // TODO: handle this type
                    pCurrentData+=nDataLength;
                    break;

	            case T_MB:
		            // TODO: handle this type
                    pCurrentData+=nDataLength;
                    break;

	            case T_MR:
		            // TODO: handle this type
                    pCurrentData+=nDataLength;
                    break;

	            case T_NAPTR: 
		            // TODO: handle this type
                    pCurrentData+=nDataLength;
		            break;

	            case T_SRV: 
		            // TODO: handle this type
                    pCurrentData+=nDataLength;
                    break;

	            case T_RT:
		            // TODO: handle this type
                    pCurrentData+=nDataLength;
                    break;

	            case T_AFSDB:
		            // TODO: handle this type
                    pCurrentData+=nDataLength;
                    break;

	            case T_HINFO:
		            // TODO: handle this type
                    pCurrentData+=nDataLength;
                    break;

	            case T_ISDN:
		            // TODO: handle this type
                    pCurrentData+=nDataLength;
                    break;

	            case T_SOA:
		            // TODO: handle this type
                    pCurrentData+=nDataLength;
                    break;

	            case T_MINFO:
		            // TODO: handle this type
                    pCurrentData+=nDataLength;
                    break;

	            case T_RP:
		            // TODO: handle this type
                    pCurrentData+=nDataLength;
                    break;

	            case T_TXT:
		            // TODO: handle this type
                    pCurrentData+=nDataLength;
                    break;

	            case T_X25:
		            // TODO: handle this type
                    pCurrentData+=nDataLength;
                    break;

	            case T_NSAP:
		            // TODO: handle this type
                    pCurrentData+=nDataLength;
                    break;

	            case T_AAAA: 
		            // TODO: handle this type
                    pCurrentData+=nDataLength;
		            break;

	            case T_UINFO:
		            // TODO: handle this type
                    pCurrentData+=nDataLength;
		            break;

	            case T_UID:
		            // TODO: handle this type
                    pCurrentData+=nDataLength;
		            break;

	            case T_GID:
		            // TODO: handle this type
                    pCurrentData+=nDataLength;
		            break;

	            case T_WKS:
		            // TODO: handle this type
                    pCurrentData+=nDataLength;
		            break;

	            case T_NULL:
		            // TODO: handle this type
                    pCurrentData+=nDataLength;
		            break;

	            default:
		            // TODO: handle this type
                    pCurrentData+=nDataLength;
                    break;
	            }

                ////////////////
                // Next answer
                ////////////////

                // skip the name
                pCurrentData += SkipName(oDNSAnswer.buf, pCurrentData, pEndOfMessage);
                // extract the type, class, TTL and data length of next answer
                GETSHORT(nType, pCurrentData);
                GETSHORT(nClass, pCurrentData);
                GETLONG(nTimeToLive, pCurrentData);
                GETSHORT(nDataLength, pCurrentData);
                cp = pCurrentData;

            }

            hReturnCode = S_OK;
        }
    }

    // Set output variable
    if (pvFoundNames) {
        _variant_t vFoundNames;
        vFoundNames.SetString((LPCTSTR)szFoundNames);
        *pvFoundNames = vFoundNames.Detach();
    }

	return hReturnCode;
}

STDMETHODIMP CSimpleDNSClient::GetDNSDomain(VARIANT *pvDNSDomainName)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState())

    // Find DNS from Registry HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters\NameServer
    HKEY hKey = NULL;
    CString szDNSDomain;
    LONG nResult = S_OK;

    nResult = RegOpenKeyEx(HKEY_LOCAL_MACHINE,
                           "SYSTEM\\CurrentControlSet\\Services\\Tcpip\\Parameters",
                           0,
                           KEY_READ,
                           &hKey
                           );

    if (nResult == ERROR_SUCCESS) {

        DWORD dwType;
        BYTE lpData[256];
        DWORD dwDataSize = sizeof(lpData);
        nResult = RegQueryValueEx(hKey,
                                  "Domain",
                                  NULL,
                                  &dwType,
                                  lpData,
                                  &dwDataSize
                                  );

        if (nResult == ERROR_SUCCESS) {

            TCHAR lpszData[256];
            memcpy((void *)lpszData, (const void *)lpData, dwDataSize);
            lpszData[dwDataSize] = '\0';

            szDNSDomain = lpszData;

        } else {

            szDNSDomain = "";
            CString szErrorMessage = "Cannot open registry key \"SYSTEM\\CurrentControlSet\\Services\\Tcpip\\Parameters\\Domain\":";
            SetError(szErrorMessage, nResult);

        }

    } else {

        szDNSDomain = "";
        CString szErrorMessage = "Cannot open registry key \"SYSTEM\\CurrentControlSet\\Services\\Tcpip\\Parameters\":";
        SetError(szErrorMessage, nResult);

    }

    // Return value
    if (pvDNSDomainName) {
        _variant_t vDNSDomain;
        vDNSDomain.SetString((LPCTSTR)szDNSDomain);
        *pvDNSDomainName = vDNSDomain.Detach();
    }

    // Cleanup
    if (hKey) {
        RegCloseKey(hKey);
        hKey = NULL;
    }

	return HRESULT_FROM_WIN32(nResult);
}

STDMETHODIMP CSimpleDNSClient::FindServerAddresses(VARIANT *pvServerAddresses)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState())

    CString szServerAddresses = FindAllDNSServers();
    HRESULT hResult = S_OK;

    if (szServerAddresses == "") {
        DWORD dwLastError = GetLastError();
        SetError("Cannot find DNS Servers in registry: ", dwLastError);
        hResult = HRESULT_FROM_WIN32(dwLastError);
    } else {
        hResult = S_OK;
    }

    // Return value
    if (pvServerAddresses) {
        _variant_t vServerAddresses = szServerAddresses;
        *pvServerAddresses = vServerAddresses.Detach();
    }

	return hResult;
}

STDMETHODIMP CSimpleDNSClient::get_Separator(BSTR *pVal)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState())

    if (pVal) {
        *pVal = _bstr_t(m_szSeparator);
    }

	return S_OK;
}

STDMETHODIMP CSimpleDNSClient::put_Separator(BSTR newVal)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState())

    _bstr_t BNewVal = newVal;
	m_szSeparator = (LPCTSTR)BNewVal;

	return S_OK;
}

/////////////////////////////////////////////////////////////////////////////
// Protected methods
/////////////////////////////////////////////////////////////////////////////

CString CSimpleDNSClient::FindAllDNSServers()
{
    // Find DNS from Registry HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters\NameServer
    HKEY hKey = NULL;
    CString szDNSAllServers;
    LONG nResult = S_OK;

    nResult = RegOpenKeyEx(HKEY_LOCAL_MACHINE,
                           "SYSTEM\\CurrentControlSet\\Services\\Tcpip\\Parameters",
                           0,
                           KEY_READ,
                           &hKey
                           );

    if (nResult == ERROR_SUCCESS) {

        DWORD dwType;
        BYTE lpData[256];
        DWORD dwDataSize = sizeof(lpData);
        nResult = RegQueryValueEx(hKey,
                                  "NameServer",
                                  NULL,
                                  &dwType,
                                  lpData,
                                  &dwDataSize
                                  );

        if (nResult == ERROR_SUCCESS) {

            TCHAR lpszData[256];
            memcpy((void *)lpszData, (const void *)lpData, dwDataSize);
            lpszData[dwDataSize] = '\0';

            szDNSAllServers = lpszData;

        } else {

            szDNSAllServers = "";

        }

    } else {

        szDNSAllServers = "";

    }

    // Cleanup
    if (hKey) {
        RegCloseKey(hKey);
        hKey = NULL;
    }

    return(szDNSAllServers);
}

CString CSimpleDNSClient::FindFirstDNSServer()
{
    CString szDNSFirstServer;
    CString szDNSAllServers = FindAllDNSServers();

    if (szDNSAllServers != "") {
        // Servers are separated by spaces
        int nPosition = szDNSAllServers.Find(" ", 0);
        if (nPosition!=-1) {
            szDNSFirstServer = szDNSAllServers.Left(nPosition);
        } else {
            szDNSFirstServer = szDNSAllServers;
        }
    }
    return(szDNSFirstServer);
}


int CSimpleDNSClient::SkipName(u_char *pStartOfMesssage, u_char *pCurrentPosition, u_char *pEndOfMessage)
{
    char buf[MAXDNAME];
    int n;

    n = dn_expand(pStartOfMesssage, pEndOfMessage, pCurrentPosition, buf, MAXDNAME);
    if (n<0) {
        n=0;
    }

    return(n);
}

int CSimpleDNSClient::SkipData(u_char *pStartOfMesssage, 
                         u_char *pCurrentPosition, 
                         u_short *pType, 
                         u_short *pClass,
                         u_int32_t *pTimeToLive,
                         u_short *pDataLength,
                         u_char *pEndOfMessage)
{
    u_char *pTempPosition = pCurrentPosition;
    // Skip the data name
    pTempPosition += SkipName(pStartOfMesssage, pTempPosition, pEndOfMessage);

    // Get the Type, Class, TTL and Data Length
    GETSHORT(*pType, pTempPosition);
    GETSHORT(*pClass, pTempPosition);
    GETLONG(*pTimeToLive, pTempPosition);
    GETSHORT(*pDataLength, pTempPosition);

    return(pTempPosition - pCurrentPosition);
}

int CSimpleDNSClient::GetResourceClassFromString(LPCTSTR lpszResourceClass)
{
    CString szResourceClass = lpszResourceClass;

    if (szResourceClass == "C_IN" ||
        szResourceClass == "IN") {
        // the arpa internet (surely the only class in use these days)
        return(C_IN);
    }
    if (szResourceClass == "C_CHAOS" ||
        szResourceClass == "CHAOS") {
        // chaos net (MIT)
        return(C_CHAOS);
    }
    if (szResourceClass == "C_HS" ||
        szResourceClass == "HS") {
        // Hesiod name server (MIT)
        return(C_HS);
    }
    if (szResourceClass == "*" ||
        szResourceClass == "C_ANY" ||
        szResourceClass == "ANY") {
        // wildcard match
        return(C_ANY);
    }

    return(DNS_INVALID_RESOURCE_CLASS);
}

int CSimpleDNSClient::GetResourceTypeFromString(LPCTSTR lpszResourceType)
{
    CString szResourceType = lpszResourceType;

    if (szResourceType == "T_A" ||
        szResourceType == "A") {
        /* host address */
        return(T_A);
    }
    if (szResourceType == "T_NS" ||
        szResourceType == "NS") {
        /* authoritative server */
        return(T_NS);
    }
    if (szResourceType == "T_MD" ||
        szResourceType == "MD") {
        /* mail destination */
        return(T_MD);
    }
    if (szResourceType == "T_MF" ||
        szResourceType == "MF") {
        /* mail forwarder */
        return(T_MF);
    }
    if (szResourceType == "T_CNAME" ||
        szResourceType == "CNAME") {
        /* canonical name */
        return(T_CNAME);
    }
    if (szResourceType == "T_SOA" ||
        szResourceType == "SOA") {
        /* start of authority zone */
        return(T_SOA);
    }
    if (szResourceType == "T_MB" ||
        szResourceType == "MB") {
        /* mailbox domain name */
        return(T_MB);
    }
    if (szResourceType == "T_MG" ||
        szResourceType == "MG") {
        /* mail group member */
        return(T_MG);
    }
    if (szResourceType == "T_MR" ||
        szResourceType == "MR") {
        /* mail rename name */
        return(T_MR);
    }
    if (szResourceType == "T_NULL" ||
        szResourceType == "NULL") {
        /* null resource record */
        return(T_NULL);
    }
    if (szResourceType == "T_WKS" ||
        szResourceType == "WKS") {
        /* well known service */
        return(T_WKS);
    }
    if (szResourceType == "T_PTR" ||
        szResourceType == "PTR") {
        /* domain name pointer */
        return(T_PTR);
    }
    if (szResourceType == "T_HINFO" ||
        szResourceType == "HINFO") {
        /* host information */
        return(T_HINFO);
    }
    if (szResourceType == "T_MINFO" ||
        szResourceType == "MINFO") {
        /* mailbox information */
        return(T_MINFO);
    }
    if (szResourceType == "T_MX" ||
        szResourceType == "MX") {
        /* mail routing information */
        return(T_MX);
    }
    if (szResourceType == "T_TXT" ||
        szResourceType == "TXT") {
        /* text strings */
        return(T_TXT);
    }
    if (szResourceType == "T_RP" ||
        szResourceType == "RP") {
        /* responsible person */
        return(T_RP);
    }
    if (szResourceType == "T_AFSDB" ||
        szResourceType == "AFSDB") {
        /* AFS cell database */
        return(T_AFSDB);
    }
    if (szResourceType == "T_X25" ||
        szResourceType == "X25") {
        /* X_25 calling address */
        return(T_X25);
    }
    if (szResourceType == "T_ISDN" ||
        szResourceType == "ISDN") {
        /* ISDN calling address */
        return(T_ISDN);
    }
    if (szResourceType == "T_RT" ||
        szResourceType == "RT") {
        /* router */
        return(T_RT);
    }
    if (szResourceType == "T_NSAP" ||
        szResourceType == "NSAP") {
        /* NSAP address */
        return(T_NSAP);
    }
    if (szResourceType == "T_NSAP_PTR" ||
        szResourceType == "NSAP_PTR") {
        /* reverse NSAP lookup (deprecated) */
        return(T_NSAP_PTR);
    }
    if (szResourceType == "T_SIG" ||
        szResourceType == "SIG") {
        /* security signature */
        return(T_SIG);
    }
    if (szResourceType == "T_KEY" ||
        szResourceType == "KEY") {
        /* security key */
        return(T_KEY);
    }
    if (szResourceType == "T_PX" ||
        szResourceType == "PX") {
        /* X.400 mail mapping */
        return(T_PX);
    }
    if (szResourceType == "T_GPOS" ||
        szResourceType == "GPOS") {
        /* geographical position (withdrawn) */
        return(T_GPOS);
    }
    if (szResourceType == "T_AAAA" ||
        szResourceType == "AAAA") {
        /* IP6 Address */
        return(T_AAAA);
    }
    if (szResourceType == "T_LOC" ||
        szResourceType == "LOC") {
        /* Location Information */
        return(T_LOC);
    }
    if (szResourceType == "T_NXT" ||
        szResourceType == "NXT") {
        /* Next Valid Name in Zone */
        return(T_NXT);
    }
    if (szResourceType == "T_EID" ||
        szResourceType == "EID") {
        /* Endpoint identifier */
        return(T_EID);
    }
    if (szResourceType == "T_NIMLOC" ||
        szResourceType == "NIMLOC") {
        /* Nimrod locator */
        return(T_NIMLOC);
    }
    if (szResourceType == "T_SRV" ||
        szResourceType == "SRV") {
        /* Server selection */
        return(T_SRV);
    }
    if (szResourceType == "T_ATMA" ||
        szResourceType == "ATMA") {
        /* ATM Address */
        return(T_ATMA);
    }
    if (szResourceType == "T_NAPTR" ||
        szResourceType == "NAPTR") {
        /* Naming Authority PoinTeR */
        return(T_NAPTR);
    }

    /////////////////
    // non standard
    /////////////////

    if (szResourceType == "T_UINFO" ||
        szResourceType == "UINFO") {
        /* user (finger) information */
        return(T_UINFO);
    }
    if (szResourceType == "T_UID" ||
        szResourceType == "UID") {
        /* user ID */
        return(T_UID);
    }
    if (szResourceType == "T_GID" ||
        szResourceType == "GID") {
        /* group ID */
        return(T_GID);
    }
    if (szResourceType == "T_UNSPEC" ||
        szResourceType == "UNSPEC") {
        /* Unspecified format (binary data) */
        return(T_UNSPEC);
    }

    //////////////////////////////////////////////////////////////
    // Query type values which do not appear in resource records
    //////////////////////////////////////////////////////////////

    if (szResourceType == "T_IXFR" ||
        szResourceType == "IXFR") {
        /* incremental zone transfer */
        return(T_IXFR);
        }
    if (szResourceType == "T_AXFR" ||
        szResourceType == "AXFR") {
        /* transfer zone of authority */
        return(T_AXFR);
        }
    if (szResourceType == "T_MAILB" ||
        szResourceType == "MAILB") {
        /* transfer mailbox records */
        return(T_MAILB);
    }
    if (szResourceType == "T_MAILA" ||
        szResourceType == "MAILA") {
        /* transfer mail agent records */
        return(T_MAILA);
    }
    if (szResourceType == "*" ||
        szResourceType == "T_ANY" ||
        szResourceType == "ANY") {
        /* wildcard match */
        return(T_ANY);
    }

    return(DNS_INVALID_RESOURCE_TYPE);
}

HRESULT CSimpleDNSClient::SetError(LPCTSTR lpszErrorMessage, DWORD dwLastError)
{
    CString szErrorMessage = lpszErrorMessage;
    USES_CONVERSION;

    if (dwLastError != 0) {
        TCHAR lpszSystemErrorText[1024];
        szErrorMessage+=WindowsGetErrorText(dwLastError, lpszSystemErrorText, sizeof(lpszSystemErrorText));
    }
    TRACE1("%s\n", szErrorMessage);

    // Build COM error info object
    ICreateErrorInfo *pcerrinfo;
    IErrorInfo *perrinfo;
    HRESULT hr;

    hr = CreateErrorInfo(&pcerrinfo);

    // Fill error info object
    pcerrinfo->SetDescription(T2OLE(szErrorMessage));
    pcerrinfo->SetSource(T2OLE("SITA.SimpleTelnetClientX"));
    pcerrinfo->SetGUID(IID_ISimpleDNSClient);

    // Set error info object for current thread
    hr = pcerrinfo->QueryInterface(IID_IErrorInfo, (LPVOID FAR*) &perrinfo);
    if (SUCCEEDED(hr))
    {
        SetErrorInfo(0, perrinfo);
        perrinfo->Release();
    }
    pcerrinfo->Release();

    return(S_OK);
}


BOOL CSimpleDNSClient::AppendResult(int nRequestedType, int nType, LPCTSTR lpszResult, CString &szTotalResult)
{
    if (nType == nRequestedType || nRequestedType == T_ANY) {
        if (szTotalResult == "") {
            szTotalResult = lpszResult;
        } else {
            // Append name (using separator property to separate entries)
            szTotalResult +=m_szSeparator;
            szTotalResult += lpszResult;
        }
    }
    return(TRUE);
}


STDMETHODIMP CSimpleDNSClient::GetEmailServers(BSTR pBDomainName, VARIANT *pvEmailServerNames)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState())

    _bstr_t BDomainName = pBDomainName;
    _variant_t vFoundNames;
    HRESULT hResult = S_OK;

    // Set parameters, if default
    if (BDomainName == _bstr_t("")) {
        _variant_t vLocalDomainName;
        hResult = GetDNSDomain(&vLocalDomainName);
        if (FAILED(hResult)) {
            SetError("Invalid parameter: empty domain name and cannot read default domain: ", hResult);
            return(hResult);
        } else {
            BDomainName = vLocalDomainName;
        }
    }

    // Simply call the resolve method with class INternet and type Mail eXchanger
    hResult = Resolve(BDomainName, &vFoundNames, _bstr_t("C_IN"), _bstr_t("T_MX"));
    
    // Set output variable
    if (pvEmailServerNames) {
        *pvEmailServerNames = vFoundNames.Detach();
    }

	return(hResult);
}

STDMETHODIMP CSimpleDNSClient::get_ServerAddresses(BSTR *pVal)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState())

    if (pVal) {
        *pVal = _bstr_t((LPCTSTR)m_szServerAddresses);
    }

	return S_OK;
}

STDMETHODIMP CSimpleDNSClient::put_ServerAddresses(BSTR newVal)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState())

	m_szServerAddresses = (LPCTSTR)bstr_t(newVal);

	return S_OK;
}


BOOL CSimpleDNSClient::BuildListFromString(LPCTSTR lpszStringWithSeparators, CStringList &oList)
{
    CString szStringWithSeparators = lpszStringWithSeparators;
    TCHAR cSeparator = ',';
    int nPos = -1;
    oList.RemoveAll();
    int nCurrentPos = 0;
    int nCurrentLength = 0;
    CString szCurrentItem;

    nPos = szStringWithSeparators.Find(cSeparator);
    if (nPos == -1) {
        // Try semi-colon
        cSeparator = ';';
        nPos = szStringWithSeparators.Find(cSeparator);
        if (nPos == -1) {
            // Try space
            cSeparator = ' ';
            nPos = szStringWithSeparators.Find(cSeparator);
        }
    }
    while (nPos != -1) {
        nCurrentLength = nPos - nCurrentPos;
        szCurrentItem = szStringWithSeparators.Mid(nCurrentPos, nCurrentLength);
        // Remove starting/trailing spaces
        szCurrentItem.TrimLeft(" ");
        szCurrentItem.TrimRight(" ");
        if (szCurrentItem != "") {
            TRACE1("Adding string \"%s\"\n", szCurrentItem);
            oList.AddTail(szCurrentItem);
        }
        nCurrentPos = nPos+1;
        nPos = szStringWithSeparators.Find(cSeparator, nCurrentPos);
    }
    // Add last item
    szCurrentItem = szStringWithSeparators.Mid(nCurrentPos);
    // Remove starting/trailing spaces
    szCurrentItem.TrimLeft(" ");
    szCurrentItem.TrimRight(" ");
    if (szCurrentItem != "") {
        TRACE1("Adding string \"%s\"\n", szCurrentItem);
        oList.AddTail(szCurrentItem);
    }
    

    return(!oList.IsEmpty());
}
