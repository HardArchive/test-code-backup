/*=========================================================================== 
    (c) Copyright 2000, Emmanuel KARTMANN, all rights reserved
  =========================================================================== 
    File           : SimpleDNSClient.h
    $Header: $
    Author         : Emmanuel KARTMANN <emmanuel@kartmann.com>
    Creation       : Monday 1/31/00 3:51:10 PM
    Remake         : 
  ------------------------------- Description ------------------------------- 

           Declaration of the CSimpleDNSClient class.

  ------------------------------ Modifications ------------------------------ 
    $Log: $  
  =========================================================================== 
*/

#ifndef __SIMPLEDNSCLIENT_H_
#define __SIMPLEDNSCLIENT_H_

#include "resource.h"       // main symbols

#define DNS_INVALID_RESOURCE_CLASS -1
#define DNS_INVALID_RESOURCE_TYPE -1

/////////////////////////////////////////////////////////////////////////////
// CSimpleDNSClient
/* -----------------------------------------------------------------
CLASS

    CSimpleDNSClient 

    COM (ActiveX) object implementing ISimpleDNSClient, a DNS resolver.

DESCRIPTION

    This class implements a DNS resolver within a COM object. It
    relies on a porting of the BIND (Berkeley Internet Name Domain)
    implementation of DNS.

USAGE

    To use this class:
    <UL>
        <LI>Create an instance of the COMponent
        <LI>Call any method of the ISimpleDNSClient interface:
        <UL>
            <LI>Resolve()
            <LI>GetEmailServers()
            <LI>FindServerAddresses()
            <LI>get_ServerAddresses()
            <LI>put_ServerAddresses()
            <LI>get_Separator()
            <LI>put_Separator()
            <LI>GetDNSDomain()
        </UL>
        <LI>Delete instance of COMponent
    </UL>

EXAMPLE

    <PRE>
    Dim oDNS
    Set oDNS = CreateObject("Emmanuel.SimpleDNSClient.1")

    Dim requested_name
    requested_name = "www.microsoft.com"

    Dim found_names
    found_names = ""

    ' Set the server address(es) [optional on Windows NT, mandatory on Win95/98]
    oDNS.ServerAddresses = "99.99.99.99"

    ' Set the separator
    oDNS.Separator = ";"

    On Error Resume Next
    oDNS.GetEmailServers requested_name, found_names
    If Err <> 0 Then
        MsgBox Err.Description
    Else
        ' Show resolved names (within dialog box)
        MsgBox "Found names:" & vbCrLf & vbCrLf & found_names
    End If
    </PRE>

ADMINISTRATIVE

  Author     Emmanuel KARTMANN <emmanuel@kartmann.com>

  Date       Monday 1/31/00 3:52:04 PM

SEE ALSO

    <A HREF="http://www.ietf.org/rfc/rfc1034.txt">RFC1034</A>,<BR>
    <A HREF="http://www.ietf.org/rfc/rfc1035.txt">RFC1035</A>.

----------------------------------------------------------------- */
class ATL_NO_VTABLE CSimpleDNSClient : 
    public CComObjectRootEx<CComMultiThreadModel>,
    public CComCoClass<CSimpleDNSClient, &CLSID_SimpleDNSClient>,
    public ISupportErrorInfo,
    public IDispatchImpl<ISimpleDNSClient, &IID_ISimpleDNSClient, &LIBID_SIMPLEDNSRESOLVERLib>
{
public:

/////////////////////////////////////////////////////////////////////
//
// <U>Purpose:</U> create an instance of the class
//
// <U>Parameters:</U> none (C++ constructor)
//
// <U>Return value :</U> none (C++ constructor)
//
// <U>Description  :</U> 
//
    CSimpleDNSClient()
        : m_szSeparator(", ")
    {
    }

DECLARE_REGISTRY_RESOURCEID(IDR_SIMPLEDNSCLIENT)

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CSimpleDNSClient)
    COM_INTERFACE_ENTRY(ISimpleDNSClient)
    COM_INTERFACE_ENTRY(IDispatch)
    COM_INTERFACE_ENTRY(ISupportErrorInfo)
END_COM_MAP()

// ISupportsErrorInfo
    STDMETHOD(InterfaceSupportsErrorInfo)(REFIID riid);

// ISimpleDNSClient
public:

/////////////////////////////////////////////////////////////////////
//
// <U>Purpose:</U> return the known DNS server addresses,
//                 as configured in your local machine (Windows Registry)
//
// <U>Parameters:</U> 
//
//       [out] pvServerAddresses
//                list of DNS Server addresses (separated by spaces),
//                in dotted notation, e.g. "192.175.235.1 192.175.234.2"
//
// <U>Return value :</U> HRESULT = S_OK for success, 
//                                 otherwise an error occurred
//
// <U>Description  :</U> This function reads the registry key
//                       HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters\NameServer
//                       to find the DNS servers on the local machine.
//
//                       This function works on Windows NT only.
//
    STDMETHOD(FindServerAddresses)(VARIANT *pvServerAddresses);

/////////////////////////////////////////////////////////////////////
//
// <U>Purpose:</U> return value of the ServerAddresses property,
//                 i.e. the list of DNS servers.
//
// <U>Parameters:</U> 
//
//       [out] pVal
//                list of DNS Server addresses (separated by spaces),
//                in dotted notation, e.g. "192.175.235.1 192.175.234.2"
//
// <U>Return value :</U> HRESULT = S_OK for success, 
//                                 otherwise an error occurred
//
// <U>Description  :</U> The property ServerAddresses can be set
//                       via method put_ServerAddresses().
//
    STDMETHOD(get_ServerAddresses)(/*[out, retval]*/ BSTR *pVal);

/////////////////////////////////////////////////////////////////////
//
// <U>Purpose:</U> set value of the ServerAddresses property,
//                 i.e. the list of DNS servers.
//
// <U>Parameters:</U> 
//
//       [in] newVal
//                new list of DNS Server addresses (separated by spaces),
//                in dotted notation, e.g. "192.175.235.1 192.175.234.2"
//
// <U>Return value :</U> HRESULT = S_OK for success, 
//                                 otherwise an error occurred
//
// <U>Description  :</U> The property ServerAddresses can be read
//                       via method get_ServerAddresses().
//
    STDMETHOD(put_ServerAddresses)(/*[in]*/ BSTR newVal);

/////////////////////////////////////////////////////////////////////
//
// <U>Purpose:</U> resolve a name in DNS, i.e. send a request and
//                 build a list (string) of results with the server's
//                 answer(s).
//
// <U>Parameters:</U> 
//
//       [in] BSearchedName
//                name of the searched resource record
//       [out] pvFoundNames
//                list of found records (a string with every entry
//                separated by value of 'Separator' property).
//       [in] BResourceClass
//                class of searched record. Can be any of the following
//                classes:
//              <UL>
//                  <LI><B>C_IN: ARPA Internet</B> (default)
//                  <LI>C_CHAOS: Chaos Net at MIT
//                  <LI>C_HS: Hesiod at MIT
//                  <LI>C_ANY: Any class
//              </UL>
//
//       [in] BResourceType
//                type of searched record. Can be any of the following
//                types:
//              <UL>
//                  <LI><B>T_A: host address (IPv4)</B> (default)
//                  <LI>T_NS: authoritative server
//                  <LI>T_MD: mail destination
//                  <LI>T_MF: mail forwarder
//                  <LI>T_CNAME: canonical name
//                  <LI>T_SOA: start of authority zone
//                  <LI>T_MB: mailbox domain name
//                  <LI>T_MG: mail group member
//                  <LI>T_MR: mail rename name
//                  <LI>T_NULL: null resource record
//                  <LI>T_WKS: well known service
//                  <LI>T_PTR: domain name pointer
//                  <LI>T_HINFO: host information
//                  <LI>T_MINFO: mailbox information
//                  <LI>T_MX: mail routing information
//                  <LI>T_TXT: text strings
//                  <LI>T_RP: responsible person
//                  <LI>T_AFSDB: AFS cell database
//                  <LI>T_X25: X_25 calling address
//                  <LI>T_ISDN: ISDN calling address
//                  <LI>T_RT: router
//                  <LI>T_NSAP: NSAP address
//                  <LI>T_NSAP_PTR: reverse NSAP lookup (deprecated)
//                  <LI>T_SIG: security signature
//                  <LI>T_KEY: security key
//                  <LI>T_PX: X.400 mail mapping
//                  <LI>T_GPOS: geographical position (withdrawn)
//                  <LI>T_AAAA: IPv6 Address
//                  <LI>T_LOC: Location Information
//                  <LI>T_NXT: Next Valid Name in Zone
//                  <LI>T_EID: Endpoint identifier
//                  <LI>T_NIMLOC: Nimrod locator
//                  <LI>T_SRV: Server selection
//                  <LI>T_ATMA: ATM Address
//                  <LI>T_NAPTR: Naming Authority PoinTeR
//                  <LI>T_UINFO: user (finger) information (non standard)
//                  <LI>T_UID: user ID (non standard)
//                  <LI>T_GID: group ID (non standard)
//                  <LI>T_UNSPEC: Unspecified format (binary data/non standard)
//                  <LI>T_IXFR: incremental zone transfer
//                  <LI>T_AXFR: transfer zone of authority
//                  <LI>T_MAILB: transfer mailbox records
//                  <LI>T_MAILA: transfer mail agent records
//                  <LI>T_ANY: wildcard match
//              </UL>
//
// <U>Return value :</U> HRESULT = S_OK for success, 
//                                 otherwise an error occurred
//
// <U>Description  :</U> IP addresses are returned in dotted notation (e.g. "123.123.123.123")
//
    STDMETHOD(Resolve)(/*[in]*/ BSTR BSearchedName, /*[out]*/ VARIANT *pvFoundNames, /*[in, optional, defaultvalue("C_IN")]*/ BSTR BResourceClass, /*[in, optional, defaultvalue("T_A")]*/ BSTR BResourceType);


/////////////////////////////////////////////////////////////////////
//
// <U>Purpose:</U> get the Email (SMTP) Servers for a given domain
//
// <U>Parameters:</U> 
//
//       [in] BDomainName
//                domain name to look for. Note that if this parameter
//                is empty, the domain name for local machine will be
//                used (see method GetDNSDomain()).
//       [out] pvEmailServerNames
//                list of found server names (a string with every entry
//                separated by value of 'Separator' property).
//
// <U>Return value :</U> HRESULT = S_OK for success, 
//                                 otherwise an error occurred
//
// <U>Description  :</U> SMTP servers are declared in the DNS database.
//                       This function calls method Resolve() with class
//                       "C_IN" and type "T_MX" for the given domain; the
//                       returned records, if any, consist in the SMTP
//                       servers declared for that domain.
//
    STDMETHOD(GetEmailServers)(/*[in, optional, defaultvalue("")]*/ BSTR BDomainName, /*[out]*/ VARIANT *pvEmailServerNames);

/////////////////////////////////////////////////////////////////////
//
// <U>Purpose:</U> return the string used to separate
//                 multiple results of method Resolve()
//
// <U>Parameters:</U> 
//
//       [out] pVal
//                separator string (defaults to ", ")
//
// <U>Return value :</U> HRESULT = S_OK for success, 
//                                 otherwise an error occurred
//
// <U>Description  :</U> 
//
    STDMETHOD(get_Separator)(/*[out, retval]*/ BSTR *pVal);

/////////////////////////////////////////////////////////////////////
//
// <U>Purpose:</U> set the string used to separate 
//                 multiple results of method Resolve()
//
// <U>Parameters:</U> 
//
//       [in] newVal
//                new separator string
//
// <U>Return value :</U> HRESULT = S_OK for success, 
//                                 otherwise an error occurred
//
// <U>Description  :</U> 
//
    STDMETHOD(put_Separator)(/*[in]*/ BSTR newVal);

/////////////////////////////////////////////////////////////////////
//
// <U>Purpose:</U> returns the DNS domain as defined in machine 
//                 configuration (Windows Registry).
//
// <U>Parameters:</U> 
//
//       [out] pvDNSDomainName
//                DNS domain name (e.g. "kartmann.com").
//
// <U>Return value :</U> HRESULT = S_OK for success, 
//                                 otherwise an error occurred
//
// <U>Description  :</U> This function works on Windows NT only.
//
//
    STDMETHOD(GetDNSDomain)(/*[out]*/ VARIANT *pvDNSDomainName);
protected:
    BOOL BuildListFromString(LPCTSTR lpszStringWithSeparators, CStringList &oList);
    CString m_szServerAddresses;
    CString m_szSeparator;
    BOOL AppendResult(int nRequestedType, int nType, LPCTSTR lpszResult, CString &szTotalResult);
    HRESULT SetError(LPCTSTR lpszErrorMessage, DWORD dwLastError = 0);
    int GetResourceTypeFromString(LPCTSTR lpszResourceType);
    int GetResourceClassFromString(LPCTSTR lpszResourceClass);
    CString FindFirstDNSServer(void);
    CString FindAllDNSServers(void);
    int SkipName(u_char *pStartOfMesssage, u_char *pCurrentPosition, u_char *pEndOfMessage);
    int SkipData(u_char *pStartOfMesssage, 
                 u_char *pCurrentPosition, 
                 u_short *pType, 
                 u_short *pClass,
                 u_int32_t *pTimeToLive,
                 u_short *pDataLength,
                 u_char *pEndOfMessage);
    BOOL ExtractData(u_char *&pCurrentData, u_short nDataLength, int nType, int nClass, int nSearchedType, CString &szFoundNames);
};

#endif //__SIMPLEDNSCLIENT_H_
