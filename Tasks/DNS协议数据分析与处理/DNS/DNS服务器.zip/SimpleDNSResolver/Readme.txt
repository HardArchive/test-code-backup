========================================================================
       ATL COM Object : SimpleDNSResolverX v1.0
========================================================================

Author: Emmanuel KARTMANN <emmanuel@kartmann.com>
Date: February 9th, 2000

OVERVIEW
========

This ATL COM component provides very simple Internet name resolving functionality (Domain Name System or DNS).



FEATURES
========

    * implement the basics of DNS, as defined in RFC1034 and RFC1035
    * send DNS requests via UDP
    * receive and process DNS replies via UDP
    * support multiple (up to 6) DNS servers (if first doesn't reply, try with second, etc...)
    * find DNS server addresses in local configuration (Windows Registry)
    * provide extended error information (ISupportErrorInfo and IErrorInfo are implemented)
    * provide very small executable: 72 KB (MinSize) to 84 KB (MinDependency)
    * require no Graphical User Interface: the component can be used in non-GUI applications, like a Windows NT Service.
    * integrated with SimpleEmailClient (another component): the latter calls method GetEmailServers to automatically find SMTP servers
    * run on Windows NT 4.0, Windows 95 and Windows 98
    * compile with VC++ 6.0 SP3



USAGE
=====

To use this component:
    * create an instance of the component,
    * put/get properties from interface ISimpleDNSClient:
        - ServerAddresses
        - Separator
    * call a method from interface ISimpleDNSClient:
        - Resolve
        - GetEmailServers
        - GetDNSDomain
        - FindPrimaryServer
    * handle errors (try/catch in C++, On Error Resume Next in VBScript)


SAMPLE CODE (VJ++)
==================

To be defined

SAMPLE CODE (VC++)
==================

To be defined

SAMPLE CODE (VBScript)
======================

	Dim oDNS
    ' Create object instance
	Set oDNS = CreateObject("Emmanuel.SimpleDNSClient.1")

    ' Declare output variable 
	Dim found_names

    ' Set the server address(es) [optional on Windows NT, mandatory on Win95/98]
    oDNS.ServerAddresses = "99.99.99.99"

    ' Set separator for output variable (if multiple results are found)
    oDNS.Separator = ", "

    ' (1) Find IP address of hostname "www.microsoft.com" (Internet class, type A)
	On Error Resume Next
	oDNS.Resolve "www.microsoft.com", found_names, "C_IN", "T_A"
	If Err <> 0 Then
		MsgBox Err.Description
	Else
        ' Show resolved names (within dialog box)
		MsgBox "Found names:" & vbCrLf & vbCrLf & found_names
	End If

    ' (2) Find Email Servers for domain "microsoft.com"
	On Error Resume Next
	oDNS.GetEmailServers "microsoft.com", found_names
	If Err <> 0 Then
		MsgBox Err.Description
	Else
        ' Show resolved names (within dialog box)
		MsgBox "Found names:" & vbCrLf & vbCrLf & found_names
	End If


Please refer to the test HTML files for a full VBSsript example :
    TestSimpleDNSResolver.htm
    TestDNSMagic.htm



IMPLEMENTATION
==============

This component relies on a porting of the BIND resolver library. It's available on the project 
DNSResolverLibrary (.dsp) in the kit.

The next version will be implemented in Java (hopefully).



TO DO LIST
==========

    * Support All DNS Resource Records (only "T_A", "T_MX", "T_CNAME" are supported)
    * Support DNS Security extensions (RFC 2535, "Domain Name System Security Extensions")


REFERENCE DOCUMENTATION
=======================

    Book: "DNS and BIND", by Paul Albitz & Cricket Liu, O'Reilly & Associates
        http://www.oreilly.com/catalog/dns3/index.html
    RFC 1034: "DOMAIN NAMES - CONCEPTS AND FACILITIES"
        http://www.ietf.org/rfc/rfc1034.txt
    RFC 1035: "DOMAIN NAMES - IMPLEMENTATION AND SPECIFICATION"
        http://www.ietf.org/rfc/rfc1035.txt
    RFC 0974: "Mail routing and the domain system"
        http://www.ietf.org/rfc/rfc0974.txt
    RFC 2181: "Clarifications to the DNS Specification"
        http://www.ietf.org/rfc/rfc2181.txt
    RFC 2671: "Extension Mechanisms for DNS (EDNS0)"
        http://www.ietf.org/rfc/rfc2671.txt
    RFC 2535: "Domain Name System Security Extensions"
        http://www.ietf.org/rfc/rfc2535.txt
