#define DOMAIN_VERSION		"0.0.2"
#define MAX_CHAR		50

struct ipt_domain_info
{
	char name[MAX_CHAR];
	char org_name[MAX_CHAR];
	int len;
};
