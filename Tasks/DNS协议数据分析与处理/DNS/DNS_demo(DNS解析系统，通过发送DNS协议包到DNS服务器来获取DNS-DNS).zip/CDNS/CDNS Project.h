// CDNS Project.h : main header file for the CDNS PROJECT application
//

#if !defined(AFX_CDNSPROJECT_H__0B5BF71D_B98B_4459_80F9_C8EF95B5CF81__INCLUDED_)
#define AFX_CDNSPROJECT_H__0B5BF71D_B98B_4459_80F9_C8EF95B5CF81__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CCDNSProjectApp:
// See CDNS Project.cpp for the implementation of this class
//

class CCDNSProjectApp : public CWinApp
{
public:
	CCDNSProjectApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CCDNSProjectApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CCDNSProjectApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CDNSPROJECT_H__0B5BF71D_B98B_4459_80F9_C8EF95B5CF81__INCLUDED_)
