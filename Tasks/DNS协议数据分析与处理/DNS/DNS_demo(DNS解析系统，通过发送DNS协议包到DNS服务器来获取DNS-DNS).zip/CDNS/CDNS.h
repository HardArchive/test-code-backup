// CDNS.h : header file
//

#ifndef _CDNS_H
#define _CDNS_H

/////////////////////////////////////////////////////////////////////////////
// CDNS definitions

class CDNS
{
public:
	CDNS(); 
	CString     GetHostname() { return inHost; }
	BOOL        DoDNSLookup();
	CString     GetIPAt(int number);
	CString     GetHostAt(int number);
	int         GetNumberOfHosts() { return numHosts; }
	int         GetNumberOfIP() { return numIPs; }
	void        SetHostname(CString hostname) { inHost = hostname; }

protected:
	CString      inHost;
	int          numHosts;
	int          numIPs;
	CStringArray outHosts;
	CStringArray outIPs;
};

#endif