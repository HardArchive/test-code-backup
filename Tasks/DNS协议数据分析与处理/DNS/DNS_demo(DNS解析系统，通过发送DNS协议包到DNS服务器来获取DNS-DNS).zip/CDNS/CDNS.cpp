// CDNS.cpp : implementation file
//
// Revisions:
//
// 22nd May 2005:
// Initial release
//

#include "stdafx.h"
#include "CDNS.h"

#include <winsock.h>

/////////////////////////////////////////////////////////////////////////////
// CDNS class



CDNS::CDNS() 
{
	numIPs = -1;
	numHosts = -1;
}



// Perform the DNS lookup
//
BOOL CDNS::DoDNSLookup()
{
	// Set the number of found IPs and hostnames to 0 initially
	numIPs = -1;
	numHosts = -1;

	// Define host and socket structures
	WSADATA sockData;                           
	hostent *dnsInfo;                     

	if(WSAStartup(0x0101, &sockData) != 0)
	{
		// Starting up failed, cleanup and return FALSE
  		WSACleanup(); 

		return FALSE;
	}

	// Attempt to lookup the hostname
	dnsInfo = gethostbyname(inHost);

	if(!dnsInfo)
	{
		// No data was returned, cleanup and return FALSE
		WSACleanup();

		return FALSE;
	}

	// Clear the output buffers
	outIPs.RemoveAll();
	outHosts.RemoveAll();

	// Loop through all IP addresses
	for(int i = 0; dnsInfo->h_addr_list[i]; i++)
	{
		// Add them to the buffer
		outIPs.Add(inet_ntoa(*((struct in_addr *)dnsInfo->h_addr_list[i])));

		// Increment the number found
		numIPs++;
	}

	// Other domain names found
	if(dnsInfo->h_aliases[0])
	{
		// Loop through all the other domains
   	 	for(i = 0; dnsInfo->h_aliases[i]; i++)
		{
			// Add them to the buffer
			outHosts.Add(dnsInfo->h_aliases[i]);
			
			// Increment the number found
			numHosts++;
		}
	}

	// Cleanup
	WSACleanup();

	// It succeeded, return TRUE
	return TRUE;
}



// Retrieve a specific hostname
//
CString CDNS::GetHostAt(int number)
{
	if (number <= numHosts)
		return outHosts.GetAt(number);
	else
		return "";
}



// Retrieve a specific IP
//
CString CDNS::GetIPAt(int number)
{
	if (number <= numIPs)
		return outIPs.GetAt(number);
	else
		return "";
}